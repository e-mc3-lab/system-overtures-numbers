/* ======================================================
 * JFreeChart : a chart library for the Java(tm) platform
 * ======================================================
 *
 * (C) Copyright 2000-present, by David Gilbert and Contributors.
 *
 * Project Info:  https://www.jfree.org/jfreechart/index.html
 *
 * This library is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation; either version 2.1 of the License, or
 * (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
 * or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public
 * License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301,
 * USA.
 *
 * [Oracle and Java are registered trademarks of Oracle and/or its affiliates. 
 * Other names may be trademarks of their respective owners.]
 *
 * -------------------------------
 * StandardXYItemRendererTest.java
 * -------------------------------
 * (C) Copyright 2003-present, by David Gilbert and Contributors.
 *
 * Original Author:  David Gilbert;
 * Contributor(s):   AIDE.
 */

package org.jfree.chart.demo;

import java.awt.Color;
import java.awt.Font;
import java.awt.GradientPaint;
import javax.swing.JPanel;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.StandardChartTheme;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.StandardXYItemRenderer;
import org.jfree.chart.renderer.xy.XYItemRenderer;
import org.jfree.chart.renderer.xy.XYLineAndShapeRenderer;
import org.jfree.chart.ui.ApplicationFrame;
import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;
import org.junit.jupiter.api.Test;

/**
 * Tests for the {@link StandardXYItemRenderer} class.
 */
public class StandardXYItemDemo extends ApplicationFrame {
	
	private static final long serialVersionUID = -1506640393061901314L;

	public StandardXYItemDemo(String title) 
    {
		super(title); setContentPane(cr�erPanneau()); // AIDE.
	}
	
    @Test
    public XYPlot getTra�ageDroites() 
    {
    	XYSeriesCollection ds = new XYSeriesCollection();
        XYSeries s1 = new XYSeries("10^");
        s1.add(-1, 0.3);
        s1.add(0, 1.0);
        s1.add(1, 2.1);
        s1.add(2, 3.1);
        s1.add(3, 6.1);
        ds.addSeries(s1);
        XYSeries s2 = new XYSeries("S2");
        s2.add(1, 1.2);
        s2.add(2, 3.1);        
        ds.addSeries(s2);
        XYSeries s3 = new XYSeries("S3");
        s3.add(1, 1.3);
        ds.addSeries(s3); 
        
        StandardChartTheme sct = new StandardChartTheme("Noir", false);
        sct.setLegendItemPaint(Color.black);
        sct.setAxisLabelPaint(Color.black);
        sct.setTickLabelPaint(Color.black);
        ChartFactory.setChartTheme(sct);           
        
        JFreeChart chart = ChartFactory.createXYLineChart("Titre", "X", "Y",
              ds, PlotOrientation.VERTICAL, true, true, false);
        
        chart.setBackgroundPaint(Color.white);
        XYPlot plot = (XYPlot) chart.getPlot();
        plot.setBackgroundPaint(Color.white);        
        plot.setDomainGridlinePaint(Color.gray);
        plot.setRangeGridlinePaint(Color.gray);    
        
        XYItemRenderer ryx = plot.getRenderer();
        if (ryx instanceof XYLineAndShapeRenderer) 
        {
            XYLineAndShapeRenderer renderer = (XYLineAndShapeRenderer) ryx;
            renderer.setDefaultShapesVisible(true); // Dessine des points:
            renderer.setDefaultShapesFilled(true);
            renderer.setDrawSeriesLineAsPath(true);
            renderer.setSeriesPaint(0, Color.blue);
            renderer.setSeriesPaint(1, Color.green);
            renderer.setSeriesPaint(2, Color.orange);
        }               
        
        plot.setQuadrantPaint(0, new GradientPaint(1.0f, 2.0f, Color.BLUE,
            3.0f, 4.0f, new Color(240, 248, 250)));
        Font DEFAULT_TICK_LABEL_FONT = new Font("SansSerif", Font.PLAIN, 13);
        ValueAxis axis = plot.getDomainAxis(); // X
        axis.setTickLabelFont(DEFAULT_TICK_LABEL_FONT);
        axis.setAutoTickUnitSelection(false); 
        axis = plot.getRangeAxis(); // Y
        axis.setTickLabelFont(DEFAULT_TICK_LABEL_FONT);
        axis.setAutoTickUnitSelection(false);    
        return plot;
    }

    /**
     * AIDE.
     */
    JPanel cr�erPanneau() 
    {   
    	JFreeChart jfc = null; try 
		{
    		XYPlot tdXY = getTra�ageDroites();	            
	        jfc = new JFreeChart(getTitle(), JFreeChart.DEFAULT_TITLE_FONT,
	           tdXY, true/*L�gende*/); 		        
	    } catch (Exception ex) { ex.printStackTrace(); } 
        return new ChartPanel(jfc);
    }    

    public static void main(String[] args) 
    {
        StandardXYItemDemo demo = new StandardXYItemDemo("Essai"); 
        demo.pack(); demo.setLocationRelativeTo(null); 
        demo.setVisible(true);
    }    
}