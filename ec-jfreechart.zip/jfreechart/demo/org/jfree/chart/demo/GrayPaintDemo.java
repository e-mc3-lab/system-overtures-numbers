/* ======================================================
 * JFreeChart : a chart library for the Java(tm) platform
 * ======================================================
 *
 * (C) Copyright 2000-present, by David Gilbert and Contributors.
 *
 * Project Info:  https://www.jfree.org/jfreechart/index.html
 *
 * This library is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation; either version 2.1 of the License, or
 * (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
 * or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public
 * License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301,
 * USA.
 *
 * [Oracle and Java are registered trademarks of Oracle and/or its affiliates. 
 * Other names may be trademarks of their respective owners.]
 *
 * -------------------
 * GrayPaintScale.java
 * -------------------
 * (C) Copyright 2006-present, by David Gilbert.
 *
 * Original Author:  David Gilbert;
 * Contributor(s):   -;
 */
package org.jfree.chart.demo;

import static org.junit.jupiter.api.Assertions.fail;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Paint;
import java.awt.image.BufferedImage;
import java.io.Serializable;
import javax.swing.JPanel;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.HashUtils;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.renderer.PaintScale;
import org.jfree.chart.ui.ApplicationFrame;
import org.jfree.chart.util.PublicCloneable;
import org.junit.jupiter.api.Test;

/**
 * A paint scale that returns shades of gray.
 */
public class GrayPaintDemo extends ApplicationFrame 
        implements PaintScale, PublicCloneable, Serializable {

    /** The lower bound. */
    private double lowerBound;

    /** The upper bound. */
    private double upperBound;

    /**
     * The alpha transparency (0-255).
     */
    private int alpha;

    /**
     * Creates a new {@code GrayPaintScale} instance with default values.
     */
    public GrayPaintDemo(String titre) 
    {
    	super(titre);
        this.GrayPaintDemo(0.0, 1.0); setContentPane(cr�erPanneau()); // AIDE
    }

    /**
     * Creates a new paint scale for values in the specified range.
     *
     * @param lowerBound  the lower bound.
     * @param upperBound  the upper bound.
     *
     * @throws IllegalArgumentException if {@code lowerBound} is not
     *       less than {@code upperBound}.
     */
    private void GrayPaintDemo(double lowerBound, double upperBound) {
        this.GrayPaintDemo(lowerBound, upperBound, 255);
    }

    /**
     * Creates a new paint scale for values in the specified range.
     *
     * @param lowerBound  the lower bound.
     * @param upperBound  the upper bound.
     * @param alpha  the alpha transparency (0-255).
     *
     * @throws IllegalArgumentException if {@code lowerBound} is not
     *       less than {@code upperBound}, or {@code alpha} is not in
     *       the range 0 to 255.
     */
    private void GrayPaintDemo(double lowerBound, double upperBound, int alpha) {
        if (lowerBound >= upperBound) {
            throw new IllegalArgumentException(
                    "Requires lowerBound < upperBound.");
        }
        if (alpha < 0 || alpha > 255) {
            throw new IllegalArgumentException(
                    "Requires alpha in the range 0 to 255.");

        }
        this.lowerBound = lowerBound;
        this.upperBound = upperBound;
        this.alpha = alpha;
    }

    /**
     * Returns the lower bound.
     *
     * @return The lower bound.
     *
     * @see #getUpperBound()
     */
    @Override
    public double getLowerBound() {
        return this.lowerBound;
    }

    /**
     * Returns the upper bound.
     *
     * @return The upper bound.
     *
     * @see #getLowerBound()
     */
    @Override
    public double getUpperBound() { return this.upperBound; }

    /**
     * Returns the alpha transparency that was specified in the constructor.
     * 
     * @return The alpha transparency (in the range 0 to 255).
     */
    public int getAlpha() { return this.alpha; }

    /**
     * Returns a paint for the specified value.
     *
     * @param value  the value (must be within the range specified by the
     *         lower and upper bounds for the scale).
     *
     * @return A paint for the specified value.
     */
    @Override @Test
    public Paint getPaint(double value) {
        double v = Math.max(value, this.lowerBound);
        v = Math.min(v, this.upperBound);
        int g = (int) ((v - this.lowerBound) / (this.upperBound
                - this.lowerBound) * 255.0);
        // FIXME:  it probably makes sense to allocate an array of 256 Colors
        // and lazily populate this array...
        return new Color(g, g, g, this.alpha);
    }

    /**
     * Tests this {@code GrayPaintScale} instance for equality with an
     * arbitrary object.  This method returns {@code true} if and only
     * if:
     * <ul>
     * <li>{@code obj} is not {@code null};</li>
     * <li>{@code obj} is an instance of {@code GrayPaintScale};</li>
     * </ul>
     *
     * @param obj  the object ({@code null} permitted).
     *
     * @return A boolean.
     */
    @Override @Test
    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof GrayPaintDemo)) {
            return false;
        }
        GrayPaintDemo that = (GrayPaintDemo) obj;
        if (this.lowerBound != that.lowerBound) {
            return false;
        }
        if (this.upperBound != that.upperBound) {
            return false;
        }
        if (this.alpha != that.alpha) {
            return false;
        }
        return true;
    }

    /**
     * Returns a hash code for this instance.
     *
     * @return A hash code.
     */
    @Override
    public int hashCode() {
        int hash = 7;
        hash = HashUtils.hashCode(hash, this.lowerBound);
        hash = HashUtils.hashCode(hash, this.upperBound);
        hash = 43 * hash + this.alpha; return hash;
    }

    /**
     * Returns a clone of this {@code GrayPaintScale} instance.
     *
     * @return A clone.
     *
     * @throws CloneNotSupportedException if there is a problem cloning this
     *     instance.
     */
    @Override
    public Object clone() throws CloneNotSupportedException {
        return super.clone();
    }
        
    /**
     * AIDE.
     */
    public JPanel cr�erPanneau() 
    {   
    	JFreeChart jfc = null; try 
		{
		} catch (Exception ex) { ex.printStackTrace(); } 
        try {
            BufferedImage image = new BufferedImage(200 , 100,
                    BufferedImage.TYPE_INT_RGB);
            Graphics2D g2 = image.createGraphics();
            g2.dispose();
        } catch (Exception e) {
            fail("No exception should be thrown.");
        }    	    	
        return new ChartPanel(jfc);
    }       
}