//package ;

import org.aide.data.Fichier;
import java.io.File;
import static org.aide.data.Constantes.ESPACE;
import static org.aide.data.Constantes.NL;

public class _Cr�ationClasses
{ 
    public static void main(String[] args)
    {
        String contenu = "package objets;" + NL
            + NL
            + "public abstract class %s extends Info {" + NL
            + NL + NL
            + "}";
        
        final String DOSSIER_INFO = "./info/", SUFX_JAVA = ".java";
        final String DOSSIER_OBJETS = DOSSIER_INFO + "objets/";
        final String CHEMIN_MOTS_TXT = DOSSIER_INFO + "mots.txt";
                
        Fichier fichMots = new Fichier(CHEMIN_MOTS_TXT);
        fichMots.ouvrirLecture();
        String texte = fichMots.lire(true); fichMots.fermer();
        String[] listeMots = texte.split(ESPACE + "|" + NL);
        Fichier fichClasse = null; String chemNomFichier;
        for (String mot: listeMots)
        {
            if ( ! mot.trim().isEmpty())
            {
                chemNomFichier = DOSSIER_OBJETS + mot + SUFX_JAVA;         
                File fich = new File(chemNomFichier);
                if (fich.exists()){ fich.delete(); }
                fichClasse = new Fichier(chemNomFichier);
                fichClasse.ouvrir�criture();
                fichClasse.�crire(String.format(contenu, mot), false);
                fichClasse.fermer();
            }
        } 
    }
}