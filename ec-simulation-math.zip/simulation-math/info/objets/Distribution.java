package objets;

public abstract class Distribution extends Info {


}