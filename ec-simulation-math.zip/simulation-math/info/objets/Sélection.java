package objets;

public abstract class S�lection extends Info {


}