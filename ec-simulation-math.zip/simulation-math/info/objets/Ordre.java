package objets;

public abstract class Ordre extends Info {


}