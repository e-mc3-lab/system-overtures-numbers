package objets;

public abstract class Appartenance extends Info {


}