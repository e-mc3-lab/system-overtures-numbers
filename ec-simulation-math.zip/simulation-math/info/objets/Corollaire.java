package objets;

public abstract class Corollaire extends Info {


}