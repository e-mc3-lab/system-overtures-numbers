package objets;

public abstract class Animation extends Info {


}