package objets;

public abstract class Tactique extends Info {


}