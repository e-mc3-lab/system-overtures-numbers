package objets;

public abstract class Orientation extends Info {


}