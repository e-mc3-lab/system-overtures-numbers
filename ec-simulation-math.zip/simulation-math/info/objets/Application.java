package objets;

public abstract class Application extends Info {


}