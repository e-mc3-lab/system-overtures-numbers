package objets;

public abstract class Association extends Info {


}