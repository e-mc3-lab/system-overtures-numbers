package objets;

public abstract class Infinit� extends Info {


}