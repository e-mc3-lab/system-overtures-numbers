package objets;

public abstract class Dimension extends Info {


}