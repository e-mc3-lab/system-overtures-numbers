package objets;

public abstract class Exemple extends Info {


}