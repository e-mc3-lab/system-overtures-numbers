package objets;

public abstract class Division extends Info {


}