package objets;

public abstract class Formule extends Info {


}