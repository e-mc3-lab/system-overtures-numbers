package objets;

public abstract class Connexion extends Info {


}