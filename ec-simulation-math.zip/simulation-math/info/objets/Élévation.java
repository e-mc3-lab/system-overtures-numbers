package objets;

public abstract class �l�vation extends Info {


}