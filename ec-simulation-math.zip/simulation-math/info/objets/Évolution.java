package objets;

public abstract class �volution extends Info {


}