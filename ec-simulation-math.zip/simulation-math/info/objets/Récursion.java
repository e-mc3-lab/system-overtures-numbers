package objets;

public abstract class R�cursion extends Info {


}