package objets;

public abstract class Transition extends Info {


}