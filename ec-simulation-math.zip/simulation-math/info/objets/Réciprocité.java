package objets;

public abstract class R�ciprocit� extends Info {


}