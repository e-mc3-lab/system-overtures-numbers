package objets;

public abstract class Fr�quence extends Info {


}