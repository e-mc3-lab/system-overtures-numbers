package objets;

public abstract class H�ritage extends Info {


}