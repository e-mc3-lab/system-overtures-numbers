package objets;

public abstract class Axiome extends Info {


}