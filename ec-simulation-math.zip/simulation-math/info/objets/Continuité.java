package objets;

public abstract class Continuit� extends Info {


}