package objets;

public abstract class Induction extends Info {


}