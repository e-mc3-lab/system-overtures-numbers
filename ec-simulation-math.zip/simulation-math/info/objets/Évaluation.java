package objets;

public abstract class �valuation extends Info {


}