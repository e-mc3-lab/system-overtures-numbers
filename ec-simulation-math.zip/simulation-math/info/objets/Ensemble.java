package objets;

public abstract class Ensemble extends Info {


}