package objets;

public abstract class Image extends Info {


}