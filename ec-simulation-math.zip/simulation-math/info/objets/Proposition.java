package objets;

public abstract class Proposition extends Info {


}