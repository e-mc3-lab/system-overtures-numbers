package objets;

public abstract class Hybridation extends Info {


}