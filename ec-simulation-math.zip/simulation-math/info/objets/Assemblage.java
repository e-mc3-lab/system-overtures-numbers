package objets;

public abstract class Assemblage extends Info {


}