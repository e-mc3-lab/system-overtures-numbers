package objets;

public abstract class P�riode extends Info {


}