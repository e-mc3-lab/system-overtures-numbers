package objets;

public abstract class Annulation extends Info {


}