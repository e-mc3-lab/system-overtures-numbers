package objets;

public abstract class �galit� extends Info {


}