package objets;

public abstract class D�duction extends Info {


}