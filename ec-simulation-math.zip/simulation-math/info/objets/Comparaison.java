package objets;

public abstract class Comparaison extends Info {


}