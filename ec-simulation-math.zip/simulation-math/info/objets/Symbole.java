package objets;

public abstract class Symbole extends Info {


}