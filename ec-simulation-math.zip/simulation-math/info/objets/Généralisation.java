package objets;

public abstract class G�n�ralisation extends Info {


}