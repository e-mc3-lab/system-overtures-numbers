package objets;

public abstract class Compl�tude extends Info {


}