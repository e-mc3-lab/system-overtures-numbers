package objets;

public abstract class Neutralit� extends Info {


}