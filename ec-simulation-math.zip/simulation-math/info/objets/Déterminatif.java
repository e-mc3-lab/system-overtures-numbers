package objets;

public abstract class D�terminatif extends Info {


}