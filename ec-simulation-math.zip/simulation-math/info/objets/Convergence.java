package objets;

public abstract class Convergence extends Info {


}