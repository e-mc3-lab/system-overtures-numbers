package objets;

public abstract class R�gle extends Info {


}