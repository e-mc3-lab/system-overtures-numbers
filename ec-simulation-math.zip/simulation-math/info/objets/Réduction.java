package objets;

public abstract class R�duction extends Info {


}