package objets;

public abstract class M�moire extends Info {


}