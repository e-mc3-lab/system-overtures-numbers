package objets;

public abstract class D�pendance extends Info {


}