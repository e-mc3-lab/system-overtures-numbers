package objets;

public abstract class Synonyme extends Info {


}