package objets;

public abstract class Contraire extends Info {


}