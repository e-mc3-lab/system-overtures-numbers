package objets;

public abstract class Probabilit� extends Info {


}