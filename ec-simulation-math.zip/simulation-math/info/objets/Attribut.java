package objets;

public abstract class Attribut extends Info {


}