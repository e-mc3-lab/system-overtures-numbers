package objets;

public abstract class Quantit� extends Info {


}