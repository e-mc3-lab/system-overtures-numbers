package objets;

public abstract class Ajustement extends Info {


}