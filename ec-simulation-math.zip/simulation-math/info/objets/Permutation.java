package objets;

public abstract class Permutation extends Info {


}