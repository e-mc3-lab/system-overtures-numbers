package objets;

public abstract class Stabilit� extends Info {


}