package objets;

public abstract class Sp�cialisation extends Info {


}