package objets;

public abstract class D�signation extends Info {


}