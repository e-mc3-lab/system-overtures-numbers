package objets;

public abstract class Synth�se extends Info {


}