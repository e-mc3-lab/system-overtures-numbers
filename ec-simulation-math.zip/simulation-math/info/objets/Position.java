package objets;

public abstract class Position extends Info {


}