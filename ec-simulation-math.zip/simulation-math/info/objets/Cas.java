package objets;

public abstract class Cas extends Info {


}