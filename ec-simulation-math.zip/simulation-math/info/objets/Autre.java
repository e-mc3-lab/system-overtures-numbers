package objets;

public abstract class Autre extends Info {


}