package objets;

public abstract class Factorisation extends Info {


}