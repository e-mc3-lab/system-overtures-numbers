package objets;

public abstract class �quation extends Info {


}