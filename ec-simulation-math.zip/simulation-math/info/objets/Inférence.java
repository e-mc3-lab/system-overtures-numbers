package objets;

public abstract class Inf�rence extends Info {


}