package objets;

public abstract class Extraction extends Info {


}