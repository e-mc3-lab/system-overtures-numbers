package objets;

public abstract class Conversion extends Info {


}