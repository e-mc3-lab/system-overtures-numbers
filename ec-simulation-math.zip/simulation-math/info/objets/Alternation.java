package objets;

public abstract class Alternation extends Info {


}