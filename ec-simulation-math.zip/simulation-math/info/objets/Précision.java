package objets;

public abstract class Pr�cision extends Info {


}