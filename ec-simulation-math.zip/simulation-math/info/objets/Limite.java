package objets;

public abstract class Limite extends Info {


}