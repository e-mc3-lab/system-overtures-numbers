package objets;

public abstract class Th�or�me extends Info {


}