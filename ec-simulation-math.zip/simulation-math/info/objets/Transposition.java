package objets;

public abstract class Transposition extends Info {


}