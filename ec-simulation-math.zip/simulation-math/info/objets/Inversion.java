package objets;

public abstract class Inversion extends Info {


}