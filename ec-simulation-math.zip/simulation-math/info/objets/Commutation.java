package objets;

public abstract class Commutation extends Info {


}