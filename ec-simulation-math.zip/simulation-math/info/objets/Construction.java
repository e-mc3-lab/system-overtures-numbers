package objets;

public abstract class Construction extends Info {


}