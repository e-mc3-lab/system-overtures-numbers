package objets;

public abstract class Abstraction extends Info {


}