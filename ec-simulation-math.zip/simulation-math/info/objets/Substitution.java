package objets;

public abstract class Substitution extends Info {


}