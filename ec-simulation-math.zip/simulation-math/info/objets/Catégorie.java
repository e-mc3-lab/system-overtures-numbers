package objets;

public abstract class Cat�gorie extends Info {


}