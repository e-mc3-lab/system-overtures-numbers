package objets;

public abstract class Exp�rience extends Info {


}