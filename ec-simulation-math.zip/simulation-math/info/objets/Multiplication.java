package objets;

public abstract class Multiplication extends Info {


}