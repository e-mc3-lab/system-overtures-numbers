package objets;

public abstract class Clarification extends Info {


}