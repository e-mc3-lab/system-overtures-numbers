package objets;

public abstract class Base extends Info {


}