package objets;

public abstract class Structure extends Info {


}