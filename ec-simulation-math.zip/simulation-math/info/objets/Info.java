package objets;
import org.aide.AFaire;

@AFaire(c="Ajouter des listes pour traiter les cas au fur et � mesure.")
public class Info 
{
	

}
