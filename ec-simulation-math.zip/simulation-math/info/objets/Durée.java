package objets;

public abstract class Dur�e extends Info {


}