package objets;

public abstract class Identit� extends Info {


}