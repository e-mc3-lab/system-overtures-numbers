package objets;

public abstract class Variable extends Info {


}