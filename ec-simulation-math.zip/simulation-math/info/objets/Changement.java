package objets;

public abstract class Changement extends Info {


}