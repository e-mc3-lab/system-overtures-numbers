package objets;

public abstract class R�le extends Info {


}