package objets;

public abstract class Combinaison extends Info {


}