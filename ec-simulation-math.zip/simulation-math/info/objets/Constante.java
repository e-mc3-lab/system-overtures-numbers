package objets;

public abstract class Constante extends Info {


}