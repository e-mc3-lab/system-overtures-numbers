package objets;

public abstract class Lemme extends Info {


}