package objets;

public abstract class Anticipation extends Info {


}