package objets;

public abstract class V�rit� extends Info {


}