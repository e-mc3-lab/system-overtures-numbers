package objets;

public abstract class Projection extends Info {


}