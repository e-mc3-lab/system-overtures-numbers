package objets;

public abstract class Nominatif extends Info {


}