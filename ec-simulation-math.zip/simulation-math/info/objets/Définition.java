package objets;

public abstract class D�finition extends Info {


}