package objets;

public abstract class Observation extends Info {


}