package objets;

public abstract class Hypoth�se extends Info {


}