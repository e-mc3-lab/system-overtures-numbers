package objets;

public abstract class Calcul extends Info {


}