package objets;

public abstract class Mesure extends Info {


}