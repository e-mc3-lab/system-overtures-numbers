package objets;

public abstract class Hasard extends Info {


}