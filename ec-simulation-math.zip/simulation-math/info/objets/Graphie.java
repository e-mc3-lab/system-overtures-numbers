package objets;

public abstract class Graphie extends Info {


}