package objets;

public abstract class R�solution extends Info {


}