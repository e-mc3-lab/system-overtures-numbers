package objets;

public abstract class Affinement extends Info {


}