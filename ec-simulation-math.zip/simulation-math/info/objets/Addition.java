package objets;

public abstract class Addition extends Info {


}