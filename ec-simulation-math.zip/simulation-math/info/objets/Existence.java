package objets;

public abstract class Existence extends Info {


}