package objets;

public abstract class Action extends Info {

}
