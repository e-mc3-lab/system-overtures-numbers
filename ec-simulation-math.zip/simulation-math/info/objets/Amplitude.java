package objets;

public abstract class Amplitude extends Info {


}