
AIDE: Advanced Integrated Development Environment. SCLE-CSES.

To note that the files of this folder are in a separated archive,
because of a github constraint which limits the size per file to 25 MB.
Deploy them in ~/proj/ec/simulation-math.

The utility programs written in Java have been compiled with Eclipse (.org),
which is free. Their execution is done in this software, to see the results
in the console, and eventually be able to stop the process. To include the
project, do File, Import... Existing.

License: CC BY-SA at creativecommons.org/share-your-work/cclicenses/.
