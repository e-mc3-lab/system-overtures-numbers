package org.aide.lutil;

import java.io.File;
import java.math.BigDecimal;
import java.math.MathContext;
import org.aide.Console;
import org.aide.data.Constantes;
import org.aide.data.EnumConst;
import org.aide.data.Fichier;
import org.aide.data.Nombre;


/**
 * @author SCLE-CSES. Theorem: 10.30|20FRM. CC BY-SA.
 */
public class Experience
{
    protected final int Z�RO = Constantes.Z�RO,
        UN     = Constantes.UN,
        DEUX   = Constantes.DEUX,
        TROIS  = Constantes.TROIS,
        QUATRE = Constantes.QUATRE,
        CINQ   = Constantes.CINQ,
        HUIT   = Constantes.HUIT,
        DIX    = Constantes.DIX,
        CENT   = Constantes.CENT,
        MILLE  = Constantes.MILLE; // ...
            
    protected final Nombre Nb0 = new Nombre(BigDecimal.ZERO);
    protected final Nombre Nb1 = new Nombre(BigDecimal.ONE);
    protected final Nombre Nb2 = new Nombre(BigDecimal.TWO);
    protected final Nombre Nb3 = new Nombre(TROIS);
    protected final Nombre Nb4 = new Nombre(QUATRE);
    protected final Nombre Nb5 = new Nombre(CINQ);   
    protected final Nombre Nb6 = new Nombre(6);
    protected final Nombre Nb7 = new Nombre(7);
    protected final Nombre Nb8 = new Nombre(8);
    protected final Nombre Nb130 = new Nombre(130);
    
    protected final Nombre N2e13 = Nb2.expo(13);
    protected final static MathContext MC = MathContext.DECIMAL128;
    protected final Nombre RC1d2  = new Nombre(new BigDecimal((double)1/DEUX).sqrt(MC));
    protected final Nombre RC1d3  = new Nombre(new BigDecimal((double)1/TROIS).sqrt(MC));
    protected final Nombre RC1d5  = new Nombre(new BigDecimal((double)1/CINQ).sqrt(MC));
    protected final Nombre RC1d6  = new Nombre(new BigDecimal((double)1/6).sqrt(MC));
    protected final Nombre RC1d7  = new Nombre(new BigDecimal((double)1/7).sqrt(MC));
    protected final Nombre RC1d8  = new Nombre(new BigDecimal((double)1/HUIT).sqrt(MC));
    protected final Nombre RC1d10 = new Nombre(new BigDecimal((double)1/DIX).sqrt(MC));
    protected final Nombre RC1d11 = new Nombre(new BigDecimal((double)1/11).sqrt(MC));
    protected final Nombre RC1d13 = new Nombre(new BigDecimal((double)1/13).sqrt(MC));                     
    
    protected class Xi
    {
        public Nombre x; public Xi(Nombre n){ this.x = n; }
    }

    protected final char VIRGULE = Constantes.VIRGULE;
    protected final String VIRGULE_ESPACE = ", ";
    
    public static final String DOSSIER_DONN�ES = "./data/";
    
    // Une abr�viation de Fichiers de Donn�es.
    protected enum FD
    {
        NOMBRES_PREMIERS, NOMBRES_IMPAIRS_DIV_1ER, V�RIF_RAPIDIT�_1ER, 
        NOMBRES_1ER1, NOMBRES_1ER2, GROUPES_NOMBRES_1ER, NOMBRES_PAIRS, 
        NOMBRES_PAIRS_DIFF, NOMBRES_IMPAIRS_SOMMES;
        
        private static EnumConst ec = new EnumConst(FD.values(),
            "gb-nombres-premiers.txt", "gb-nombres-impairs-div-1er.txt",
            "gb-v�rif-rapidit�-1er.txt", "gb-nombres-1er1.txt",
            "gb-nombres-1er2.txt", "gb-groupes-nombres-1er.txt",
            "gb-nombres-pairs.txt", "gb-nombres-pairs-diff.txt",
            "gb-nombres-impairs-sommes.txt");

        public static String getNom(FD f){
            return (String)ec.getCl�(f.ordinal());
        }
    }

    protected final int BLOC_NOMBRES = 3600011; 

    private Fichier fichier = null;

    protected Fichier getFichier(){ return this.fichier; }
    
    protected boolean pasN�cessaireDeCr�er(String nf)
    {
        Fichier f = this.fichier;
        if ((f != null) && f.existeFEcrit() && (f.getTaille() > MILLE))
        {
            Console.�crire(String.format("Le fichier %s existe d�j�.", nf));
            return true;
        }
        return false;
    }    
        
    /**
     * @pre le chemin doit exister.
     * 
     * @param bSupprimer le fichier si existe d�j�.
     */
    protected void ouvrir(String nomFichier, boolean bSupprimer)
    {
        if (this.fichier == null)
        {
            String cheminNomFichier = DOSSIER_DONN�ES + nomFichier;
            this.fichier = new Fichier(cheminNomFichier);
            if (bSupprimer)
            {
                File fich = new File(cheminNomFichier);
                if (fich.exists()){ fich.delete(); }
            }
            this.fichier = new Fichier(cheminNomFichier);
        }
        this.fichier.ouvrir�criture();
    }    

    protected void fermer()
    {
        if (this.fichier != null){ this.fichier.fermer(); }
    }

    protected void �crireLigne(String format, Object... args)
    {
        if (this.fichier != null){
            this.fichier.�crire(String.format(format, args));
        }
    }

    protected boolean estMultiple(final Nombre n1, /* de */ final Nombre n2)
    {   
        // Synonyme: n1 est compos� de n2.
        if (n1.equals(n2) || n2.equals(Nb1)){ return false; }
        BigDecimal reste = n1.remainder(n2); return reste.equals(Nb0);
    }

    /**
     * Version s�re, mais simple et lente avec des grands nombres.<br>
     * On cherche ((n/2)+1)/Rc(N) nombres impairs et v�rifie si divisent n.
     */
    protected boolean estPremier1(Nombre n, Nombre maxDivN, boolean bAffFact)
    {
        boolean r�sultat = true; Nombre m = Nb3;
        if (this.estMultiple(n, Nb2)){ return false; }
        if (this.estMultiple(n, Nb5)){ return false; } // Miller-Rabin:
        if ( ! n.toBigInteger().isProbablePrime(CENT)){ return false; }
        if (maxDivN.comparer�(Nb0) == Z�RO){ return true; }
        if (bAffFact){ this.�crireLigne(n + "="); }
        while ((m.comparer�(maxDivN) <= Z�RO) && (r�sultat || bAffFact))
        {
            // Parcours s�quentiel.
            if (this.estMultiple(n, m))
            {
                r�sultat = false; if (bAffFact){
                   this.�crireLigne(m + "x" + n.diviser(m));
                }
            }
            m = m.ajouter(Nb2);
        }
        return r�sultat;
    }
}