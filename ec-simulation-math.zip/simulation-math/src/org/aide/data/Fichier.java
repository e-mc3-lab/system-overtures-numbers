package org.aide.data;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import org.aide.nalternative.AidException;
import static org.aide.data.Constantes.HUIT;
import static org.aide.data.Constantes.TROIS;
import static org.aide.data.Constantes.Z�RO;

public class Fichier 
{
    final long KO = 1024; // �AIDE Th�or�me: 10.30|20FRM. CC BY-SA.
    
    final int TAILLE_BLOC_LECTURE = HUIT * (int) KO;
    
    private String chemNomFichier = null;
    private File lecture = null; InputStream inStream = null;
    private FileWriter fWriter = null;

    public Fichier(final String chemFichier){
        this.chemNomFichier = chemFichier;
    }
   
    public boolean ouvrirLecture()
    {
        boolean r�sultat = true; try
        {
            this.lecture = new File(this.chemNomFichier);
            r�sultat = (this.lecture.exists());
            if (r�sultat){
                this.inStream = new FileInputStream(this.lecture);
            }
        } catch (FileNotFoundException ex){
            throw new AidException("Fichier inexistant: " + ex);
        }
        return r�sultat;
    }
    
    public void ouvrir�criture()
    {
        try {
            this.fWriter = new FileWriter(this.chemNomFichier, true);
        } catch (IOException ex){
            throw new AidException("Probl�me ouverture: " + ex);
        }
    }
   
    public void fermer()
    {
        this.lecture = null;
        if (this.inStream != null) try
        {
            this.inStream.close(); this.inStream = null;
        } catch (IOException ex){
            throw new AidException(ex.getCause());
        }
        if (this.fWriter != null) try {
            this.fWriter.close();
        } catch (IOException ex){
            throw new AidException(ex.getCause());
        }
    }

    public String getChemNomFichier(){ return this.chemNomFichier; }
    
    public boolean existeFLect(){
        return (this.lecture != null && this.lecture.exists());
    }

    public boolean existeFEcrit(){
        return new File(this.getChemNomFichier()).exists();
    }    

    public String getMsgFichierInexistant(String nf){
        return "Le fichier " + nf + " n'existe pas.";
    }

    public long getTaille(){
        return (this.fWriter  != null ? 
                (new File(this.chemNomFichier).length()) : 0);
    }

    public void �crire(final String txt){ this.�crire(txt, true); }
    
    public void �crire(final String txt, boolean sautDeLigne)
    {
        try
        {
            final String FL = (sautDeLigne ? "\n": "");
            this.fWriter.write(txt + FL); System.out.print(txt + FL);
        } catch (Exception ex){
            throw new AidException(ex.getCause());
        }
    }
    
    public String lire(boolean bToutLeContenu)
    {
        String r�sultat = null;
        if (this.lecture != null) synchronized(this.lecture)
        {
            try
            {
                byte[] tabCars = null;
                if (bToutLeContenu){
                    tabCars = this.inStream.readAllBytes();
                } else {
                    tabCars = new byte[TAILLE_BLOC_LECTURE];
                    this.inStream.read(tabCars, Z�RO, tabCars.length);
                }
                r�sultat = new String(tabCars);
                
            } catch (IOException ex){ throw new AidException(ex.getCause()); }
        } else {
            throw new AidException("Le fichier doit �tre ouvert avant lecture.");
        }
        return r�sultat;
    }
    
    public String lire(){ return this.lire(false); }
    
    
    public boolean estDerni�reLecture(String bloc)
    {
        return ((bloc.length() < TAILLE_BLOC_LECTURE) ||
                (bloc.charAt(Z�RO) == Z�RO) || (bloc.charAt(TROIS) == Z�RO));
    }
}