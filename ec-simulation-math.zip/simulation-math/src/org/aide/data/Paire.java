package org.aide.data;

public class Paire 
{
    public Double n; public Double max; boolean al�atoire = false;
    
    public Paire(Double n1, Double m){ this(n1, m, false); }    
    
    public Paire(Double n1, Double m, boolean a)
    { 
        this.n = n1; this.max = m; this.al�atoire = a;
    }
}