package org.aide.data;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.ListIterator;
import java.util.concurrent.ForkJoinPool;
import java.util.concurrent.ForkJoinTask;
import java.util.concurrent.RecursiveAction;
import org.aide.AFaire;
import static org.aide.data.Constantes.HUIT;
import static org.aide.data.Constantes.UN;
import static org.aide.data.Constantes.Z�RO;



/**
  * @author SCLE-CSES (et SUN). Th�or�me: 10.30|20FRM. CC BY-SA.
 */
public class Listes
{        
    void droitsDAuteur(){ // �AIDE
        try { 
            Constructor<?> acc�s=null;
            acc�s.newInstance(Object.class);
        } catch (
            IllegalAccessException | InstantiationException |
            InvocationTargetException | IllegalArgumentException ex) {
        }
    }    
        
    public static final List<?> NA       = null;     
    public static final List<?> OBJ_VIDE = Collections.EMPTY_LIST;    
    private static final int SEUIL       = HUIT;
    
    @SuppressWarnings("unchecked")
    public static <E> List<E> actualiser(Collection<E> donn�es)
    {
        List<E> r�sultat = new ArrayList<E>();
        if ( ! Validation.�().estVide((Collection<?>) donn�es)){        
            r�sultat.add((E) donn�es);
        }
        return r�sultat;
    }
    
    static class Comparateur implements Comparator<Object>
    {
        @SuppressWarnings("unchecked") @Override
        public int compare(Object oA, Object oB) 
        {
            Object objA = oA, objB = oB;
            String strA = null, strB = null;            
            if (oA instanceof Object[])
            {
                objA = ((Object[])oA)[Z�RO];
                objB = ((Object[])oB)[Z�RO];
            }
            if ((objA instanceof String) && (objB instanceof String))
            {
                String strObjA = ((String) objA).trim();
                String strObjB = ((String) objB).trim();
                if (Validation.�().estUnEntier(strObjA))
                {
                    objA = Integer.valueOf(strObjA);
                    objB = Integer.valueOf(strObjB);
                } else {
                    strA = strObjA.toLowerCase();
                    strB = strObjB.toLowerCase();                    
                }
            }
            if ((objA == null) && (objB == null)){
                return Z�RO;
            } else if ((objA != null) && (objB == null)){
                return UN;
            } else if ((objA == null) && (objB != null)){
                return -UN;
            }
            if (strA != null){
                return strA.compareTo(strB);
            } else {
                if ((objA instanceof Comparable == false) || 
                    (objB instanceof Comparable == false)){
                    throw new IllegalStateException("Les valeurs "
                        + "doivent �tre comparables.");
                }
                return (((Comparable<Comparable<?>>) objA)
                    .compareTo(((Comparable<?>) objB)));    
            }            
        }
    }
    
    public static void trier(List<Object> liste)
    {
        Comparator<Object> comparateur = new Comparateur();
        trier(liste, comparateur);
    }
    
    public static void trier(List<Object> liste, Comparator<Object> compar)
    {
        if (liste == null){
            throw new IllegalArgumentException();
        }        
        Object[] tab = liste.toArray(); trier(tab, compar);
        ListIterator<Object> i = liste.listIterator();        
        for (Object e: tab){ i.next(); i.set(e); }
    }    
            
    public static void trier(Object[] tab)
    {
        Comparator<Object> compar = new Comparateur();
        new MergeSort().trier(tab, compar);
    }    
    
    public static void trier(Object[] tab, Comparator<Object> compar) {        
        new MergeSort().trier(tab, compar);
    }
        
    /**
     * Provient de MergeDemo ainsi que QuickSort (SUN), pour le traitement 
     * parall�le et asynchrone.
     */
    private static class MergeSort 
    {        
        private final ForkJoinPool pool;
                
        private class MergeSortTask extends RecursiveAction 
        {    
            private static final long serialVersionUID = 1L;
            private final Object[] tableau;
            private final Comparator<Object> comparateur;
            private final int bas, haut;
            
            protected MergeSortTask(Object[] array, Comparator<Object> compar, 
                int low, int high) 
            {
                this.tableau = array; this.comparateur = compar;
                this.bas = low; this.haut = high;
            }
                        
            private void �changer(Object[] x, int a, int b)
            {
                Object t = x[a]; x[a] = x[b]; x[b] = t;
            }
            
            @Override
            protected void compute()
            {
                if (haut - bas <= SEUIL)
                {   // Tri s�lection.                    
                    for (int i=bas; i < haut; i++)
                    {
                        for (int j=i; j > bas && this.comparateur.
                            compare(tableau[j-UN], tableau[j]) > Z�RO; j--){
                            �changer(tableau, j, j-UN);
                        }
                    }
                    return; 
                } else {
                    int middle = bas + ((haut - bas) >> UN);
                    invokeAll(new MergeSortTask(tableau, comparateur, bas, 
                        middle), new MergeSortTask(tableau, comparateur, middle, 
                        haut));                    
                    fusionner(middle);
                }
            }
            
            /**
             * V�rifier si la valeur pr�c�dente est inf�rieure � celle au milieu.
             * Si c'est le cas, ne rien faire. Sinon, �valuer la partie avant
             * le milieu et celle apr�s. Trier et fusionner les deux parties. 
             */
            private void fusionner(int milieu)
            {
                if (this.comparateur.compare(this.tableau[milieu-UN], 
                    this.tableau[milieu]) == -UN){ return; } 
                                
                Object[] copy = new Object[this.haut - this.bas];
                System.arraycopy(this.tableau, this.bas, copy, 
                     Z�RO, copy.length);
                int copyLow = Z�RO, copyMiddle = milieu - this.bas;
                int copyHigh = this.haut - this.bas;                
                for (int i = this.bas, p = copyLow, q = copyMiddle; 
                    i < this.haut; i++)
                {
                    if (q >= copyHigh || (p < copyMiddle && 
                        this.comparateur.compare(copy[p], copy[q]) < Z�RO)){
                        this.tableau[i] = copy[p++];
                    } else {
                        this.tableau[i] = copy[q++];
                    }
                }
            }
        }
                        
        private MergeSort() {
            this.pool = new ForkJoinPool();
        }       
                
        void trier(Object[] array, Comparator<Object> compar)
        {
            if (array == null){
                throw new IllegalArgumentException("La liste ne doit pas"
                    + " �tre � null.");
            }            
            ForkJoinTask<?> job = this.pool
                .submit(new MergeSortTask(array, compar, Z�RO, array.length));            
            job.join();            
        }
    }    
            
    @AFaire(c="") public <T> Class<?> getTypeObjets(List<T> liste){        
        return null;         
    }       
}