package org.aide.data;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Stack;
import static org.aide.data.Constantes.CAR_ESPACE;
import static org.aide.data.Constantes.CAR_MOINS_REGEX;
import static org.aide.data.Constantes.VIDE;
import static org.aide.data.Constantes.Z�RO;

/**
 * @author SCLE-CSES. Th�or�me: 10.30|20FRM. CC BY-SA.
 */
public class Validation 
{
    void droitsDAuteur(){ // �AIDE
        try {
            Constructor<?> acc�s=null; acc�s.newInstance(Object.class);
        } catch (IllegalAccessException | InstantiationException |  
               InvocationTargetException | IllegalArgumentException ex) {
        }
    }
    
    private volatile static Validation instance = null;    
    
    public static Validation �() 
    {
        if (instance == null)
        {
            synchronized (Validation.class){ // Thread safe avec volatile.
                if (instance == null){ // Source: Head First Design Patterns.
                    instance = new Validation();
                }
            }    
        }
        return instance;
    }    
        
    public final String SUFX_JAVA = "java";
    
    public final String MSG_CLASSE_INVALIDE = 
        "Cette m�thode ne peut �tre appel�e que par la classe ";    
              
    public String getNomClasse(String nomFichierJava)
    {
        String r�sultat = nomFichierJava;        
        if (nomFichierJava == null){ return null; }         
        int pos = nomFichierJava.indexOf(SUFX_JAVA);        
        if (pos > Z�RO){
            r�sultat = r�sultat.substring(Z�RO, pos);
        }
        return r�sultat;        
    }      
        
    public boolean estVide(Integer i){
        return (i == null) || i < Z�RO;
    }    
    
    public boolean estVide(Short i){
        return (i == null) || i < Z�RO;
    }
    
    public boolean estVide(char c){
        return (c == Z�RO) || (c == CAR_ESPACE);
    }       
    
    public boolean estVide(Double[] valeurs){
        return (valeurs == null || valeurs.length == Z�RO);
    }
    
    public boolean estVide(String str){
        return (str == null) || str.trim().isEmpty();
    }
    
    /**
     * @param supprimerEspace: si true, @param str sera consid�r� vide s'il ne 
     *        contient que des espaces.
     */
    public boolean estVide(String str, boolean ignorerEspaces)
    {
        if (str == null){ return true; }     
        String txt = str;
        if (ignorerEspaces){ txt = txt.trim(); }     
        return txt.isEmpty();
    }   
        
    public boolean estVide(char[] str){
        return (str == null || str.length == Z�RO) ||
            String.valueOf(str).trim().isEmpty(); 
    }
    
    public boolean estVide(List<?> liste)
    {
        boolean r�sultat = true;
        try {
            r�sultat = (liste == null) || liste.isEmpty();  
        } catch (Exception ex){}
        return r�sultat;
    }
    
    public boolean estVide(Collection<?> liste)
    {
        boolean r�sultat = true;
        try {
            r�sultat = (liste == null) || (liste.size() == Z�RO);  
        } catch (Exception ex){}
        return r�sultat;
    }    
    
    public boolean estVide(Map<?, ?> liste)
    {
        boolean r�sultat = true;
        try {
            r�sultat = (liste == null) || liste.isEmpty();  
        } catch (Exception ex){}
        return r�sultat;
    }    
    
    public boolean estVide(Object[] liste)
    {
        boolean r�sultat = true;
        if ((liste != null) && (liste.length > Z�RO)) try
        {
            for (Object obj: liste)
            {    
                if ((obj == null) ||
                    ((obj instanceof String) &&
                     ((String)obj).isEmpty()))
                {  
                    r�sultat = true; break;
                } else {
                    r�sultat = false;
                }
            }
        } catch (Exception ex){}
        return r�sultat;
    }    
        
    public boolean estVide(Set<?> liste)
    {
        boolean r�sultat = true;
        try {
            r�sultat = (liste == null) || liste.isEmpty();   
        } catch (Exception ex){}
        return r�sultat;
    }    
    
    public boolean estVide(Object obj){
        return estVide(obj, true);
    }
    
    public boolean estVide(Object obj, boolean ignorerEspaces)
    {
        boolean r�sultat = false;
        if (obj instanceof String){
            r�sultat = this.estVide((String)obj, ignorerEspaces);
        } else if (obj instanceof Integer){
            r�sultat = this.estVide((Integer) obj);
        } else if (obj instanceof Object[]){
            r�sultat = this.estVide((Object[]) obj);
        } else if (obj instanceof List){
            r�sultat = this.estVide((List<?>) obj);
        } else if (obj instanceof Map){
            r�sultat = this.estVide((Map<?, ?>) obj);         
        } else if (obj instanceof Short){
            r�sultat = this.estVide((Short) obj);
        } else if (obj instanceof Collection){          
            r�sultat = this.estVide((Collection<?>) obj);
        } else if (obj instanceof Set){
            r�sultat = this.estVide((Set<?>) obj);        
        } else {
            r�sultat = (obj == null);
        }
        return r�sultat;
    }    
    
    public boolean estPileVide(Stack<?> liste)
    {
        boolean r�sultat = true;
        try {
            r�sultat = (liste == null) || liste.isEmpty();
        } catch (Exception ex){}
        return r�sultat;
    } 
            
    public Object getValeur(Object obj)
    {
        if (obj == null){ return Z�RO; } return (Object) obj;
    }
    
    public Comparable<?> getValeur(Class<?> cls, Comparable<?> valeur)
    {
        String nb = String.valueOf(valeur);
        return (Comparable<?>) getValeur(cls, nb);  
    }
        
    public Object getValeur(Class<?> cls, String txt)
    {
        Object r�sultat = null;
        if (cls.equals(Double.class)){
            r�sultat = Double.valueOf(txt);
        } else if (cls.equals(Short.class)){
            r�sultat = Short.valueOf(txt);
        } else if (cls.equals(Integer.class)){
            r�sultat = Integer.valueOf(txt);
        } else if (cls.equals(Long.class)){
            r�sultat = Long.valueOf(txt);                      
        }      
        return r�sultat;
    }   
    
    public int taille(Object[] tab){
        return (tab != null ? tab.length : Z�RO);
    }    
    
    public boolean estUnChiffre(char chiffreEnCaract�re){ 
        return Character.isDigit(chiffreEnCaract�re);
    }
    
    public boolean estUnEntier(String nombre){
        return this.estUnEntier(nombre, false);     
    }
    
    public boolean estUnEntier(Object nombre){
        return (this.estUnEntier(String.valueOf(nombre), false));     
    }    

    /**
     * @param groupeNombre: quand le nombre est s�par� par des '-'.
     */
    public boolean estUnEntier(String nombre, boolean groupeNombre)
    {
        boolean r�sultat = true; final int VINGT = 20;   
        if ((nombre == null) || nombre.isEmpty()){ return false; }
        try 
        {
            if (groupeNombre)
            {
                String[] nombres = nombre.trim().split(CAR_MOINS_REGEX + VIDE);                
                for (String n: nombres)
                {
                    if (n.length() < VINGT){
                        Long.valueOf(n);
                    } else {
                        r�sultat = this.estUnEntierLong(n);                    
                    }
                }
            } else {
                if (nombre.length() < VINGT){
                    Long.valueOf(nombre.trim()); 
                } else {
                    r�sultat = this.estUnEntierLong(nombre);
                }
            }
        } catch (NumberFormatException ex){
            r�sultat = false;
        }
        return r�sultat;
    }
        
    private boolean estUnEntierLong(String nombre)
    {
        boolean r�sultat = true; String tmpNombre = nombre.trim();      
        for (int i=Z�RO; i < tmpNombre.length(); i++)
        {
             if ( ! this.estUnChiffre(tmpNombre.charAt(i)))
             {
                 r�sultat = false; break;
             }
         }
        return r�sultat;
    }
    
    public boolean estUnEntier(Double nombre)
    {
        boolean r�sultat = false;
        if (nombre == null){ return false; }       
        int entier = (int) nombre.doubleValue();
        r�sultat = ((nombre - entier) == Z�RO);
        return r�sultat;
    }                   
}