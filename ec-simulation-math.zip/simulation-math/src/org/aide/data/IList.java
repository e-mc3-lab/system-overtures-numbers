package org.aide.data;

public interface IList 
{
    boolean estModifi�e();
    void setEstModifi�e(boolean b);
    
    int getTailleInitiale();
    void setTailleInitiale(int n);   
}