package org.aide.data;

public final class Constantes {

    public static final int Z�RO = 0, UN = 1, DEUX = 2, TROIS = 3, 
        QUATRE = 4, CINQ = 5, SIX = 6, HUIT = 8, DIX = 10, CENT = 100, 
        MILLE = 1000;
    
    public static final char CAR_VIDE = (char) Z�RO, CAR_ESPACE = ' ',
        �GAL = '=', PLUS = '+', FOIS = 'x',
        VIRGULE = ',', CAR_VIRGULE_REGEX = 0x2C, CAR_MOINS_REGEX = 0x2D;
    
    public static final String VIDE = "", NL = "\n", 
        ESPACE = CAR_ESPACE + VIDE;
}