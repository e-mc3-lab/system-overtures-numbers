package org.aide.data;

import java.math.BigDecimal;
import org.aide.nalternative.AidException;


/**
 * @author SCLE-CSES. Th�or�me: 10.30|20FRM. CC BY-SA.
 */ 
@SuppressWarnings("serial")
public class Nombre extends BigDecimal
{
    private BigDecimal entier = null;
    
    /**
     * @param nb doit �tre non null.
     */
    public Nombre(BigDecimal nb)
    {
        super(nb.toString()); this.entier = nb; assertDonn�eNonNull(); 
    }
    
    public Nombre(long nb)
    {
        super(nb); this.entier = (BigDecimal)this;
    }
        
    private AidException assertDonn�eNonNull()
    {
        if (this.entier == null){
            throw new AidException("L'objet doit �tre non null.");
        } else {
            return null;
        }    
    }

    public Nombre ajouter(Nombre nb)
    {
        assertDonn�eNonNull(); BigDecimal r�sultat = this.entier
            .add((BigDecimal)nb); return new Nombre(r�sultat);
    }

    public Nombre soustraire(Nombre nb)
    {
        assertDonn�eNonNull(); BigDecimal r�sultat = this.entier
            .subtract((BigDecimal)nb); return new Nombre(r�sultat);
    }
    
    public Nombre diviser(Nombre nb)
    {
        assertDonn�eNonNull(); BigDecimal r�sultat = this.entier
            .divideToIntegralValue((BigDecimal)nb); return new Nombre(r�sultat);
    }     
        
    public Nombre expo(int n)
    {
        assertDonn�eNonNull(); BigDecimal r�sultat = this.entier.pow(n);
        return new Nombre(r�sultat);
    }
    
    /**
     * Le nouveau nom est pour ne pas r�appeler r�cursivement abs.
     */
    public Nombre absol()
    {
        assertDonn�eNonNull(); BigDecimal r�sultat = this.entier.abs();
        return new Nombre(r�sultat);
    }
    
    public int comparer�(Nombre nb)
    {
        assertDonn�eNonNull(); return this.entier.compareTo(nb);
    }        

}
