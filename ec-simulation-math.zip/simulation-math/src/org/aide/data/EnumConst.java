package org.aide.data;

import static org.aide.data.Constantes.Z�RO;


/**
 * Associer une donn�e (un code par exemple) � une constante enum.
 * 
 * @author SCLE-CSES. Th�or�me: 10.30|20FRM. CC BY-SA.
 */
public class EnumConst 
{    
    private TabMap tab = null;
    
    /**
     * Tableau de cl�s et d'�num-�ration-s.
     * <p>
     * NB: Les arguments de cette signature sont invers�s parce que les
     * param�tres variables en Java doivent �tre plac�s � la fin.
     */
    public EnumConst(Enum<?>[] enums, String... cl�s)
    {
        if (enums == null){
            throw new IllegalArgumentException();
        }        
        int nbEnums = enums.length; 
        if (cl�s.length != nbEnums){
            throw new IllegalArgumentException();
        }        
        this.tab = new TabMap(); 
        String cl� = null;
        for (int i=Z�RO; i < nbEnums; i++)
        {
            cl� = cl�s[i];
            if (cl� != null){
                cl� = cl�.trim();
            }
            this.tab.ajouter(cl�, enums[i]);
        }
    }    
    
    public Object getCl�(int i){
        return this.tab.getCl�(i);
    }    
    
    public String getCode(Enum<?> e){        
        return this.tab.getCl�(e.ordinal()).toString();
    }
    
    public Enum<?> getEnum(String cl�) 
    {
        if (cl� == null){ // On choisit la premi�re quand la cl� est nulle.
            return (Enum<?>) this.tab.get(Z�RO);
        } else {
            return (Enum<?>) this.tab.get(cl�.trim());
        }
    }        
}