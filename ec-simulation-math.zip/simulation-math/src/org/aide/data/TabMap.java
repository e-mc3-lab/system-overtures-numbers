package org.aide.data;

import java.lang.reflect.Constructor;
import java.util.Comparator;
import java.util.List;
import org.aide.AFaire;
import org.aide.nalternative.AidException;
import static org.aide.data.Constantes.Z�RO;
import static org.aide.data.Constantes.UN;
import static org.aide.data.Constantes.DEUX;
import static org.aide.data.Constantes.CENT;



/**
 * Cette classe est une variante de {@link java.util.Map}.
 * Le tableau interne est agrandi de 100, ou selon la capacit� initiale, 
 * quand il n'y a plus d'espace pour ajouter un objet. C'est aussi 
 * g�n�ralement plus l�ger qu'ArrayList.
 *  
 * @author SCLE-CSES Th�or�me: 10.30|20FRM. CC BY-SA.
 */ @SuppressWarnings("unchecked")
public class TabMap 
{    
    void droitsDAuteur()
    {   // �AIDE 
        try { Constructor<?> acc�s=null; acc�s.newInstance(Object.class);
        } catch (Exception ex) {}
    }
        
    private final int CL� = Z�RO, VALEUR = UN; private Object[][] tab = null;
    private int taille = Z�RO, nbEntr�es = Z�RO, capacit� = CENT;
    private Listes.Comparateur comparCl�s = null; boolean bTri = false;
    public static final TabMap NA = null; 
    private boolean concat�nerAvecValeurExistante = false;
    
    public TabMap()
    { 
        this(CENT); this.comparCl�s = new Listes.Comparateur(); 
    }        
    
    /**
     * @param capacit� initiale, ainsi que la capacit� d'agrandissement.
     */
    public TabMap(int capacit�){ this.initialiser(capacit�); }    
    
    /**
     * @post les cl�s tri�es en tout temps. 
     * NB: la performance donne l'impression d'�tre meilleure quand 
     * les ajouts sont r�partis, et non successifs [n log(n)].
     * 
     * @see TabMap
     */
    public TabMap(boolean concat�nerValeurExist)
    {
        this.initialiser(DEUX*CENT); bTri = true;
        this.comparCl�s = new Listes.Comparateur();        
        this.concat�nerAvecValeurExistante = concat�nerValeurExist;
    }      
    
    private final void initialiser(int c)
    {
        this.taille = c; this.nbEntr�es = Z�RO; this.capacit� = c;
        this.tab = new Object[this.taille][DEUX];     
    }
        
    private void v�rifier(String nomM�thode, int i)
    {
        if ((i < Z�RO) || ((i != Z�RO) && (i >= this.nbEntr�es))){
            throw new AidException(nomM�thode + " " + i);
        }        
    }
    
    /**
     * pre: quand les cl�s sont tri�es, appeler la m�thode ci-apr�s.
     */
    public int getIndex(String cl�)
    {
        int r�sultat = -UN;        
        for (int i=Z�RO; i < this.nbEntr�es; i++)
        {
            if (this.tab[i][CL�] == null){
                break;
            }
            if (this.tab[i][CL�].equals(cl�)){
                r�sultat = i; break;
            }
        }
        return r�sultat;
    }
    
    /**
     * @pre les valeurs dans la liste doivent �tre comparables et bTri vraie.
     * 
     * @param premi�reValeurSup pour les listes (d�j�) tri�es.
     * 
     * @return l'index o� est la cl�; ou celui apr�s une valeur inf�rieure. 
     */
    private int getIndex(String cl�, boolean premi�reValeurSup)
    {
        int bas = Z�RO, milieu = -UN, haut = this.nbEntr�es - UN, cmp;        
        Object cl�Milieu; boolean trouv� = false;        
        while ((bas <= haut) && ! trouv�)
        {   
            // Recherche binaire.
            milieu = (bas + haut) / DEUX;            
            cl�Milieu = this.getCl�(milieu);            
            cmp = this.comparCl�s.compare(cl�Milieu, cl�);            
            if (cmp < Z�RO){
                bas = milieu + UN;
            } else if (cmp > Z�RO){                
                haut = milieu - UN;
            } else {
                trouv� = true;
            }
        } 
        int r�sultat = Z�RO;
        if (trouv�){
            r�sultat = milieu; 
        } else if (premi�reValeurSup){            
            if (bas >= Z�RO){ r�sultat = bas; }
        } else {
            r�sultat = -UN;
        }
        return r�sultat;
    }      
    
    public boolean estVide(){ return (this.nbEntr�es == Z�RO); }
    
    public void vider()
    {
        if (this.nbEntr�es > Z�RO)
        {
            this.tab = null; this.initialiser(this.capacit�);            
        }
    }

    public synchronized Object getCl�(int pos){
        return ((pos >= Z�RO) && (pos < this.nbEntr�es)) ? 
            this.tab[pos][CL�] : null;
    }        
    
    public void setCl�(int pos, String cl�)
    {
        this.v�rifier("setCl�", pos); this.tab[pos][CL�] = cl�;
    }    
        
    public synchronized Object get(String cl�){ return this.get(cl�, Z�RO); }
    
    public synchronized Object get(String cl�, int pos)
    {
        this.v�rifier("get", pos); Object r�sultat = null;        
        if (this.comparCl�s != null)
        {
            int i = this.getIndex(cl�, false);
            if (i >= Z�RO){ r�sultat = this.tab[i][VALEUR]; }
        } else for (int i=pos; i < this.nbEntr�es; i++){
            if (this.tab[i][CL�] == null){ break; }            
            if (this.tab[i][CL�].equals(cl�))
            {
                r�sultat = this.tab[i][VALEUR]; break;
            }
        }            
        return r�sultat;
    }
    
    public synchronized Object get(int pos) 
    {
        this.v�rifier("get", pos); return this.tab[pos][VALEUR]; 
    }
                
    public boolean contient(Object valeur)
    {
        boolean r�sultat = false; Object v�rif = null;        
        for (int i=Z�RO; i < this.nbEntr�es; i++)
        {
            v�rif = this.tab[i][VALEUR];
            if (v�rif != null && v�rif.equals(valeur))
            {
                r�sultat = true; break;
            }
        }
        return r�sultat;
    }    
        
    /**
     * @return Les valeurs (sans les cl�s) dans une table.
     */
    public synchronized Object[] getTable()
    {
        Object[] r�sultat = ((Object[]) new Object[this.nbEntr�es]);        
        for (int i=Z�RO; i < this.nbEntr�es; i++){
            r�sultat[i] = this.tab[i][VALEUR];    
        }
        return r�sultat;
    }    
 
    @AFaire(c = "V�rifier si fonctionne encore, apr�s reconception.")
    public synchronized List<?> getListe() 
    {   
        if (this.nbEntr�es == Z�RO){
            return null;
        } else {
            List<Object> liste = new TabList<>();
            Object[] listeObj = this.getTable();     
            if (listeObj != null) for (Object v: listeObj){
                liste.add(v); // Arrays.asList retourne 
            } // une liste abstraite et l�ve une exception            
            return liste; // en ajoutant un �l�ment.
        }
    }
        
    /**
     * @return les cl�s tri�es dans un tableau de 'String'.
     */
    public synchronized String[] getTabCl�s()
    {
        String[] r�sultat = ((String[]) new Object[this.nbEntr�es]);         
        for (int i=Z�RO; i < this.nbEntr�es; i++){
            r�sultat[i] = (String) (this.tab[i][CL�]);
        }
        return r�sultat;
    }
        
    public synchronized List<String> getCl�s()
    {
        List<String> liste = null;                
        if (this.nbEntr�es == Z�RO){
            return null;
        } else {            
            String[] table = this.getTabCl�s();
            liste = new TabList<String>();
            for (String v: table){
                liste.add(v); // Arrays.asList retourne 
            } // une liste abstraite et l�ve une exception.            
        }
        return liste;
    }
    
    public void set(int pos, String valeur)
    {
        this.v�rifier("set", pos); this.tab[pos][VALEUR] = valeur;
    }
            
    public int taille(){ return this.nbEntr�es; }    
            
    /**
     * @return un tableau de paires [CL�, VALEURS].
     */
    private Object[][] agrandir()
    {
        Object[][] r�sultat = new Object[this.taille][DEUX];
        System.arraycopy(this.tab, Z�RO, r�sultat, Z�RO, this.nbEntr�es);        
        return r�sultat;
    }    
    
    /**
     * Ajouter une valeur, ou remplacer celle existante.
     */
    public Object ajouter(Object c, Object v)
    {    
        String cl� = null;
        if (c == null){ return null; }
        cl� = c.toString();
        int iFin = this.nbEntr�es;            
        int iCl� = (this.bTri ? this.getIndex(cl�, true) : this.getIndex(cl�));                  
        if (this.nbEntr�es >= this.taille)
        { 
            this.taille += this.capacit�; this.tab = this.agrandir();
        }         
        int pos = ((iCl� >= Z�RO) ? iCl�: iFin); // Existe-t-elle ?
        if ((pos < this.taille) && ! cl�.equals(tab[pos][CL�])) 
        {
            Object[][] tabTmp = null;            
            if (this.bTri && (iFin > pos))
            {   // NB: 'arraycopy' est ~O(1), aussi efficace qu'une affectation.
                tabTmp = new Object[this.taille][DEUX]; // Paires de c. & v.
                System.arraycopy(this.tab, Z�RO, tabTmp, Z�RO, pos); // Seg. //1
                System.arraycopy(this.tab, pos, tabTmp, pos+UN, iFin - pos); //2     
            }
            if (tabTmp != null){ this.tab = tabTmp; }
            this.tab[pos][CL�] = cl�; this.tab[pos][VALEUR] = v;    
            this.nbEntr�es++;
        } else {
            String sobj = (this.tab[pos][VALEUR] != null ? 
                   this.tab[pos][VALEUR].toString() : null);
            if (this.concat�nerAvecValeurExistante && (sobj != null)){ 
                this.tab[pos][VALEUR] = sobj + ", " + v;
            } else {
                this.tab[iCl�][UN] = v;    
            }
        } 
        return v;
    }    
    
    /**
     * @pre Les cl�s sont de type entier (Integer). Ajouter � la fin.
     */
    public Object ajouter(Object valeur){ 
        return this.ajouter(this.nbEntr�es, valeur);
    }
    
    public String ins�rer(int i, Object valeur)
    {
        if ((i < Z�RO) || (i > this.nbEntr�es) || (valeur == null)){
            throw new AidException("ins�rer: " + i);
        }                    
        if (this.nbEntr�es >= this.taille){ this.taille += this.capacit�; }        
        Object[][] tabTmp = new Object[this.taille][DEUX];   
        System.arraycopy(this.tab, Z�RO, tabTmp, Z�RO, i);                    
        System.arraycopy(this.tab, i, tabTmp, i+UN, this.nbEntr�es - i);            
        this.tab = tabTmp; this.tab[i][CL�] = i+""; this.tab[i][VALEUR] = valeur;
        this.nbEntr�es++; return valeur.toString();
    }        
            
    /**
     * @pre La paire [cl�, valeur] doit �tre de format [Object, Boolean].
     * 
     * @param liste contient les objets cl�s.
     */    
    public void ajouter(List<Object> liste)
    {
        String cl� = null; 
        if (liste != null) for (int i=Z�RO; i < liste.size(); i++)
        {
            cl� = liste.get(i).toString(); this.ajouter(cl�, Boolean.TRUE);
        }
    }       
        
    public Object supprimer(Object cl�)
    {
        Object r�sultat = null; Object[] rechCl� = null;         
        for (int i=Z�RO; i < this.nbEntr�es; i++)
        {
            rechCl� = this.tab[i]; if (rechCl�[Z�RO].equals(cl�))
            {
                r�sultat = this.supprimer(i); break;
            }
        }        
        return r�sultat;
    }
            
    public Object supprimer(int i)
    {        
        this.v�rifier("supprimer", i);        
        Object r�sultat = this.tab[i]; int j = i + UN;        
        for (; j < this.nbEntr�es; j++)
        {
            this.tab[j-UN][CL�] = this.tab[j][CL�];
            this.tab[j-UN][VALEUR] = this.tab[j][VALEUR];
        }
        this.nbEntr�es--;
        if (this.nbEntr�es >= Z�RO)
        {
            this.tab[this.nbEntr�es][CL�] = null;
            this.tab[this.nbEntr�es][VALEUR] = null;            
        }
        return r�sultat;
    }
  
    public void trier(){ this.trier(null); }
        
    public void trier(Comparator<Object> compar) 
    {
        Object[][] tableau = new Object[this.nbEntr�es][DEUX];
        System.arraycopy(this.tab, Z�RO, tableau, Z�RO, this.nbEntr�es);        
        if (compar != null){ 
            Listes.trier(tableau, compar);
        } else { // NB: on ne trie pas les entr�es nulles.
            Listes.trier(tableau); 
        }
        System.arraycopy(tableau, Z�RO, this.tab, Z�RO, this.nbEntr�es);
    }    
    
    /**
     * @return un nouveau 'tabmap' repr�sentant deux autres concat�n�s.
     */
    public void fusionner(TabMap table)
    {
        Object cl� = null;
        if (table != null) for (int i=Z�RO; i < table.nbEntr�es; i++)
        {
            cl� = table.getCl�(i); this.ajouter(cl�, table.get(i));
        }
    }
    
    @Override
    public synchronized TabMap clone()
    {
        TabMap tm = new TabMap(); tm.tab = this.tab.clone();
        tm.taille = this.taille; tm.nbEntr�es = this.nbEntr�es; return tm;
    }
    
    public synchronized Object[] getSousEnsemble(int i1, int i2)
    {
        Object[] r�sultat = ((Object[]) new Object[i2-i1]);
        for (int i=i1; i < i2; i++){ r�sultat[i] = this.tab[i][VALEUR]; }
        return r�sultat;
    }
}