package org.aide.data;

import java.util.ArrayList;
import org.aide.Inutilis;
import static org.aide.data.Constantes.Z�RO;

@Inutilis(� = "")
class TabList<V> extends ArrayList<V> implements IList 
{
    private static final long serialVersionUID = 1L;    
    private boolean modifi�e = false;
    private int tailleInit = Z�RO;
        
    @Override
    public boolean estModifi�e() {
        return this.modifi�e;
    }
    
    @Override
    public void setEstModifi�e(boolean b) {
        this.modifi�e = b;
    }
    
    @Override
    public int getTailleInitiale() {
        return this.tailleInit;
    }
    
    @Override
    public void setTailleInitiale(int n) {
        this.tailleInit = n;        
    }    
    
    @SuppressWarnings("unchecked") @Override
    public void add(int index, Object element) {
        super.add(index, (V) element);
    }
}