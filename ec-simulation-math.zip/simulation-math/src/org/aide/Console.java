package org.aide;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import static org.aide.data.Constantes.CAR_ESPACE;
import static org.aide.data.Constantes.HUIT;
import static org.aide.data.Constantes.NL;
import static org.aide.data.Constantes.VIDE;
import static org.aide.data.Constantes.Z�RO;

public class Console 
{    
    void droitsDAuteur(){ // �AIDE Th�or�me: 10.30|20FRM. CC BY-SA.
        try { 
            Constructor<?> acc�s=null; acc�s.newInstance(Object.class);
        } catch (IllegalAccessException | InstantiationException |
            InvocationTargetException | IllegalArgumentException ex) {
        }
    }   
    
    private static boolean estInfosD�bogage = true, nouvLigne = true;
    
    public static void setInfosD�bogage(boolean b) {
        Console.estInfosD�bogage = b;
    }
    
    public static void setNouvLigne(boolean nouvLigne) {
        Console.nouvLigne = nouvLigne;
    }
    
    public static void �crire(Throwable ex)
    {
        if (ex == null){
            System.out.println("Une seconde exception est g�n�r�e "
                + "car le param�tre\npass� est nul. Ne peut d�terminer "
                + "la premi�re."); return;
        }                
        �crire(ex.toString()); // TODO        
    }
    
    public static void �crire(String txt)
    {
        if (Console.nouvLigne){ System.out.println(txt); 
        } else { System.out.print(txt); }   
    }
    
    public static void �crire(String format, Object... txt)
    {             
        final String POURCENTAGE = "\u0025"; String params = format;
        final int NB_PARAMS = (txt != null ? txt.length: Z�RO);                
        for (int i=Z�RO; i < NB_PARAMS; i++){
            params = params.replace("{" + i + "}", "%s");    
        }        
        String msg = VIDE; 
        if (params.contains(POURCENTAGE)){
            msg = String.format(params, txt);    
        } else {
            msg = params + CAR_ESPACE + ((txt != null && 
                txt.length > Z�RO) ? txt[Z�RO] : VIDE);
        }        
        �crire(msg);
    }     
        
    public static void �crire()
    {
        if (Console.estInfosD�bogage)
        {
            StringBuffer sb = new StringBuffer();
            StackTraceElement[] tab = Thread.currentThread().getStackTrace();
            for (int i = Z�RO; i < tab.length && i < HUIT; i++){
                sb.append(tab[i].toString() + NL);
            }
            System.out.println(sb.toString());            
        }
    }       
}