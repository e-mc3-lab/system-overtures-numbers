package org.aide.simulation.goldbach;

import java.math.BigDecimal;
import org.aide.Console;
import org.aide.data.Fichier;
import org.aide.data.Nombre;
import org.aide.data.TabMap;
import org.aide.lutil.Experience;
import org.aide.nalternative.AidException;
import static org.aide.data.Constantes.NL;
import static org.aide.data.Constantes.VIDE;
import static org.aide.data.Constantes.�GAL;


/**
 * @author SCLE-CSES. Theorem: 10.30|20FRM. CC BY-SA.
 */
public class InitialGb extends Experience
{    
    private final Nombre MAX_DIV = new Nombre((long)Math.sqrt(BLOC_NOMBRES));
    private final String MSG_INIT_TABX1 = "'tabX1er1' doit �tre initialis�.";
    
    public Xi[] tabX1er1 = null, tabX1er2 = null; private TabMap listeDiv = null; 
    public String[] tabXComp1er = null; int nb1er = Z�RO; int nbCmp1er = Z�RO;    
        
    private boolean d�nombrerPremiers()
    {   // Temps: 3.6M = ~6 min.
        final String FICHIER_DONN�ES = FD.getNom(FD.NOMBRES_PREMIERS);

        this.ouvrir(FICHIER_DONN�ES, false); Fichier fich = this.getFichier();      
        if ((fich != null) && fich.existeFEcrit()){
            return false; // Sortir: pas besoin de le refaire.
        }
        final long N = BLOC_NOMBRES + TROIS; Nombre n = new Nombre(Z�RO);
        int j = Z�RO; StringBuilder ligneNb1ers = new StringBuilder();
        ligneNb1ers.append("2, 3, 5, 7, 11, 13, 17, 19, 23");
        this.�crireLigne("%s" , ligneNb1ers); ligneNb1ers.setLength(Z�RO);
        for (int x=23; x <= N; x += DEUX)
        {
            n = new Nombre(x);
            if (this.estPremier1(n, MAX_DIV, false)){
                   ligneNb1ers.append(n + VIRGULE_ESPACE);
            }
            j += DEUX; if (j >= DIX)
            {
                this.�crireLigne("%s" , ligneNb1ers);
                j = Z�RO; ligneNb1ers.setLength(Z�RO);
            }
        } /* for x */ this.fermer();
        return true;
    }
    
    private int getPosPr�c(String s)
    {
        int r�sultat = -UN, j = s.length()-UN;
        for (int i=j; i > Z�RO; i--)
        {
            if (s.charAt(i) == NL.charAt(Z�RO)){ r�sultat = i + UN; break; }
        }
        return r�sultat;
    }
    
    private boolean estCoup�(String nbPr�c, String nb){
        return ((nbPr�c.length() < (nb.length() - UN)) ||
                ((nbPr�c.length() + UN) > nb.length()));
    }
            
    public void iniTabX1er()
    {
        final String FICHIER_DONN�ES = FD.getNom(FD.NOMBRES_PREMIERS);
        
        if (this.tabX1er1 != null){ return; }
        String blocNb = null; int i = Z�RO, j1 = Z�RO, j2 = Z�RO;
        final int N = BLOC_NOMBRES; this.tabX1er1 = new Xi[N+UN/CENT];
        String finBlocPr�c = null; String sNb = VIDE; Xi xi = null;
        Fichier fichier = new Fichier(Experience.DOSSIER_DONN�ES
            + FICHIER_DONN�ES); fichier.ouvrirLecture();
        if ( ! fichier.existeFLect()){
             throw new AidException(fichier
                 .getMsgFichierInexistant(FICHIER_DONN�ES));
        }
        blocNb = fichier.lire(); this.nb1er = Z�RO;  
        for (int j = Z�RO; (i < N) && (j < N); j++)
        {
               j2 = blocNb.indexOf(VIRGULE, j1);
               while ((j2 >= Z�RO) && (i < N))
               {
                   sNb = blocNb.substring(j1, j2).trim();
                if ( ! sNb.isEmpty())
                {
                    xi = new Xi(new Nombre(new BigDecimal(sNb))); 
                    this.tabX1er1[i++] = xi; this.nb1er++;   
                }
                j1 = j2 + DEUX; j2 = blocNb.indexOf(VIRGULE, j1);
               }
               if (fichier.estDerni�reLecture(blocNb)){ break; } // Fin boucle for.               
               finBlocPr�c = blocNb.substring(blocNb.length()-30, blocNb.length());
               if ( ! finBlocPr�c.trim().endsWith(VIRGULE + VIDE))
               {
                   j1 = this.getPosPr�c(blocNb);
                   if (j1 > 0){
                       finBlocPr�c = blocNb.substring(j1, blocNb.length()).trim();    
                   } else { break; } // Arr�ter.
               } else { finBlocPr�c = VIDE; }
               blocNb = fichier.lire();
               finBlocPr�c += (this.estCoup�(sNb, finBlocPr�c) ? VIDE: VIRGULE);               
               blocNb = finBlocPr�c + blocNb; j1 = Z�RO;
        } /* j */ fichier.fermer();
    }
    
    private int getTotalNb1er(Xi[] xis) 
    {
        final int N = BLOC_NOMBRES / (CENT + DIX); int i = N;
        for (; xis[i] != null; i++){} return i;
    }
    
    /**
     * Mots-Cl�s (MC) - Keyword (KW): recherche binaire, dichotomique.
     * @param xis Tableau de nombres premiers tri�s � mesure.
     */
    private int getPos1er(Xi[] xis, Nombre n) 
    {   
        int bas = Z�RO, milieu, comp; Nombre nb;
        if (this.nb1er <= Z�RO){ this.nb1er = this.getTotalNb1er(xis); }        
        int haut = this.nb1er-UN; while (bas <= haut)
        {
            milieu = (bas + haut) / DEUX; nb = xis[milieu].x;
            comp = nb.comparer�(n);
            if (comp < Z�RO){
                bas = milieu + UN;
            } else if (comp > Z�RO){
                haut = milieu - UN;
            } else {
                return milieu;
            }
        }
        return bas - UN;
    }
        
    private int getPos1erInf�rieur�(Nombre demieN)
    {
        int r�sultat = -UN, i = this.getPos1er(this.tabX1er2, demieN);
        for (int j = Z�RO; j <= i; j++)
        {
            // Voir le commentaire ci-apr�s.
            if (demieN.comparer�(this.tabX1er2[i].x) >= Z�RO)
            {
                r�sultat = i; break; // Fin boucle.
            } i--;
        }
        return r�sultat;
    }
        
    /**
     * Diviser en 2 � chaque it�ration: v�rifier alors si les nombres premiers
     * pr�c�dents et suivants sont diviseurs. Arr�ter rendu � 1. Si rien
     * trouv�, 'n' est premier, sinon, est divisible. O(log2(n)).
     *
     * @pre 'tabX1er1' doit contenir les nombres premiers < n.
     */
    private boolean estPremier(Nombre n) // EN: isPrime.
    {
        boolean r�sultat = true; Xi prm = new Xi(n); int i = Z�RO,
            j = n.intValue();
        Nombre demieN = n.ajouter(Nb1).diviser(Nb2);
        if (this.estMultiple(n, Nb2)){ return false; }
        if (n.toString().endsWith(CINQ+VIDE)){ return false; }
        if (this.tabX1er2 == null){
            throw new AidException("L'ensemble des nombres "
                + "premiers doit �tre non vide.");
        }
        int nbEssais = Math.round((int)Math.log(j) + UN / (int)Math.log10(j));
        nbEssais += n.divide(N2e13).intValue() + DIX * (int)(j / 300000);     
        this.�crireLigne("n: " + n.toString());
        while ((demieN.comparer�(Nb1) >= UN) && r�sultat)
        {
            if (this.estMultiple(n, demieN)){
                r�sultat = false;
            } else {
                i = this.getPos1erInf�rieur�(demieN);
                if (i < Z�RO){ break; } // Fin boucle.
                prm = this.tabX1er2[i];
                if (prm.x.comparer�(n) != Z�RO)
                {
                    if (this.estMultiple(n, prm.x)){
                        r�sultat = false;
                    } else {
                        int j1 = i - UN, j3;
                        for (j3 = i+UN; j3 <= (i+nbEssais) && r�sultat; j3++)
                        {
                            if ((j1 > Z�RO) && 
                                (this.tabX1er2[j1].x.comparer�(n) != Z�RO)) 
                            {
                                prm = this.tabX1er2[j1];
                                if (this.estMultiple(n, prm.x)){
                                    r�sultat = false;
                                }
                            } j1--;
                            if ((this.tabX1er2[j3] != null) && r�sultat &&  
                                (this.tabX1er2[j3].x.comparer�(n) != Z�RO))
                            {
                                prm = this.tabX1er2[j3];
                                if (this.estMultiple(n, prm.x)){
                                    r�sultat = false;
                                }
                            }
                        }
                    }
                }
            }
            demieN = demieN.ajouter(Nb1).diviser(Nb2);
        }
        if ( ! r�sultat && n.toString().endsWith(UN+VIDE)){
            this.listeDiv.ajouter(prm.x, n);
        }
        this.�crireLigne(r�sultat + VIDE); return r�sultat;
    } 
    
    /**
     * On fonctionne un peu par induction: on a trouv� 78500 nombres
     * premiers parmi les nombres ~inf�rieurs � 1000003. Cette fois-ci,
     * on d�nombre le premier 3.6 millions de nombres premiers. Temps:
     * ~60 min, avec un PC 'ordinaire', et deux processeurs dans une MV.
     */
    private void cr�erTableNombres1erEtFacteurs()
    {
        final String FICHIER_DONN�ES = FD.getNom(FD.NOMBRES_1ER1);
        
        final int N = BLOC_NOMBRES; this.tabX1er2 = new Xi[N+UN/CENT];         
        this.tabX1er2[this.nb1er++] = new Xi(Nb1);
        this.tabX1er2[this.nb1er++] = new Xi(Nb2);
        this.tabX1er2[this.nb1er++] = new Xi(Nb3);
        this.tabX1er2[this.nb1er++] = new Xi(Nb5);
        this.tabX1er2[this.nb1er++] = new Xi(Nb7);
        this.tabX1er2[this.nb1er++] = new Xi(new Nombre(11));
        Nombre nb = null; int pr = 13, iProtectionFinBoucle = Z�RO;
        this.ouvrir(FICHIER_DONN�ES, true); int ec = Z�RO, ecM = Z�RO;
        final boolean CONCAT�NER_NFACT = true;
        this.listeDiv = new TabMap(CONCAT�NER_NFACT);
        for (int i=UN; i < N & this.nb1er < N; i++) // Liste des nombres 1er.
        {
            nb = new Nombre(pr); pr++; ec = Z�RO;
            while ( ! this.estPremier(nb) && (iProtectionFinBoucle++ < MILLE))
            {
                nb = nb.ajouter(Nb1); pr++; ec++;
            }
            if (iProtectionFinBoucle >= MILLE){
                throw new AidException("Aucun nombre premier trouv� en "
                    + MILLE + " essais.");
            } iProtectionFinBoucle = Z�RO; if (ec - UN > ecM){ ecM = ec; }
            this.�crireLigne(nb.toString());
            this.tabX1er2[this.nb1er++] = new Xi(nb);
        } // i
        this.�crireLigne("Liste des facteurs des nombres se terminant par 1 "
            + "(%d): ", this.listeDiv.taille());
        for (int i = Z�RO; i < this.listeDiv.taille(); i++){
            �crireLigne("%s: %s", this.listeDiv.getCl�(i), this.listeDiv.get(i));
        }
        this.�crireLigne("Le plus grand �cart sans nombre premier: %d.", ecM);
        this.fermer();
    }
    
    private String[] get3Nombres(final String sNb, char op�rateur)
    {
        final String MSG_ERREUR = "Argument invalide.";
        String[] tab3 = null; int i = sNb.indexOf(�GAL);
        if (i > Z�RO)
        {
            tab3 = new String[TROIS]; tab3[Z�RO] = sNb.substring(Z�RO, i); 
            int j = sNb.indexOf(op�rateur, i+UN); if (j > Z�RO)
            {
                tab3[UN] = sNb.substring(i+UN, j);
                i = sNb.length(); tab3[DEUX] = sNb.substring(j+UN, i);        
            } else {
                throw new AidException(MSG_ERREUR);
            }
        } else {
            throw new AidException(MSG_ERREUR);
        }
        return tab3;
    }
     
    /**
     * Une ligne est comme suit: n = pr1 [x|+] pr2, o� pr1 et pr2 sont premiers.
     * Les groupes sont ainsi compos�s de trois nombres.
     */
    public void iniTabXCmp1er(String fd, char op�rateur)
    {
        final String FICHIER_DONN�ES = fd;
         
        String blocNb = null; int i = Z�RO, j1 = Z�RO, j2 = Z�RO;
        final int N = BLOC_NOMBRES; this.tabXComp1er = new String[N];
        String finBlocPr�c = null; String sNb = VIDE; String troisNb[]; 
        Fichier fichier = new Fichier(Experience.DOSSIER_DONN�ES
             + FICHIER_DONN�ES); fichier.ouvrirLecture();
        if ( ! fichier.existeFLect()){
             throw new AidException(fichier
                 .getMsgFichierInexistant(FICHIER_DONN�ES));
        }        
        blocNb = fichier.lire();
        for (int j = Z�RO; (i < N) && (j < N); j++)
        {
            j2 = blocNb.indexOf(NL, j1);
            while ((j2 >= Z�RO) && (i < N))
            {
                sNb = blocNb.substring(j1, j2+UN).trim(); if ( ! sNb.isEmpty())
                {
                    troisNb = this.get3Nombres(sNb, op�rateur);
                    if (troisNb != null)
                    {
                        this.tabXComp1er[i++] = troisNb[Z�RO];
                        this.tabXComp1er[i++] = troisNb[UN]; 
                        this.tabXComp1er[i++] = troisNb[DEUX];
                        this.nbCmp1er += TROIS;
                    }
                 }
                 j1 = j2 + UN; j2 = blocNb.indexOf(NL, j1);
            } // while
            if (fichier.estDerni�reLecture(blocNb)){ break; } // Fin.   
            finBlocPr�c = blocNb.substring(blocNb.length()-30, blocNb.length());
            if ( ! finBlocPr�c.trim().endsWith(NL))
            {
                j1 = this.getPosPr�c(blocNb);
                if (j1 > Z�RO){
                    finBlocPr�c = blocNb.substring(j1, blocNb.length()).trim();  
                } else { i = j = N; } // Fin.                    
            } else {  finBlocPr�c = VIDE; }
            blocNb = fichier.lire();
            finBlocPr�c += (this.estCoup�(sNb, finBlocPr�c) ? VIDE: NL);      
            blocNb = finBlocPr�c + blocNb; j1 = Z�RO;
        } // for j
        fichier.fermer();
    }
    
    public int getNbCmp1er(){ return this.nbCmp1er; }
            
    /**
     * Est-ce que tout nombre pair est la somme de deux nombres premiers ?
     */
    private boolean v�rifierConjectureGoldbach()
    {
        final String FICHIER_DONN�ES = FD.getNom(FD.NOMBRES_PAIRS);
        
        boolean bContrEx = false; this.ouvrir(FICHIER_DONN�ES, false);
        if (this.pasN�cessaireDeCr�er(FICHIER_DONN�ES))
        {            
            this.fermer(); return true;
        }
        int r, s, cmp = Z�RO; this.iniTabX1er(); Nombre n, diff, max = Nb0;
        final int N = this.nb1er-UN; if (this.tabX1er1 == null)
        {
            this.fermer(); throw new AidException(MSG_INIT_TABX1);
        }        
        for (int i=HUIT; (this.tabX1er1[i] != null) && ! bContrEx; i += DEUX)
        {
            n = new Nombre(i); r = Z�RO;
            while ((this.tabX1er1[r] != null) && (r < i + DIX))
            {
                s = r; cmp = this.tabX1er1[r].x.ajouter(this.tabX1er1[s].x)
                    .comparer�(n);
                while ((cmp != Z�RO) && (s < N)){
                    cmp = this.tabX1er1[r].x.ajouter(this.tabX1er1[++s].x)
                        .comparer�(n);
                }
                if (cmp == Z�RO)
                {
                    this.�crireLigne("%d=%s+%s", i, this.tabX1er1[r].x,
                        this.tabX1er1[s].x); break; // Fin boucle.
                } 
                r++;
                diff = n.soustraire(this.tabX1er1[s].x);
                if (diff.comparer�(max) > Z�RO){ max = diff; }
            }
            if (cmp != Z�RO)
            {
                this.�crireLigne("Le nombre %d n'est pas la somme de deux "
                       + "premiers.", i); bContrEx = true;
            }
        } // for i
        if ( ! bContrEx){ // Oui apr�s v�rification.
            Console.�crire("Maximum obtenu: %d.", max.intValue());
        }
        this.fermer(); return true;
    }
    
    public void pr�parerDonn�esGb()
    {
        InitialGb ngb = new InitialGb();
        if (ngb.d�nombrerPremiers())
        {
            ngb.cr�erTableNombres1erEtFacteurs();
            ngb.v�rifierConjectureGoldbach();
        } else {
            Console.�crire("Les fichiers de donn�es pr�liminaires "
                    + "existent d�j�.");
        }
    }
}