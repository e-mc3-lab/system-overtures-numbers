package org.aide.simulation.goldbach;

import java.awt.Color;
import java.awt.Font;
import java.awt.GradientPaint;
import javax.swing.JPanel;
import org.aide.data.Paire;
import org.aide.data.TabMap;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.StandardChartTheme;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.XYItemRenderer;
import org.jfree.chart.renderer.xy.XYLineAndShapeRenderer;
import org.jfree.chart.ui.ApplicationFrame;
import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;
import static org.aide.data.Constantes.UN;
import static org.aide.data.Constantes.Z�RO;


class VerificationGb extends ApplicationFrame // SCLE-CSES. 
{

    private static final long serialVersionUID = 1L;

    private XYSeriesCollection donn�es = null;

    public VerificationGb(){ super(""); }

    public XYPlot getTra��Lignes()
    {
        XYSeriesCollection ds = this.donn�es;       
        StandardChartTheme sct = new StandardChartTheme("Noir", false);
        sct.setLegendItemPaint(Color.black); // Rendre les chiffres
        sct.setAxisLabelPaint(Color.black); // plus fonc�s.
        sct.setTickLabelPaint(Color.black);
        ChartFactory.setChartTheme(sct);
        JFreeChart plan = ChartFactory.createXYLineChart("Titre", "X", "Y",
            ds, PlotOrientation.VERTICAL, true, true, false);
        plan.setBackgroundPaint(Color.white);
        XYPlot trac� = (XYPlot) plan.getPlot();
        trac�.setBackgroundPaint(Color.white);
        trac�.setDomainGridlinePaint(Color.gray);
        trac�.setRangeGridlinePaint(Color.gray);
        XYItemRenderer ryx = trac�.getRenderer();
        if (ryx instanceof XYLineAndShapeRenderer)
        {
            XYLineAndShapeRenderer rendu = (XYLineAndShapeRenderer) ryx;     
            rendu.setDrawOutlines(false);
            rendu.setDefaultShapesVisible(true); // :dessine des points:
            rendu.setDefaultShapesFilled(true);
            rendu.setDrawSeriesLineAsPath(true);
            rendu.setSeriesPaint(0, Color.black);
            rendu.setSeriesPaint(1, Color.blue);
            rendu.setSeriesPaint(2, Color.yellow);
        }
        final Font police = new Font("SansSerif", Font.BOLD, 10);
        trac�.setQuadrantPaint(0, new GradientPaint(1.0f, 2.0f, Color.BLUE,
            3.0f, 4.0f, new Color(206, 233, 250))); // Partie gauche (-).
        ValueAxis axes = trac�.getDomainAxis(); // X
        axes.setTickLabelFont(police);
        axes.setAutoTickUnitSelection(false); // Unit�s enti�res.
        axes = trac�.getRangeAxis(); // Y
        axes.setTickLabelFont(police); return trac�;
    }

    JPanel getPanneau() 
    {   
        XYPlot tdXY = getTra��Lignes();     
        JFreeChart jfc = new JFreeChart(getTitle(),
            JFreeChart.DEFAULT_TITLE_FONT, tdXY, true/*L�gende*/);
        jfc.setBackgroundPaint(Color.white); // Sinon gris.
        jfc.setBorderVisible(true); jfc.setBorderPaint(Color.black);
        return new ChartPanel(jfc);
    }    

    void cr�er(TabMap tm)
    { 
        XYSeriesCollection xySc = new XYSeriesCollection();
        XYSeries s10Expo = new XYSeries("Log n");
        XYSeries sSr = new XYSeries("Log(max(Sr))"); // Ensemble/Set-recherche.
        XYSeries sMaxN = new XYSeries("Log(max(Sr))/log(n)");
        if (tm == null)
        {
            s10Expo.add(-1, 0.3); s10Expo.add(0, 1.0); s10Expo.add(1, 2.1);
            s10Expo.add(2, 3.1); s10Expo.add(6, 6.1); sSr.add(1, 1.2);
            sSr.add(2, 3.1); sMaxN.add(1, 1.3);
        } else {
            Paire pgb = null; double la, lb;
            for (int i=Z�RO; i < tm.taille(); i++)
            {
                pgb = (Paire)tm.get(i); int j = i + UN;
                la = Math.ceil(Math.log10(pgb.n)); // Pour comparaison:
                if ((la + "").endsWith("9.0")) { la += UN; }
                lb = Math.log10(pgb.max);
                s10Expo.add(j, la); sSr.add(j, lb); sMaxN.add(j, lb / la);        
            }
        }
        xySc.addSeries(s10Expo); xySc.addSeries(sSr); xySc.addSeries(sMaxN);
        this.donn�es = xySc; this.setContentPane(this.getPanneau());
        this.pack(); this.setLocationRelativeTo(null); this.setVisible(true);
    }


    public static void main(String[] args)
    {
        EvenPrimeFactorGb epf = new EvenPrimeFactorGb();
        epf.getObjetIGb().pr�parerDonn�esGb();
        epf.v�rifierConjectureGb(300); TabMap tm = epf.getR�sultatsGoldbach();
        VerificationGb ggb = new VerificationGb(); ggb.cr�er(tm);
    }
}