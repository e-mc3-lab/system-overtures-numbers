package org.aide.simulation.goldbach;

import java.math.BigDecimal;
import java.math.MathContext;
import org.aide.Console;
import org.aide.data.TabMap;
import org.aide.data.Fichier;
import org.aide.data.Nombre;
import org.aide.data.Paire;
import org.aide.lutil.Experience;
import org.aide.nalternative.AidException;
import static org.aide.data.Constantes.NL;
import static org.aide.data.Constantes.PLUS;

/**
 * @author SCLE-CSES. Theorem: 10.30|20FRM. CC BY-SA.
 */
public class EvenPrimeFactorGb extends Experience
{               
    private final String MSG_INIT_TABX1 = "'tabX1er1' doit �tre initialis�.";     
    private final String MSG_TABX_COMP_1ER = "Initialiser 'tabXComp1er'.";
    private final String MC_N_�GAL = "n=";
    private final String MC_G�N = "+g�n: ";
             
    private TabMap tm = null; private InitialGb igb = null;
    
    EvenPrimeFactorGb(){ this.igb = new InitialGb(); }
    
    public InitialGb getObjetIGb(){ return this.igb; }
        
    private void v�rifierConjectureGbA()
    {   
        final String FICHIER_DONN�ES = FD.getNom(FD.NOMBRES_PAIRS_DIFF);
        
        this.ouvrir(FICHIER_DONN�ES, false); // PR�: pas de validation.
        final Nombre Nb10 = new Nombre(DIX); Nombre n = Nb0, np = Nb3;
        final Nombre MAX_DOUBLE = new Nombre(new BigDecimal(Double.MAX_VALUE));
        this.igb.iniTabXCmp1er(FD.getNom(FD.NOMBRES_PAIRS), PLUS);
        this.igb.iniTabX1er(); Nombre dix�LaN = Nb10; this.tm = new TabMap(50); 
        if (this.igb.tabX1er1 == null){ throw new AidException(MSG_INIT_TABX1); }
        if (this.igb.tabXComp1er == null)
        {
            this.fermer(); throw new AidException(MSG_TABX_COMP_1ER);
        }
        final int N = this.igb.getNbCmp1er(); Nombre diff, max = Nb0;
        if (N == 0){ this.fermer(); throw new AidException(MSG_TABX_COMP_1ER); }
        Console.�crire("Puissances de dix et r:");
        for (int i=Z�RO; i < N; i += TROIS)
        {
            n = new Nombre(new BigDecimal(this.igb.tabXComp1er[i+DEUX]));
            diff = n.soustraire(np);
            if (diff.comparer�(max) > Z�RO){ max = diff; }
            if (n.comparer�(dix�LaN) > Z�RO)
            {
                Console.�crire("%s, max = %s, max/n = %s.",
                    dix�LaN, max, max.divide(np, MathContext.DECIMAL32));
                this.tm.ajouter(new Paire(np.doubleValue(), max.doubleValue()));
                dix�LaN = new Nombre(dix�LaN.multiply(Nb10)); max = Nb0;
            }  np = n;
        } // for
        Console.�crire("%s, max = %s, max/n = %s.",
            dix�LaN, max, max.divide(n, MathContext.DECIMAL32));
        this.tm.ajouter(new Paire(n.doubleValue(), max.doubleValue()));
        this.fermer(); Fichier fichier = this.getFichier();
        fichier.ouvrirLecture(); String texte = fichier.lire(true);
        String nombre, emax; int i = texte.indexOf(MC_N_�GAL), j1, j2=Z�RO;
        final int L1 = MC_N_�GAL.length(), L2 = MC_G�N.length();
        while (i >= Z�RO)
        {
            j1 = texte.indexOf(NL, i+UN); if (j1 > Z�RO)
            {
                nombre = texte.substring(i+L1, j1).trim();
                j1 = texte.indexOf(MC_G�N, j1+UN); if (j1 > Z�RO)
                {
                    j2 = texte.indexOf(NL, j1+UN); if (j2 > Z�RO)
                    {
                        emax = texte.substring(j1+L2, j2); Console.�crire(emax);
                    } else { break; }
                } else { break; }
            } else { break; }
            n = new Nombre(new BigDecimal(nombre));
            max = new Nombre(new BigDecimal(emax));
            if (n.comparer�(MAX_DOUBLE) < Z�RO){
                this.tm.ajouter(new Paire(n.doubleValue(),
                    max.doubleValue(), true));
            } i = texte.indexOf(MC_N_�GAL, j2+L1);
        } // i        
        fichier.fermer();
    }
    
    private void v�rifierConjectureGoldbachB(int nbChiffres)
    {           
        final String FICHIER_DONN�ES = FD.getNom(FD.NOMBRES_PAIRS_DIFF);
        
        this.ouvrir(FICHIER_DONN�ES, false);
        if (this.pasN�cessaireDeCr�er(FICHIER_DONN�ES))
        {   // Pour refaire un autre jeu de donn�es, effacer manuellement 
            this.fermer(); return; // le fichier avant la simulation.
        }
        this.igb.iniTabXCmp1er(FD.getNom(FD.NOMBRES_PAIRS), PLUS);
        this.igb.iniTabX1er(); Nombre n, np = Nb0, nc;
        if (this.igb.tabX1er1 == null){ 
            this.fermer(); throw new AidException(MSG_INIT_TABX1); }
        int N1 = this.igb.nbCmp1er; if (this.igb.tabXComp1er == null){
            this.fermer(); throw new AidException("'tabXComp1er' doit �tre initialis�.");
        }
        
        Nombre max = Nb0; boolean bContrEx = false;
        long n1; int n2, n3, i; final int Ne = DEUX * DIX; Nombre tabN1er[];
        N1 = 36; int N2 = N1 / DEUX; tabN1er = new Nombre[N1];
        n1 = (long)(Math.random() * CENT * MILLE);
        n2 = (int)(Math.random() * n1 * DIX * MILLE);
        n3 = (int)(Math.random() * n2); n = new Nombre(n1*n2*n3*N1).expo(Ne);
        n = new Nombre(new BigDecimal(n.toString().substring(Z�RO, nbChiffres)));        
        
        for (i=Z�RO; i < N1;)
        {
            if (this.estPremier1(n, Nb0, false)){ tabN1er[i++] = n; }
            n = n.ajouter(Nb1);
        }
        
        int s, r, cmp = Z�RO; i--; np = tabN1er[i]; n = np.ajouter(Nb1);
        this.�crireLigne(MC_N_�GAL + n); Xi[] tX1er = this.igb.tabX1er1;     
        for (int j=i; j >= N2 && ! bContrEx; j--)
        {
            r = Z�RO; while ((tX1er[r] != null) && (i >= Z�RO))
            {
                s = i; cmp = tX1er[r].x.ajouter(tabN1er[s]).comparer�(n);
                while ((cmp > Z�RO) && (s >= Z�RO))
                {
                    cmp = tX1er[r].x.ajouter(tabN1er[s--]).comparer�(n);
                }
                if (cmp == Z�RO)
                {
                    Console.�crire(tX1er[r].x + "+...");
                    if ((nc = tabN1er[s].soustraire(np).absol())
                        .comparer�(max) > Z�RO){ max = nc; }
                    np = tabN1er[s]; break; // Fin boucle.
                } r++;
            } // while
            if (cmp != Z�RO)
            {
                this.�crireLigne("Le nombre %s n'est pas la somme de deux "
                       + "premiers.", n); bContrEx = true;
            }
            n = n.soustraire(Nb2);
        } 
        // Le plus Grand �cart d'un Nombre (G�N) par rapport au pr�c�dent.
        this.�crireLigne(MC_G�N + max.intValue() + NL); this.fermer();
    }
    
    // Regrouper deux v�rifications compl�mentaires.
    void v�rifierConjectureGb(int nbChiffres)
    {
        this.v�rifierConjectureGbA(); this.v�rifierConjectureGoldbachB(nbChiffres);  
    }

    public TabMap getR�sultatsGoldbach(){ return this.tm; }

    public static void main(String[] args)
    {
        EvenPrimeFactorGb pfg = new EvenPrimeFactorGb();
        pfg.igb.pr�parerDonn�esGb(); pfg.v�rifierConjectureGb(300);
    }
}