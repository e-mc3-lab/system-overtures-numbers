package org.aide.simulation.fermat;

import java.util.ArrayList;
import java.util.List;
import org.aide.data.Nombre;
import org.aide.lutil.Experience;
import org.aide.nalternative.AidException;

/**
 * @author Jacques Vall�e. Th�or�me: 10.30|20FRM.
 */
public class PseudoCroissance extends Experience
{
    private final String FICHIER_DONN�ES = "fmt-pseudo-croissance.txt";
            
    private class ClasseFermat implements Cloneable
    {    
        int x, y, z, n; boolean distance0, changeDirection;
        
        @Override    
        public boolean equals(Object obj)
        {   // Dans ce cas-ci, on g�re une liste sans doublon.        
            return ((((ClasseFermat)obj).y) == ClasseFermat.this.x) &&
             ((((ClasseFermat)obj).x) == ClasseFermat.this.y);    
        }         
        
        protected ClasseFermat getCopie()
        {        
            ClasseFermat r�sultat = null; try {
                r�sultat = (ClasseFermat) super.clone();
            } catch (CloneNotSupportedException ex) {         
                throw new AidException(ex);
            }        
            return r�sultat;    
        }
    }
    
    private void ouvrirFichier(){ super.ouvrir(FICHIER_DONN�ES, true); }
    
    protected void fermer(){ super.fermer(); }    
    
    private Nombre getDistanceSuivante(ClasseFermat cls)
    {   // La croissance est soit positive ou n�gative (d�croissance).  
        Nombre r�sultat = null;        
        Nombre xN = new Nombre(cls.x).expo(cls.n + UN);
        Nombre yN = new Nombre(cls.y).expo(cls.n + UN);
        Nombre xNPlusYN = xN.ajouter(yN);
        Nombre zN = new Nombre(cls.z).expo(cls.n + UN);
        r�sultat = xNPlusYN.soustraire(zN); return r�sultat;
    }
        
    void v�rifierVariations(int minN, int maxN)
    {       
        final Nombre Nb0 = new Nombre(Z�RO); int it = Z�RO;
        final int TROIS_MILLE = TROIS * MILLE;
        Nombre distPrec = Nb0, distance, distSuiv; 
        boolean bCroissancePrec, bCroissance;
        int xyFin = MILLE, nD�but = minN, nFin = nD�but + maxN;
        int zD�but = DEUX, zFin = zD�but + CENT;         
        ClasseFermat clsFmt = new ClasseFermat(); // Plus l�ger que Set:
        List<ClasseFermat> listeCls = new ArrayList<ClasseFermat>();                
        for (int x=TROIS; x <= xyFin && (x <= (UN + CENT)); x++)
        {
            this.ouvrirFichier();
            for (int y=TROIS; y <= xyFin && (y <= (UN + CENT)); y++)
            {
                for (int z=zD�but; z <= zFin && ! ((x == UN) && (y == UN)) || 
                    (z <= (zD�but + CENT)); z++)
                {
                    for (int n=nD�but; n <= nFin; n++) // Comparaison verticale.
                    {
                        Nombre xN = new Nombre(x).expo(n);
                        Nombre yN = new Nombre(y).expo(n); 
                        Nombre xNPlusYN = xN.ajouter(yN);
                        Nombre zN = new Nombre(z).expo(n);
                        distance = xNPlusYN.soustraire(zN);
                        bCroissancePrec = (distance.absol() // faux < 0
                            .comparer�(distPrec.absol()) >= Z�RO); // vrai >= 0.                       
                        if ((n > TROIS) && (x > 1) && (y > 1) && (z != x))
                        {     
                            clsFmt.x = x; clsFmt.y = y;
                            clsFmt.z = z; clsFmt.n = n; 
                            clsFmt.distance0 = false; 
                            clsFmt.changeDirection = true;                           
                            distSuiv = this.getDistanceSuivante(clsFmt);                            
                            bCroissance = (distSuiv.absol()
                                .comparer�(distance.absol()) >= Z�RO);
                            if (distance.comparer�(Nb0) == Z�RO){
                                clsFmt.distance0 = true;
                            }                                                           
                            if ((( ! bCroissancePrec && bCroissance) || 
                                 ( bCroissancePrec && ! bCroissance)) && 
                                 (n > HUIT) && ! listeCls.contains(clsFmt)) 
                            {              
                                this.�crireLigne("n=%d x=%d y=%d z=%d, " 
                                     + "[xN+yN-zN] avant=%d, courante=%d, "
                                     + "apr�s=%d.", clsFmt.n, clsFmt.x, 
                                     clsFmt.y, clsFmt.z,  distPrec.intValue(), 
                                     distance.intValue(), distSuiv.intValue());
                                 
                                boolean bDirPrecSup0, bDirSup0;
                                bDirPrecSup0 = (distPrec.comparer�(Nb0) > Z�RO); 
                                bDirSup0 = (distance.comparer�(Nb0) > Z�RO);
                                if ( ! ((bDirPrecSup0 && ! bDirSup0) || 
                                        ( ! bDirPrecSup0 && bDirSup0))) {
                                    clsFmt.changeDirection = false;
                                }
                                listeCls.add(clsFmt.getCopie());
                                // Faut savoir quand arr�ter:
                                if (it++ > TROIS_MILLE) { x = y = xyFin; break; }
                            }          
                        }                         
                        distPrec = new Nombre(Z�RO).ajouter(distance);                         
                    } // n                     
                    distPrec = new Nombre(Z�RO);
                } // z
            } // y               
            this.fermer();            
        } // x        
        this.ouvrirFichier();
        this.�crireLigne("Liste des classes avec distance nulle: ");
        for (ClasseFermat cls: listeCls) 
        {
            if (cls.distance0){
            this.�crireLigne("n=%d x=%d y=%d z=%d.", 
                cls.n, cls.x, cls.y, cls.z);
            }
        }
        this.�crireLigne("Liste des classes dont le changement de croissance "
            + "n'est pas fonction d'un changement de direction: ");
        for (ClasseFermat cls: listeCls) 
        {
            if ( ! cls.changeDirection){
                this.�crireLigne("n=%d x=%d y=%d z=%d.", 
                   cls.n, cls.x, cls.y, cls.z);
            }
        } this.fermer();
    }    
                    
    public static void main(String[] args){    
        new PseudoCroissance().v�rifierVariations(3, 100);      
    }
}