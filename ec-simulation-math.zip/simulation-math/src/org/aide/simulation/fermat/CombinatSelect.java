package org.aide.simulation.fermat;

import org.aide.data.Nombre;
import org.aide.lutil.Experience;


/**
 * @author Jacques Vall�e. Th�or�me: 10.30|20FRM.
 */
public class CombinatSelect extends Experience
{       
    private final String FICHIER_DONN�ES = "fmt-simulation0.txt"; 

    private void ouvrirFichier(){
        super.ouvrir(FICHIER_DONN�ES, true);        
    }
    
    protected void fermer(){
        super.fermer();
    }       
        
    /**
     * NB: la validation de classes en double n'est pas impl�ment�e.
     */
    void d�nombrerClassesFermat()
    {
        Nombre i, distance; final int DEUX_MILLE = DEUX * MILLE; 
                
        for (int n=TROIS; n <= 32; n++) // Remplacer ensuite n (1 it�ration).
        {   // Exemple: n=366 et n <= 366; n=1000 et n <= 1000; ...
            i = new Nombre(16).expo(n - TROIS);
            
            this.ouvrirFichier(); this.�crireLigne("n=%d i=%.0f", n, i);
            
            for (int x=UN; x <= MILLE; x++)
            {   
                for (int y=UN; y <= MILLE; y++)
                {                    
                    Nombre xN = new Nombre(x).expo(n);
                    Nombre yN = new Nombre(y).expo(n);                    
                    Nombre xNPlusYN = xN.ajouter(yN);
                    
                    for (int z=TROIS; z <= DEUX_MILLE; z++)
                    {
                        Nombre zN = new Nombre(z).expo(n);
                        Nombre xNyNMoinsI = xNPlusYN.soustraire(i);
                        Nombre xNyNPlusI = xNPlusYN.ajouter(i); 
                                                
                        if ( ! ((x == UN) && (y == UN)) && 
                             (z != x) && (z != y) &&
                             (zN.comparer�(xNyNMoinsI) >= Z�RO) &&
                             (zN.comparer�(xNyNPlusI) <= Z�RO))
                        {
                            distance = xNPlusYN.soustraire(zN); 
                            this.�crireLigne("n=%d x=%d y=%d xN=%.0f " + 
                                "yN=%.0f xN+yN=%.0f z=%d zN=%.0f %.0f.", 
                                n, x, y, xN, yN, xNPlusYN, z, zN, 
                                distance.abs());
                        }
                    } // z
                } // y
            } // x            
            this.fermer();            
        } // n        
    }
            
    public static void main(String[] args) {
        new CombinatSelect().d�nombrerClassesFermat();                
    }
}