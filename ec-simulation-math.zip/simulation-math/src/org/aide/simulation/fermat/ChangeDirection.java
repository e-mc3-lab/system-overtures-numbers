package org.aide.simulation.fermat;

import org.aide.data.Nombre;
import org.aide.lutil.Experience;


/**
 * @author SCLE-CSES. Th�or�me: 10.30|20FRM.
 */
public class ChangeDirection extends Experience
{
    private final String FICHIER_DONN�ES = "fmt-chg-direction.txt";
        
    private class ClasseFermat 
    {
        private int x, y, z, n; // Note: dans ce programme, n = N.
    }
    
    private ClasseFermat clsExpoSup8 = null;
    
    private void ouvrirFichier(){
        super.ouvrir(FICHIER_DONN�ES, true); 
    }
    
    protected void fermer(){
        super.fermer();
    }        

    void v�rifierVariation(int xyD�but)
    {   
        final Nombre NB0 = new Nombre(0); Nombre distance;
        boolean bDistancePositivePrec = true, bDistancePositive;
        int xyFin = xyD�but + MILLE, nD�but = TROIS, nFin = nD�but + CENT;
        int zD�but = xyD�but + DEUX, zFin = zD�but + CENT; //, it = Z�RO;
        int nbIterVidesX = 0, maxIterVidesX;
        int nbIterVidesY = 0, maxIterVidesY = 0, nbIterVidesZ = 0, maxIterVidesZ;
        maxIterVidesX = maxIterVidesY = maxIterVidesZ = ((zFin - zD�but) / TROIS);
        this.clsExpoSup8 = new ClasseFermat();
        
        for (int x=xyD�but; x <= xyFin && ((x <= (xyD�but + CENT)) ||
            (nbIterVidesX++ < maxIterVidesX)); x++)
        {
            this.ouvrirFichier();
            for (int y=xyD�but; y <= xyFin && ((y <= (xyD�but + CENT)) ||
                (nbIterVidesY++ < maxIterVidesY)); y++)
            {
                for (int z=zD�but; z <= zFin && ! ((x == UN) && (y == UN)) &&
                    ((nbIterVidesZ++ < maxIterVidesZ) ||
                    (z <= (zD�but + CENT))); z++) // Apr�s, le d�lai est trop long.
                {
                    for (int n=nD�but; n <= nFin; n++) // Comparaison verticale.
                    {
                        Nombre xN = new Nombre(x).expo(n);
                        Nombre yN = new Nombre(y).expo(n);
                        Nombre xNPlusYN = xN.ajouter(yN);
                        Nombre zN = new Nombre(z).expo(n);
                        distance = xNPlusYN.soustraire(zN);
                        bDistancePositive = (distance.comparer�(NB0) >= Z�RO);                     
                        if (((bDistancePositivePrec && ! bDistancePositive) ||
                            ( ! bDistancePositivePrec && bDistancePositive)) && 
                            (n > TROIS) && (x > 1) && (y > 1) && (x != y) &&          
                            (z != x) && (z != y)) // Changement de direction.
                        {
                            nbIterVidesX = nbIterVidesY = nbIterVidesZ = 0;                          	
                            if (n > this.clsExpoSup8.n)       
                            {
                                this.clsExpoSup8.x = x;
                                this.clsExpoSup8.y = y;
                                this.clsExpoSup8.z = z;
                                this.clsExpoSup8.n = n;               
                            } // if (it++ > 10000000) { x = y = xyFin; break; }
                        }
                        bDistancePositivePrec = bDistancePositive;       
                    } // n
                } // z
                nbIterVidesZ = 0;
            } // y
            nbIterVidesY = 0; this.fermer();
        } // x
        
        this.ouvrirFichier(); // x=0, y=0, z=0: aucune.
        this.�crireLigne("Exposant n sup�rieur � 8: x=%d, y=%d, z=%d n=%d.\n\n", 
            this.clsExpoSup8.x, this.clsExpoSup8.y, this.clsExpoSup8.z,
            this.clsExpoSup8.n); this.fermer();
    }
        
    public static void main(String[] args)
    {
        ChangeDirection scd = new ChangeDirection();   
        scd.v�rifierVariation(1);
    }
}