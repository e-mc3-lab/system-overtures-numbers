package org.aide.nalternative;

@SuppressWarnings("serial") // Classe � la fois g�n�rique et sp�cialis�e. 
public class AidException extends IllegalArgumentException
{
    public AidException(String message) {
        super(message);
    }
    
    public AidException(Exception ex) {
        super(ex);
    }
    
    public AidException(Throwable ex) {
        super(ex);
    }
    
}