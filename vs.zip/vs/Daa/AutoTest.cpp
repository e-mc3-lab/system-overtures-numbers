/*
 Legal Notice: Some portions of the source code contained in this file were
 derived from the source code of Encryption. Modifications and additions to
 the original source code (contained in this file), and all other portions
 of this file are Copyright(c) 2003-2013 'Fondation TrueCrypt'. These are
 also governed by the SCLE License; the full text of which is contained
 in the file Licence 1.0.txt included in NetDisq packages. 2024-2026. */

#include "Fichier.h"
#include "Crypto.h"
#include "Crc.h"
#include "Random.h"
#include "ModXyz.h"
#include "Secret.h"
#include "Prf.h"
#include "Aesdefs.h"
#include "TextHexa.h"
#include "Doa.h"
#include "AutoTest.h"

#define ND_TEST_COUNT   8 
#define NB_CAS_TEST     1
#define NB_AUTO_ESSAIS  3

typedef struct { uint8 testCase; uint32 crc; } CHIFFRE_SECTEUR;

static INFO_CRYPTO gCi = {0}; BOOL bD�jaTest� = FALSE; uint gEssai = 0;

NTSTATUS test_prf()
{
    #define DIM_TAB_DK    11 * DIM_BLOC_EA
    byte moDPasse[] = "MotdePasse", passw[] = "password";
    const ENTIER DIM_MDPA = STRLEN(moDPasse), DIM_PWD = STRLEN(passw);
    const byte SELa[] = "\x12\x33\x50\x79";
    const byte SELb[] = "\x18\x47\x9a\xbc";
    const byte SELc[] = "\x67\x89\xab\xcd\xef";
    const byte SELd[] = "\x12\x34\x56\x78\x9a\xbc";
    const byte SELe[] = "\x12\x34\x56\x78";
    const int DIM_SELa = (int)STRLEN(SELa);
    const int NB_ITER = 6; byte dk0[DIM_TAB_DK] = {0}, dk[DIM_TAB_DK] = {0};
    /* Test 1 with HMAC-RIPEMD used as the PRF. */
    d�chiqueter_RIPEMD(passw, DIM_PWD, SELd, 6, 3, dk, 30);
    ND_ASSERT_CS(comparerNbDiff(passw, dk, 6), ERR_CHIFFREMENT_INVALIDE);
    /* Test 2 with HMAC-RIPEMD used as the PRF (derives a key longer
        than the underlying hash). journaliserTabHexa1(dk, 48); */
    memcpy(dk0, dk, 48); d�chiqueter_RIPEMD(passw, DIM_PWD, SELe, 4, 5, dk, 48);
    ND_ASSERT_CS(comparerNbDiff(dk0, dk, 48), ERR_CHIFFREMENT_INVALIDE);
    init0(dk, DIM_TAB_DK); /* Test 1 with HMAC-SHA-512 used as the PRF. */
    d�chiqueter_SHA(moDPasse, DIM_MDPA, SELa, DIM_SELa, NB_ITER, dk, 6);
    ND_ASSERT_CS(comparerNbDiff(moDPasse, dk, 6), ERR_CHIFFREMENT_INVALIDE);
    /* Test 2 with HMAC-SHA-512 used as the PRF (derives a key longer
        * than the underlying hash output size and block size). */
    memcpy(dk0, dk, 30); d�chiqueter_SHA(moDPasse, DIM_MDPA, SELa, DIM_SELa,
        NB_ITER, dk, 30); ND_ASSERT_CS(comparerNbDiff(dk0, dk, 30),
            ERR_CHIFFREMENT_INVALIDE);
    init0(dk, DIM_TAB_DK); /* Test 1 with HMAC-Whirlpool used as the PRF. */
    d�chiqueter_WHIRLPOOL(passw, DIM_PWD, SELb, 4, 7, dk, 6);
    ND_ASSERT_CS(comparerNbDiff(passw, dk, 6), ERR_CHIFFREMENT_INVALIDE);
    memcpy(dk0, dk, 80); /* Test 2 with HMAC-Whirlpool used as the PRF
    (derives a key longer than the underlying hash). */
    d�chiqueter_WHIRLPOOL(passw, DIM_PWD, SELc, 5, 6, dk, 80);
    ND_ASSERT_CS(comparerNbDiff(dk0, dk, 80), ERR_CHIFFREMENT_INVALIDE);
    ND_FIN(); ERR: ND_JOURNALISER_ERREUR("test_prf"); FIN:return gNDR�sultat;
}

NTSTATUS getCl�Rem32(byte tab[])
{
    const uint16 NET_DIV = RNG_POOL_SIZE;
    for (uint i = 0; i < DIM_32; i++){ tab[i] = byte('a' + (rand() % 43)); } 
    setNonVide(tab, DIM_32, FALSE, TRUE); return STATUS_SUCCESS;
}

NTSTATUS getCl�0(byte tab[], uint n, BOOL bModPasse)
{
    const uint16 NET_DIV = RNG_POOL_SIZE;
    for (uint i = 0; i < n; i++){ tab[i] = byte('a' + (rand() % 23)); }
    setNonVide(tab, n, FALSE, bModPasse); return STATUS_SUCCESS;
}

BOOL estAlgorithmeValide(__in uint8 ea)
{
    int r = 0; uint i, j; uint8 tab0[UDM] = {0}, tab[UDM] = {0};
    for (i = 0, j = 1; i < ND_TEST_COUNT; i++, j++)
    {
        init0(gCi.cl�0, UDM); getDataTest(gCi.cl�0, DK0, TRUE);
        setKey0(gCi.cl�0); getDataTest(tab, UDM, FALSE); r = initEA(ea);
        if ( ! NT_SUCCESS(r)){ return FALSE; } memcpy(tab0, tab, UDM);
        encryptBlock16(ea, j, tab); if ( ! comparerNbDiff(tab0, tab, UDM)){
            break; } TCSleep(1); decryptBlock16(ea, j, tab); 
        if (memcmp(tab0, tab, UDM) != 0){ break; }
    } /*for*/ return (i == ND_TEST_COUNT);
}

BOOL initDonn�esXTS(CRYPTO_INFO* ci, uchar* tab0, uint n)
{
    getDataTest(ci->cl�0, DK0, TRUE); getDataTest(tab0, n, FALSE);
    if ( ! NT_SUCCESS(initialisec(ci))){ return FALSE; } return TRUE;
}

BOOL initDonn�esMode(CRYPTO_INFO* ci, uchar* tab, uint n){
    return initDonn�esXTS(ci, tab, n);
}

NTSTATUS v�rifierEAs(uint8 cifr, BOOL bJournal)
{
    BOOL bValide = TRUE;
    for (uint8 ea = getEAD�but(cifr); ea >= ENUM_1; ea = getEASuivant(cifr))
    {
        bValide = estAlgorithmeValide(ea); if (bJournal)
        journaliser("Est ea=%d valide ? %s.", ea, (bValide ? "Oui" : "Non"));
        if ( ! bValide){ return ERR_ALGORITHME_INVALIDE; }
    } 
    return EXIT_SUCCESS;
}

BOOL validerCiphers(INFO_CRYPTO* ci)
{
    BOOL r�sultat = TRUE; uint32 n = 0; uint32 ct = 0, crc0, nbUnits = 1;
    uint8 c = 0; const uint N = NB_CAS_TEST * UDM; char* name = NULL;
    byte tab0[UDM] = {0}, tab[UDM] = {0}; uint64 i = 0, idUnit = 0;
    int ECI = ERR_CHIFFREMENT_INVALIDE; for (ct = 0; ct < NB_CAS_TEST; ct++)
    {
        for (int i = REM; i <= FISH; i++)
        {
            for (int j = REM; j <= FISH; j++)
            {
                if (i != j)
                {
                    ci->cifr = c; ci->mode = XTS;
                    if ( ! initDonn�esMode(ci, tab, UDM)){
                        ND_ASSERT_S(ERR_INVALID_MODE);
                    }
                    name = getNomCipher(c);
                    memcpy(tab0, tab, UDM); crc0 = getCrc32(tab, UDM);
                    if ( ! NT_SUCCESS(EncryptDataUnits(tab, idUnit,
                        nbUnits, ci))){ ND_ASSERT_S(ECI); }
                    if ( ! comparerNbDiff(tab0, tab, UDM)){
                        ND_ASSERT_S(ERR_CHIFFREMENT_INVALIDE);
                    }
                    if ( ! NT_SUCCESS(DecryptDataUnits(tab, idUnit,
                        nbUnits, ci))){ ND_ASSERT_S(ECI); }
                    if (memcmp(tab0, tab, UDM) != 0){
                        ND_ASSERT_S(ECI);
                    }
                    if (crc0 != getCrc32(tab, UDM)){ ND_ASSERT_S(ECI); }
                    n++; c++; finalisec(ci, FALSE);
                }
            } //j
        } // i
        ct++;
    } // for     
    ND_FIN(); ERR:r�sultat = FALSE; if (gEssai >= NB_AUTO_ESSAIS)
    {
        journaliser("Erreur AutoTest (ligne %d): %s Cifr %d Ct %d CRC 0x%x.",
            gNoLigne, name, ci->cifr, ct, crc0); v�rifierEAs(ci->cifr, TRUE);
    } 
    finalisec(ci, FALSE); FIN: setSautDeLigne(TRUE); return r�sultat;
}

static BOOL DoAutoTestAlgorithms()
{
    NTSTATUS r = EXIT_SUCCESS; uint8 ea = 0; uint32 crc0;
    journaliser("DoAutoTestAlgorithm IsHwEnc? %d.", IsHwEncryptionEnabled());
    byte tab[2 * UDM] = {0}, *cc = (byte*)NDAllouer(DK0);
    const uint16 N = sizeof(tab) / getBlockSizeREM();    
    init0(gCi.cl�0, UDM); getDataTest(gCi.cl�0, DK0, TRUE); 
    getDataTest(cc, DK0, TRUE); getDataTest(tab, UDM, FALSE); 
    getDataTest(tab + UDM, UDM, FALSE);
    // CRC32
    crc0 = getCrc32(tab, sizeof(tab)); setKey0(gCi.cl�0);
    r = (crc0 == getCrc32(tab, sizeof(tab))); ND_ASSERT_S(r);
    // PRF
    ea = -1; r = test_prf(); ND_ASSERT_S(r);
    journaliser("validCiphers (per data unit).");
    r = validerCiphers(&gCi); ND_ASSERT_CS(r, ERR_CHIFFREMENT_INVALIDE);
    journaliser("%s succeeded.\n", __FILENAME__); 
    ND_FIN(); ERR: ND_JOURNALISER_ERREUR(__FILENAME__); if (ea > 0){ 
    journaliser("EA=%d.", ea); } r = gNDR�sultat; FIN:NDFree(cc); 
    NDV�riRefsOubli�es(FALSE); return NT_SUCCESS(r);
}

BOOL ex�cuterAutoTest()
{   // Appel�e par ndbuild.cmd (du projet CxRef).
    BOOL r = FALSE; if (bD�jaTest�){ return TRUE; } EnableHwEncryption(FALSE);   
    for (gEssai = 1; gEssai <= NB_AUTO_ESSAIS && ! r; gEssai++){
        r = DoAutoTestAlgorithms();
    }
    bD�jaTest� = r; return r;
}