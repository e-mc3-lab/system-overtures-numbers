
Daa.dll is a part of the user key. This module serves for the
creation of the file KeySpace.nd and after, the authentication.

On the algorithms in Doa.cpp: it is possible to disassemble and find the data
SALT, for example. Nevertheless, this task becomes complicated enough to
realize. It would be useful, despite all, to implement an 'EthX' application
would act as a filter and watch the operations. Like an antivirus and/or a
specialized firewall. As soon as this file is created, the source must be
deleted for each user (just keep the binary).

All commercial or public enterprise that would want to beneficiate of these
functionalities could modify DAA (Domain of Authentication Algorithm) in a
way that the reference source would not be known from the exterior... For
example, change the constants in arrays of the function 'sr', and other
functions. Integrate the module GenKey.cpp and use 'prf' (pseudo-random
function) at different places in the module 'Doa'. Then the retro-coding
would become more uncertain. In effect, it is having in hands the sources
that this work is possible and facilitated. The best would be that no third
party can access physically to these informations. But the fact that there
are at least two algorithms for each Cipher, renders the probability to
decrypt by brute force improbable enough: ~O(10^50) years.

Finally, the memory used by this module is freed. Then a part is reallocated
in the client application to reduce the coupling (and the scope of variables).
Only the content of a variable of type 'CONTEXTE_VOLUME' must be transfered.

DEBUG

a. Right-click on NWAdmin (in [Solution Explorer]), and select
   "Set as Startup Project".
b. Execute the application and create a user. Quit.
c. In Debugging, indicate: /aut /confg $(Configuration) nouvCodeUtil
d. Add a break point.
e. Execute again by pressing [F5] and [F11].
f. Reinitialize the arguments by default: /nouvl /confg $(Configuration)

Or utilize NWModule to verify the authentication.