/*
Copyright(c) 2024-2026 SCLE-CSES. Governed by the SCLE License 1.0; the
full text of which is contained in the file Licence.txt included in
NetDisq packages.
*/

#include "Memoire.h"
#include "Fichier.h"
#include "ModXyz.h"
#include "ProcesSpace.h"
#include "Random.h"
#include "Doa.h"
#include "AutoTest.h"

extern "C"
{

static BOOL gInitChiffre = FALSE;

void journaliserDaa()
{
    if ((gNDR�sultat != ERR_MOTPASSE_INVALIDE) &&
        (getNbDoaEssais() + 1 >= MAX_ESSAIS_NOUVG)){
        ND_JOURNALISER_ERREUR(NOM_DAA_DLL);
    }
}

NETDISQ_DLL_EXPORT BOOL execDoaAutoTest(){ return ex�cuterAutoTest(); }

void a(CONTEXTE_VOLUME* ctx); void b(CONTEXTE_VOLUME* ctx);

NETDISQ_DLL_EXPORT void nouveauDaa(CONTEXTE_VOLUME* ctx)
{
    const uint8 MAX_ESSAIS = 1; ND_ASSERT_CS(ctx, ERR_ARGUMENT_INVALIDE);
    {
        int i = 0; a(ctx); if ( ! NT_SUCCESS(ctx->r�sultat))
        {  
            for (; i < MAX_ESSAIS; i++){
                b(ctx); if (NT_SUCCESS(ctx->r�sultat)){ break; }
            }
        } /*if-for*/ ND_ASSERT_CS((i < MAX_ESSAIS), ERR_AUTHENTIFICATION);
    }
    ND_FIN(); ERR:if (ctx){ supprimerFichier0(ND_CC(ctx->nwModule.chemKeyNd)); }
    journaliserDaa(); FIN: if (ctx){ ctx->r�sultat = gNDR�sultat; }
}

NETDISQ_DLL_EXPORT void authentifier(CONTEXTE_VOLUME* ctx)
{
    const uint8 MAX_ESSAIS = 1; for (int i = 0; i < MAX_ESSAIS; i++)
    {
        b(ctx); if (NT_SUCCESS(ctx->r�sultat)){ break; }
    }
}
   
// Cipher.
uint8 genNoAlgorithmeChiffre()
{
    uint8 r; uint64 al�atoire = 0; uint i;
    uint n = (GetCurrentProcessId() % GetCurrentThreadId() % 13) + 1;
    const int N0 = NB_CIPHERS; uint germe = getEstampille(); srand(germe);
    r = (germe % 100) + 60; uint j = 0;
    for (j = 0; j < r; j++){ srand(r); srand(r); srand(r); }
    for (i = 0; i < n; i++, j++){
        al�atoire += (UI64(randx()) * UI64(j));
    } 
    r = UI8(al�atoire * UI64(randx()) % N0);
    while (r >= N0){ r = i++ % N0; } return r;
}

uint8 genNoModeXY(){ return ZTS; }

HANDLE ouvrirFichierCl�(const char cnf[], BOOL bNouveau)
{   // Ouvrir un fichier ou le cr�er vide. S'il existe, faire une copie ~nf.
    HANDLE hf = NULL; DWORD tailleFichier = 0; BOOL bCr�erNouveau = FALSE;
    char *ccfh1 = ND_CC(cnf), ccfh2[MAX_PATH] = {0};
    sprintf(ccfh2, "%s~", ccfh1); BOOL bExisteFichier1 = existe(ccfh1);
    if (bExisteFichier1)
    {
        if (bNouveau)
        {
            hf = CreateFileA(cnf, ACC�S_LECTURE_�CRITURE, MODE_PARTAG�,
                NULL, OPEN_EXISTING, 0, NULL); // Ouvrir.
            tailleFichier = GetFileSize(hf, NULL); fermerFichier(&hf);
            if (tailleFichier == 0)
			{
                bCr�erNouveau = TRUE; supprimerFichier(ccfh1);
            }
        }
    } else { bCr�erNouveau = TRUE; }
    hf = CreateFileA(cnf, ACC�S_LECTURE_�CRITURE, MODE_PARTAG�,
        NULL, (bCr�erNouveau ? CREATE_NEW : OPEN_EXISTING), 0, NULL);
    tailleFichier = GetFileSize(hf, NULL); if ( ! bCr�erNouveau &&
        ((tailleFichier >= 0) && (tailleFichier < ND_KEYFILE_SIZE)))
    {
        journaliser("Le fichier %s est de taille invalide.",
            NOM_KEYSPACE_ND); fermerFichier(&hf); hf = INVALID_HANDLE_VALUE;
    } else if (bExisteFichier1){ // TODO: le d�placer dans un dossier ?
        if (existe(ccfh2)){ supprimerFichier(ccfh2); }
    }
    return hf;
}

BOOL setDimensionFichierDaa(HANDLE hf)
{
    LARGE_INTEGER dimF = {0}; dimF.QuadPart = ND_KEYFILE_SIZE;
    if (( ! SetFilePointerEx(hf, dimF, NULL, FILE_BEGIN) ||
          ! SetEndOfFile(hf) || (SetFilePointer(hf,
            0, NULL, FILE_BEGIN) != 0))){ return FALSE; }
    ULONG dim = GetFileSize(hf, NULL); return (dim > 0);
}

void a(CONTEXTE_VOLUME* ctx)
{
    uint64 dimSecteur = UDM; char ccnfc[MAX_PATH] = {0}; HANDLE hv = NULL;
    strcpy(ccnfc, ctx->nwModule.chemKeyNd); const uint8 UN = ENUM_1; uint16 l;
    journaliser("\ncr�erDoa"); hv = ouvrirFichierCl�(ctx->nwModule.chemKeyNd,
        TRUE); ctx->r�sultat = ERR_SUCCESS;
    ND_ASSERT_CS((hv != INVALID_HANDLE_VALUE), ERR_FILE_OPEN);
    ctx->poign�e = hv; if ( ! setDimensionFichierDaa(hv)){
        ND_ASSERT_S(ERR_OBJECT_SIZE_WRONG); }
    l = ctx->nwModule.util.mpassd.longueur = UI16_STRLEN(ctx->nwModule.util
        .mpassd.texte); ND_ASSERT_CS((l > 0), ERR_MOTPASSE_INVALIDE);
    gNDR�sultat = ed(hv, 0, ND_KEYFILE_SIZE); ND_ASSERT_S(gNDR�sultat);
    init0(&ctx->ci, DIM_CI); init0(&ctx->eci, NDH); init0(&ctx->em16, NDH);
    if (ctx->nwModule.util.mpassd.nouveau){
        ctx->cifr = genNoAlgorithmeChiffre(); }
    ctx->ci.mode = genNoModeXY(); bm(ctx); ND_ASSERT_S(ctx->r�sultat); fN(ctx);
    ND_ASSERT_S(ctx->r�sultat); finalisec(&ctx->ci, FALSE); init0(&ctx->eci,
        NDH); init0(&ctx->em16, NDH); ND_FIN(); ERR: journaliserDaa();
FIN:fermerFichier(&ctx->poign�e); terminerHasard(TRUE);
    ctx->r�sultat = gNDR�sultat;
}

// Authentifier
void b(CONTEXTE_VOLUME* ctx) 
{
    HANDLE hfv = ouvrirFichierCl�(ctx->nwModule.chemKeyNd, FALSE);
    uint16 l; ctx->poign�e = hfv; l = ctx->nwModule.util.mpassd.longueur;
    ND_ASSERT_CS((hfv != INVALID_HANDLE_VALUE), ERR_FILE_OPEN);
    ND_ASSERT_CS((l >= PASSWORD_LEN_MIN_WARNING), ERR_MPASS_OU_ENT�TE);
    tac(ctx); ND_ASSERT_S(ctx->r�sultat);
    NDInit0(ctx->eci, NDH); NDInit0(ctx->em16, NDH); ND_FIN();
ERR:journaliserDaa(); ctx->r�sultat = gNDR�sultat;
FIN:fermerFichier(&ctx->poign�e); terminerHasard(TRUE);
}

NETDISQ_DLL_EXPORT void finDaa(CRYPTO_INFO* ci){ finalisec(ci, TRUE); }

BOOL APIENTRY DllMain(HMODULE hModule, DWORD ul_reason_for_call, LPVOID lpr){
    return TRUE;
}

} // extern "C"