/*
 Legal Notice: Some portions of the source code contained in this file were
 derived from the source code of Encryption. Modifications and additions to
 the original source code (contained in this file), and all other portions
 of this file are Copyright(c) 2003-2013 'Fondation TrueCrypt'. These are
 also governed by the SCLE License; the full text of which is contained
 in the file Licence 1.0.txt included in NetDisq packages. 2024-2026. */

#ifndef ND_HEADER_AUTOTEST
#define ND_HEADER_AUTOTEST

#include "Doa.h"

#ifdef __cplusplus
extern "C"
{
#endif

#define NOM_FCT_EX�CUTER_TEST   "execDoaAutoTest"

typedef struct 
{
    UCHAR key[DIM_32], texte[DIM_16], chiffre[DIM_16];

} ESSAI_CHIFFR;

NTSTATUS v�rifierEAs(uint8 cifr, BOOL bJournal);

NETDISQ_DLL_EXPORT BOOL execDoaAutoTest();
BOOL ex�cuterAutoTest();

#if defined(__cplusplus)
}
#endif

#endif // ND_HEADER_AUTOTEST