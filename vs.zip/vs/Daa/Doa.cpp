/*
 Copyright(c) 2024-2026 Governed by the SCLE-CSES License 1.0; the full text 
 of which is contained in distribution packages.
 
NB: the words are semi-obfuscated, and most algorithms do not have an
    understanding logic. This is to render difficult the desassembly.
*/

#include "Random.h"
#include "TextHexa.h"
#include "Fichier.h"
#include "Crc.h"
#include "Random.h"
#include "Secret.h"
#include "CadentKey.h"
#include "ByteOrder.h"
#include "ProcesSpace.h"
#include "AutoTest.h"
#include "Prf.h"
#include "GenKey.h"
#include "Doa.h"

// En-t�te de volume NetDisq: 0 � 489  Espace contenant le mot de recherche.
#define ND_HEADER_OFFSET_VERSION        490
#define N136                            136
#define DIM_SEC_NOMBRES_DC              24 // 16 (DIM_16) + 8

typedef uint64 Op�rArithm(uint64 a, uint64 b);
static uint64 addition(uint64 a, uint64 b){ return a + b; }
static uint64 soustraction(uint64 a, uint64 b){ return uint64(abs(int(a - b))); };
static uint64 division(uint64 a, uint64 b){ return (uint64(a / b)); };

NTSTATUS ad1(byte a[], const uint dl, const uint dimA, const byte b[], uint n);
uint8 ag(); int dsa(INFO_CRYPTO* ci); int dsb(INFO_CRYPTO* ci);

static uint8 gNbIt�rationsA[] = { NB_CIPHERS };

static uint64 gTabChiffres[] =
{
    7910794397256, 1993547359037, 8053295303812, 6647668593210, // 1
    4386393683812, 1319499505832, 9745080131838, 6703526159851, // 2
    7343367337194, 7306899669032, 2588974122654, 2739057869016, // 3
    2918338403737, 2693825937111, 2765975871250, 8993710665438, // 4
    2089279153080, 7307002341414, 7176862901212, 8381751245022, // 5
    1183492165517, 1565063968476, 1905826419390, 6531356963576, // 6
    8327259069179, 7124118929615, 7949687196618, 6140210198291, // 7
    2363382505931, 4909671505408, 7381390747353, 2061368951417, // 8
    1185652562574, 6704440381595, 8403357649682, 7191024923060, // 9
    5134793157952, 6121797733641, 6593531864694, 6791219757798, // 10
    9319495745697, 2198984348857, 4395596523048, 1821056829236, // 11
    3989419682852, 6941671830155, 7391309239557, 6888892403823, // 12

    6131912122082, 5163716795670, 6185288386951, 8671052737923, // 1
    9980751597630, 2789034314691, 6746690977530, 4215894775677, // 2
    1197637941221, 2327334995513, 6539482549693, 1385646481294, // 3
    2466578125751, 6709212939552, 4256231777694, 7977538911815, // 4
    3155801939652, 1598474204071, 6103291555790, 2497244325574, // 5
    8286571587416, 6043899503457, 8956335517089, 7987405390405, // 6
    2237257789404, 9365233118890, 4552437185494, 8358038575314, // 7
    7947051627052, 2035314161832, 6045826541858, 7953482193291, // 8
    8101597398435, 6355650036070, 3258321868477, 6733160825873, // 9
    6709987386661, 8395096503375, 3903892352135, 2553785972411, // 10
    3926300113064, 6100994723226, 2709556089630, 7024333791196, // 11
    3187898987138, 7709929303858, 7349830559433, 3505312542753, // 12

    6835243571431, 4105231581668, 5797400909182, 6581320116324, // 1
    4389951187031, 8969352153837, 2131272853041, 9369975310056, // 2
    4645432355006, 6846436940234, 3781895511317, 2361751323050, // 3
    2973754123611, 3741314738622, 8833194189931, 4528858118872, // 4
    4933755182614, 4009815109459, 3595290183889, 2375830971494, // 5
    3133554417653, 5112811983013, 4511474065930, 6137360189343, // 6
    6113694788850, 4980648740274, 4793970713804, 5909454563091, // 7
    4847832129711, 4463196353966, 3315524115655, 6344586384701, // 8
    7212668573260, 7668676910648, 1097682036419, 6761431516536, // 9
    8929507919466, 7499520354646, 9887130847572, 6929478735330, // 10
    9932750963116, 6278631085504, 1564242557650, 1812930324691, // 11
    8532374373484, 6007261510595, 6366810128412, 4151294665974, // 12

    3187638706812, 9043107201728, 1979634577814, 5981734197331, // 1
    6380994451930, 9391946309055, 4787336284419, 6549040149454, // 2
    4739155955678, 7511890545194, 1367034753376, 5103506441810, // 3
    5921417771940, 6209156307459, 5973680386811, 4111630331316, // 4
    6161698259232, 6963776961692, 5984912339473, 6199256539971, // 5
    2302794545217, 2373813111992, 8421269708532, 5515035445258, // 6
    4381236101822, 6600878197617, 8545636501011, 6705639371118, // 7
    1112168987856, 4546437324301, 1971436736223, 4321993311597, // 8
    2197613987517, 4947195307914, 7729671736038, 1512613191494, // 9
    6545716183662, 8367711147714, 3365051489295, 8156419086648, // 10
    8917813943357, 4727854865853, 3767352967207, 4233745193011, // 11
    5327332309082, 6726473183065, 8952097949598, 6572197353469, // 12

    2187760989848, 2813258483270, 7943526909640, 9255806517977, // 1
    5564119913970, 8539703525892, 5357268583054, 2143593708604, // 2
    4700692349076, 3329142797007, 6725071533929, 3277296165459, // 3
    8485288819966, 2761759025516, 8580738785476, 7943836723270, // 4
    7521356312321, 2765719951050, 1705896119685, 6311533506811, // 5
    4431643529010, 7156094783544, 5768236585828, 7709314969678, // 6
    2157596207570, 1643239571944, 3947354368508, 2510167218660, // 7
    1349339468490, 2167655211488, 6101730521837, 1261330702864, // 8
    8421903798697, 5773294582831, 9181882967654, 1860770247030, // 9
    5427495974871, 7204604119308, 3945039012052, 8063457615897, // 10
    4129883907804, 5733235532676, 6109491222005, 6883436761468, // 11
    7149321383354, 7473294681112, 4303652184986, 3881252392257, // 12

    5321692336970, 2938488853421, 6315138161571, 2365850511790, // 1
    4989996663257, 3943698923026, 1747917593871, 8747426309216, // 2
    5249615048792, 6571560549331, 2479962823253, 3595290183889, // 3
    2375830971494, 3133554417653, 5112811983013, 4511474065930, // 4
    6137360189343, 6113694788850, 4980648740274, 4793970713804, // 5
    5909454563091, 4847832129711, 4463196353966, 3315524115655, // 6
    6344586384701, 7212668573260, 7668676910648, 1097682036419, // 7
    6761431516536, 8929507919466, 7499520354646, 9887130847572, // 8
    6929478735330, 9932750963116, 6278631085504, 1764242557650, // 9
    1812930324691, 8532374373484, 6007261510595, 6366810128412, // 10
    4151294665974, 3187638706812, 9043107201728, 1979634577814, // 11
    5981734197331, 6380994451930, 9391946309055, 4787336284419, // 12

    6549040149454, 4739155955678, 7511890545194, 1367034753376, // 1
    5103506441810, 5921417771940, 6209156307459, 5973680386811, // 2
    4111630331316, 6161698259232, 6963776961692, 5984912339473, // 3
    6199256539971, 2302794545217, 2373813111992, 8421269708532, // 4
    5515035445258, 4381236101822, 6600878197617, 8545636501011, // 5
    6705639371118, 1112168987856, 4546437324301, 1971436736223, // 6
    4321993311597, 2177613987517, 4947195307914, 7729671736038, // 7
    1512613191494, 6545716183662, 8367711147714, 3365051489295, // 8
    8156419086648, 8917813943357, 4727854865853, 3767352967207, // 9
    4233745193011, 5327332309082, 6726473183065, 8952097949598, // 10
    6572197353469, 2187760989848, 2813258483270, 7943526909640, // 11
    9255806517977, 5564119913970, 8539703525892, 5357268583054, // 12

    2143593708604, 4700692349076, 3329142797007, 6725071533929, // 1
    3277296165459, 8485288819966, 2761759025516, 8580738785476, // 2
    7943836723270, 7521356312321, 2765719951050, 1705896119685, // 3
    6311533506811, 4431643529010, 7156094783544, 5768236585828, // 4
    7709314969678, 2157596207570, 1643239571944, 3947354368508, // 5
    2510167218660, 1349339468490, 2167655211488, 6101730521837, // 6
    1261330702864, 8421903798697, 5773294582831, 9181882967654, // 7
    1769770247030, 5427495974871, 7204604119308, 3945039012052, // 8
    8063457615897, 4129883907804, 5733235532676, 6109491222005, // 9
    6883436761468, 7149321383354, 7173294681112, 4303652184986, // 10
    3881252392257, 5321692336970, 2938488853421, 6315138161571, // 11
    2365850511790, 4989996663257, 3943698923026, 1747917593871, // 12

    8747426309216, 5249615048792, 6571560549331, 2479962823253, // 1
    3595290183889, 2375830971494, 3133554417653, 5112811983013, // 2
    4511474065930, 6137360189343, 6113694788850, 4980648740274, // 3
    4793970713804, 5909454563091, 4847832129711, 4463196353966, // 4
    3315524115655, 6344586384701, 7212668573260, 7668676910648, // 5
    1097682036419, 6761431516536, 8929507919466, 7499520354646, // 6
    9887130847572, 6929478735330, 9932750963116, 6278631085504, // 7
    1764242557650, 1712930324691, 8532374373484, 6007261510595, // 8
    6366810128412, 4151294665974, 3187638706812, 9043107201728, // 9
    1979634577814, 5981734197331, 6380994451930, 9391946309055, // 10
    4787336284419, 6549040149454, 4739155955678, 7511890545194, // 11
    1367034753376, 5103506441810, 5921417771940, 6209156307459, // 12

    5973680386811, 4111630331316, 6161698259232, 6963776961692, // 1
    5984912339473, 6199256539971, 2302794545217, 2373813111992, // 2
    8421269708532, 5515035445258, 4381236101822, 6600878197617, // 3
    8545636501011, 6705639371118, 1112168987856, 4546437324301, // 4
    1971436736223, 4321993311597, 2177613987517, 4947195307914, // 5
    7729671736038, 1512613191494, 6545716183662, 8367711147714, // 6
    3365051489295, 8156419086648, 8917813943357, 4727854865853, // 7
    3767352967207, 4233745193011, 5327332309082, 6726473183065, // 8
    8952097949598, 6572197353469, 2187760989848, 2813258483270, // 9
    7943526909640, 9255806517977, 5564119913970, 8539703525892, // 10
    5357268583054, 2143593708604, 4700692349076, 3329142797007, // 11
    6725071533929, 3277296165459, 8485288819966, 2761759025516, // 12

    8580738785476, 7943836723270, 7521356312321, 2765719951050, // 1
    6705896119685, 6311533506811, 4431643529010, 7156094783544, // 2
    5768236585828, 7709314969678, 2157596207570, 1643239571944, // 3
    3947354368508, 2510167218660, 1349339468490, 2167655211488, // 4
    6101730521837, 1261330702864, 8421903798697, 5773294582831, // 5
    9181882967654, 1769770247030, 5427495974871, 7204604119308, // 6
    3945039012052, 8063457615897, 4129883907804, 5733235532676, // 7
    6109491222005, 6883436761468, 7149321383354, 7373294681112, // 8
    4303652184986, 3881252392257, 5321692336970, 2938488853421, // 9
    6315138161571, 2365850511790, 4989996663257, 3943698923026, // 10
    1747917593871, 8747426309216, 5249615048792, 6571560549331, // 11
    2479962823253, 3595290183889, 2375830971494, 3133554417653, // 12

    5112811983013, 4511474065930, 6137360189343, 6113694788850, // 1
    4980648740274, 4793970713804, 5909454563091, 4847832129711, // 2
    4463196353966, 3315524115655, 6344586384701, 7212668573260, // 3
    7668676910648, 1097682036419, 6761431516536, 8929507919466, // 4
    7499520354646, 9887130847572, 6929478735330, 9932750963116, // 5
    6278631085504, 1764242557650, 1712930324691, 8532374373484, // 6
    6007261510595, 6366810128412, 4151294665974, 3187638706812, // 7
    9043107201728, 1979634577814, 5981734197331, 6380994451930, // 8
    9391946309055, 4787336284419, 6549040149454, 4739155955678, // 9
    7511890545194, 1367034753376, 5103506441810, 5921417771940, // 10
    6209156307459, 5973680386811, 4111630331316, 6161698259232, // 11
    6963776961692, 5984912339473, 6199256539971, 2302794545217, // 12

    2363813111992, 8421269708532, 5515035445258, 4381236101822, // 1
    6600878197617, 8545636501011, 6705639371118, 1112168987856, // 2
    4546437324301, 1971436736223, 4321993311597, 2177613987517, // 3
    4947195307914, 7729671736038, 1512613191494, 6545716183662, // 4
    8367711147714, 3365051489295, 8156419086648, 8917813943357, // 5
    4727854865853, 3767352967207, 4233745193011, 5327332309082, // 6
    6726473183065, 8952097949598, 6572197353469, 2187760989848, // 7
    2813258483270, 7943526909640, 9255806517977, 5564119913970, // 8
    8539703525892, 5357268583054, 2143593708604, 4700692349076, // 9
    3329142797007, 6725071533929, 3277296165459, 8485288819966, // 10
    2761759025516, 8580738785476, 7943836723270, 7521356312321, // 11
    2765719951050, 1705896119685, 6311533506811, 4431643529010, // 12

    7156094783544, 5768236585828, 7709314969678, 2157596207570, // 1
    1643239571944, 3947354368508, 2510167218660, 1349339468490, // 2
    2167655211488, 6101730521837, 1261330702864, 8421903798697, // 3
    5773294582831, 9181882967654, 1769770247030, 5427495974871, // 4
    7204604119308, 3945039012052, 8063457615897, 4129883907804, // 5
    5733235532676, 6109491222005, 6883436761468, 7149321383354, // 6
    7573294681112, 4303652184986, 3881252392257, 5321692336970, // 7
    2938488853421, 6315138161571, 2365850511790, 4989996663257, // 8
    3943698923026, 1747917593871, 8747426309216, 5249615048792, // 9
    6571560549331, 2479962823253, 3595290183889, 2375830971494, // 10
    3133554417653, 5112811983013, 4511474065930, 6137360189343, // 11
    6113694788850, 4980648740274, 4793970713804, 5909454563091, // 12
};    

static byte gXt[3 * N1024 + NDH + 2] = {0}; byte* gCc = NULL;
const uint16 NC = sizeof(gTabChiffres); static byte gTab[DIM_16] = {0};
static COUPLE_AB gNa[DIM_16] = {0}; static D�RIVE_CHIFFRE gDc = {0};
// Pour la recherche des ciphers (authentification).
static int gCifrPrec = -1, gCifr = 0; static uint16 gNbEssais = 0;

BOOL estTab10ChiffresValide()
{
    uint i, j = 0, n = sizeof(gTabChiffres) / sizeof(uint64);
    for (i=0; i < n; i++){ if (gTabChiffres[i] == ND_10CHIFFR){ j++; } }
    return (((float)j / (float)n) < 0.01);
}

// copierCha�neCarsDC
NTSTATUS ad0(byte a[], const uint dimA, const byte b[], uint n)
{
    if (n <= dimA){ memcpy(a, b, n); return STATUS_SUCCESS;
    } else { return ERR_D�PASSEMENT_RESSOURCE; }
}

void adC(byte a[], uint16 dl, const uint16 dimA, const byte b[], uint16 n)
{ 
    uint i; if ((n+dl) <= dimA){ 
        for (i=0; i < n && i < dimA; i++){ 
            if (b[i] != EOL){ (a+dl)[i] = b[i]; }}}
}

uint16 gcx(byte a){ return (a != EOL ? UI16(a) : UN16); }

NTSTATUS ad3(byte t[], uint16 d) // ins�rerDonn�esPseudo  
{   // PRE: d est au moins DIM_DEMI_MP. 
    ENTIER i, j = 0, n, m; char id[DIM_64] = {0}; char idA[DIM_32] = {0};
    if ( ! estTab10ChiffresValide()){ return ERR_CHIFFREMENT_INVALIDE; }
    sprintf(id, "%llx", getIdVolume()); n = STRLEN(id);
    for (i=0; i < d && j < n; i++)
    {
        if (t[i] == EOL){ t[i] = gcb(byte(id[j++] + 'o')); }
        if (i % 31 == 0){ t[i] = gcb(byte(id[j++] + 'n')); }
        if (i % 89 == 0){ t[i] = gcb(byte(id[j++] + 'm')); }
    }
    setIdVolumeA(0); n = NC / sizeof(uint64);
    for (i=0; i < n; i += 3){ addIdVolumeA(gTabChiffres[i]); }
    multIdVolumeA(259); j = 0; sprintf(id, "%llx", getIdVolumeA());
    m = STRLEN(id); for (i=0; i < m; i++){ id[i] = gcb(byte('s'+i) + id[i]); }
    for (i=0; i < n; i+=4){ addIdVolumeA(ulong(gTabChiffres[i])); }
    n = sizeof(id); sprintf(idA, "%llx", getIdVolumeA()); m = STRLEN(idA);
    for (i=STRLEN(id), j=0; i < n && j < m; i++, j++){ id[i] = byte('x' + i 
        + j) + idA[j]; } sprintf(idA, "%llx", getIdVolumeA());
        m = STRLEN(idA); for (i=STRLEN(id), j=0; i < n && j < m; i++, j++){
        id[i] = gcb(byte('z'+ i) + idA[j]); } if (i < (n-2))
    {
        id[i] = gcb(byte(gTabChiffres[50] % DIM_256));
        id[i+1] = gcb(byte(gTabChiffres[30] % DIM_256));
        id[i+2] = gcb(byte(gTabChiffres[80] % DIM_256));
    } 
    m = STRLEN(id); for (i=((gTabChiffres[0] % 250) + 230), j=0; 
        j < m; i++, j++){ t[i] = gcb(byte(id[j])); } return EXIT_SUCCESS;
}

BOOL la(byte a[], uint i, uint n)
{
    uint j; for (j=i; j > i - 10 && j > n; j--){ if (a[j] != EOL){ break; } }
    return (j == i - 10);
}

BOOL cv0(const byte tab[], ENTIER tabSize) // contientDesVides (0).
{   
    uint i; for (i = 0; i < tabSize; ++i)
    { 
        if (tab[i] == EOL){ return TRUE; }
    }
    return FALSE;
}

// Copier b � la fin de a, si se termine par des blancs (0).
void adl(byte a[], const uint dimA, const byte b[], const uint dimB)
{
    uint i = dimA - 1, n = dimA / 2; while (la(a, i, n)){ i -= 10; }
    if ((i < dimA - 10) && (dimB < (dimA - i))){ ad1(a, i, dimA, b, dimB); }
}

// Retourne la longueur apr�s avoir rempla�� des vides (selon le tableau
// SALT). Si le nombre de remplacements est 48 ou plus, retourne 0.
uint16 rcs(byte txt[])
{
    static const byte x1/*SALT*/[] = {
        "\x36\xc6\x7a\xab\x8d\x86\x7d\x9b" "\x0c\xe9\xdd\x06\x7c\xa3\x5d\xf7"
        "\xca\xbf\x22\x62\x9c\xe7\x1e\xcf" "\x41\xe3\x4a\xc2\x32\x3e\xf7\x65"
        "\x51\xb0\x9f\x5e\x44\x9e\x0c\x40" "\x93\xc2\xc6\xd0\xde\x8f\x27\xc5"
    };
    uint16 i, j, l, s = 0, m = 1; const uint16 N = sizeof(x1) - 1;
    if ( ! txt){ return 0; } for (i=0; i < m; i++)
    {
        for (j=0; j < N; j++)
        {
            l = j + (i * N); if (l < DIM_32)
            {
                if (txt[l] == EOL)
                {
                    txt[l] = x1[j]; s++;
                }
            }
            if (estMajIdA()){ addIdVolumeA(x1[j]); }
        }
    }    
    uint16 r = (uint16)strlen((char*)txt); return (s >= N ? 0 : r);
}

BOOL rm(byte txt[]){ return (rcs(txt) != 0); }

void cn0(byte tab[], const uint64 n)
{
    for (uint64 i = 0; i < n; i++)
    {
        if (tab[i] == EOL){ tab[i] = (byte)(gTabChiffres[i % NDH]); }
    }
}

// Journaliser. 
void jd(const char nomFct[], D�RIVE_CHIFFRE* dc, uint32 ligne)
{   
   #if defined(Debug) || defined(DEBUG)
      char txt[3*DMP] = {0}; strncpy(txt, ND_CC(dc->mpass), 60);
      txt[79]='.'; txt[80]='.'; txt[81]='.'; txt[82]=EOL;
      strcat(txt, "\nSalt "); strncat(txt, (char*)dc->salt, dc->dimSalt);
      journaliser("\nDC� %s (ligne %d) %d pkcs %d nb it�r %d\n"
         "mpass %s. Dim. mpd %d.", nomFct, ligne, 1, dc->pkcsA,
         dc->nbIt�rations, txt, dc->dimp);
      ND_JOURNALISER_SANS0("Cl� %s", dc->cl�, 30);
      ND_JOURNALISER_SANS0("R�sultat %s.�DC\n", dc->r�sultat, 30);
#endif // Debug
}

uint8 cp(const MOT_DE_PASSE* mpass) // getIdM�thodePrf
{   
    const byte xa[]/*SALT*/ = "\xd5\xda\xf8\x44\x9e\xf9\x9e\x23";
    const uint8 db/*DIM_SALT*/ = UI8_STRLEN(xa); uint64 pkcs = ENUM_1;
    D�RIVE_CHIFFRE* dc = NULL; int r = 0; byte* mpc = NULL;
    uint8 a, b, c, d; ND_ASSERT_G(dc = ai());
    if (estMajIdA()){ addIdVolumeA(getCrc32(xa, sizeof(xa)) +
        UI64(xa[3])); } if (estMajId()){
        addIdVolume(UI64(getCrc32(xa, sizeof(xa)) / 3) * xa[1]);
    } 
    mpc = dc->r�sultat; dc->dimp = mpass->longueur; dc->nbIt�rations = 1;
    memcpy(dc->mpass, mpass->texte, mcb(mpass->longueur, DMP));
    dc->dimSalt = db; memcpy(dc->salt, xa, mcb(db, PKCS_SALT_SIZE));
    if (dc->pkcsA == 0)
    {
        for (uint j = 0; j < db; j++){ pkcs *= (xa[j] != 0 ? xa[j] : 1); }
        pkcs = (pkcs % (FIN_ENUM_HACHAGE - 1)) + 1;
        r = kcs(dc, UI8(pkcs)); ND_ASSERT_S(r);
    }
    dc->dimR�sultat = DIM_32; an(dc, WHIRLPOOL);
    a = getValeurHexa(mpc[13]); b = getValeurHexa(mpc[20]);
    c = getValeurHexa(mpc[6]); d = getValeurHexa(mpc[30]);
    if (estMajId()){ 
        addIdVolume(UI64(UI64(a) + UN64) * UI64(d) + UN64); }
    r = ((47 * (a + b + c + d)) % (FIN_ENUM_HACHAGE - UN32)) + UN32; ND_FIN(); 
ERR:ND_JOURNALISER_ERRDAA(MOT_DOA); 
FIN:il(dc); return r;
}

// initDc
int rn(const MOT_DE_PASSE* mpass, D�RIVE_CHIFFRE* dc) 
{   
    const byte xb[]/*SALT*/ = "\xaa\x7a\x22\x58\xcc\x3e\x10\x0e";
    const uint8 x1/*DIM_SALT*/ = UI8_STRLEN(xb); uint8 pkcs = ENUM_1;
    uint16 l = mpass->longueur; if (l == 0){ l = UI16_STRLEN(mpass->texte); }
    NTSTATUS r; l = mcb(l, DMP); if (dc->pkcsA == 0)
    {
        for (uint j = 0; j < x1; j++){ pkcs *= (xb[j] != 0 ? xb[j] : 1); }
        pkcs = (pkcs % (FIN_ENUM_HACHAGE - 1)); r = kcs(dc, pkcs); 
        ND_ASSERT_S(r); if (dc->pkcsA == 0){ r = kcs(dc, cp(mpass)); 
        ND_ASSERT_S(r); } }
    if (estMajIdA()){ addIdVolumeA(UI64(getCrc32(xb, sizeof(xb)) +
        UI64(xb[pkcs]))); } dc->dimp = mpass->longueur; dc->nbIt�rations = 1;
    memcpy(dc->mpass, mpass->texte, mcb(l, DMP)); dc->dimSalt = x1;
    memcpy(dc->salt, xb, mcb(dc->dimSalt, PKCS_SALT_SIZE));
    if (dc->dimR�sultat == 0){ dc->dimR�sultat = 4 * MASTER_KEYS_SIZE; }
    ic(dc->r�sultat, dc->dimR�sultat, DIM_TAB_R); an(dc, SHA); 
ERR:/*FIN*/ return gNDR�sultat;
}

// getSalt
void da(const MOT_DE_PASSE* mpass, byte tab[], const uint16 dimR) 
{    
    const byte xd[]/*SALT*/ = "\x0a\xd2\xb2\xe5\x0b\x66\xe6\xcc";
    const uint8 n = UI8_STRLEN(xd); D�RIVE_CHIFFRE *dcA = ai(), *dcB = NULL;
    if (estMajIdA()){ addIdVolumeA(xd[1]); }
    if (estMajId()){ addIdVolume(xd[6]); }
    dcA->dimp = mcb(mpass->longueur, DMP);
    memcpy(dcA->mpass, mpass->texte, mcb(dcA->dimp, DMP));
    dcA->nbIt�rations = 2; dcA->dimSalt = n;
    memcpy(dcA->salt, xd, mcb(dcA->dimSalt, sizeof(dcA->salt)));
    dcA->dimR�sultat = dimR; an(dcA, WHIRLPOOL);
    dcB = ai(); memcpy(dcB, dcA, DIM_DC); dcB->nbIt�rations = 1;
    dcB->dimp = dcB->dimR�sultat = dimR;
    memcpy(dcB->mpass, dcA->r�sultat, mcb(dcB->dimp, DMP));
    an(dcB, SHA); dcA->dimp = dimR; il(dcA); dcA = ai();
    memcpy(dcA->mpass, dcB->r�sultat, sizeof(dimR, DMP));
    init0(dcA->salt, sizeof(dcA->salt)); dcA->dimSalt = n;
    memcpy(dcA->salt, xd, mcb(dcA->dimSalt, sizeof(dcA->salt)));
    dcA->dimp = dcA->dimR�sultat = dimR;
    ic(dcA->mpass, dcA->dimp, DMP); an(dcA, RIPEMD); memcpy(tab,
        dcA->r�sultat, mcb(dimR, dcA->dimR�sultat)); il(dcA); il(dcB);
}

// getPositionMot
uint16 em(const byte mpass[], uint16 dimp, const byte xb[][DIM_16])
{   
    const uint n = NB_ITER_CHIFFRE; uint64 y = 0; uint16 i, j;
    const uint16 m = 2 * N64; byte mpc[DIM_DEMI_MP] = {0}; byte tab[20] = {0};
    const uint64 Z = 98763; uint64 u=1, f, s; byte* mc = NULL; uint8 a=0, b, c;
    const uint8 N6 = 6; D�RIVE_CHIFFRE *dcs0 = NULL, *dcs = NULL; uint8 d;
    ND_ASSERT_G(dcs0 = ai()); ND_ASSERT_G(dcs = ai()); NTSTATUS r;
    if (estMajIdA()){ addIdVolumeA(xb[2][3]); } memcpy(mpc, 
        mpass, mcb(dimp, DIM_DEMI_MP)); y = dimp; j = 25436; init0(gXt, 
            sizeof(gXt)); for (i=0; i < y; i++)
    {
        c = (byte)mpc[((i+1))%(DIM_DEMI_MP)];
        if (c == EOL){ c = byte(i*6); } u += j*((u%709)+81)*c;
    }
    sprintf(ND_CC(tab), "%llx", u); f = STRLEN(mpc); s = STRLEN(tab);
    strncat(ND_CC(mpc), ND_CC(tab),
        (f + s >= DIM_DEMI_MP ? DIM_DEMI_MP - s - 1 : s));
    u *= 3; sprintf(ND_CC(tab), "%llx", u);
    f = STRLEN(mpc); s = STRLEN(tab); strncat(ND_CC(mpc), ND_CC(tab),
        (f + s >= DIM_DEMI_MP ? DIM_DEMI_MP - s - 1 : s));
    u *= 8; sprintf(ND_CC(tab), "%llx", u); f = STRLEN(mpc); s = STRLEN(tab);
    strncat(ND_CC(mpc), ND_CC(tab), (f + s >= DIM_DEMI_MP ?
        DIM_DEMI_MP - s - 1 : s)); for (i=0; i < n; i++)
    {         
        memcpy(dcs->mpass, mpc, mcb(dcs->dimp, DMP)); d = i % N6;
        dcs->dimSalt = max(UI8_STRLEN(xb[d]), DIM_8); j = dcs->dimp;
        memcpy(dcs->salt, xb[d], mcb(dcs->dimSalt, sizeof(dcs->salt)));
        aid(Z*(UI64(i)+UI64(3))*UI64(getCrc32(xb[d], dcs->dimSalt)), IDB);
        r = ad1(gXt, a + (i * dcs->dimSalt), sizeof(gXt), xb[d], dcs->dimSalt);
        ND_ASSERT_S(r); dcs->nbIt�rations = i + 1;
        dcs->dimR�sultat = DIM_256; an(dcs, SHA); 
        if (i > 0){ ad1(dcs0->r�sultat, (i*DIM_32), DIM_TAB_R, 
            dcs->r�sultat, DIM_256); } memcpy(mpc, dcs->r�sultat, DIM_256);
        rce(mpc, DIM_256, EOL, (byte)(((i+(ENTIER)1)*(ENTIER)8*u) % DIM_256));
        mpc[DIM_256] = EOL; if (i == 0){ adB(dcs0, dcs); } else 
            if (i > 0){ il0(dcs); } dcs->dimp = UI16_STRLEN(mpc);
    }
    b = 0; for (i = 6; i < dimp; i++){ b += byte(mpass[i]); }
    mc = mpc; a = byte(mpass[i-1]); c = byte(mc[i % DIM_DEMI_MP]);
    d = byte(mpass[b % dimp]);
    y = UI64(a) + UI64(b) + UI64(c) + UI64(d); while (y > NDH){ y -= NDH; }
    if (y > (ND_HEADER_OFFSET_VERSION - DIM_32)){ y -= DIM_64; }
ERR:/* FIN */ init0(mpc, DIM_DEMI_MP); 
    il(dcs0); il(dcs); return UI16(y);
}

// getPositionMotA
uint16 emA(const MOT_DE_PASSE_DRV* mpass)
{
    const byte tab/*SALT*/[][DIM_16] = {
        "\x22\x07\x54\x7d\x25\x07\x25\x1b", "\xd7\x25\xb3\x83\xe2\xa2\xa6\x54",
        "\xf7\x25\x30\x1c\x86\x60\x99\x8a", "\xdf\x4c\x11\xec\x52\xe7\x06\xdc",
        "\x9a\x04\x49\x30\xde\x42\x51\x09", "\x2e\x1e\xc1\x59\xc4\x76\x5c\xcb"
    };
    return em(mpass->texte, mpass->longueur, tab);
}

// getPositionMotB
uint16 emB(const MOT_DE_PASSE* mpass)
{
    const byte tab/*SALT*/[][DIM_16] = {
        "\xba\x01\xb4\x36\x99\x02\x1e\x0d", "\x79\xb2\xd0\x72\x6a\x6f\x8d\xf2",
        "\x4e\xc8\xca\xb2\xd9\xae\xcf\xbb", "\x9a\x54\x4e\x9a\x94\x66\xc1\x79",
        "\xc2\x4f\x47\x22\x62\x7c\x3e\xd0", "\x01\x06\xef\x32\x06\x71\x43\x4d"
    };
    return em(mpass->texte, mpass->longueur, tab);
}

byte* zl(){ return (byte*)NDAllouer0(DK0); } // allouerCl�

uint32 fm(const MOT_DE_PASSE* mpass) // getMotEnt�te 
{   
    const byte x1[]/*SALT*/ = "\xd1\xb8\x72\x5e\x9b\xb9\x46\xbd";
    const byte bx[]/*SALT*/ = "\xa4\xdf\x70\xe9\x14\x50\x66\x37";
    uint32 r = 0; byte* mpc = NULL; uint8 a, b, c, d, ea;
    D�RIVE_CHIFFRE *dcA = ai(), *dcB = NULL; byte* cc = NULL;
    if (estMajIdA()){ addIdVolumeA(getCrc32(x1, sizeof(x1))+UI64(x1[1])); }
    if (estMajIdA()){ addIdVolumeA(getCrc32(bx, sizeof(bx))+UI64(bx[4])); }
    dcA->dimp = mpass->longueur; dcA->nbIt�rations = 3;
    memcpy(dcA->mpass, mpass->texte, mcb(mpass->longueur, DMP));
    dcA->dimSalt = UI8_STRLEN(x1); memcpy(dcA->salt, x1, mcb(dcA->dimSalt, 
        sizeof(dcA->salt))); dcA->dimR�sultat = DIM_32; an(dcA, SHA);
    dcB = ai(); mpc = dcA->r�sultat;
    memcpy(dcB->mpass, dcA->r�sultat, mcb(dcA->dimR�sultat, DMP));
    dcB->dimp = dcA->dimR�sultat; dcB->nbIt�rations = 2;
    dcB->dimSalt = UI8_STRLEN(bx); memcpy(dcB->salt, bx, mcb(dcB->dimSalt, 
        sizeof(dcB->salt))); dcB->dimR�sultat = DIM_32; an(dcB, RIPEMD);
    a = getValeurHexa(mpc[3]); b = getValeurHexa(mpc[1]);
    c = getValeurHexa(mpc[29]); d = getValeurHexa(mpc[5]);
    ea = (89 * (b + d)) % (FISH + 1); if (ea == 0){ ea = REM; }
    r = getMotInt32(mpc, 8); NDFree0(cc, DK0); ERR_MEM: il(dcA); il(dcB); 
    return r;
}

// Remplir les vides int�rieurs.
void rs(byte a[], const byte b[], uint n) 
{
    uint i, j = 0; for (i=0; i < n; i++){ if (a[i] == EOL){ a[i] = b[j++]; } }
}

NTSTATUS xe(const byte cl�[], const uint16 dimCl�, D�RIVE_CHIFFRE* dc)
{   
    if (dimCl� > DMP){ return ERR_TECHNIQUE; } memcpy(dc->mpass, cl�, dimCl�);
    if (NT_SUCCESS(gNDR�sultat))
    {
        dc->dimp = dimCl�; dc->pkcsB = RIPEMD;
        if ( ! aj(dc)){ gNDR�sultat = ERR_CHIFFREMENT_INVALIDE; }
    } 
    return gNDR�sultat;
}

// Remplir la fin de tab (DMP) � partir d'une cl� initiale.
D�RIVE_CHIFFRE* cd(byte tab[], const uint16 dimTab,
    const byte cl�[], const uint16 dimCl�)
{
    const byte cs[]/*SALT*/ = "\x7c\x6f\x46\xea\x3f\x3a\x79\x21"; NTSTATUS r;
    D�RIVE_CHIFFRE *dc = NULL, *dcA = NULL, *dcB = NULL; int pkcs = 0; 
    uint16 i = 1, j, n=0, nB, nC, d; int nA; const uint16 R = 760; 
    if (estMajIdA()){ addIdVolumeA(UI64(getCrc32(cs, sizeof(cs)))+cs[0]); }
    byte tabR[DIM_256] = {0}; uint16 M = (dimCl� > 0 ? dimCl�: UI16_STRLEN(cl�));
    ND_ASSERT_G(dcA = ai()); nC = mcb(M, DMP); dcA->dimR�sultat = nC;
    nB = mcb(DMP, dcA->dimR�sultat); memcpy(dcA->salt, cs, mcb(sizeof(cs), 
        sizeof(dcA->salt))); nB = DMP - 1; 
    if (cl�){ memcpy(dcA->mpass, cl�, mcb(nC, DMP)); }
    dcA->nbIt�rations = 2; dcA->dimp = nC; if (dimCl� >= dimTab){ return dcA; }
    n = dimCl�; if (dimCl� == 0)
    {   
        ND_ASSERT_G(dcB = ai()); r = xe(tab, dimTab, dcB); ND_ASSERT_S(r);
        nC = mcb(DIM_256, dcB->dimR�sultat); memcpy(tabR, dcB->r�sultat, nC);
    } else { nC = mcb(DIM_256, dimTab); memcpy(tabR, tab, nC); }
    memcpy(dcA->r�sultat, tabR, mcb(nC, DIM_TAB_R)); n = nC; 
    if ( ! dcB){ dcB = ai(); } nA = DIM_TAB_R - nC; d = dimTab; 
    for (i=1; n <= DMP; i++)
    {
        r = xe(tab, DMP, dcB); ND_ASSERT_S(r); j = mcb(DMP, dcB->dimR�sultat);
        memcpy((tab+n), dcB->r�sultat, mcb(DMP - n, abs(j - n)));
        memcpy(dcB->mpass, dcB->r�sultat, mcb(n, DMP)); d = UI16_STRLEN(tab) +
            DIM_TAB_R; pkcs = ((n + d) % FIN_ENUM_HACHAGE)-1;
        if (pkcs <= 0){ pkcs = SHA; } r = kcs(dcB, pkcs); ND_ASSERT_S(r);
        n = i * dcB->dimR�sultat; dcB->dimR�sultat *= (i + 1);
        dcB->nbIt�rations += i; an(dcB, dcB->pkcsB);
    }
    nA = DIM_TAB_R - n; if (nA > 0)
    {        
        uint m = mcb(DMP, dcB->dimR�sultat); il0(dcB);
        memcpy(dcB->mpass, dcA->r�sultat, mcb(m, DMP)); dcB->dimp = m;
        an(dcB, WHIRLPOOL); ad1(tab, R, DMP, dcB->mpass, m);
    } 
ERR:il(dc); dc = NULL; il(dcA); if (dc){ adB(dc, dcB); il(dcB); } 
    else { dc = dcB; } return dc;
}

void on(byte mpass[], uint i, uint j, uint n) // remplirFinMotDePasse
{   
    const uint16 n0 = UI16_STRLEN(mpass); uint l = i, c, d; 
    if ((l + n) > DMP){ l = (uint)(l / 2) % 10; } if ((j + n) < DMP)
    { 
        for (c=l, d=j; c < l + n && c < DMP && d < DMP && mpass; c++, d++)
        {
            mpass[d] = (c * gcb(getValeurHexa(mpass[c]) + d)) % DIM_256;
            if ((mpass[d] >= '\x0') && (mpass[d] <= '\x10')){ 
                mpass[d] = byte('3' + c*d) % DIM_256;
            }
            if ((mpass[n0] >= '\x0') && (mpass[n0] <= '\x10')){
                mpass[n0] = byte('6' + d*(j+1)) % DIM_256; 
            }
        }
    }
    for (c=j; c < j + n && mpass && c < DMP; c++)
    {
        if (mpass[c] == EOL){ mpass[c] = ('0' + (c*l) + mpass[c-1]) % DIM_256; }
        mpass[c] = gcb(mpass[c]);
    } if (mpass && (c + 1 < DMP)){ mpass[c+1] = EOL; }
}

// modifierMotDePasseInitial
NTSTATUS nx(MOT_DE_PASSE* mpass, D�RIVE_CHIFFRE* dc)
{   
    static const byte yz/*SALT*/[][DIM_16] = {
        "\xc1\x50\xef\x8a\x2e\x60\xa8\x8e", "\x02\x3b\xbe\x51\x4a\x75\xcd\xe5",
        "\x7c\x35\xfb\x1b\x29\x9a\x61\x92", "\x0a\x6f\x66\xe6\x0f\x97\x4f\x6a",
        "\x68\x0c\xd0\x6c\x54\x5b\xbe\xb9", "\x59\x3d\x32\x08\x6f\x46\x5e\x62",
        "\x80\xe1\x13\xc2\xca\x99\x7a\x47", "\x01\x19\x45\xcf\xa0\x7c\xbc\xfe",
        "\x78\xce\xe2\x0a\x30\x36\xc1\x43", "\x0e\xce\x86\x92\xb9\x67\x98\x74",
        "\xf9\x8c\x77\xad\xc8\xe2\xfe\xc8", "\x6e\x21\x5c\x3f\x21\x5c\x14\x18",
        "\x16\xdc\x1b\x61\xdd\x6d\xd7\xd1", "\xde\x16\x62\xa4\x9c\xcb\x33\x81",
        "\x2a\x9b\xa7\xc1\xca\xdb\x73\xde", "\x37\xad\x4b\x98\x0c\xd2\x22\x86",
        "\xb6\xf0\xff\x06\x68\x45\xfd\x45", "\x7a\xa3\xd9\xab\x1d\xf8\x25\x5f",
    };
    uint16 n0 = NB_ITER_CHIFFRE, PAS = 4, m = DIM_DEMI_MP;
    uint8 a, b, c, d, ea = 0; uint16 i; byte* cc = NULL;
    uint16 n = max(DIM_256 + mpass->longueur, DIM_256);
    D�RIVE_CHIFFRE *dcs0 = NULL, *dcs1 = NULL, *dcs = NULL, *dcA = NULL,
        *dcB = NULL, *dcC = NULL; byte mpasst[DMP+1] = {0}, *mpc = NULL;
    const uint X = sizeof(yz); ND_ASSERT_G(dcs0 = ai()); ND_ASSERT_G(dcs1 = ai());
    ND_ASSERT_G(dcs = ai()); if ( ! estTableHexaValide(yz, X)){
        return ERR_CHIFFREMENT_INVALIDE; }
    if (estMajIdA()){ addIdVolumeA(yz[8][2]); }
    if (estMajId()){ addIdVolume((ENTIER)getCrc32(yz[6],
        UI8(sizeof(yz[6]))) + UI8(yz[10][1])); }
    if (n > NDH){ n = 3 * DIM_256; }
    cc = zl(); memcpy(mpasst, mpass->texte, mcb(mpass->longueur, DMP));
    for (i=0; (uint32)i < n; i++){ on(mpasst, i*2+1, N64 + i, 4); }
    for (i=0; i < n0 && (uint32)(i * DIM_256) < n; i++)
    {
        dcs->dimp = n; memcpy(dcs->mpass, mpass, mcb(n, DMP));
        dcs->dimSalt = UI8_STRLEN(yz[i+PAS]);
        memcpy(dcs->salt, yz[i+PAS], mcb(dcs->dimSalt, sizeof(dcs->salt)));
        dcs->nbIt�rations = i + 1; dcs->dimR�sultat = n;
        an(dcs, SHA); if (i == 0){ adB(dcs0, dcs); } 
        else if (i == 1){ adB(dcs1, dcs); } else { ad1(dcs0->r�sultat, 
            (i * DIM_256), DIM_TAB_R, dcs->r�sultat, DIM_256); il0(dcs); } 
    }
    n0 = (i < n0 ? i : n0); ND_ASSERT_G(dcB = ai()); if (dcs0)
    { 
        mpc = dcs0->r�sultat;
        memcpy(dcB->mpass, mpc, mcb(dcs0->dimR�sultat, DMP));
    }
    if (dcs1->r�sultat){ mpc = dcs1->r�sultat; i = dcs1->dimR�sultat;
    } else { i = UI16_STRLEN(mpc); } memcpy(dcB->mpass, mpc, mcb(i, DMP));
    dcB->dimp = n; dcB->nbIt�rations = 2; dcB->dimSalt = UI8_STRLEN(yz[3]);
    memcpy(dcB->salt, yz[2], mcb(dcB->dimSalt, sizeof(dcB->salt)));
    dcB->dimR�sultat = DIM_256; an(dcB, RIPEMD);
    memcpy(dcB->cl�, dcB->r�sultat, mcb(dcB->dimR�sultat, MASTER_KEYS_SIZE));
    dcA = ai(); dcA->dimp = n; memcpy(dcA->mpass, mpc, mcb(n, DMP));
    dcA->nbIt�rations = 1; dcA->dimSalt = UI8_STRLEN(yz[2*PAS]);
    memcpy(dcA->salt, yz[2*PAS+3], mcb(dcA->dimSalt, sizeof(dcA->salt)));
    dcA->dimR�sultat = DIM_256; an(dcA, WHIRLPOOL); init0(dcB, DIM_DC);
    memcpy(dcB->r�sultat, dcA->r�sultat, mcb(dcA->dimR�sultat, DIM_TAB_R));
    dcB->dimR�sultat = dcA->dimR�sultat; if (mpc)
    {
        a = getValeurHexa(mpc[50]); b = getValeurHexa(mpc[180]); 
        c = getValeurHexa(mpc[620]); d = getValeurHexa(mpc[1001]);
        if (dcs0){ dcs0->enUtilisation = FALSE; }
        ea = (31 * (b + d + 2)) % (FISH+1);
        if (ea == 0){ ea = ENUM_1; }
    }
    n = 2 * DIM_256; memcpy(dcB->mpass, dcB->r�sultat+3, DIM_256);
    dcB->dimp = DIM_256; n += DIM_256; dcB->dimR�sultat = n; 
    an(dcB, SHA); rs(dcB->r�sultat, mpc, n);
    ad1(dcB->r�sultat, n, DIM_TAB_R, dcA->r�sultat, n); 
    n += dcA->dimp; if (n > DMP){ n = DMP; }
    memcpy(dcB->mpass, mpc, mcb(n, DMP));
    dcB->dimp = mcb(DMP, dcB->dimR�sultat);
    ND_ASSERT_G(dcC = ai()); adB(dcC, dcB); an(dcC, SHA);
    dc = cd(mpasst, DMP, dcB->mpass, dcB->dimp);
    memcpy(cc, mpasst, DMP); n += DIM_256; n /= 2;
    dcC->dimR�sultat = DIM_TAB_R; rs(cc, dcA->r�sultat, DIM_TAB_R);
    mpass->longueur = UI16_STRLEN(mpass->texte); 
    setNonVide(mpass->texte, mpass->longueur, FALSE, TRUE);
    memcpy(dcC->mpass, mpass->texte, mcb(m, DMP)); 
    dcC->dimp = mpass->longueur; ERR: NDFree0(cc, DK0);
    ERR_MEM: il(dcs0); il(dcs1); il(dcs); il(dcA); il(dcB); il(dcC);
    return gNDR�sultat;
}

D�RIVE_CHIFFRE* sm(MOT_DE_PASSE* mpass, uint16 it�r, BOOL modifMdp)
{   // setMotDePasseD�riv� + getCl�Ent�teB
    static const byte yz/*SALT*/[][DIM_16] = {
        "\x22\x8b\x5b\x25\x5f\xb7\x9b\xbf", "\xb7\x9e\xae\xda\xaf\xa2\xc4\x7f",
        "\x38\x98\x56\x5b\xbf\x1a\x95\x54", "\x1a\x04\x57\x48\xa6\x34\x9c\x18",
        "\x5b\xd1\x49\xc4\x46\x6a\xff\x8a", "\xf3\x8f\x40\xc1\xea\x7a\x22\xe0",
        "\x41\xe3\xb6\x7f\xf2\xb1\x0b\x1d", "\xa7\xcc\x5a\x87\xda\x56\x40\x4a",
        "\xbe\xec\x94\x86\xdb\x27\x21\xdc", "\xe3\x87\x7c\xd6\xc0\x14\xaa\xd4",
        "\xcd\xb6\x8a\x90\x84\x3e\x73\xf8", "\x27\xec\xfb\xd0\x1a\x6c\x6e\x1a",
        "\xd4\xb8\xaa\x8c\x83\x22\xb1\xd4", "\x01\xc6\x33\xfa\xf4\x0f\x70\x78",
        "\xa2\xcc\x3b\x47\xdc\x11\xf5\x8e", "\xd3\x78\xee\x4e\x73\xcc\xbb\x33",
        "\x4d\x28\x11\x14\xda\xf0\x94\xaa", "\x48\x9e\x28\xc9\xbc\xda\x92\x2e",
    };
    uint16 n0 = NB_ITER_CHIFFRE, PAS = 4, m = DIM_DEMI_MP; byte* cc = NULL;
    uint8 a, b, c, d, ea = 0, j; uint16 i; uint16 lmdp = (mpass ?
        UI16_STRLEN(mpass->texte) : 0), n = mcb(DIM_256 + lmdp, DMP);
    int r; D�RIVE_CHIFFRE *dc = NULL, *dcs0 = NULL, *dcs = NULL, *dcA = NULL, 
        *dcB = NULL, *dcC = NULL; const uint X = sizeof(yz); 
    byte mpassd[DMP + 1] = {0}, *mpc = NULL; ND_ASSERT_CS(mpass, 
        ERR_INVALID_INIT); ND_ASSERT_G(dcs0 = ai()); ND_ASSERT_G(dcs = ai()); 
    ND_ASSERT_G(dcA = ai()); if ( ! estTableHexaValide(yz, X)){
        ND_ASSERT_S(ERR_CHIFFREMENT_INVALIDE); } 
    if (estMajIdA()){ addIdVolumeA(yz[8][2]); }
    if (estMajId()){ addIdVolume((ENTIER)getCrc32(yz[6],
        UI8(sizeof(yz[6]))) + UI8(yz[10][1])); }
    if (n > NDH){ n = 3 * DIM_256; } cc = zl();
    if (mpass->longueur == 0){ mpass->longueur = lmdp; }
    memcpy(mpassd, mpass->texte, mcb(mpass->longueur, DMP));
    for (i = 0; (uint32)i < n; i++){ on(mpassd, i * 2 + 1, N64 + i, 4); }
    for (i = 0; i < n0 && (uint32)(i * DIM_256) < n; i++)
    {
        dcs->dimp = n; memcpy(dcs->mpass, mpass, mcb(n, DMP));
        dcs->dimp = n; dcs->dimSalt = UI8_STRLEN(yz[i + PAS]);
        memcpy(dcs->salt, yz[i + PAS], mcb(dcs->dimSalt, sizeof(dcs->salt)));
        dcs->nbIt�rations = i + 1; dcs->dimR�sultat = n;
        an(dcs, SHA); if (i == 0){ adB(dcs0, dcs); } else {            
            ad1(dcs0->r�sultat, (i * DIM_256), DIM_TAB_R, 
                dcs->r�sultat, DIM_256); il0(dcs); }
    }
    if (dcs0->dimR�sultat == 0){ adB(dcs0, dcs); }
    if (dcs0->dimR�sultat == 0){ i = UI16_STRLEN(mpass);
       memcpy(dcs0->r�sultat, mpass, i); dcs0->dimR�sultat = i; }
    n0 = (i < n0 ? i : n0); il(dcs); ND_ASSERT_G(dcB = ai());
    mpc = dcs0->r�sultat;
    memcpy(dcB->mpass, mpc, mcb(dcs0->dimR�sultat, DMP));
    if (dcs0){ mpc = dcs0->r�sultat; i = dcs0->dimR�sultat;
    } else { i = UI16_STRLEN(mpc); }
    n = (i > DMP ? DMP : i); memcpy(dcB->mpass, mpc, mcb(n, DMP));
    dcB->dimp = n; dcB->nbIt�rations = 2; dcB->dimSalt = UI8_STRLEN(yz[3]);
    memcpy(dcB->salt, yz[2], mcb(dcB->dimSalt, sizeof(dcB->salt)));
    dcB->dimR�sultat = DIM_256; an(dcB, RIPEMD);
    memcpy(dcB->cl�, dcB->r�sultat, mcb(dcB->dimR�sultat, MASTER_KEYS_SIZE));
    dcA->dimp = n; memcpy(dcA->mpass, dcB->r�sultat, mcb(n, DMP));
    dcA->nbIt�rations = 1; dcA->dimSalt = UI8_STRLEN(yz[2 * PAS]);
    memcpy(dcA->salt, yz[2 * PAS + 3], mcb(dcA->dimSalt, sizeof(dcA->salt)));
    dcA->dimR�sultat = DIM_256; an(dcA, WHIRLPOOL);
    memcpy(dcB->r�sultat, dcA->r�sultat, mcb(dcA->dimR�sultat, DIM_TAB_R));
    dcB->dimR�sultat = dcA->dimR�sultat; if (mpc)
    {
        a = getValeurHexa(mpc[50]); b = getValeurHexa(mpc[180]);
        c = getValeurHexa(mpc[620]); d = getValeurHexa(mpc[1001]);
        dcs0->enUtilisation = FALSE; 
        ea = (31 * (b + d + 2)) % (FISH+1);
        if (ea == 0){ ea = ENUM_1; }
    }
    n = 2 * DIM_256; memcpy(dcB->mpass, dcB->r�sultat + 3, DIM_256);
    dcB->dimp = DIM_256; n += DIM_256; dcB->dimR�sultat = n;
    an(dcB, SHA); rs(dcB->r�sultat, mpc, n);
    ad1(dcB->r�sultat, n, DIM_TAB_R, dcA->r�sultat, n); 
    n += dcA->dimp; if (n > DMP){ n = DMP; }
    memcpy(dcB->mpass, dcB->r�sultat, mcb(n, DMP));
    dcB->dimp = mcb(DMP, dcB->dimR�sultat); ND_ASSERT_G(dcC = ai());
    adB(dcC, dcB); an(dcC, SHA); ND_ASSERT_CS(dcB->dimp > 0, 
        ERR_CHIFFREMENT_INVALIDE);
    cd(dcC->r�sultat, dcC->dimR�sultat, dcB->mpass, dcB->dimp);
    dcC->dimR�sultat = DIM_TAB_R; j = mcb(dcC->dimR�sultat, DIM_TAB_R/2);
    if (dcC->nbIt�rations == 0){ il(dcC); dcC = dcB; }
    r = ad0(cc, DK0, dcC->r�sultat, j); ND_ASSERT_S(r); n += DIM_256;
    n /= 2; rs(dcB->r�sultat, cc, DIM_TAB_R); mpass->longueur = dcC->dimp;
    memcpy(mpass->texte, dcC->mpass, mcb(dcC->dimp, DMP));
    ad1(mpass->texte, m, DMP, dcB->r�sultat,
        mcb(abs(DMP - m), mcb(abs(DMP - dcB->dimR�sultat), DMP)));
    if (dcs0 && dcs0->nbIt�rations > 0){ dcC->dimp = dcs0->dimR�sultat; } 
    dc = dcB; ND_FIN(); ERR: ND_JOURNALISER_ERREUR(__FILENAME__);
FIN:il(dcs); il(dcA); if (dcC && dcB && (dcC->pos != dcB->pos)){ il(dcC); }
    if (dcC && (dcC->nbIt�rations == 0)){ dc = ai(); if (cc){
       memcpy(dc->r�sultat, cc, DIM_TAB_R); } dc->dimR�sultat = UI16_STRLEN(cc);
    dc->nbIt�rations = 1; } NDFree0(cc, DK0); ERR_MEM: return dc;
}

// estUnePositionAl�atoireAssign�e.
BOOL ao(const uint16 r)
{   
    BOOL r�sultat = FALSE; uint i; for (i=0; i < DIM_16; i++)
    {   
        if ((r + DIM_SEC_NOMBRES_DC > gNa[i].a) && (r < gNa[i].a)){
            r�sultat = TRUE; break;
        }
        if (gNa[i].a == r){ r�sultat = TRUE; break; }
        if (r == 0){ return TRUE; break; }
    } 
    return r�sultat;
}

void m(byte tab[], uint i, uint n){ // d�calerCarsDroite 
    memmove(&tab[i+1], &tab[i], (n-i)*sizeof(byte));
}

// Retourne la longueur du mot de passe (~al�atoire).
uint16 getN(const byte mpass[], uint16 diMax)
{
    uint16 r�sultat = 0, n0 = diMax; uint i, j = 0;
    for (i=0; i < n0; i = (i + 3) * 2){ 
        j += (uint)mpass[mcb(i, (uint)n0-1)];
    }
    i = UI16(DIM_DEMI_MP); if (j < i){ j += i; }
    if (j > diMax){ j = (j % i) + i + DIM_16; }
    if (j > diMax){ j = i + DIM_256 + (j - diMax); }
    r�sultat = mcb(UI16(j), UI16(diMax-1)); return r�sultat;
}

// genCiPseudoAl�atoire
int md(const MOT_DE_PASSE* mpass, CRYPTO_INFO* ci)
{   
    int r�sultat = ERR_SUCCESS, i = 0; uint16 a, b, c, d; uint32 na;
    const uint M = DMP; byte mpc[DMP+1] = {0};
    memcpy(mpc, mpass->texte, mcb(mpass->longueur, M)); 
    for (i=0; i < DMP; i+=3){
        on(mpc, mcb(i*2+1, DMP-1), mcb(i + N32, DMP-1), 2);
    }
    na = getN(mpc, DMP); a = mpc[81]; b = mpc[33]; c = mpc[6]; d = mpc[20];
    ci->cifr = (byte)((uint32)(57 * (a + b + c + d)) % NB_CIPHERS);
    ci->cifr = getCipher(ci->cifr); ci->mode = YTS;
    while (ci->cifr == NB_CIPHERS){ ci->cifr = getCipher(na++ % NB_CIPHERS); }
    init0(mpc, M); return r�sultat;
}

// dimTxt est la longueur maximale de txt.
uint16 STRLEN_DC(const byte txt[], const uint16 dimTxt)
{
    int i = UI16_STRLEN(txt), j; if (i == 0){ return 0; }
    for (i=dimTxt-1; i >= 0; i--) if (txt[i] != EOL)
    {
        j = i; while ((j >= 0) && txt[j] != EOL){ j--; }
        if ((i - j) > 3){ break; }
    } 
    return UI16(i+1);
}

// modifMotDePasseD�riv�.
int ds(MOT_DE_PASSE* mpass, CRYPTO_INFO* ci, D�RIVE_CHIFFRE* dc, BOOL modifMdp)
{
    static const byte x0/*SALT*/[][DIM_16] = {
        "\xf8\x47\x1c\x35\x72\x38\x4d\xed", "\x22\x04\xd4\xd3\x23\xbe\x57\x06",
        "\xfb\xc4\x5c\xcf\xd5\x91\x5b\x66", "\x6a\x5e\x3d\x08\xdd\xf5\xec\xbf",
        "\x84\x5a\x05\x14\xb4\x3b\x06\x22", "\x82\xe5\xbb\x6b\xfc\x79\x0e\x54",
        "\x46\x7e\x7f\x03\x02\x7a\x0e\x2e", "\x66\x77\xf9\x55\x01\x3e\x16\xfe",
        "\xc6\x7a\x0f\xb8\xc8\x66\x8b\x58", "\xd2\xac\x4e\xa2\x6e\x7b\x09\x77",
        "\xfe\xd3\x15\xb2\xbd\xfb\x71\xf4", "\xaf\x5b\xe7\x0a\x69\xf7\x70\x01"
    };
    int r = ERR_SUCCESS; uint16 nbIPkcs, i, n0 = 1, X = sizeof(x0);
    MOT_DE_PASSE moDPassA = {0}; INFO_CRYPTO ciA = {0}; uint8 cifr = 0;
    long c; uint16 dcm; /* Multiple de 256 */ D�RIVE_CHIFFRE* dcA = NULL;
    uint8 pkcsA = SHA, pkcsB = ENUM_1, pkcs = RIPEMD; uint16 nbIt�rations = 13;
    const uint16 NOMBRE_AL�ATOIRE0 = gNa[0].a; // Sauvegarde.
    const uint16 MDCM = DK0 - MASTER_KEYS_SIZE - 1; if (estMajId()){
        addIdVolume(UI64(getCrc32(x0[3],
            UI64(sizeof(x0[3])) + UI64(x0[6][0])))); } ND_ASSERT_G(dcA = ai());
    if ( ! estTableHexaValide(x0, X)){ return ERR_CHIFFREMENT_INVALIDE; }
    if (estMajIdA()){ addIdVolumeA(UI64(getCrc32(x0[5],
        UI64(sizeof(x0[5]))) + UI64(x0[6][7]))); }
    adB(dcA, dc); init0(dcA->r�sultat, DIM_TAB_R);
    r = initialisec(&ciA); ND_ASSERT_S(r);
    pkcsB = dcA->pkcsA; memcpy(&moDPassA, mpass, DIM_MP);
    ND_ASSERT_CS(mpass->longueur > 0, ERR_CHIFFREMENT_INVALIDE);
    da(&moDPassA, ciA.salt, PKCS_SALT_SIZE); dcA->dimR�sultat = DIM_TAB_R;
    r = rn(&moDPassA, dcA); if (r != ERR_SUCCESS){ ND_ERREUR(); }
    nbIPkcs = 1; ciA.mode = YTS; c = getNombreDC(mpass->texte,
        mpass->longueur, x0, DIM_8, dc->mpass[23], sizeof(x0));
    cifr = c % NB_CIPHERS; cifr = getCipher(cifr); ciA.cifr = cifr;
    pkcsB = (c % (FIN_ENUM_HACHAGE-1))+1;
    n0 = UI16(((DK0 - UI16(3 * DIM_256)) / DIM_256) - 1);
    n0 = mcb(10, n0); memcpy(ciA.cl�0, moDPassA.texte, DMP);
    for (i=0; i < n0; i++)
    {
        r = kcs(dcA, pkcsB); ND_ASSERT_S(r); r = adB(dcA, sm(&moDPassA,
            (i + 1), modifMdp)); ND_ASSERT_S(r);
        ND_ASSERT_CS((dcA->nbIt�rations > 0), ERR_CHIFFREMENT_INVALIDE);
        dcm = i * DIM_256; dcA->nbIt�rations = nbIPkcs;
        dcm = (dcm > MDCM ? MDCM : dcm); memcpy(dcA->cl�, ciA.cl�0+dcm, N136);
        // Cl� d'initialisation.
        if ( ! rm(dcA->cl�)){ ND_ASSERT_S(ERR_CIPHER_INIT_FAILURE); }
        if (UI16_STRLEN(ciA.cl�0) == 0){
            if ( ! rm(ciA.cl�0)){ ND_ASSERT_S(ERR_CIPHER_INIT_FAILURE); }
        } // Cl� cadenc�e.
        if ( ! rm(dcA->r�sultat)){ ND_ASSERT_S(ERR_CIPHER_INIT_FAILURE); }
        if ( ! an(dcA, WHIRLPOOL)){ ND_ASSERT_S(ERR_CIPHER_INIT_FAILURE); }
    }
    if ( ! rm(mpass->texte)){ ND_ASSERT_S(ERR_CIPHER_INIT_FAILURE); }
    ND_ASSERT_CS(moDPassA.longueur > 0, ERR_CHIFFREMENT_INVALIDE);
    memcpy(mpass, &moDPassA, DIM_MP);
    r = ad0(ciA.cl�0, DK0, ciA.cl�0, DK0); ND_ASSERT_S(r);
    r = dsa(ci); ND_ASSERT_S(r); r = dsb(ci); ND_ASSERT_S(r);
    n0 = UI16(DK0 * 0.93); i = DIM_TAB_R;
    adC(dcA->r�sultat, n0, i, ciA.cl�0 + 2 * UI16(DK0)/4, DIM_256);
    dcA->r�sultat[i-1] = EOL; adB(dc, dcA); r = kcs(dc, pkcsA); ND_ASSERT_S(r);
    ND_FIN(); ERR: ND_JOURNALISER_ERRDAA(MOT_DOA);
    r = gNDR�sultat; FIN: gNa[0].a = NOMBRE_AL�ATOIRE0; // Restauration.
    nbIt�rations = dc->nbIt�rations; init0(ci->salt, sizeof(ci->salt));
    il(dcA); finalisec(ci, FALSE); return r;
}

int dsa(CRYPTO_INFO* ci)
{
    static const byte ur/*SALT*/[][DIM_16] = {
        "\x6d\x76\x7e\xbe\xd3\x76\x18\x19", "\xac\x0e\x12\x74\x4e\x32\xf2\x99",
        "\xa1\x04\xe2\x4d\xa8\x0a\x91\xd8", "\x7e\x4c\xad\x7b\x40\x7d\xc6\xb4",
        "\x01\xe0\xd4\x88\xfb\x4a\x84\xae", "\xd8\xa4\xc0\x28\x5a\xde\xd8\x52",
        "\x09\xa5\x50\x68\x29\x16\xc3\x7b", "\x56\x60\x6b\xec\xea\xfc\x8a\x67",
        "\x56\x56\xbb\x4e\xaf\x79\xfc\x56", "\xb8\x5b\x25\xd9\x1e\x28\xb3\xdc",
        "\x90\xcb\x40\x7e\xa0\x50\x3b\x6a", "\xa2\x08\x74\x57\x1d\xe5\x5c\xbf",
        "\xb1\x2a\x2d\xb0\xee\x66\x57\x0a", "\xb6\x65\xb3\x0a\x58\x70\x09\xaf",
        "\xaf\x2e\x8f\xcc\x18\xde\x8b\x2a", "\x6e\x4a\x6c\xf3\x9a\x8c\x28\xe8",
        "\xa6\xc2\xd8\xe4\x98\x29\x69\x46", "\x40\x72\x5e\x50\x2f\xb8\x11\x33",
        "\x6b\xff\x32\xb4\xd6\xa1\x95\xa9", "\x5c\x3f\xca\x01\x27\x14\xa2\x36"
    };
    const uint16 DIM_CL� = DK0, NC = DIM_256, X = sizeof(ur);
    const uint16 ND = STRLEN_DC(ci->cl�0, DIM_CL�), m = (DK0-ND)/NC;
    const uint16 R = 4; D�RIVE_CHIFFRE* dc = NULL; uint16 i, j, n;     
    if (estMajIdA()){ addIdVolumeA(UI64(getCrc32(ur[1], sizeof(ur[1]))) +
        UI64(ur[2][3])); } ND_ASSERT_G(dc = ai());
    if ( ! estTableHexaValide(ur, X)){ return ERR_CHIFFREMENT_INVALIDE; }
    memcpy(dc->mpass, ci->cl�0, mcb(NC, DMP)); for (i=0; i < m; i++)
    {
        dc->dimp = NC; j = i % R; dc->dimSalt = UI8_STRLEN(ur[j]);
        memcpy(dc->salt, ur[j], mcb(dc->dimSalt, sizeof(dc->salt)));
        dc->nbIt�rations = i + j + 1; dc->dimR�sultat = NC;
        n = mcb(ND + (i*NC), DK0 - NC); an(dc, SHA);
        ad0(ci->cl�0 + ND + UI64(i) * UI64(NC), DK0-n, dc->r�sultat, n);
        memcpy(dc->mpass, dc->r�sultat, NC);
    }
    i = DIM_CL� - ND - (m * NC); if (i > 0)
    {
        dc->dimp = i; j = i % R; dc->dimSalt = UI8_STRLEN(ur[j]);
        memcpy(dc->salt, ur[j], mcb(dc->dimSalt, sizeof(dc->salt)));
        dc->nbIt�rations = 3; dc->dimR�sultat = i;
        j = STRLEN_DC(ci->cl�0, DIM_CL�)-1; an(dc, RIPEMD); 
        ad0(ci->cl�0 + j, DK0 - j, dc->r�sultat, i);
    } 
    ND_FIN(); ERR: ND_JOURNALISER_ERREUR(__FILENAME__);
    FIN: il(dc); return gNDR�sultat;
}

// getKeySchedule
byte* igc(CRYPTO_INFO* ci) 
{
    byte* cc = NULL; uint N = DK0; N /= 3; N--; 
    uint16 i = 0, d = 0;
    uint8 c = ci->cifr; if ( ! gCc){ gCc = zl(); }
    if (ci) 
    {
        for (uint8 ea = getEAD�but(c); ea >= ENUM_1; ea = getEASuivant(c))
        {
            cc = getKeySchedule(ea, i); if (cc && ! estVide100(cc, 25)){
                memcpy(gCc + d, cc, N);
            } d += N;
        }
    }
    return gCc;
}

int dsb(CRYPTO_INFO* ci)
{
    static const byte iv/*SALT*/[][DIM_16] = {
        "\x74\xf9\x82\x51\xa4\xa2\x22\x3a", "\xe1\xff\x80\x8b\x50\x7d\xa8\x47",
        "\x52\xe4\x0f\xc6\x1f\x62\x6d\xa8", "\x87\xce\xa5\x3e\x37\x8a\x78\xe3",
        "\x84\x4e\xea\xdc\xb8\x22\x4a\x06", "\xb4\x96\x42\xe4\x35\x06\x5f\x3b",
        "\x7f\x6d\xa0\x39\x34\xd7\xbd\xa3", "\x9c\x6c\x95\xc5\x44\x4a\xf4\x43",
        "\x85\xfc\x63\xf7\x7e\x86\x37\xa9", "\xd7\x83\x12\x9e\xf4\xe2\xcf\xe3",
        "\x9e\xf8\x64\x44\x38\x2f\x22\x52", "\x9a\xda\xe7\x38\x4d\xac\xd4\x3a"
    };
    const uint16 DIM_CL� = DK0, NC = MASTER_KEYS_SIZE, X = sizeof(iv);
    D�RIVE_CHIFFRE* dc = NULL; uint16 i, n, u; byte* cled = igc(ci);
    const uint16 ND = STRLEN_DC(cled, DIM_CL�), m = (DK0 - ND) / NC;
    const uint16 R = 4; ND_ASSERT_CS(cled, ERR_OBJECT_INIT); if (estMajIdA()){
        addIdVolumeA(UI64(getCrc32(iv[0], sizeof(iv[0])) +
            UI64(iv[1][0]))); } ND_ASSERT_G(dc = ai());
    if ( ! estTableHexaValide(iv, X)){ return ERR_CHIFFREMENT_INVALIDE; }
    memcpy(dc->mpass, cled, NC); for (i=0; i < m; i++)
    {
        dc->dimp = NC; u = i % R; dc->dimSalt = UI8_STRLEN(iv[u]);
        memcpy(dc->salt, iv[u], mcb(dc->dimSalt, PKCS_SALT_SIZE));
        dc->nbIt�rations = i + u + 1; dc->dimR�sultat = NC; an(dc, WHIRLPOOL);
        n = mcb(ND + (i * NC), DK0 - NC); an(dc, SHA);
        ad0(cled + ND + UI64(i)*UI64(NC), DIM_CL� - n, 
            dc->r�sultat, n); memcpy(dc->mpass, dc->r�sultat, NC);
    }
    i = DK0 - ND - (m * NC); if ((i > 0) && (i < DIM_TAB_R))
    {
        dc->dimp = i; u = i % R; dc->dimSalt = UI8_STRLEN(iv[u]);
        memcpy(dc->salt, iv[u], mcb(dc->dimSalt, sizeof(dc->salt)));
        dc->nbIt�rations = 6; dc->dimR�sultat = i;
        u = STRLEN_DC(cled, DIM_CL�) - 1; an(dc, SHA); 
        ad0(cled + u, DK0 - u, dc->r�sultat, i);
    } 
    ND_FIN();
ERR:ND_JOURNALISER_ERREUR(__FILENAME__); FIN:il(dc); return gNDR�sultat;
}

int dsM(MOT_DE_PASSE* mpass, CRYPTO_INFO* ci, D�RIVE_CHIFFRE* dc){ // Voir ds.
    return ds(mpass, ci, dc, TRUE);
}

int dna(MOT_DE_PASSE* mpass, CRYPTO_INFO* ci, D�RIVE_CHIFFRE* dc)
{
    int r�sultat = ds(mpass, ci, dc, TRUE); 
    if (r�sultat == ERR_SUCCESS)
    {
        uint16 n = UI16(DK0 * 0.91);
        n = ((n / DIM_256) * DIM_256) + DIM_256;
        ic(dc->r�sultat, n, DIM_TAB_R);
    } return r�sultat;
}

// getPosAl�atoire
uint16 l(const byte mpc[], uint16 diMpc, uint i, int32 j) 
{
    const uint16 n0 = ND_HEADER_OFFSET_VERSION - DIM_SEC_NOMBRES_DC;
    uint x = 1, s = i; uint16 a = UI16(mpc[s] % n0);
    while ( ! ((a + DIM_SEC_NOMBRES_DC < j) || (a > j + DIM_32)) || ao(a))
    {   
        // CRC: pas de chevauchement de nombres.
        if (s >= DMP){ s = 0; } a = ((x*mpc[s++]+(j*s)) % n0);
        x++; s++; if (s > diMpc){ s = 0; } if (a > n0){ s = 0; a = 0; }
    }
    if (a == 0){ ND_JOURNALISER_ERRDAA(MOT_DOA); } return a;
}

// initNombresAl�atoires
int gi(const MOT_DE_PASSE* mpass, D�RIVE_CHIFFRE* dc, const int32 pm)
{   
    int r�sultat = ERR_SUCCESS, i = 0; uint16 a; byte* mpc = dc->mpass;
    memcpy(mpc, mpass->texte, mcb(mpass->longueur, DMP));
    for (i=0; i < DMP; i+=3){
        on(mpc, mcb(i * 2+1, DMP-1), mcb(i + N32, DMP-1), 2);
    }
    dc->dimp = DMP; init0(gNa, sizeof(gNa));
    for (i=0; i < DIM_16; i++)
    {
        a = ((i + 1) * 2 * (506)) % ND_HEADER_OFFSET_VERSION;
        gNa[i].a = l(mpc, mpass->longueur, a, pm);
    } return r�sultat;
}

void rg(const byte tab[]) // PRE: tab est de dimension NDH. 
{
    uint i, n0 = sizeof(gTab); COUPLE_AB* stab = NULL; 
    for (i=0; i < n0; i++)
    {
        stab = &gNa[i]; gTab[i] = gcb(tab[stab->a]);
    }
}

// set16BytesAl�atoiresMotDePasse
void sd(){ getRandBytes(gTab, sizeof(gTab), TRUE); }

// genMotDePasseChiffrePr�alable
int mg(MOT_DE_PASSE* mpass, CRYPTO_INFO* ci, byte cl�0[], D�RIVE_CHIFFRE* dc)
{   
    int r = ERR_SUCCESS; byte* mpc = dc->mpass; uint16 lm = 0;
    uint16 a, b, c, d, n; byte tab[80] = {0}; lm = UI16_STRLEN(dc->mpass);
    sprintf(ND_CC(tab), "%llx%llx", getDci().b, getDci().c);
    a = 73 + ((lm * (getDci().b / 3)) % PASSWORD_LEN_MAX_WARNING) * 11;
    ad1(mpc, a, DMP, gXt, UI8_STRLEN(gXt)); setMajId(TRUE); setMajIdA(TRUE);
    n = mpass->longueur = getN(mpc, DMP);
    memcpy(mpass->texte, mpc, mcb(mpass->longueur, DMP));
    a = getValeurHexa(mpc[36]); b = getValeurHexa(mpc[38]);
    c = getValeurHexa(mpc[5]); d = getValeurHexa(mpc[10]);
    ci->cifr = uint8(23 * uint8(a + b + c + d)) % NB_CIPHERS;
    ci->cifr = getCipher(ci->cifr); ci->mode = YTS;
    while (ci->cifr == NB_CIPHERS){ ci->cifr = getCipher(n++ % NB_CIPHERS); }
    r = rn(mpass, dc); ND_ASSERT_S(r); nx(mpass, dc);
ERR: /* FIN */ r = gNDR�sultat; setMajId(FALSE); setMajIdA(FALSE); return r;
}

// genKeyData
int gd(MOT_DE_PASSE* mpass, D�RIVE_CHIFFRE* dc)
{   
    int r = ERR_SUCCESS; 
    static const byte xs/*SALT*/[][DIM_16] = {
        "\xa6\x58\xca\x2a\x9a\xb2\x0c\xef", "\x4b\xe4\x9d\x7d\x15\x43\x91\x89",
        "\x42\xd8\x08\x5b\x3e\xbb\xb3\x84", "\x0f\x7a\x49\x92\x8e\xd5\xc3\x3a",
        "\xbc\x04\xa1\x42\x75\xc7\x50\x7e", "\x7a\xe3\xf8\x94\xe3\xd2\x28\xd8",
        "\x75\xd4\xea\xd5\xae\xe3\x0f\x4c", "\x74\x66\x88\x74\xb0\x91\xba\xde",
        "\x40\x48\xe4\x4d\x42\x6b\x40\xdf", "\xed\x22\x44\x74\x05\x68\xd4\xe6",
        "\xe6\x49\xf5\x4d\xa2\xb0\xba\x37", "\xa8\x0e\xce\x92\xfe\x76\xb0\x73",
        "\x2a\xf2\x8f\x1d\xbe\xd7\x0c\x82", "\x3e\x90\x9a\xa3\xdc\x0d\x98\x19",
        "\x55\x8c\x86\x6c\x1c\x0c\x92\xb4", "\x96\x8f\x4c\xf8\x1a\xe4\xc7\xf0",
        "\xf8\x0b\x68\x04\x42\x92\x34\xb4", "\xc1\xda\x6a\xfb\xa8\x7b\x68\x0c",
        "\xe1\xe2\x85\x80\x9c\x9e\xc2\x45", "\x87\xfa\x79\xb7\xa7\x08\x5e\x95",
    };
    const uint n0 = NB_ITER_CHIFFRE; uint i, l; uint16 n, X = sizeof(xs);
    byte* mpc = NULL; D�RIVE_CHIFFRE *dcs0 = NULL, * dcs = NULL;
    ND_ASSERT_G(dcs0 = ai()); ND_ASSERT_G(dcs = ai());
    if ( ! estTableHexaValide(xs, X)){ return ERR_CHIFFREMENT_INVALIDE; }
    if (estMajIdA()){ addIdVolumeA(UI64(getCrc32(xs[1],
        sizeof(xs[1]))) + UI64(xs[2][3])); } for (i = 0; i < n0; i++)
    {
        dc->dimp = mcb(dc->dimp, DMP); memcpy(dcs->mpass, dc->mpass,
            mcb(dc->dimp, DMP)); dcs->dimp = dc->dimp;
        gsv(dcs->mpass, dcs->dimp, dcs->r�sultat, DMP);
        dcs->dimSalt = UI8_STRLEN(xs[i]);
        memcpy(dcs->salt, xs[i], mcb(dcs->dimSalt, sizeof(dcs->salt)));
        dcs->nbIt�rations = UI16(i) + 1; dcs->dimR�sultat = DIM_256;
        an(dcs, SHA); if (i == 0){ adB(dcs0, dcs); } else {
            ad1(dcs0->r�sultat, (i * DIM_256), DIM_TAB_R,
                dcs0->r�sultat, DIM_256); il0(dcs);
        }
    }
    mpc = dcs0->r�sultat; n = getN(mpc, DMP);
    for (i=0; i < DIM_16; i++)
    {
        l = (((i + 3) + (i * 2)) * 47) % n; m(mpc, l, DMP-1); mpc[l] = gNa[i].b;
    }
    mpass->texte[n] = EOL; mpass->texte[n+1] = EOL; memcpy(mpass->texte, mpc,
        mcb(n, DMP)); mpass->longueur = n; ERR: il(dcs0); il(dcs); return r;
}

// getEnt�te16BytesAl�atoires + maj du mot de passe d�riv�.
void dz(MOT_DE_PASSE* mpass)
{
    uint16 i, j = 0; uint32 r; for (i=0, j = mpass->longueur; i < DIM_16; i++)
    {
        gNa[i].b = gcb(gTab[i]); mpass->texte[j] = gcb(gTab[i]);
    }
    mpass->longueur = j; rcs(mpass->texte+j); r = getCrc32(mpass->texte, 
        j); mpass->longueur = uint16(j + (gTab[8] % 3) + (gTab[3] % 61));
    for (i=0; i < mpass->longueur; i++)
    {
        if (mpass->texte[i] == EOL){
            mpass->texte[i] = gcb((gTab[(i+1)%DIM_16]+i+3) % DIM_256);
        }
    }
}

/* 
 * setMotDePassePourDonn�es: +-utile puisqu'il suffirait de lire 16 caract�res 
 * al�atoires, via une position qui d�pend du mot de passe de l'utilisateur. */
void za(MOT_DE_PASSE* mpass) 
{
    uint16 i; const uint n0 = 3 * DIM_16; 
    for (i=0; i < DIM_16; i++)
    {
        gNa[i].b = gcb(gTab[i]);
        if (mpass->longueur < int(DMP - n0 - DIM_32 - 1)){
            mpass->texte[mpass->longueur++] = gcb(gTab[i]);
        } else {
            mpass->texte[(3*i) + DIM_32] = gcb(gTab[i]);
        }
    }
}

// setEnt�te16BytesAl�atoires
// PRE: get ou set16BytesAl�atoiresMotDePasse (sd) doivent �tre appel�es avant.
void jl(byte tab[])
{
    uint i, n0 = sizeof(gTab); COUPLE_AB* stab = NULL; for (i=0; i < n0; i++)
    {
        stab = &gNa[i]; stab->b = gcb(gTab[i]); tab[stab->a] = gcb(gTab[i]);
    }
}

uint64 sr(const MOT_DE_PASSE_DRV* mpass, const byte tA[], const byte tB[])
{   // getPositionEnt�te 
    uint64 r = 0; NTSTATUS �tat = STATUS_SUCCESS;
    const uint64 DFC = ND_KEYFILE_SIZE, n0 = 3*NDH;
    D�RIVE_CHIFFRE *dcA = NULL, *dcB = NULL;
    byte* mpc = NULL; uint8 a, b, d, ea; uint16 e;
    byte* cl�Cd = NULL; uint64 i; ENTIER j = 0; ND_ASSERT_G(dcA = ai());
    memcpy(dcA->mpass, mpass->texte, mcb(mpass->longueur, DMP));
    dcA->dimp = mpass->longueur; dcA->nbIt�rations = 1;
    dcA->dimSalt = UI8_STRLEN(tA); memcpy(dcA->salt, tA, 
        mcb(dcA->dimSalt, sizeof(dcA->salt))); dcA->dimR�sultat = DIM_32;
    if ( ! an(dcA, WHIRLPOOL)){ ND_ASSERT_S(ERR_INSUCC�S); } 
    ND_ASSERT_G(dcB = ai()); memcpy(dcB->mpass, dcA->r�sultat, mcb(dcA->dimR�sultat, 
        DMP)); dcB->dimp = dcA->dimR�sultat; dcB->nbIt�rations = 3;
    dcB->dimSalt = UI8_STRLEN(tB); memcpy(dcB->salt, tB, mcb(dcB->dimSalt,
        PKCS_SALT_SIZE)); dcB->dimR�sultat = DIM_32;
    if ( ! an(dcB, SHA)){ ND_ASSERT_S(ERR_INSUCC�S); } mpc = dcB->r�sultat;
    a = mpc[DIM_32+3]; b = mpc[DIM_32]; d = mpc[DIM_8]; e = mpc[DIM_16];
    ea = (gTabChiffres[a] * (b + d + e)) % (FISH+1); j = 0;
    if (ea == 0){ ea = ENUM_1; }; cl�Cd = zl(); ND_ASSERT_CS(cl�Cd,
        ERR_OBJET_�_NULL); memcpy(cl�Cd, dcA->r�sultat, DK0);
    an(dcA, RIPEMD); i = DFC - n0 + NDH; j = ((getValeurHexa(cl�Cd[3])+3)
        * (getValeurHexa(cl�Cd[29])+1) * (getValeurHexa(cl�Cd[18])+6)
        * (getValeurHexa(cl�Cd[37])+2)) % n0; r = i + j; 
    if ((r > (DFC - NDH)) || (r < i)){ r = i
        + UI64(getValeurHexa(cl�Cd[59]) + UN64) * (gTabChiffres[d] % 6280)
        + 3; r %= (DFC - NDH); }
    ND_FIN(); ERR: ND_JOURNALISER_ERRDAA(MOT_DOA); FIN: 
    NDFree0(cl�Cd, DK0); ERR_MEM: il(dcA); il(dcB); return r;
}

uint64 srD(const MOT_DE_PASSE_DRV* mpass)
{
    const byte x0[]/*SALT*/ = "\xec\xee\xe2\xf7\x76\x96\xe9\x53";
    const byte x1[]/*SALT*/ = "\x13\xb1\xa8\xe9\x26\x2a\x02\x77";
    return sr(mpass, x0, x1);
}

uint64 srE(const MOT_DE_PASSE_DRV* mpass, uint64 srp)
{    
    const byte x0[]/*SALT*/ = "\xf8\x18\x8d\x57\x4a\xb6\x33\xad";
    const byte x1[]/*SALT*/ = "\xfa\xa8\x34\x0c\x91\x02\x1e\x67";
    uint64 r0 = sr(mpass, x0, x1); int64 r = (int64)r0;
    if ((r0 > srp - NDH) && (r0 < srp)){ r -= NDH; } 
    if (r < 0){ r = r0 + (DIM_8 * N1024); } return r;
}

uint32 rf(const byte ec[], const MOT_DE_PASSE* mpass) // getContr�lCyclique
{   
    uint32 r�sultat = 0, n = getCrc32(mpass->texte, mpass->longueur);
    n = n % (ND_HEADER_OFFSET_VERSION /2);
    if (n == 0){ n = ND_HEADER_OFFSET_VERSION - 90; }
    r�sultat = getCrc32(ec + DIM_16, n); return r�sultat;
}

// modifierCInfosDonn�es
int xr(MOT_DE_PASSE* mpass, CRYPTO_INFO* ci, D�RIVE_CHIFFRE* dc)
{
    NTSTATUS r = STATUS_SUCCESS; uint8 cifr = ci->cifr; 
    r = kcs(dc, cp(mpass)); ND_ASSERT_S(r); 
    r = ds(mpass, ci, dc, FALSE); ND_ASSERT_S(r); r = md(mpass, ci);
    ND_ASSERT_S(r); ci->cifr = cifr; ERR: /* FIN */ return gNDR�sultat;
}

unsigned gy() // getNombreHorloge
{   
    unsigned r�sultat = 0; SYSTEMTIME st; GetLocalTime(&st);
    r�sultat = st.wYear * 10000 + st.wMonth * 1000 + 
        st.wDay * 10 + st.wHour * 11 + st.wMinute * 12 + st.wSecond * 13;
    return r�sultat;
}

// initTabPosCifers: m�langer l'indice des ciphers pour am�liorer la recherche.
void er(const byte x6[]/*ent�te*/) // C.-�-d., al�atoire vs s�quentielle.
{   // TODO: ne sert plus depuis l'ajout du mode ZTS et autres changements.
    int i, j; uint32 ri = getCrc32(x6+50, NDH/2); const uint M = NB_CIPHERS / 2;
    int8 np = -1, n; uint8 bExiste; srand(gy()*ri); init0(gXt, sizeof(gXt));
    gXt[M] = 0; for (i=0; i < NB_CIPHERS; i++)
    {
        if (i != M)
        {
            n = ((i + 1) * rand()) % NB_CIPHERS;
            if (n == np){ n = (np + i) % NB_CIPHERS; }
            if (estMajId()){ addIdVolume(ri); }
            while (n == 0){ n = rand() % NB_CIPHERS; } 
            if (n == np){ n = (np + 1) % NB_CIPHERS; }
            bExiste = FALSE; for (j=1; j <= i; j++)
            {
                if (gXt[j] == n){ bExiste = TRUE; break; }
            }
            if (bExiste){ i--; } else { gXt[i] = n; } np = n;
        }
    }
}

uint8 contientTropDe0AuD�but(const byte txt[])
{
    uint8 r�sultat = FALSE; int i = 0, j = 0;
    for (i = 0; i < 10; i++){ if (txt[i] == EOL){ j++; } }
    if (j > 3){ r�sultat = TRUE; }
    return r�sultat;
}

void copierSegmentTabChiffres(byte* cl�, uint64 dl, uint64 n, byte s[], uint n0)
{
    uint64 M = dl + n; uint16 j = 0;
    for (uint64 i = dl; i < M && j < DMP; i++, j++)
    {
        cl�[j] = byte((gTabChiffres[i] + s[i % n0]) % DIM_256);
        if (cl�[j] == EOL){ cl�[j] = (byte)DIM_256/(j+1); }
    }
}

void zc(byte cl�[], const byte ref[])
{
    for (uint i = 0; i < DK0; i++){ if (cl�[i] == EOL){ cl�[i] = ref[i]; } }
}

// initCiMdp. PRE: dim.s=NMPD et dim.r=256 (ci.salt).
NTSTATUS uy(CRYPTO_INFO* ci, byte s[], uint n0, Op�rArithm oa)
{
    uint8 i; uint64 N, M, y = 0, z; char tab[DIM_16] = {0}; byte* st = ci->salt;
    if ( ! estTab10ChiffresValide()){ return ERR_CHIFFREMENT_INVALIDE; }
    uint64 *zt = (uint64*)gTabChiffres; N = sizeof(gTabChiffres);
    uint8 j, prf; int nbIt�r; ci->mode = YTS; MOT_DE_PASSE mpass;
    D�RIVE_CHIFFRE* dc = NULL; uint64 d; ND_ASSERT_G(dc = ai());    
    for (i = 0; i < n0; i++){ y += (zt[y % N] * UI64(s[i]) + 1); }
    prf = ((zt[n0 + 1] % (FIN_ENUM_HACHAGE-1)) + 1); nbIt�r = DIM_256;
    ci->cifr = getCipher(y % NB_CIPHERS); for (i=0; i < DIM_64; i += DIM_8)
    {
        z = zt[(oa(zt[i], s[i % DIM_8]) % DIM_64) + DIM_8];
        sprintf(tab, "%lld", z); for (j=0; j < DIM_8; j++){
            st[j+i] = gcb(byte(getValeurHexa(tab[j]))); }
    } 
    M = (oa(y, N136) % N1024) + N1024; z = oa(y, UI64(n0) * NDH * (DIM_256+1));
    copierSegmentTabChiffres(ci->cl�0, (d = (z % (N - M))), M, s, n0);
    memcpy(dc->mpass, ci->cl�0, DMP); gd(&mpass, dc); dc->pkcsB = SHA; aj(dc);
    memcpy(ci->cl�0 + d, mpass.texte, mcb(mcb(mpass.longueur, DK0 - uint(d)),
        DIM_256)); memcpy(ci->cl�0 + max(N1024, estVide0(ci->cl�0, DK0, 0)), 
        dc->r�sultat, mcb(dc->dimR�sultat, DK0 - N1024)); zc(ci->cl�0, 
        dc->r�sultat); ERR: /* FIN */ il(dc); if (estVide0(ci->cl�0, 
    DK0, 0)){ gNDR�sultat = ERR_CIPHER_INIT_WEAK_KEY; }; return gNDR�sultat;
} 

uint8 xg() // sontPositionsNombresValides ?
{   
    uint8 r�sultat = TRUE; int i; for (i = 0; i < DIM_16; i++)
    {
        if (gNa[i].a == 0)
        {
            ND_JOURNALISER_ERRDAA(MOT_DOA); r�sultat = FALSE; break;
        }
    } return r�sultat;
}

// �crireDonn�esAl�atoires
NTSTATUS ed(HANDLE hv, ulong d, ulong e)
{
    NTSTATUS �tat = STATUS_SUCCESS; const ulong DIM_SEGMENTS = DIM_32K;
    byte* tab = NULL; ulong nbBytes��crire = e - d; ulong bytesDone = 0;
    HCRYPTPROV hProv = getCtxChiffre(); 
    ND_ASSERT_CS(hProv, ERR_CIPHER_INIT_FAILURE);
    tab = (byte*)NDAllouer0(DIM_SEGMENTS); while (nbBytes��crire > 0)
    {
        CryptGenRandom(hProv, DIM_SEGMENTS, tab);
        if ( ! WriteFile(hv, tab, DIM_SEGMENTS, &bytesDone, NULL)){
            ND_ASSERT_S(ERR_FILE_WRITE);
        }
        if (bytesDone == 0){ break; } if (nbBytes��crire < bytesDone)
        {
            if ( ! WriteFile(hv, tab, nbBytes��crire,
                &bytesDone, NULL)){ ND_ASSERT_S(ERR_FILE_WRITE); }
        }
        nbBytes��crire -= bytesDone;
    } 
    gNDR�sultat = �tat; ND_FIN(); ERR:ND_JOURNALISER_ERRDAA(MOT_DOA);
FIN:NDFree0(tab, DIM_SEGMENTS); ERR_MEM:return gNDR�sultat;
}

void dbgt(byte tab[], const int n) // v�rifierNL
{   // V�rifier si la grandeur d'un tableau est relative et non absolue.
    int i = 0; for (int i = 0; i < n; i++) // C.-�-d. dans un contexte o�
    {   // la fin des cha�nes de caract�res n'est pas d�termin�e par un '\0'.
        if (tab[i] == EOL){ ND_JOURNALISER_DAA("pos=%d", i); }
    }
}

uint16 getNbDoaEssais(){ return gNbEssais; }

NTSTATUS grb(byte tab[])
{
    const uint16 NET_DIV = NDH / 2;
    if ( ! getRandBytes(tab, NET_DIV, TRUE)){ 
        return ERR_CIPHER_INIT_WEAK_KEY; }
    if ( ! getRandBytes(tab + NET_DIV, NET_DIV, TRUE)){
         return ERR_CIPHER_INIT_WEAK_KEY; }
    return STATUS_SUCCESS;
}

NTSTATUS ce(const byte tab0[], byte tab[], CRYPTO_INFO* ci) // chiffrerEnt�te
{
    NTSTATUS r = ERR_SUCCESS; memcpy(tab, tab0, NDH);
    {
        r = EncryptDataUnits(tab, 0, 1, ci); ND_ASSERT_S(r);
        r = DecryptDataUnits(tab, 0, 1, ci); ND_ASSERT_S(r);
        r = abs(memcmp(tab0, tab, NDH)) * -1;  ND_ASSERT_S(r); 
        ND_JOURNALISER_DAA("Chiffrement r�ussi.");
    }
    if (gNbEssais + 1 >= MAX_ESSAIS_NOUVG){
        ND_ASSERT_S(r); ND_ASSERT_S(ERR_INSUCC�S); } 
ERR:/*FIN*/return r;
}

// V�rification: remplace l'auto-test (+ l�ger).
NTSTATUS cev(CRYPTO_INFO* ci, const byte tab0[], byte tab[])
{
    NTSTATUS r = EncryptDataUnits(tab, 0, 1, ci); ND_ASSERT_S(r);
    r = DecryptDataUnits(tab, 0, 1, ci); ND_ASSERT_S(r);
    if (memcmp(tab0, tab, NDH) != 0)
    {
        r = ERR_CIPHER_INIT_FAILURE; 
        for (uint j = 0; j < 3 && ! NT_SUCCESS(r); j++){
            r = ce(tab0, tab, ci); 
        }
    } 
ERR:/*FIN*/ return r;
}

// createVolumeHeaderInMemory
void bm(CONTEXTE_VOLUME* ctx) 
{   
    int r = ERROR_SUCCESS; uint16 jmA, jmB; uint32 m = 0, lmp = 0;
    byte* tab = NULL; uint8 cifr; uint16 n0 = 0; MOT_DE_PASSE mdp16 = {0};
    INFO_CRYPTO* ci = NULL; uint8 j = 0; gNDR�sultat = STATUS_SUCCESS;
    byte *tabR = NULL, tab0[NDH] = {0}; D�RIVE_CHIFFRE* dCRC = NULL;
    MOT_DE_PASSE mpass = {0}; uint8 pkcs, mode; ci = &ctx->ci; gNoLigne = 0;
    init0(gXt, sizeof(gXt)); init0(gNa, sizeof(gNa)); byte* cl�0 = NULL;
    ND_ASSERT_CS(ci, ERR_OBJET_�_NULL); init0Myz(); assignPrfs();
    if (cv0(ctx->nwModule.util.mpassd.texte, ctx->nwModule.util
        .mpassd.longueur)){ ND_ASSERT_S(ERR_MOTPASSE_INVALIDE); }
    // Section 1: g�n�ration du mot de passe de 16 caract�res.
    cifr = ctx->cifr; mode = ctx->ci.mode;
    init0(ci, DIM_CI); init0(gCc, DK0); r = grb(ctx->eci); ND_ASSERT_S(r);    
    r = grb(ctx->em16); ND_ASSERT_S(r); ND_ASSERT_G(ctx->dc = ai()); 
    ctx->dc->global = TRUE; ci->mode = YTS;
    jmA = emA(&ctx->nwModule.util.mpassd); sd(); za(&mdp16); 
    tab = ctx->em16; memcpy(&tab[jmA], mdp16.texte, DIM_16);
    lmp = ctx->nwModule.util.mpassd.longueur;
    memcpy(ci->cl�0, ctx->nwModule.util.mpassd.texte, lmp);
    r = uy(ci, ctx->nwModule.util.mpassd.texte, lmp, addition); ND_ASSERT_S(r);
    cl�0 = zl(); memcpy(cl�0, ci->cl�0, DK0);
    r = initialisec(ci); ND_ASSERT_S(r); ci->nouvFx = TRUE;
    r = EncryptDataUnits(tab, 0, 1, ci); ND_ASSERT_S(r);
    r = zs(tab, ci->cl�0 + NDH, TRUE); ND_ASSERT_S(r); finalisec(ci, FALSE);
    // Section 2: configuration de 'ci'.
    memcpy(&mpass.texte, ctx->nwModule.util.mpassd.texte, lmp);
    strncat(ND_CC(mpass.texte), ND_CC(mdp16.texte), DIM_16);
    n0 = lmp = mpass.longueur = ctx->nwModule.util.mpassd.longueur + DIM_16;
    mpass.texte[n0] = EOL; jl(ctx->em16); r = md(&mpass, ci);
    ND_ASSERT_S(r); pkcs = ENUM_1; ci->mode = YTS; tab = ctx->eci;
    r = ui(mpass.texte, FALSE, TRUE, TRUE); ND_ASSERT_S(r); il(ctx->dc);
    jmB = emB(&mpass); ND_ASSERT_CS((jmB >= 0), ERR_CHIFFREMENT_INVALIDE);
    ND_ASSERT_G(ctx->dc = ai()); r = gi(&mpass, ctx->dc, jmB); ND_ASSERT_S(r);
    r = ad3(mpass.texte, mpass.longueur); ND_ASSERT_S(r); // Mot de recherche:
    r = mg(&mpass, ci, cl�0, ctx->dc); ND_ASSERT_S(r); m = fm(&mpass); 
    tabR = (tab + jmB); setMemInt32(tabR, m, FALSE);
    // Version de l'en-t�te.
    tabR = (tab + ND_HEADER_OFFSET_VERSION);
    setMemWord(tabR, ND_VERSION_ENT�TE, TRUE); 
    r = xg(); ND_ASSERT_CS(r, ERR_CIPHER_INIT_FAILURE); init0(gCc, DK0);    
    r = uy(ci, mpass.texte, n0, division); ND_ASSERT_S(r); init0Keys();
    ci->cifr = cifr; ci->mode = YTS;
    /* CRC d'un segment de la cl�: ne pas l'�crire. */
    r = zs(tab, cl�0, TRUE);
    ND_ASSERT_S(r); memcpy(tab0, tab, NDH); r = estVide0(cl�0, DK0, 0);
    ND_ASSERT_CS( ! r, ERR_CIPHER_INIT_WEAK_KEY);
    memcpy(ci->salt, gTabChiffres + DIM_256, PKCS_SALT_SIZE);
    memcpy(ci->cl�0, cl�0, DK0); rcs(ci->salt); rcs(ci->salt + DIM_32);
    r = initialisec(ci); ND_ASSERT_S(r); setKey0(cl�0);
    r = cev(ci, tab0, tab); ND_ASSERT_S(r); ci->nouvFx = TRUE;
    r = EncryptDataUnits(tab, 0, 1, ci);
    ND_ASSERT_CS((comparerMem(tab0, tab, NDH, FALSE) != 0),
        ERR_CHIFFREMENT_INVALIDE); ND_ASSERT_S(r); ND_FIN();
ERR:if (gNDR�sultat != ERR_SUCCESS) { r = gNDR�sultat; }
    if (r == ERR_SUCCESS){ r = ERR_NOUVEAU_DOA; }
    ND_JOURNALISER_ERRDAA(MOT_DOA); ctx->r�sultat = gNDR�sultat;
FIN:il(dCRC); NDFree(gCc); init0Myz(); NDFree(cl�0);
    init0(&ctx->mpass, sizeof(ctx->mpass)); init0(&mpass, sizeof(mpass));
}

void fN(CONTEXTE_VOLUME* ctx) // �crire les donn�es d'en-t�te.
{
    NTSTATUS r�sultat = STATUS_SUCCESS; LARGE_INTEGER dimFichier = {0};
    DWORD nbBytes�crits, bytesDone = 0; byte* tab = (byte*)ctx->eci;
    LARGE_INTEGER de = {0}; const DWORD DIM_SEGMENTS = DIM_32K;
    HANDLE hv = ctx->poign�e; ND_ASSERT_CS(hv, ERR_OBJECT_INIT);
    dimFichier.QuadPart = ND_KEYFILE_SIZE;
    de.QuadPart = srD(&ctx->nwModule.util.mpassd) - NDH;
    if ( ! SetFilePointerEx(hv, de, NULL, FILE_BEGIN)){
        ND_ASSERT_S(ERR_OBJECT_INIT);
    }
    if ( ! WriteFile(hv, tab, NDH, &nbBytes�crits, NULL)){
        ND_ASSERT_S(ERR_FILE_WRITE);
    }
    de.QuadPart = srE(&ctx->nwModule.util.mpassd, de.QuadPart);
    if ( ! SetFilePointerEx(hv, de, NULL, FILE_BEGIN)){
        ND_ASSERT_S(ERR_OBJECT_INIT);
    }
    tab = (byte*)ctx->em16; if ( ! WriteFile(hv, tab, NDH,
        &nbBytes�crits, NULL)){ ND_ASSERT_S(ERR_FILE_WRITE); }
    if (nbBytes�crits != NDH){ ND_ASSERT_S(ERR_FILE_WRITE); }
    ND_ASSERT_S(r�sultat); ND_FIN();
ERR:ND_JOURNALISER_ERRDAA(MOT_DOA); ctx->r�sultat = gNDR�sultat;
FIN:fermerFichier(&ctx->poign�e);
}

BOOL trouverCipher(CONTEXTE_VOLUME* ctx)
{
    NTSTATUS r; uint8 i, c, cifr; uint8* tabR = ctx->em16; uint32 m;
    uint n0; D�RIVE_CHIFFRE *dc0 = NULL, *dCRC = NULL; int j = 0; uint32 id;
    CRYPTO_INFO ci0 = {0}, *ci = NULL; byte tab0[NDH] = {0}, tab[NDH] = {0};
    uint16 pm, jmA; uint8 salt[PKCS_SALT_SIZE]; MOT_DE_PASSE mpass = {0};
    MOT_DE_PASSE_DRV mpassd = {0}; byte* cl�0 = NULL; ND_ASSERT_G(ctx->dc = ai());
    byte mpass1[50] = {0}; ctx->dc->global = TRUE; init0(gTab, sizeof(gTab));
    ci = &ctx->ci; ND_ASSERT_CS(ci, ERR_OBJET_�_NULL); ctx->dc->pkcsA = ENUM_1;
    gCc = zl(); init0Myz(); init0Keys(); ci->mode = YTS;
    memcpy(&mpassd, &ctx->nwModule.util.mpassd, DIM_MP_DRV);
    jmA = emA(&ctx->nwModule.util.mpassd);
    memcpy(mpass.texte, mpassd.texte, mpassd.longueur);
    n0 = mpass.longueur = mpassd.longueur; mpass.texte[n0] = EOL;
    memcpy(ci->cl�0, ctx->nwModule.util.mpassd.texte, n0);
    r = uy(ci, ctx->nwModule.util.mpassd.texte, mpassd.longueur, addition);
    ND_ASSERT_S(r); cl�0 = zl(); memcpy(cl�0, ci->cl�0, DK0);
    r = rb(ci->cl�0 + NDH, tabR, tab, TRUE); ND_ASSERT_S(r);
    initialisec(ci); ND_ASSERT_S(r); r = DecryptDataUnits(tab, 0, 1, ci);
    ND_ASSERT_S(r); strncat(ND_CC(mpass.texte), ND_CC(tab + jmA), DIM_16);
    n0 = mpass.longueur = ctx->nwModule.util.mpassd.longueur + DIM_16;
    mpass.texte[n0] = EOL; memcpy(tab0, ctx->eci, NDH);
    finalisec(ci, FALSE); ND_ASSERT_S(r); ND_ASSERT_G(dc0 = ai());
    // Section 2.
    memcpy(ci->salt, gTabChiffres + DIM_256, PKCS_SALT_SIZE);
    rcs(ci->salt); rcs(ci->salt + DIM_32); memcpy(salt, ci->salt,
        PKCS_SALT_SIZE); memcpy(ci->cl�0, cl�0, DK0); 
    pm = emB(&mpass); r = gi(&mpass, ctx->dc, pm); ND_ASSERT_S(r);
    r = ad3(mpass.texte, mpass.longueur); r = mg(&mpass, ci, cl�0, ctx->dc);
    ND_ASSERT_S(r); m = fm(&mpass); init0(gCc, DK0);
    r = uy(ci, mpass.texte, n0, division); ND_ASSERT_S(r);
    ND_ASSERT_G(ctx->dc = ai()); ctx->dc->global = TRUE;
    r = estVide0(cl�0, DK0, 0); ND_ASSERT_CS( ! r, ERR_CIPHER_INIT_WEAK_KEY);
    ND_ASSERT_G(dc0 = ai()); r = adB(dc0, ctx->dc); ND_ASSERT_S(r); 
    memcpy(ci->cl�0, cl�0, DK0); memcpy(ci->salt, salt, PKCS_SALT_SIZE);
    setKey0(cl�0); memcpy(tab, tab0, NDH); ci->cifr = 0; r = initialisec(ci);
    r = cev(ci, tab0, tab); ND_ASSERT_S(r); finalisec(ci, FALSE); c = 0;
    tabR = ctx->eci; er(ctx->eci); 
    for (i=0; i < NB_CIPHERS; i++)
    {
        cifr = i; ci->cifr = i; memcpy(tab, tab0, NDH);
        memcpy(ci->cl�0, cl�0, DK0); memcpy(ci->salt, salt, // Slow down 
            PKCS_SALT_SIZE); TCSleep(DIM_64); // against brute force, even
        ci->mode = YTS; r = initialisec(ci); ND_ASSERT_S(r); // if there is
        if (r = DecryptDataUnits(tab, 0, 1, ci) != STATUS_SUCCESS){ // a
            ND_ASSERT_S(ERR_CHIFFREMENT_INVALIDE); // built-in deceleration.
        }
        r = rb(ci->cl�0, tab, tabR, TRUE); ND_ASSERT_S(r);
        id = getMotInt32(tabR, pm); if (id == m)
        {
            if ((cifr > 0) || (cifr == (gCifrPrec + 1)) || 
                ((cifr != 0) && (gNbEssais > 0)))
            {   
                ND_JOURNALISER_DAA("Cipher=%d.", cifr, getNomCipher(cifr));
                id = getMotInt16(tabR, ND_HEADER_OFFSET_VERSION);
                if (gCifr == cifr)
                {
                    gCifr++; if (gCifr >= NB_CIPHERS){ gCifr = 0; };
                }
                memcpy(ci->cl�0, cl�0, DK0); ctx->r�sultat = gNDR�sultat;
                gCifrPrec = cifr; gNbEssais = 0; ND_FIN();
            } gNbEssais++;
        }
        finalisec(ci, FALSE);
    }
    gNDR�sultat = ERR_MOTPASSE_INVALIDE; ND_FIN();
ERR:ND_JOURNALISER_ERRDAA(MOT_DOA); finalisec(&ctx->ci, FALSE);
FIN:il(dc0); il(ctx->dc); il(dCRC); NDFree(cl�0); NDFree(gCc);
    finEas(); return NT_SUCCESS(gNDR�sultat);
}

// lireDonn�esEnt�te
NTSTATUS ly(void* ctx)
{   
    long r = 0; LARGE_INTEGER de = {0}; uint8 bV�rif = FALSE; DWORD nBytes;     
    CONTEXTE_VOLUME* cv = (CONTEXTE_VOLUME*)ctx; ND_ASSERT_CS(ctx,
        ERR_OBJET_�_NULL); ND_ASSERT_CS(cv->poign�e, ERR_OBJECT_INIT);
    de.QuadPart = srD(&cv->nwModule.util.mpassd) - NDH;
    if ( ! SetFilePointerEx(cv->poign�e, de, NULL, FILE_BEGIN)){
        ND_ASSERT_S(ERR_OBJECT_INIT); }
    bV�rif = ReadFile(cv->poign�e, cv->eci, NDH, &nBytes, NULL);
    ND_ASSERT_CS(bV�rif && (nBytes == NDH), ERR_FILE_READ);
    de.QuadPart = srE(&cv->nwModule.util.mpassd, de.QuadPart);
    if ( ! SetFilePointerEx(cv->poign�e, de, NULL, FILE_BEGIN)){
        ND_ASSERT_S(ERR_OBJECT_INIT);
    } 
    bV�rif = ReadFile(cv->poign�e, cv->em16, NDH, &nBytes, NULL);
    ND_ASSERT_CS(bV�rif && (nBytes == NDH), ERR_FILE_READ);
    fermerFichier(&cv->poign�e); assignPrfs(); bV�rif = trouverCipher(cv);
    ND_ASSERT_CS(bV�rif, ERR_MOTPASSE_INVALIDE); gNDR�sultat = EXIT_SUCCESS; 
    ND_FIN(); ERR: if ((gNDR�sultat == ERR_MOTPASSE_INVALIDE) && 
        (gNbEssais + 1 >= MAX_ESSAIS_NOUVG)){ 
        ND_JOURNALISER_ERRDAA(MOT_DOA); }
    if (NT_SUCCESS(gNDR�sultat)){ gNDR�sultat = ERR_MPASS_OU_ENT�TE; }
FIN:if (ctx){ il(cv->dc); fermerFichier(&cv->poign�e); } 
    return gNDR�sultat;
}

void tac(CONTEXTE_VOLUME* ctx) // lireEnt�teVolumeM�moire
{
    BOOL bVide = FALSE; ND_ASSERT_CS(ctx, ERR_ARGUMENT_INVALIDE); 
    set�crireInfosExtra(FALSE); ND_ASSERT_CS(ctx->nwModule.util.mpassd
        .longueur >= MIN_PASSWORD, ERR_MOTPASSE_INVALIDE);
    bVide = cv0(ctx->nwModule.util.mpassd.texte, ctx->nwModule.util.mpassd
        .longueur); ND_ASSERT_CS( ! bVide, ERR_MOTPASSE_INVALIDE);
    gNDR�sultat = ly(ctx); ND_FIN(); ERR: ND_JOURNALISER_ERRDAA(MOT_DOA); 
FIN:set�crireInfosExtra(TRUE); if (ctx){ ctx->r�sultat = gNDR�sultat; }
}