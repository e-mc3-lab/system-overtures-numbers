/**
 * @auteur: SCLE|CSES.
 */

#include <math.h>
#include "GenKey.h"

typedef struct
{
    void(*setRandKey)(byte tabCad[], uint i);
    
} RandomKeyFunction;

#define DIM_RKF sizeof(RandomKeyFunction)

typedef struct
{
    double(*opA)(double a);
    double(*opB)(double a, double b);
    double(*opC)(double a, double b, double c);

} RandomKeyOperation;

#define NB_OP 50    

static RandomKeyOperation gTabOps[NB_OP] = {0};
static RandomKeyFunction gTabRfs[NB_PRF] = {0}; BOOL bIniTabPrfs = FALSE;

double plus(double x, double y){ return x + y; }
double moins(double x, double y){ return x - y; }
double fois(double x, double y){ return x * y; }
double diva(double x, double y){ return (y != 0 ? x / y : x); }
double divb(double x, double y){ return (y != 0 ? (x * y) / y : x); }
double divc(double x, double y){ return (y != 0 ? (x + (y * y )) / y : x); }
double nxta(double x, double y){ return nextafter(x, y); }
double nearbn(double x){ return nearbyint(x); }

double labsolu(double x)
{
    double r�sult = double(llabs(uint64(x)));
    return (r�sult > 0.0001 ? r�sult : 1.0);
}

double getRsA(RandomKeyOperation* op, double x){
    return labsolu(op->opA(x));
}

double getRsB(RandomKeyOperation* op, double x, double y){
    return op->opB(double(llabs(llong(x))), y);
}

double getRsC(RandomKeyOperation* op, double x, double y, double z){
    return labsolu(op->opC(x, y, z));
}

#ifndef exp10
  double exp10(uint8 x){ return pow(10, x); }
#endif

RandomKeyFunction* getRkf(uint16 i)
{
    if (i < NB_PRF){ return &gTabRfs[i]; } else { return NULL; }
}

void calcPrf(byte tabCad[], const uint i, const uint8 tab[], const uint8 N)
{
    double s = 0.0, r = 0, result = 1.0; RandomKeyOperation* op = NULL;
    byte* tabc = tabCad + i; for (uint8 j = 0; j < N; j++)
    {
        s = double(tabc[j]); op = &gTabOps[tab[j]];
        if (op->opA){ r = getRsA(op, s); }
        else if (op->opB){ r = getRsB(op, result, s); }
        else { r = getRsC(op, result, double(tab[0]), s); }
        if (r < 0.1)
        {
            char tabr[DIM_16] = {0}; double conv = 1;
            sprintf(tabr, "%12f", result);
            for (uint8 l = 0; l < 3; l++){ conv += tabr[j] * exp10(j); }
            result = conv;
        } else if (r < 100){ r *= 1000; } result += r;
        if (result < DIM_256){ result *= s; }
        result = double(llabs(uint64(result)) % DIM_256);
        if (result == 0){ result = 1; } tabc[j] = byte(result);
    }
}
void iniTabOps()
{   
    uint8 i = 0;
    gTabOps[i++].opB = plus;
    gTabOps[i++].opB = moins;
    gTabOps[i++].opB = fois;
    gTabOps[i++].opB = diva;
    gTabOps[i++].opB = divb;
    gTabOps[i++].opB = divc;
    gTabOps[i++].opA = acos;
    gTabOps[i++].opA = asin;
    gTabOps[i++].opA = atan;
    gTabOps[i++].opA = cos;
    gTabOps[i++].opA = cosh;
    gTabOps[i++].opA = rint;
    gTabOps[i++].opA = exp;
    gTabOps[i++].opA = fabs;
    gTabOps[i++].opB = fmod;
    gTabOps[i++].opA = log;
    gTabOps[i++].opA = log10;
    gTabOps[i++].opB = pow;
    gTabOps[i++].opA = sin;
    gTabOps[i++].opA = sinh;
    gTabOps[i++].opA = sqrt;
    gTabOps[i++].opA = tan;
    gTabOps[i++].opA = tanh;
    gTabOps[i++].opA = acosh;
    gTabOps[i++].opA = asinh;
    gTabOps[i++].opA = atanh;
    gTabOps[i++].opA = ceil;
    gTabOps[i++].opA = cbrt;
    gTabOps[i++].opA = erf;
    gTabOps[i++].opA = erfc;
    gTabOps[i++].opA = exp2;
    gTabOps[i++].opA = expm1;
    gTabOps[i++].opB = fdim;
    gTabOps[i++].opA = floor;
    gTabOps[i++].opB = atan2;
    gTabOps[i++].opA = lgamma;
    gTabOps[i++].opB = nxta;
    gTabOps[i++].opA = round;
    gTabOps[i++].opB = hypot;
    gTabOps[i++].opC = fma;
    gTabOps[i++].opB = fmax;
    gTabOps[i++].opB = fmin;
    gTabOps[i++].opA = floor;
    gTabOps[i++].opA = nearbn;
    gTabOps[i++].opA = log1p;
    gTabOps[i++].opA = log2;
    gTabOps[i++].opA = logb;
    gTabOps[i++].opA = tgamma;
}

void prf00(byte tabCad[], const uint i)
{
    uint8 tab[] = { 11, 5, 40 };
    calcPrf(tabCad, i, tab, sizeof(tab));
}

void prf01(byte tabCad[], const uint i)
{
    uint8 tab[] = { 17, 0, 34 };
    calcPrf(tabCad, i, tab, sizeof(tab));
}

void prf02(byte tabCad[], const uint i)
{
    uint8 tab[] = { 8, 0, 40 };
    calcPrf(tabCad, i, tab, sizeof(tab));
}

void prf03(byte tabCad[], const uint i)
{
    uint8 tab[] = { 8, 3, 28 };
    calcPrf(tabCad, i, tab, sizeof(tab));
}

void prf04(byte tabCad[], const uint i)
{
    uint8 tab[] = { 36, 0, 25 };
    calcPrf(tabCad, i, tab, sizeof(tab));
}

void prf05(byte tabCad[], const uint i)
{
    uint8 tab[] = { 8, 2, 42 };
    calcPrf(tabCad, i, tab, sizeof(tab));
}

void prf06(byte tabCad[], const uint i)
{
    uint8 tab[] = { 24, 4, 13 };
    calcPrf(tabCad, i, tab, sizeof(tab));
}

void prf07(byte tabCad[], const uint i)
{
    uint8 tab[] = { 14, 3, 27 };
    calcPrf(tabCad, i, tab, sizeof(tab));
}

void prf08(byte tabCad[], const uint i)
{
    uint8 tab[] = { 44, 0, 39 };
    calcPrf(tabCad, i, tab, sizeof(tab));
}

void prf09(byte tabCad[], const uint i)
{
    uint8 tab[] = { 16, 0, 23 };
    calcPrf(tabCad, i, tab, sizeof(tab));
}

void prf10(byte tabCad[], const uint i)
{
    uint8 tab[] = { 24, 3, 18 };
    calcPrf(tabCad, i, tab, sizeof(tab));
}

void prf11(byte tabCad[], const uint i)
{
    uint8 tab[] = { 39, 0, 27 };
    calcPrf(tabCad, i, tab, sizeof(tab));
}

void prf12(byte tabCad[], const uint i)
{
    uint8 tab[] = { 8, 4, 26 };
    calcPrf(tabCad, i, tab, sizeof(tab));
}

void prf13(byte tabCad[], const uint i)
{
    uint8 tab[] = { 19, 0, 29 };
    calcPrf(tabCad, i, tab, sizeof(tab));
}

void prf14(byte tabCad[], const uint i)
{
    uint8 tab[] = { 18, 4, 36 };
    calcPrf(tabCad, i, tab, sizeof(tab));
}

void prf15(byte tabCad[], const uint i)
{
    uint8 tab[] = { 24, 4, 31 };
    calcPrf(tabCad, i, tab, sizeof(tab));
}

void assignPrfs()
{
   RandomKeyFunction rkf = {0}; if ( ! bIniTabPrfs){ iniTabOps(); }
   bIniTabPrfs = TRUE; uint8 i = 0;
   gTabRfs[i++].setRandKey = prf00;
   gTabRfs[i++].setRandKey = prf01;
   gTabRfs[i++].setRandKey = prf02;
   gTabRfs[i++].setRandKey = prf03;
   gTabRfs[i++].setRandKey = prf04;
   gTabRfs[i++].setRandKey = prf05;
   gTabRfs[i++].setRandKey = prf06;
   gTabRfs[i++].setRandKey = prf07;
   gTabRfs[i++].setRandKey = prf08;
   gTabRfs[i++].setRandKey = prf09;
   gTabRfs[i++].setRandKey = prf10;
   gTabRfs[i++].setRandKey = prf11;
   gTabRfs[i++].setRandKey = prf12;
   gTabRfs[i++].setRandKey = prf13;
   gTabRfs[i++].setRandKey = prf14;
   gTabRfs[i++].setRandKey = prf15;
}

void prf(byte tabCad[], const uint i)
{
   RandomKeyFunction* prf = NULL; byte* tab = (tabCad + i);
   uint16 j = 0;    j = tab[9] % DIM_16;
   prf = getRkf(j); if (prf){ prf->setRandKey(tabCad, i + (j % 13)); }
   j = tab[5] % DIM_16;
   prf = getRkf(j); if (prf){ prf->setRandKey(tabCad, i + (j % 13)); }
   j = tab[4] % DIM_16;
   prf = getRkf(j); if (prf){ prf->setRandKey(tabCad, i + (j % 13)); }
}
