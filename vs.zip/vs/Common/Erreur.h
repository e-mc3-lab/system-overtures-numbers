/*
 Legal Notice: Modifications and additions to the original source code 
 (contained in this file) and all other portions of this file are 
 Copyright (c) 2003-2013 'Fondation TrueCrypt' and are governed 
 by the SCLE License; the full text of which is contained in the 
 file Licence.txt 1.0 included in NetDisq distribution packages.
 */
#ifndef ND_HEADER_ERREUR
#define ND_HEADER_ERREUR

#include "CompatibX.h"


#ifndef NT_SUCCESS
#define NT_SUCCESS(Status) ((long)Status >= 0)
#endif

enum
{
    /**
     WARNING: ADD ANY NEW CODES AT THE END (DO NOT INSERT THEM BETWEEN EXISTING). DO *NOT* DELETE 
     ANY EXISTING CODES! Changing these values or their meanings may cause incompatibility with 
     other versions (for example, if a new version of the SCLE installer receives an error 
     code from an installed driver whose version is lower, it will report the error incorrectly). 

     SCLE: les constantes sont n�gatives afin de les valider avec NT_SUCCESS.
           Elles sont de plus diff�rentes de celles de winerror.h et ntstatus.h.
           Voir aussi ND_ASSERT. La valeur s'affiche en hexad�cimale invers�e:
           dans la calculatrice, s�lectionner Dword et ensuite Qword; ou
           soustraire 0x100000000 du r�sultat. Ex: 0xffffffff - 0x100000000 = -1.

           Noter que la fonction IoCompleteRequest (Mode Noyau [kernel])
           ne met pas � jour le contenu de SystemBuffer en retour (Mode
           Utilisateur [user]), quand Irp.IoStatus est insucc�s et .info est 0.
    */
    ERR_SUCCESS                         =   0, // STATUS/EXIT_SUCCESS
    ERR_INSUCC�S                        =  -1,
    ERR_VERSION_SE_INVALIDE             =  -2,
    ERR_OBJECT_NOT_FOUND                =  -3,
    ERR_DRIVER_VERSION                  =  -5,
    ERR_NOUVEAU_DOA                     =  -6, 
    ERR_DRIVER_PAS_D�MARR�_OU_EN_ERREUR =  -8,
    ERR_COMPRESSION_NOT_SUPPORTED       =  -9,
    ERR_SECTOR_SIZE_INCOMPATIBLE        = -10,
    ERR_OBJECT_INIT                     = -11,
    ERR_OBJECT_SIZE_WRONG               = -12,
    ERR_FILE_OPEN                       = -13,
    ERR_FILE_READ                       = -14,
    ERR_FILE_WRITE                      = -15,
    ERR_ACCESS_DENIED                   = -18,
    ERR_SYS_FICHIERS_INCERTAIN          = -19,
    ERR_NEW_VERSION_REQUIRED            = -20,
    ERR_MAX_ESPACE_MOT_DE_PASSE         = -21,
    ERR_MOTPASSE_INVALIDE               = -22,
    ERR_MPASS_OU_ENT�TE                 = -23,   
    ERR_KEYFILE_NOT_FOUND               = -24,
    ERR_TECHNIQUE                       = -27,
    ERR_INVALID_USER                    = -31,
    ERR_D�PASSEMENT_RESSOURCE           = -32,
    ERR_NO_ETHX_DB                      = -36,
    ERR_CIPHER_INIT_FAILURE             = -37,
    ERR_CIPHER_INIT_WEAK_KEY            = -38,
    ERR_SELF_TESTS_FAILED               = -40,
    ERR_INVALID_MODE                    = -41,
    ERR_INVALID_CIPHER                  = -42,
    ERR_INVALID_INIT                    = -47,
    ERR_ALGORITHME_INVALIDE             = -49,
    ERR_CHIFFREMENT_INVALIDE            = -50,
    ERR_AUTHENTIFICATION                = -52,
    ERR_DONT_REPORT                     = -53,
    ERR_ARGUMENT_INVALIDE               = -54,    
    ERR_REFS_M�MOIRE_NON_LIB�R�ES       = -56,
    ERR_USER_ABORT                      = -58,
    ERR_MAX_REFS_OBJET                  = -59,  
    ERR_INVALID_FILE                    = -60,
    ERR_OBJET_�_NULL                    = -62,
    ERR_FIN                             = -63,
};


#ifdef __cplusplus
extern "C" {
#endif

static int gNDrivErreur;

#ifndef TC_WINDOWS_DRIVER

char* getErreurWindows(DWORD code);
DWORD traiterErreurWindows();
void traiterErreurUnit�NonDisponible();
BOOL estDisqueEnErreur(DWORD code);
BOOL estErreurLectureDisque(DWORD code);
BOOL estErreur�critureDisque(DWORD code);

#endif // ! TC_WINDOWS_DRIVER

#ifdef __cplusplus
}
#endif

#endif // ND_HEADER_ERREUR