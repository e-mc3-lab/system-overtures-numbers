/*
 Copyright(c) 2003-2013 'Fondation TrueCrypt'. All rights reserved.

 Governed by the NetDisq License, the full text of which is contained in
 the file Licence 1.0.txt included in NetDisq distribution packages.
 2024-2025.
*/

#ifdef TC_WINDOWS_DRIVER

   #include <wdm.h>
   #include <windef.h>

   ANSI_STRING ansiString; // R�sultat d'impression (final).

   char* toCCHAR(WCHAR* txt)
   {        
       UNICODE_STRING unicodeString;
       RtlInitUnicodeString(&unicodeString, txt);        
       RtlInitAnsiString(&ansiString, NULL);       
       RtlUnicodeStringToAnsiString(&ansiString, &unicodeString, FALSE);        
       return (char*) ansiString.Buffer;
   }

#ifndef IDOK
#define IDOK 1
#endif

#ifndef IDNO
#define IDNO 0
#endif

#else
   #include <Windows.h>
   BOOL Silent = FALSE;

#endif

#ifdef TC_WINDOWS_DRIVER 
#include "Driver.h"
#endif
#include "Constantes.h"
#include "Message.h"


#ifdef TC_WINDOWS_DRIVER  

   void NDRaiseStatus(long code)
   {
        __try // NB: on ne relaye pas l'exception au niveau sup�rieur
        {      // pour l'instant (jusqu'� ce que le projet soit stable).
            if (KeGetCurrentIrql() < DISPATCH_LEVEL){
                ExRaiseStatus(code);
            } else {
                journaliser("Erreur NDRaiseStatus");
            }
        } __except(EXCEPTION_EXECUTE_HANDLER) {
            journaliser("Erreur NDRaiseStatus (%x).", GetExceptionCode());
        }    
   } 

   void TCThrowException(char* msg, long statut)
   {
       journaliser("Exception: %s.", (msg == NULL ? "" : msg));
       NDRaiseStatus(statut);
   } 
#else 
   
   void TCThrowException(const char msg[], long statut)
   {       
       // journaliser("Exception: %s", (msg == NULL ? "" : msg));       
       // afficherErreur(constEnWCHAR(msg));
       RaiseException(statut, EXCEPTION_CONTINUE_EXECUTION, 0, NULL); 
   } 

   void CTRaiseStatus(long code)
   {
       RaiseException(code, EXCEPTION_CONTINUE_EXECUTION, 0, NULL); 
   }
#endif

int afficherInfo(const WCHAR txt[])
{
    #ifdef TC_WINDOWS_DRIVER
       journaliser("%ls", txt); return IDOK;
    #else
       if (Silent){ 
            return IDOK; 
       } else {
            return MessageBoxW(NULL, txt, TITRE_W, MB_ICONINFORMATION);
       }        
    #endif    
}

int afficherAttention(const WCHAR txt[])
{
    #ifdef TC_WINDOWS_DRIVER
        journaliser("%ls", txt); return IDOK; 
    #else
        if (Silent){ 
            return IDNO; 
        } else {
            return MessageBoxW(NULL, txt, TITRE_W, MB_ICONWARNING);
        }        
    #endif    
}

int afficherErreur(const WCHAR txt[])
{
    #ifdef TC_WINDOWS_DRIVER
        journaliser("%ls", txt); return IDOK; 
    #else
        if (Silent){ 
            return IDNO; 
        } else {
            return MessageBoxW(NULL, txt, TITRE_W, MB_ICONERROR);
        }        
    #endif    
}

/*
* Il n'y a pas d'int�raction avec les drivers: on journalise dans ce cas.
*/
int poserQuestionOuiNon(const WCHAR txt[])
{
    #ifdef TC_WINDOWS_DRIVER
        journaliser("%ls", txt); return IDNO;     
    #else
        if (Silent){ 
            return IDNO; 

        } else {
            return MessageBoxW(NULL, txt, TITRE_W, 
                MB_ICONQUESTION | MB_YESNO | MB_DEFBUTTON1);
        }
    #endif    
}

int poserQuestionAttentionOuiNon(const WCHAR txt[])
{
    #ifdef TC_WINDOWS_DRIVER
        journaliser("%ls", txt); return IDNO;  
    #else
        if (Silent){ 
            return IDNO; 
        } else {

            return MessageBoxW(NULL, txt, TITRE_W, 
                MB_ICONWARNING | MB_YESNO | MB_DEFBUTTON1);
        }
    #endif    
}

int poserQuestionAttentionNonOui(const WCHAR txt[])
{
    #ifdef TC_WINDOWS_DRIVER
        journaliser("%ls", txt); return IDNO; 
    #else
        if (Silent){ 
            return IDNO; 
        } else {
            return MessageBoxW(NULL, txt, TITRE_W, 
                MB_ICONWARNING | MB_YESNO | MB_DEFBUTTON2);
        }        
    #endif    
}