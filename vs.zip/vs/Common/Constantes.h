#ifndef CONSTANTES_H
#define CONSTANTES_H
/**
 * ==============================================================================
 * SCLE: la conversion des #define de CHAR* � W(ide)CHAR* (et inversement) n'est
 * pas accept�e par le compilateur. Utiliser TEXT. Les projets doivent �tre en
 * format 'UNICODE'.
 * ==============================================================================
 */

#define MOT_SERVICE                  "Service"
#define SCLE                         "Scle [+] Cses"
#define MOT_SCLE_MAJ                 "SCLE [+] CSES"
#define NETDISQ                      "netdisq"
#define MOT_NETDISQ                  "NetDisq"
#define DISQUE                       "disque" // Voir enum dans ServiceCt.h

#define MOT_VOLUME                   "Volume"
#define MOT_FILTRE                   "Filtre"
#define DOSSIER_DIST                 "dist\\"
#define DOSSIER_PRG                  "prg\\"
#define DOSSIER_DONN�ES              "don\\"

#define NOM_SERVICE_SCLE             MOT_SERVICE " " SCLE
#define TITRE_W                      TEXT(MOT_NETDISQ) // L" Scle"

#define SUFX_EXE                     ".exe"
#define SUFX_DLL                     ".dll"
#define SUFX_SYS                     ".sys"
#define SUFX_ND                      ".nd" // Pronunciation ? 'dot n-day'

#define NOM_VOLUME_EXE               NETDISQ "-volume" SUFX_EXE
#define NOM_NETDISQ_VOLUME           MOT_NETDISQ MOT_VOLUME // TODO: ajouter au dictionnaire
#define NOM_COMPAGNIE_SCLE           "Service Cryptographique pour Logiciels " \
                                     "d'Entreprise Enr."
#define ND_RELEASE_DATE_YEAR         2026 // Voir dans Mount.cpp
#define ND_RELEASE_DATE_MONTH        1 // TC: "Auto-detect a system crash".
#define ND_STR_RELEASED_BY           "Mis � jour par " NOM_COMPAGNIE_SCLE " En " \
                                     ND_RELEASE_DATE_YEAR
#define VERSION_STRING               "1.0a" // Version displayed to user.
#define VERSION_NUM                  0x010a // Compare with registry value.

#define MAX_URL_LENGTH               2080 // Internet Explorer limit.
#define ND_HOMEPAGE                  "http://scle.compagnie.qc.ca/"
#define ND_APPLINK                   "http://scle.compagnie.qc.ca/applink?version=" VERSION_STRING
#define ND_APPLINK_SECURE            "https://scle.compagnie.qc.ca/applink?version=" VERSION_STRING

#define CHEM_P�RIPH_RELATIF_COURANT  "\\\\.\\"
#define NOM_UNIT�_DISQUE_EN          "PhysicalDrive"
#define ND_WIN_DEV_USER_MODE         TEXT(CHEM_P�RIPH_RELATIF_COURANT)\
                                     TEXT(MOT_NETDISQ)

#define EXCL_ACCESS_MAX_AUTO_RETRIES 500
#define EXCL_ACCESS_AUTO_RETRY_DELAY 10

#define D�LAI_1SEC                   int64(-10 * 1000 * 1000) // x 100 ns = 1 s.
#define D�LAI_3SEC                   3 * D�LAI_1SEC // < 0: selon le temps SE.
#define D�LAI_6SEC                   6 * D�LAI_1SEC
#define D�LAI_10SEC                  10 * D�LAI_1SEC

#define MIN_UNIT_VOLUME              ('A' - 'A') + 1
#define MAX_UNIT_VOLUME              ('Z' - 'A') + 1

#define MAX_LONGUEUR_MSG             1030

#define ANNULATION                   0
#define CONFORME                     1
#define EN_ERREUR                    2 // SCLE: et plus..
#define NON_ADMIN_NTFS               3 

#endif // CONSTANTES_H