/*
 Copyright (c) 2005-2010 'Fondation TrueCrypt'. All rights reserved.

 Governed by the SCLE License; the full text of which is contained in the
 file Licence 1.0.txt included in NetDisq distribution packages. 2023-2026.
*/

#include <stdio.h>

#ifdef __cplusplus
extern "C" {
#endif

char *XmlNextNode(const char xmlNode[]);
char *XmlFindElement(const char xmlNode[], const char nodeName[]);
char *XmlGetAttributeText(const char xmlNode[], const char xmlAttrName[],
        char xmlAttrValue[], int xmlAttrValueSize);
char *XmlGetNodeText(const char xmlNode[], char xmlText[], int xmlTextSize);
int XmlWriteHeader(FILE *file);
int XmlWriteHeaderW(FILE *file);
int XmlWriteFooter(FILE *file);
int XmlWriteFooterW(FILE *file);
char *XmlFindElementByAttributeValue(char xml[], const char nodeName[],
        char attrName[], char attrValue[]);
char *XmlQuoteText(const char textSrc[], char textDst[], int textDstMaxSize);

#ifdef __cplusplus
}
#endif
