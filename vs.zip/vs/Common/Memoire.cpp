/**
  * Noter que "memset" ne fonctionne pas bien quand appel�e dans 
  * une boucle (en lot) et dans un thread ? TODO: � r�essayer...
  * La m�thode SAFE_ERASE64 est utilis�e en remplacement. Elle n'est pas
  * moins rapide � l'ex�cution quand la dimension est moins de 4 Ko.
  * SCLE 2024-2026.
  */
#include "Journal.h"
#include "Memoire.h"

#ifdef __cplusplus
extern "C" {
#endif

#ifdef TC_WINDOWS_DRIVER      
  #include <wdm.h>
#endif

#define N  2 * MILLE_VINGT_QUATRE

typedef struct 
{
    void* objet; TypeAdresse catMem; int nbRefs; uint noLigne; ENTIER dim;
        
} OBJET_R�FER;

typedef struct 
{
    OBJET_R�FER table[N];
        
} R�F�RENCES;
 

#if (defined(_DEBUG) || defined(DEBUG)) && defined(_JOURAMEM)

static R�F�RENCES gRefs = {0}; static volatile long gNbEc = 0;

int getPosObjet(void* mem)
{ 
    int i, nbVides = 0; BOOL trouv� = FALSE; for (i=0; i < N; i++)
    {
        if (gRefs.table[i].objet == NULL){ 
            nbVides++;
        } else if (mem == gRefs.table[i].objet){ 
            trouv� = TRUE; break;
        } // Parcourir au plus le tiers du tableau.
        if (nbVides > (N/3)){ break; }
    }
    if ( ! trouv� ){ i = -1; } return i;
}

OBJET_R�FER* setR�f�rence(void* mem, int unit�)
{
    OBJET_R�FER* obj = NULL; int i = getPosObjet(mem); 
    if (i >=0)
    { 
        obj = &gRefs.table[i]; obj->nbRefs += unit�;        
    } else for (i=0; i < N; i++){
        // Chercher un espace libre.
        if (gRefs.table[i].objet == NULL)
        {
            gRefs.table[i].objet = mem;
            gRefs.table[i].nbRefs = unit�;
            obj = &gRefs.table[i]; break;
        }
    } /*for*/ if ( ! obj && i >= N){
        journaliser("Erreur setR�f�rence: le maximum est atteint (%d).", i); }
    return obj;
}

BOOL estMaxNbRefsAtteint(){ return (gNbEc > N); }

void NDR�f�rerObjetV�rif(void* mem, ENTIER n, TypeAdresse catMem, uint noLigne)
{
    /* ND_ASSERT_S((KeGetCurrentIrql() == PASSIVE_LEVEL)) */
    if (mem)
    {   // Via safe_malloc.
        OBJET_R�FER* obj = setR�f�rence(mem, 1);
        if ( ! obj){ goto ERR; } obj->catMem = catMem;
        obj->noLigne = noLigne; if (catMem == M�MOIRE){ obj->dim = n; }
        journaliserRM("NDR�f�rerObjet %d %p (cat.mem. %d. "
            "Ligne %d).", obj->nbRefs, mem, obj->catMem, noLigne);
    }
    if (estMaxNbRefsAtteint())
    {
        gNDR�sultat = gNDrivErreur = ERR_MAX_REFS_OBJET;
        ND_JOURNALISER_EXCEPTION("Memoire", ERR_MAX_REFS_OBJET, __LINE__);
    } return;
ERR: gNDR�sultat = ERR_OBJET_�_NULL;
    journaliser("NDR�f�rerObjetV�rif: objet %x introuvable ou en erreur "
    "(%d).", mem, gNDR�sultat); ND_JOURNALISER_SIGNET(".");
}

void NDR�f�rerObjet(void* mem, uint noLigne){
    NDR�f�rerObjetV�rif(mem, 0, R�F�RENCE, noLigne);
}

void NDAjouterR�f�rence(void* mem, uint noLigne){
    NDR�f�rerObjetV�rif(mem, 0, R�F�RENCE, noLigne);
}

void NDAjouterR�f�renceFilEx(void* mem, uint noLigne){
    NDR�f�rerObjetV�rif(mem, 0, FILEX, noLigne);
}

void NDAjouterR�f�renceReqES(void* mem, uint noLigne){
    NDR�f�rerObjetV�rif(mem, 0, REQU�TE_ES, noLigne);
}

int NDD�r�f�rerObjetV�rif(void* mem)
{
    int r�sultat = FALSE; journaliserRM("NDD�r�f�rerObjetV�rif %p.", mem);
    if (mem != NULL)
    { 
        OBJET_R�FER* obj = setR�f�rence(mem, -1); if (obj != NULL)
        {
            if (obj->nbRefs >= 0)
            {
                r�sultat = TRUE; gNbEc--;
                journaliserRM("NDD�r�ferObjet %d %p.", obj->nbRefs, mem);
            }
        } else {
            journaliser("ERREUR NDD�r�ferObjet: objet introuvable.");
        }
    } 
    return r�sultat;
}

void NDD�r�ferObjet(void* mem){ NDD�r�f�rerObjetV�rif(mem); }
  
int NDEstObjetD�r�f�rence(void* mem){ return NDD�r�f�rerObjetV�rif(mem); }

NTSTATUS NDV�riRefsOubli�es(BOOL bInitCompteur)
{
    NTSTATUS r�sultat = STATUS_SUCCESS; uint i, j = 0; BOOL bExiste = FALSE;
    journaliserRM("Liste des adresses non lib�r�es ou non d�r�f�renc�es : ");
    for (i = 0; i < N; i++)
    {
        if ((gRefs.table[i].objet != NULL) && (gRefs.table[i].nbRefs > 0))
        {
            journaliserRM("%p (mem. %d).",
                gRefs.table[i].objet, gRefs.table[i].catMem); bExiste = TRUE;
            r�sultat = ERR_REFS_M�MOIRE_NON_LIB�R�ES;
            if (i != j)
            {
                gRefs.table[j].objet = gRefs.table[i].objet;
                gRefs.table[j].catMem = gRefs.table[i].catMem;
                gRefs.table[j].nbRefs = gRefs.table[i].nbRefs;
            }
            j++;
        }
    } /*for*/ InterlockedExchange(&gNbEc, (bInitCompteur ? 0 : j));
    if ( ! bExiste){ journaliser("0 (succ�s)."); } return r�sultat;
}

BOOL yaTilDesRequ�tESNonR�solues()
{   
    // Pour les drivers de type Windows.
    BOOL r�sultat = FALSE; long i, M = InterlockedExchangeAdd(&gNbEc, 0);
    for (i = 0; i < M; i++)
    {
        if ((gRefs.table[i].objet != NULL) && (gRefs.table[i].nbRefs > 0) &&
            (gRefs.table[i].catMem == REQU�TE_ES)){ r�sultat = TRUE; break; }
    } return r�sultat;
}

#else // DEBUG

NTSTATUS NDV�riRefsOubli�es(BOOL bInitCompteur){ return STATUS_SUCCESS; };
BOOL yaTilDesRequ�tESNonR�solues(){ return FALSE; }

#endif // [!] DEBUG

void* allouerM�moire(ENTIER n, BOOL bInit0, const char nm[],
    uint noLigne, uint max) // PRE: nm doit �tre �gal � __FILE__.
{   
    void* mem = NULL; char* nomModule = (char*)nm;
    ND_ASSERT_CS( ! ((n == 0) || (n > max)), ERR_ARGUMENT_INVALIDE); 
    #ifdef TC_WINDOWS_DRIVER
      if (KeGetCurrentIrql() > DISPATCH_LEVEL)
      {
          ND_ASSERT_CS( ! IRQL_NOT_LESS_OR_EQUAL, ERR_TECHNIQUE);
      }
      mem = (void*) ExAllocatePoolWithTag(NonPagedPool, n, ND_TAG_MEM);
    #else
      mem = (void*)malloc(n);
    #endif
    #if (defined(_DEBUG) || defined(DEBUG)) && defined(_JOURAMEM)
      NDR�f�rerObjetV�rif(mem, n, M�MOIRE, noLigne); ND_ASSERT_S(gNDR�sultat);
    #endif // DEBUG
    if (nomModule) 
    {   // Conserver le nom sans le chemin.
        gNoLigne = noLigne; ENTIER M = strlen(nm); 
        nomModule = strrchr(nomModule, '\\'); // TODO: Linux '/'.
        if (nomModule){ nomModule = (char*)&nm[M - strlen(nomModule)]; }
    }
    if (mem){ if (bInit0){ init0(mem, n); } 
    } else { gNDR�sultat = STATUS_INSUFFICIENT_RESOURCES; ND_ERREUR(); }    
    #ifdef _JOURAMEM // 'JOUR'naliser 'A'llocation 'MEM'oire.
      journaliser("allouerM�moire %p %s (%d).", mem, nomModule, noLigne);
    #endif
    ND_FIN(); ERR: journaliser("Erreur allouerM�moire %x. %s (%d) n=%I64d.", 
        gNDR�sultat, nomModule, noLigne, n); ND_JOURNALISER_SIGNET(".");
    gNDrivErreur = gNDR�sultat; NDFree(mem); FIN: return mem;
}

void* safe_malloc(ENTIER n, const char nomModule[], uint noLigne){ 
    return allouerM�moire(n, FALSE, nomModule, noLigne, 10*MEGA_BYTES);
}

void* safe_malloc0(ENTIER n, const char nomModule[], uint noLigne){
    return allouerM�moire(n, TRUE, nomModule, noLigne, 10*MEGA_BYTES);
}

void* safe_malloc0M(ENTIER n, const char nomModule[], uint noLigne, uint max){
    return allouerM�moire(n, TRUE, nomModule, noLigne, max);
}

int safe_free(void** mem)
{    
    int r�sultat = TRUE; if ((mem != NULL) && (*mem != NULL))
    { 
        #ifdef TC_WINDOWS_DRIVER
          if (NDD�r�f�rerObjetV�rif(*mem, FALSE))
          {
              if (KeGetCurrentIrql() <= DISPATCH_LEVEL)
              { 
                  ExFreePoolWithTag(*mem, ND_TAG_MEM); *mem = NULL;
              } else {
                  journaliser("Le niveau IRQ est trop �lev� pour "
                      "lib�rer la m�moire (0x%08X).", mem); r�sultat = FALSE;
              }
          }
        #elif defined(_DEBUG) || defined(DEBUG)

           #if defined(_JOURAMEM) 
              journaliser("lib�rerM�moire %p.", *mem); NDD�r�ferObjet((*mem));
           #endif

           free(*mem); *mem = NULL; return NT_SUCCESS(gNDR�sultat);
        #endif // DEBUG
    } 
    gNDR�sultat = r�sultat; return r�sultat;
}

void safErase64(void* mem, const uint64 dim)
{   // PRE: 'dim' devrait �tre pr�f�rablement multiple de 8.
    volatile uint64* suppMem = NULL; ENTIER i = 0; do
    {
        if (mem && (dim > DIM_4K)){ memset(mem, 0, dim); } 
        else if (mem){
            suppMem = (volatile uint64*)(mem);
            i = dim >> 3; while (i--){ *suppMem++ = NULL; }
        } else { break; }
    } while (FALSE);
}

void setNDDrivErreur(int code){ gNDrivErreur = code; }

/**
 * Copier n bytes de src vers dest. Retourner une erreur globale quand n 
 * d�passe la taille de src. NB: les variables doivent �tre 'dynamiques'.
 */
NTSTATUS copierM�moire(void* dst, const void* src, __in ENTIER n)
{
    gNDR�sultat = EXIT_SUCCESS; int i = 0, j = 0; if (src && dst)
    {
        if (n > 0) __try 
        { 
            #if (defined(_DEBUG) || defined(DEBUG)) && defined(_JOURAMEM)
              i = getPosObjet((void*)src), j = getPosObjet((void*)dst);
              if ((i >= 0) && (j >= 0))
              {
                  volatile OBJET_R�FER objA = gRefs.table[i], objB = gRefs.table[j];
                  if ((n > objA.dim) || (n > (objB.dim))){
                      ND_ASSERT_S(ERR_ARGUMENT_INVALIDE);
                  }
              } else { ND_ASSERT_S(ERR_ARGUMENT_INVALIDE); }
            #endif
            memcpy(dst, src, n); // TODO: une fonction 'move'.
        } __except (EXCEPTION_EXECUTE_HANDLER){ ND_ASSERT_S(GetExceptionCode()); }
    } 
    ND_FIN(); ERR: ND_JOURNALISER_EXCEPTION0("Memoire", gNDR�sultat);
    journaliser("n=%I64d", n); FIN: return gNDR�sultat;
}

/**
 * PRE: les arguments (param�tres) sont d�clar�s void* pour ne pas avoir des 
 *      erreurs de compilation quand on passe des structures. Les champs 
 *      tableau doivent �tre de type uint8*. Les variables globales: byte* 
 *      ou char*. Ne pas passer une double adresse, c'est � dire &arg, quand 
 *      arg est d�j� une adresse (*).
 */
int comparerMem(const void* a, const void* b, uint64 n, BOOL bJournal)
{
    int r�sultat = 0, i; for (i=0; i < n; i++)
    {
        if (((const byte*)a)[i] < (((const byte*)b)[i]))
        {
            r�sultat = -1; if (bJournal) journaliser("Pas �gales: %c < %c "\
                "Position % d.", (ND_CC(a))[i], (ND_CC(b))[i], i); break;
        } else if ((ND_CC(a))[i] > (ND_CC(b))[i]){
            r�sultat = 1; if (bJournal) journaliser("Pas �gales: %c > %c "\
                "Position % d.", (ND_CC(a))[i], (ND_CC(b))[i], i); break;
        }
    } return r�sultat;
}  

#ifdef __cplusplus
}
#endif