#ifndef MOTDEPASSE_H
#define MOTDEPASSE_H

#include "CompatibX.h"

// NB: ce fichier est � part, � cause notamment de MainCom.idl.
#define MIN_PASSWORD               8 
#define MAX_PASSWORD               50
#define DMP256                     256 
#define DMP                        4 * DMP256 // NB: doit �tre multiple.

#define PASSWORD_LEN_MIN_WARNING   8 // Display a warning when is shorter.
#define PASSWORD_LEN_MAX_WARNING   30 // (SCLE) Warn when is greater.

#ifndef uint16
typedef unsigned short uint16; // Pour le projet Volume.
#endif

typedef struct
{    
    byte texte[DMP256]; uint16 longueur; BOOL nouveau;

} MOT_DE_PASSE_DRV; // Initial | D�but | Utilisateur.

typedef struct
{    
    byte texte[DMP+14]; uint16 longueur;

} MOT_DE_PASSE; // �tendu/D�riv�/Chiffr�.

#define DIM_MP_DRV  sizeof(MOT_DE_PASSE_DRV)
#define DIM_MP      sizeof(MOT_DE_PASSE)

#endif // MOTDEPASSE_H