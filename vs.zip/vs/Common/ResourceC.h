#ifndef RESOURCE_COMMON_H
#define RESOURCE_COMMON_H
//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file. 
// Used by Common.rc
//
#define IDR_NETDISQ_RSRC_HEADER         500
#define IDR_COMMON_RSRC_HEADER          506
#define IDD_LANGUAGE                    508
#define IDR_LICENSE                     509
#define IDR_LANGUAGE_FR                 518
#define IDR_LANGUAGE_EN                 519
#define IDR_LANGUAGE_ES                 520

// Others languages: TODO.
#define IDC_MYICON                      3

#define IDC_NETDISQ                     619
#define IDM_NETDISQ_EN                  620
#define IDM_NETDISQ_FR                  621
#define IDI_NETDISQ32                   623
#define IDI_NETDISQ16                   624
#define IDS_TITRE_APP                   626
#define IDD_AIDE_EN                     627
#define IDD_AIDE_FR                     628
#define IDM_AIDE                        630
#define IDM_FERMER                      631

#define IDT_TEXT_ABOUT_1                820
#define IDT_TEXT_ABOUT_2                821
#define IDT_TEXT_ABOUT_3                822
#define IDT_TEXT_ABOUT_4                823
#define IDT_TEXT_ABOUT_5                824
#define IDT_TEXT_ABOUT_6                825

#endif
 