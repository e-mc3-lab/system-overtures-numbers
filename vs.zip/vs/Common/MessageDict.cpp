/**
 *  @auteurs TrueCrypt et SCLE.
 */
#include <Windows.h>
#include "Constantes.h"
#include "Language.h"
#include "Sortie.h"
#include "MessageDict.h"

const BOOL Silent = FALSE; char message[500] = {0};

int Info(const char stringId[])
{
    if (Silent){ return 0; }
    return MessageBoxW(NULL, GetString(stringId), TITRE_W, MB_ICONINFORMATION);
}

int InfoTopMost(const char stringId[])
{
    if (Silent){ return 0; }
    return MessageBoxW(NULL, GetString(stringId), TITRE_W, MB_ICONINFORMATION 
        | MB_SETFOREGROUND | MB_TOPMOST);
}

int Warning(const char stringId[])
{
    if (Silent){ return 0; }
    return MessageBoxW(NULL, GetString(stringId), TITRE_W, MB_ICONWARNING | 
        MB_SETFOREGROUND | MB_TOPMOST);
}

int Error(const char stringId[])
{
    if (Silent){ return 0; }
    return MessageBoxW(NULL, GetString(stringId), TITRE_W, MB_ICONERROR);
}

int ErrorTopMost(const char stringId[])
{
    if (Silent){ return 0; }
    return MessageBoxW(NULL, GetString(stringId), TITRE_W, MB_ICONERROR | 
        MB_SETFOREGROUND | MB_TOPMOST);
}

int AskYesNo(const char stringId[])
{
    if (Silent){ return IDNO; }
    return MessageBoxW(NULL, GetString(stringId), TITRE_W, MB_ICONQUESTION | 
        MB_YESNO | MB_DEFBUTTON1);
}

int AskYesNoTopmost(const char stringId[])
{
    if (Silent){ return IDNO; }
    return MessageBoxW(NULL, GetString(stringId), TITRE_W, MB_ICONQUESTION | 
        MB_YESNO | MB_DEFBUTTON1 | MB_SETFOREGROUND | MB_TOPMOST);
}

int AskNoYes(const char stringId[])
{
    if (Silent){ return IDNO; }
    return MessageBoxW(NULL, GetString(stringId), TITRE_W, MB_ICONQUESTION | 
        MB_YESNO | MB_DEFBUTTON2);
}

int AskOkCancel(const char stringId[])
{
    if (Silent){ return IDCANCEL; }
    return MessageBoxW(NULL, GetString(stringId), TITRE_W, MB_ICONQUESTION | 
        MB_OKCANCEL | MB_DEFBUTTON1);
}

int AskWarnYesNo(const char stringId[])
{
    if (Silent){ return IDNO; }
    return MessageBoxW(NULL, GetString(stringId), TITRE_W, MB_ICONWARNING | 
        MB_YESNO | MB_DEFBUTTON1);
}

int AskWarnYesNoTopmost(const char stringId[])
{
    if (Silent){ return IDNO; }
    return MessageBoxW(NULL, GetString(stringId), TITRE_W, MB_ICONWARNING | MB_YESNO |
        MB_DEFBUTTON1 | MB_SETFOREGROUND | MB_TOPMOST);
}

int AskWarnYesNoStringTopmost(const WCHAR txt[])
{
    if (Silent){ return IDNO; }
    return MessageBoxW(NULL, txt, TITRE_W, MB_ICONWARNING | MB_YESNO | 
        MB_DEFBUTTON1 | MB_SETFOREGROUND | MB_TOPMOST);
}

int AskWarnNoYes(const char stringId[])
{
    if (Silent){ return IDNO; }
    return MessageBoxW(NULL, GetString(stringId), TITRE_W, MB_ICONWARNING | 
        MB_YESNO | MB_DEFBUTTON2);
}

int AskWarnNoYesTopmost(const char stringId[])
{
    if (Silent){ return IDNO; }
    return MessageBoxW(NULL, GetString(stringId), TITRE_W, MB_ICONWARNING | 
        MB_YESNO | MB_DEFBUTTON2 | MB_SETFOREGROUND | MB_TOPMOST);
}

int AskWarnOkCancel(const char stringId[])
{
    if (Silent){ return IDCANCEL; }
    return MessageBoxW(NULL, GetString(stringId), TITRE_W, MB_ICONWARNING | 
        MB_OKCANCEL | MB_DEFBUTTON1);
}

int AskWarnCancelOk(const char stringId[])
{
    if (Silent){ return IDCANCEL; }
    return MessageBoxW(NULL, GetString(stringId), TITRE_W, MB_ICONWARNING | 
        MB_OKCANCEL | MB_DEFBUTTON2);
}

int AskErrYesNo(const char stringId[])
{
    if (Silent){ return IDNO; }
    return MessageBoxW(NULL, GetString(stringId), TITRE_W, MB_ICONERROR | 
        MB_YESNO | MB_DEFBUTTON1);
}

int AskErrNoYes(const char stringId[])
{
    if (Silent){ return IDNO; }
    return MessageBoxW(NULL, GetString(stringId), TITRE_W, MB_ICONERROR | 
        MB_YESNO | MB_DEFBUTTON2);
}

void AbortProcess(const char stringId[])
{    // Note that this function also causes localcleanup() to be called (see atexit())
    MessageBeep(MB_ICONEXCLAMATION);
    MessageBoxW(NULL, GetString(stringId), TITRE_W, MB_ICONSTOP);
    QuitterF(NULL, ANNULATION, TRUE);
}