/*
 Legal Notice: Modifications and additions to the original source code 
 (contained in this file) and all other portions of this file are 
 governed by the SCLE License; the full text of which is contained in 
 the file Licence 1.0.txt included in NetDisq distribution packages. 
 2024-2026. 
 */
#ifndef COMMON_JOURNAL_H
#define COMMON_JOURNAL_H

#ifdef TC_WINDOWS_DRIVER
    #include <wdm.h>
    #include "SortieDrv.h"
#else
   #include "CompatibX.h"
   #include "Sortie.h"
   
   #define STATUS_SUCCESS                ((NTSTATUS)0x00000000L)
   #define STATUS_UNSUCCESSFUL           ((NTSTATUS)0xC0000001L)
   #define STATUS_INVALID_INFO_CLASS     ((NTSTATUS)0xC0000003L)
   #define STATUS_INSUFFICIENT_RESOURCES ((NTSTATUS)0xC000009AL)   
   #define STATUS_INVALID_DEVICE_REQUEST ((NTSTATUS)0xC0000010L)
   #define STATUS_INVALID_BUFFER_SIZE    ((NTSTATUS)0xC0000206L)

#endif // [!] TC_WINDOWS_DRIVER

#define CHEM_JOURNAL  C_SCLE_DONN�ES

static char gTexteJrnl[MAX_LONGUEUR_MSG] = {0};
static volatile LONG gNDR�sultat = 0; static uint gNoLigne;

#ifdef __cplusplus
extern "C" {
#endif

#define ND_ERREUR(){ \
    gNoLigne = __LINE__; goto ERR; } 

#define ND_FIN(){ goto FIN; }

// @param r�sultat (PRE) doit �tre une variable, et non une fonction.
#define ND_ASSERT_S(r�sultat) \
{ \
    gNDR�sultat = r�sultat; if ( ! NT_SUCCESS(r�sultat)){ ND_ERREUR(); } \
}

#define ND_ASSERT(argument) \
{ \
    if ( ! (argument)){ gNDR�sultat = EXIT_FAILURE; ND_ERREUR(); } \
}

#define ND_ASSERT_CS(condition, statut) \
{ \
    gNDR�sultat = STATUS_SUCCESS; \
    if ( ! (condition)) \
    { \
        gNDR�sultat = statut; ND_ERREUR(); \
    } \
}

#define ND_SET_D�LAI_�CRITURES(secondes){ \
    setD�laiApr�s�criture(secondes); \
}

#define ND_JOURNALISER_SANS0(fmt, txt, n) \
{ \
    const int M = sizeof(gTexteJrnl); if ((n > 12) && (n < (M-4))) \
    { \
        strncpy(gTexteJrnl, ND_CC(txt), n); gTexteJrnl[n] = EOL; \
        strcat(gTexteJrnl, "..."); for (int i = 0; i < n; i++){ \
            if (gTexteJrnl[i] == EOL){ gTexteJrnl[i] = '0'; } \
        } \
        journaliser(fmt, ND_CC(gTexteJrnl)); \
    } else { \
        journaliser("ND_JOURNALISER_SANS0: n (%d) est invalide.", n); \
    } \
}

// Surtout utile pour les 'drivers'.
#define ND_JOURNALISER_ERREUR_A(nomModule, b�crirImm�diat) \
{ \
    uint a=0; diff�rerMessages( ! b�crirImm�diat, 0); \
    journaliser(MOT_ERREUR \
        " %s %d (globale ? %d. Ligne %d. Adresse %p).", nomModule, \
        gNDR�sultat, (gNDrivErreur != EXIT_SUCCESS), \
    (gNoLigne > 0 ? gNoLigne : __LINE__), &a); \
    diff�rerMessages(TRUE, 0); \
}

#define ND_JOURNALISER_ERREUR(nomModule){ \
    ND_JOURNALISER_ERREUR_A(nomModule, TRUE); \
}

#define ND_JOURNALISER_EXCEPTION(nomModule, code, ligne) \
{ \
    uint a=0; diff�rerMessages(FALSE, 0); journaliser(MOT_ERREUR " globale " \
        "%s %d (ligne %d. Adresse %p) ", nomModule, code, \
        (ligne != 0 ? ligne : __LINE__), &a); \
        gNDrivErreur = code; diff�rerMessages(TRUE, 0); \
}

#define ND_JOURNALISER_EXCEPTION0(nomModule, code) { \
    ND_JOURNALISER_EXCEPTION(nomModule, code, 0); \
}

#define ND_JOURNALISER_SIGNET(txt) \
{ \
    diff�rerMessages(FALSE, 0); \
    journaliser(txt); diff�rerMessages(TRUE, 0); \
}

#define ND_JOURNALISER_SIGNETF(fmt, arg) \
{ \
    diff�rerMessages(FALSE, 0); journaliser(fmt, arg); \
    diff�rerMessages(TRUE, 0); \
}

#define ND_JOURNALISER_ADRESSE_CODE() \
{ \
    uint a; journaliser("Adresse: %p.", &a); \
} // Une ligne de code = 4.
    
#define ND_SET_MESSAGE_ERREUR_GLOBAL(msg) \
{ \
    ND_SYNCHRO_VR_INTRL(); strncpy(gMessageErrSys, msg, \
        min(STRLEN_CB(ND_CCX msg, DIM_256), \
        DIM_256)); gMessageErrSys[DIM_256-1] = EOL; \
}

#ifdef __cplusplus
}
#endif

#endif // COMMON_JOURNAL_H