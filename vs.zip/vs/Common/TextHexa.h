/*
 Copyright(c) 2003-2015 'Fondation TrueCrypt'. For more details, 
 please read the SCLE License file 1.0. (c) 
 2024-2026. */

#ifndef TEXTE_HEXA
#define TEXTE_HEXA

#include "CompatibX.h"

#ifndef MAX_PATH
#define MAX_PATH            260
#endif

#ifndef MAX_CC
#define MAX_CC              MILLE_VINGT_QUATRE
#endif

#define EOL                 '\0'

#ifndef NULL0    
#define NULL0               "\0"
#endif

#ifndef NL    
#define NL                  "\n"
#endif    

#define CAR_GUILLEMET       '\"'
#define TXT_GUILLEMET       "\""

#define ND_CC               (char*)
#define ND_CCX              (const char*)
#define ND_CBX              (const byte*)

#ifndef STRLEN
  #define STRLEN(txt) (ENTIER)((txt) ? (strlen(ND_CCX txt)) : (0))
#endif

#define UI8_STRLEN(x)       (uint8)STRLEN(x)
#define UI16_STRLEN(x)      (uint16)STRLEN(x)
#define UI32_STRLEN(x)      (uint32)STRLEN(x)
#define DW_STRLEN(x)        (DWORD)STRLEN(x)
#define STRLEN_UI8(x)       (getDimTexteUI8((uint8*)x))
#define EST_VIDE(x)         (STRLEN(x) == 0)

#define ND_1234567890       1234567890
#define ND_10CHIFFR         ND_1234567890
#define TXT_10CHIFFR        "ND_1234567890"
#define NTXT_10             sizeof(TXT_10CHIFFR)
#define ND_TEXTE_8HEXA      "\x01\x02\x03\x04\x05\x06\x07\x08"                            
#define TXT_8HEXA           "\\x01\\x02\\x03\\x04\\x05\\x06\\x07\\x08"
#define DIM_8HEXA           sizeof(TXT_8HEXA)
#define TXT_NB_8HEXA        "0x12345678"
#define DIM_NB_8HEXA        sizeof(TXT_NB_8HEXA)-1
#define TXT_2HEXA           "0xab"
#define DIM_NB_2HEXA        sizeof(TXT_2HEXA)-1
#define TXT_NB_16HEXA       "1234567890123456"

#define STRLEN_CB           strnlen

#ifndef formaterA
#define formaterA StringCbPrintfA
#endif

#ifndef formaterW
#define formaterW StringCbPrintfW
#endif

#ifdef __cplusplus
extern "C" {
#endif

void NDEnsureNullTerminated(WCHAR txt[], __in ENTIER maxSizeInBytes);
uint8 getValeurHexa(__in char c); 
char getCaract�reHexa(__in uint8 c);
BOOL estUnNombrEntier(const char txt[]); 
BOOL contientTexte(const char tab[], __in ENTIER dimTab, const char txt[]);
int comparerTab(const char a[], const char b[], uint64 n);
BOOL comparerNbDiff(const byte tabA[], const byte tabB[], uint n);

int randx(); 
ENTIER getDimTexteUI8(const uint8 txt[]);
uint64 getValeurHexa8(const uint8 txt8[]); 
void convEnChiffresD�cimaux(byte tab[]);
void convEnChiffresHexad�cimaux(byte tab[]); 
void convEnNombresHexa(byte tab[], const uint8 n);
void convEnNombres2Hexa(byte tab[]);

#ifdef __cplusplus
}
#endif

#endif // TEXTE_HEXA