
Library for client applications (with GUI, i.e. the NW<Module>s).

C PROGRAMMING

On the comparisons of structure in memory: if it does not return 0,
while consulting data in the debugger, and it seems to have an equality,
modify the type of first field; and/or add one. The total dimension
would be multiple of 16 (alignment for OS 64). One way to know the size
of a structure in the VS editor is to position the mouse on sizeof(structure)
in the .h (also .cpp). Ex: int i = sizeof(INFO_VOLUME).
See also the project CxRef.

How to evaluate a character in the debugger ? Position the mouse cursor
on the variable, do right-click and chose "Hexadecimal Display".
Otherwise, if it is less than 0 (-) and that we do not find it in the table
of characters, add 256 to his value. Convert after in hexadecimal.
Example: -67 ['�'] + 256 = 189 = \xbd. Warning: \x9d is not conform and
must be ignored (seems to be a problem with C++ vs C).

Global variables and constant text : we suggest to declare them char[].
Research "Accessing Read-Only System Memory" in the WDK help. This
recommendation is also applicable to the arguments 'char*' of functions.
The IDE validates this when executing (client mode) and overloading. The
passage of structure in parameters (often called 'context'), stays the
most secure method. Moreover, a static structure containing dynamic data
is more secure than a standalone dynamic. Particularly with threads. See
the definition of CRYPTO_INFO.

At last, all program sources included in the driver projects and dll
are in C (sometimes mixed with C++). Here are the reasons (cf.
"Coding Drivers in C" in the WDK help):

    a. Facilitate the integration of .asm/.c vs .obj and the external
       references which are programmed in Assembler/C [+] portability.
       
    b. Insure a better coherency and cohesion.

    c. Avoid to have compilation errors sometimes complicated
       (or useless) to solve. Others...

NOMENCLATURE

The constants of prefix NOM_ are composed of many words. Cf. Constantes.h.
While those of prefix MOT_ represent a word containing only at least a
capital and lower letters. FilEx is a french traduction and more precise
than the word 'Thread'. The abbreviation used is 'fx'.

GLOBAL ERRORS

The NetDisq drivers do not return "BugCheck" (fatal error), but used the
variable gNDrivErreur. When a such exception happens, the problem must be
corrected, start again the virtual machine.

JOURNALISATION (LOGGING)

Research "Adding Event Tracing to Kernel-Mode Drivers" in the WDK help.
See also: ~\WinDDK\src\general\tracing\evntdrv. A lighter version is
available in this project. If an instruction stops the machine, add
ND_SET_D�LAI_�CRITURES at the right place. Please note however that
this is disable in production (configuration Release).

Verify the not freed memory addresses with the option "_JOURAMEM".

CONVERSION 

Microsoft C++ vs Linux

The TC code in Linux is very different of the one for Windows. It would be
preferable to standardize it, in using common interfaces and methods
(signatures). I.e. abstract data type (modules C), instead of C++ classes.
The simple types are however normalized.
Example: uint8, uchar, ulong, ENTIER, ...

Windows: __try { } __except(EXCEPTION_EXECUTE_HANDLER){ GetExceptionCode() }
Linux:   try {} catch (exception ex){ ex.getExceptionCode() } To test.

Windows: CryptGenRandom, RtlRandomEx
Linux:   int urandom = open ("/dev/urandom", O_RDONLY) // in ~/TC/Core.
See also ~/TC/Main (./Forms), ~/TC/Platform et ~/TC/Volume.

Windows: CreateFile, CloseHandle, ReadFile, WriteFile, CopyFile, DeleteFile, ... 
Linux:   File.Open, .Close, .Read, .Write, .Copy, FilePath.Delete, ... 

Windows: String: in Commutil/TexteCc.
Linux:   done in C++. Add it in C modules.
Example: TexteCc.h : ./Windows/TexteCc.cpp and ./Linux/TexteCc.cpp.

In NetDisq, the Microsoft methods like "ReadFile" are replaced
(often enough) by their corresponding in 'C'.