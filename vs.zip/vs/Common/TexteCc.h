#ifndef TEXTE_CH_CARACT�RES
#define TEXTE_CH_CARACT�RES

#include "CompatibX.h"
#include "Journal.h"

#ifdef __cplusplus
extern "C" {
#endif

#ifndef MAX_CC
#define MAX_CC              MILLE_VINGT_QUATRE
#endif

#define EOL                 '\0'

#ifndef NULL0    
#define NULL0               "\0"
#endif

#ifndef NL    
#define NL                  "\n"
#endif    

#define CAR_GUILLEMET       '\"'
#define TXT_GUILLEMET       "\""

#ifndef STRLEN
#define STRLEN(txt) (ENTIER)((txt) ? (strlen(ND_CCX txt)) : (0))
#endif

#define UI8_STRLEN(x)       (uint8)STRLEN(x)
#define UI16_STRLEN(x)      (uint16)STRLEN(x)
#define UI32_STRLEN(x)      (uint32)STRLEN(x)
#define DW_STRLEN(x)        (DWORD)STRLEN(x)
#define STRLEN_UI8(x)       (getDimTexteUI8((uint8*)x))

#define EST_VIDE(x)         (STRLEN(x) == 0)

#ifndef TC_WINDOWS_DRIVER
#define STRLEN_CB           strnlen
#endif

#ifndef formaterA
#define formaterA           StringCbPrintfA
#endif

#ifndef formaterW
#define formaterW           StringCbPrintfW
#endif

/**
 * PRE: les arguments doivent �tre des variables instanci�es, et non
 *      des constantes. NB: il n'est pas possible d'utiliser ces fonctions
 *      plusieurs fois de suite. Sinon, il faut copier le r�sultat dans une
 *      autre variable texte.
 *
 * @RETURN: texte converti � usage unique, avec port�e restreinte.
 */
WCHAR* convEnWCHAR(const char txt[]); // ~ WCHAR* (Unicode).
char* convEnCCHAR(const WCHAR txt[], uint16 Mx); // Idem.

char* trim(const char txt[]); WCHAR* trimW(WCHAR txt[], uint16 Mx);

/*
 * PRE: @param txt est soit une constante (ou const) ou c_str.
 */
char* constEnCCHAR(const WCHAR txt[], uint16 Mx); // Utiliser autant que  
WCHAR* constEnWCHAR(const char txt[]); // possible des #define avec TEXT.
char* getNomSansSuffixe(const char nf[]);
char* convEnMinuscules(const char txt[]);
char* convEnMajuscules(const char txt[]);
BOOL estEnMajuscules(const char txt[]);

#ifndef ND_FILTRE

char* d�calerGauche(char txt[], int len, int targetLen, char filler);
const char* chercherTexte(const char txt[], uint64 dimTxt, 
    const char str[], uint64 dimStr);
BOOL commencePar(const char txt[], const char prfx[]);
BOOL seTerminePar(const char txt[], const char sufx[]);
void ajouterGuillemetD�but(char txt[], __in ENTIER dimTab);
void ajouterGuillemetFin(char txt[], __in ENTIER dimTab);
void mettreEntreGuillemets(char txt[], __in ENTIER dimTab);
BOOL estVide0(const byte tab[], uint64 n, uint8 pourcentSignificatif);
BOOL estVide100(const byte tab[], uint64 n); 
void setNonVide(byte tab[], uint n, BOOL bCodUtil, BOOL bModPasse);
char* remplacerMot(char txt[], uint max, const char motA[], const char motB[]);

#ifndef _CONSOLE // ! Projet Commande

void GetSizeString(__in uint64 size, __in WCHAR txt[]);
void GetSpeedString(__in uint64 speed, __in WCHAR txt[]);

#endif // ! _CONSOLE

#endif ! ND_FILTRE

#ifdef __cplusplus
}
#endif

#endif // TEXTE_CH_CARACT�RES