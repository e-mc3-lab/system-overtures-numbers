/**
 *  @auteurs TrueCrypt et SCLE.
 */
#ifndef LANGAGE_FR
#define LANGAGE_FR

#define TC_BYTE                  L"o";

#define KB                       L"KO"
#define MB                       L"MO"
#define GB                       L"GO"
#define TB                       L"TO"
#define PB                       L"PB"

#define B_PER_SEC                L"o/s"
#define KB_PER_SEC               L"Ko/s"
#define MB_PER_SEC               L"Mo/s"
#define GB_PER_SEC               L"Go/s"
#define TB_PER_SEC               L"To/s"
#define PB_PER_SEC               L"Po/s"


#define ERR_VERSION_SE           L"Impossible de d�terminer la version de votre syst�me "\
                                 L"d'exploitation (ou c'est non reconnu)."

#define ERR_OS_ACCESS_DENIED     L"Acc�s refus� par le syst�me d'exploitation (SE).\n\n"\
                                 L"Cause possible: le syst�me d'exploitation n�cessite que "\
                                 L"vous ayez la permission en lecture/�criture (ou des "\
                                 L"privil�ges d'administrateur) pour certains dossiers, fichiers "\
                                 L"et p�riph�riques pour �tre autoris� � y lire/�crire des donn�es. "\
                                 L"Normalement un utilisateur sans privil�ge d'administrateur est "\
                                 L"autoris� � cr�er, lire et modifier les fichiers de son dossier "\
                                 L"� Mes Documents �."

#define CANNOT_WRITE_FILE_X      L"Impossible d'�crire dans le fichier %hs"

#define REPAIRING_FS             L"Tentative de r�paration du syst�me de fichiers sur le "\
                                 L"volume SCLE mont� sous %hs..."

#define CHECKING_FS              L"V�rification du syst�me de fichiers sur le volume SCLE "\
                                 L"mont� sous %hs..."

#define CANNOT_CALC_SPACE        L"Impossible d'acc�der au p�riph�rique. V�rifiez s'il existe et "\
                                 L"qu'il n'est pas utilis� par le syst�me."

#define CANT_GET_VOLSIZE         L"Erreur : impossible d'obtenir la dimension du volume.\n\nAssurez-vous "\
                                 L"que le volume s�lectionn� n'est pas utilis� par le syst�me ou par "\
                                 L"une application."

#define SYS_AUTOMOUNT_DISABLED   L"Le syst�me (SE) n'est pas configur� pour monter "\
                                 L"automatiquement de nouveaux volumes."

#define DEVICE_NOT_READY_ERROR   L"Assurez-vous que le disque est ins�r� dans l'unit�."

#define ERR_HARDWARE_ERROR       L"Le volume est endommag� (il y a un d�faut physique dessus) "\
                                 L"ou un c�ble est endommag�; ou encore la m�moire fonctionne "\
                                 L"mal.\n\nNotez qu'il s'agit d'un probl�me avec votre mat�riel, "\
                                 L"et non pas le service SCLE. Contactez le support technique "\
                                 L"informatique pour une assistance."

#endif // LANGAGE_FR