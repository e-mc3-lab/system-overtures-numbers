/*
 Copyright (c) 2003-2015 'Fondation TrueCrypt'. All rights reserved.

 Governed by the SCLE License; the full text of which is contained in
 the file Licence 1.0.txt included in NetDisq distribution packages.
 2023-2025.
*/
#ifndef COMMON_DICTIONARY_H
#define COMMON_DICTIONARY_H

#include <windows.h>
#include "CompatibX.h"

#define DATA_POOL_CAPACITY   2 * DIM_256K

#ifdef __cplusplus
extern "C" {
#endif

void AddDictionaryEntry(char *key, int intKey, void *value);
void *GetDictionaryValue(const char *key);
void *GetDictionaryValueByInt(int intKey);
void *AddPoolData(void *data, size_t dataSize);
void ClearDictionaryPool();

#ifdef __cplusplus
}
#endif

#endif // COMMON_DICTIONARY_H
