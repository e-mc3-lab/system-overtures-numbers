::
:: Copyright (c) 2003-2015 'Fondation TrueCrypt'. All rights reserved.
::               2023-2024 SCLE. 
::
:: Governed by the SCLE License 1.0; the full text of which is contained in
:: the file Licence.txt included in NetDisq source and binary code distribution
:: packages.
::
@echo off
chcp 28591 > nul

set ND_ARG_CMD=%~1
shift
set ND_ARG_CONFIG=%~1
shift
if "%~1"=="" goto args_en_erreur
set ND_ARG_PLATFORM=%~1
shift
set CHEM_RELATIF=.

::Initialisation

set ND_C_DEFINES=-DTC_WINDOWS_DRIVER -DWDDK -DPROJET_DRIVER_DLL -DUNICODE -D_WIN64
set ND_C_FLAGS=-nologo -I..
set ND_C_WARNING_LEVEL=-W4
set ND_C_DISABLED_WARNINGS=-wd4047 -wd4100 -wd4127 -wd4152 -wd4201 -wd4995
set ND_LIBRARIAN_FLAGS=-nologo
set ND_LINKER_FLAGS=-nologo
set ND_TEST_SIGN=0

:: Configuration

if "%ND_ARG_CONFIG%"=="Debug" (    
    set ND_C_DEFINES=%ND_C_DEFINES% -DDEBUG -D_DEBUG -DJOURNALISER
) else if "%ND_ARG_CONFIG%"=="Service" (  
    REM NB:
    REM la version Service sert pour la cr�ation de volumes (disques).
    REM On active la journalisation; alors qu'avec la version client,
    REM cela n'est pas permis pour des raisons de s�curit�.
    set ND_C_DEFINES=%ND_C_DEFINES% -DRelease -DJOURNALISER
    set ND_ARG_CONFIG=Release
) else (
    set ND_C_DEFINES=%ND_C_DEFINES% -D%ND_ARG_CONFIG%
)

:: Plateforme

set ND_ARG_PLATFORM_DIR=%ND_ARG_PLATFORM%
set ND_LINKER_FLAGS=%ND_LINKER_FLAGS% -LTCG

set ND_BUILD_TYPE=fre
set ND_TEST_SIGN=0

set ND_BUILD_ALT_DIR=

:: Ouverture d'une session WDK.
pushd .
CALL %WINDDK%\bin\setenv %WINDDK% %ND_BUILD_TYPE% %ND_ARG_PLATFORM% no_oacr || exit /B %errorlevel%
popd

:: Construction
set WDK_PREFAST=
if "%ND_ARG_CMD%"=="-rebuild" (set OPTIONS_BUILD=-wcez)
if "%ND_ARG_CMD%"=="-prefast" (set WDK_PREFAST=prefast) 

pushd .

:build_dirs

    if "%ND_ARG_CMD%"=="-clean" (
        
        rmdir /s /q obj 2>NUL:
        
    ) else (
        
        set DIR_R�SULTAT=%CHEM_RELATIF\%ND_BUILD_ALT_DIR%\%ND_ARG_PLATFORM%\
        set USER_C_FLAGS=%ND_C_FLAGS% %ND_C_DISABLED_WARNINGS% -FAcs -Fa%DIR_R�SULTAT%
        set MSC_WARNING_LEVEL=%ND_C_WARNING_LEVEL%
        set C_DEFINES=%ND_C_DEFINES%         
        set RCOPTIONS=/I %MFC_INC_PATH%
        set LIBRARIAN_FLAGS=%ND_LIBRARIAN_FLAGS%
        set LINKER_FLAGS=%ND_LINKER_FLAGS% 
        set BUILD_ALT_DIR=%ND_BUILD_ALT_DIR%
        
        %WDK_PREFAST% build.exe %OPTIONS_BUILD% -nmake /S -nmake /C
    )
popd

if "%ND_ARG_CMD%"=="-clean" goto FIN

goto FIN

:args_en_erreur

echo Usage: BuildSys <-build|-rebuild|-clean> <Release|Debug|Service> <x64>

:FIN

del /q *.cod 2>NUL:
:: exit /B 0
