/**
 * @auteurs TrueCrypt et SCLE.
 */
#include <stdio.h>
#include <windef.h>
#include <shlobj.h>
#include <dbt.h>
#include "Journal.h"
#include "Version.h"
#include "Memoire.h"
#include "Config.h"
#include "Fichier.h"
#include "TexteCc.h"
#include "ErreurDict.h"
#include "ServiceCt.h"


BOOL d�chargerPilote(TypeDriver td);
void fermerhService(TypeDriver td);

char gChemProgrammes[MAX_PATH] = {0};
char gChemSysDrivers[MAX_PATH] = {EOL}; // [0]
char nomSansSuffixe[MAX_PATH] = {0};
BOOL installation = TRUE, bMessageErrD�j�Affich� = FALSE;
SC_HANDLE ghManager = NULL; SC_HANDLE ghService[TD_MAX] = {0};
HANDLE ghDriver[TD_MAX] = {0}; BOOL bService�Supprimer = FALSE;
SERVICE_STATUS objEtatService[TD_MAX] = {0};
SERVICE_STATUS_HANDLE objhEtatService[TD_MAX] = {0};
BOOL broadcastChangeP�riphD�sactiv = FALSE;
DWORD gErreurService = 0;



void setInstallation(BOOL b){
    installation = b;
}

BOOL estMessageErrD�j�Affich�(){
    return bMessageErrD�j�Affich�;
}

void setMessageErrD�j�Affich�(BOOL b){
    bMessageErrD�j�Affich� = b;
}

BOOL estService�Supprimer(){
    return bService�Supprimer;
}

DWORD getErreurService(){
    return gErreurService;
}

void setCheminProgrammes(char* cp){
    strcpy(gChemProgrammes, cp);
}

void v�rifierCheminProgrammes(char* nomFichierBinaire)
{
    if ((gChemProgrammes == NULL) || (STRLEN(gChemProgrammes) == 0))
    {
        WCHAR* MSG_ERREUR_V�RIF_CHEM_PROGRAMME = L"Chemin du driver "\
            L"introuvable ou invalide."; HKEY hkey = 0;
        char* chemProgram = SOFTWARE MICROSOFT WINDOWS \
             CURRENT_VERSION UNINSTALL "\\" MOT_NETDISQ;        
        if (RegOpenKeyExA(HKEY_LOCAL_MACHINE, chemProgram, 0, 
            KEY_QUERY_VALUE, &hkey) == ERROR_SUCCESS)
        {
            char szTmp[MAX_PATH] = {0}; DWORD nChemNomDriver = sizeof(szTmp);            
            if (RegQueryValueExA(hkey, MODIFY_PATH, 0, 0, (LPBYTE) &szTmp, 
                &nChemNomDriver) != ERROR_SUCCESS || (nChemNomDriver < 1))
            {
                afficherErreur(MSG_ERREUR_V�RIF_CHEM_PROGRAMME);
                RegCloseKey(hkey); exit(ANNULATION); // TODO Quitter(NULL, ANNULATION);

            } else {
                char* txtA = strrchr(szTmp, '\\');                
                if (txtA)
                { 
                    ENTIER n = STRLEN(szTmp)-STRLEN(txtA);
                    szTmp[n-1] = '\\'; szTmp[n] = EOL;
                    strcpy(gChemProgrammes, szTmp+1); RegCloseKey(hkey);
                }
            }
        } else {
            afficherErreur(MSG_ERREUR_V�RIF_CHEM_PROGRAMME);
            RegCloseKey(hkey); exit(ANNULATION); // Quitter(NULL, ANNULATION);
        }
    }
}

char* getChemSysDrivers(){ return gChemSysDrivers; }

void setChemSysDrivers()
{
    const BOOL driver64 = TRUE; if (gChemSysDrivers[0] == EOL)
    {
        ENTIER N; if (driver64){ EnableWow64FsRedirection(FALSE); }
        GetSystemDirectoryA(gChemSysDrivers, sizeof(gChemSysDrivers));
        N = STRLEN(gChemSysDrivers);
        if (gChemSysDrivers[N-1] != '\\'){ strcat(gChemSysDrivers, "\\"); }
        sprintf(gChemSysDrivers, "%s%s\\", gChemSysDrivers, DOSSIER_DRIVERS);    
    }
}

BOOL existeCl�RegistreModeServeur()
{
    BOOL r�sultat = FALSE; HKEY hkey = 0;
    if (RegOpenKeyExA(HKEY_LOCAL_MACHINE, SOFTWARE MOT_NETDISQ MOT_SERVEUR, 0, 
        KEY_READ, &hkey) == ERROR_SUCCESS){ r�sultat = TRUE; }
    RegCloseKey(hkey); return r�sultat;
}

SC_HANDLE gethManager(){ return ghManager; }

TypeDriver getIndex(const char* nom)
{
    TypeDriver r�sultat = TD_DISQUE;
    if (strcmp(NOM_NETDISQ_L, nom) == 0)
    {
        r�sultat = TD_DISQUE;
    } else if (strcmp(NOM_NETDISQ_F, nom) == 0){
        r�sultat = TD_FILTRE;
    } else if (strcmp(NOM_NETDISQ_C, nom) == 0){
        r�sultat = TD_COUPEFEU;
    } return r�sultat;
}

char* getNomService(TypeDriver td)
{
    char* r�sultat = NULL; if (td == TD_DISQUE){
        r�sultat = NOM_NETDISQ_L; 
    } else if (td == TD_FILTRE){
        r�sultat = NOM_NETDISQ_F; 
    } else if (td == TD_COUPEFEU){
        r�sultat = NOM_NETDISQ_C; 
    } return r�sultat;
}

SC_HANDLE gethService(TypeDriver td){ return ghService[td]; }

HANDLE gethDriver(TypeDriver td)
{
    if (ghDriver[td] == NULL)
    {
        afficherErreur(L"Op�ration non permise: un objet doit �tre " \
            L"initialis�."); journaliser("ServiceCt %d.", __LINE__+1); exit(1);
    } return ghDriver[td];
}

void sethDriver(HANDLE hd, TypeDriver td){ ghDriver[td] = hd; }


SERVICE_STATUS getObjEtatService(TypeDriver td){
    return objEtatService[td];
}

SERVICE_STATUS_HANDLE getObjHEtatService(TypeDriver td){
    return objhEtatService[td];
}

void setObjHEtatService(SERVICE_STATUS_HANDLE ssh, TypeDriver td){
    objhEtatService[td] = ssh;
}

void contr�ler(DWORD code)
{    
    journaliser("Contr�ler: %d.", code); if (IsAdmin()) switch (code)
    {   
        // NB: ne doit pas pouvoir arr�ter si utilisateur normal.
        case SERVICE_CONTROL_STOP: 
        {            
            setStatutSCM(TD_DISQUE, SERVICE_STOP_PENDING, NO_ERROR, 0);
            arr�terService(TD_DISQUE, FALSE);
            setStatutSCM(TD_FILTRE, SERVICE_STOP_PENDING, NO_ERROR, 0);
            arr�terService(TD_FILTRE, FALSE);
        }
        return;

        case SERVICE_CONTROL_INTERROGATE:
            break;

        default: break;
    }
    setStatutSCM(TD_DISQUE, objEtatService[TD_DISQUE].dwCurrentState, 
        NO_ERROR, 0);
    setStatutSCM(TD_FILTRE, objEtatService[TD_FILTRE].dwCurrentState, 
        NO_ERROR, 0);
}


void setObjHEtatServiceN(TypeDriver td)
{
    if (objhEtatService[td] == NULL)
    {
        WCHAR nom[MAX_PATH] = {0}; wcscpy(nom, constEnWCHAR(getNomService(td)));
        objhEtatService[td] = RegisterServiceCtrlHandler(nom, contr�ler);
    }
}

/*
 * Mettre � jour l'�tat du service et en informer le SCM.
 * @param d�lai - le maximum d'attente.
 * @return TRUE si succ�s, FALSE sinon.
*/
BOOL setStatutSCM(TypeDriver td, DWORD �tat, DWORD codeSortie, DWORD d�lai)
{    
    BOOL r�sultat = TRUE; gErreurService = 0;
    static DWORD dwCheckPoint = 1; char msg[MAX_PATH]; 
    if (objhEtatService[td] == NULL){ return TRUE; }    
    sprintf_s(msg, sizeof(msg), "setStatutSCM: %d.", �tat); journaliser(msg);
    if (�tat == SERVICE_START_PENDING){
        objEtatService[td].dwControlsAccepted = 0;
    } else {
        objEtatService[td].dwControlsAccepted = SERVICE_ACCEPT_STOP;
    }
    objEtatService[td].dwCurrentState = �tat;
    objEtatService[td].dwWin32ExitCode = codeSortie;
    objEtatService[td].dwWaitHint = d�lai;
    if ((�tat == SERVICE_RUNNING) || (�tat == SERVICE_STOPPED) ){
        objEtatService[td].dwCheckPoint = 0;
    } else {
        objEtatService[td].dwCheckPoint = dwCheckPoint++;
    }
    setObjHEtatServiceN(td);     
    r�sultat = SetServiceStatus(objhEtatService[td], &objEtatService[td]);
    if ( ! r�sultat){ journaliser("setStatutSCM: �chec."); }
    return r�sultat;
}

void fermerSCManager()
{
    if (ghManager != NULL)
    {
        CloseServiceHandle(ghManager); ghManager = NULL;
    }
}

/**
  * @tS: SERVICE_KERNEL_DRIVER. @tDem: SERVICE_AUTO_START, SERVICE_SYSTEM_START.
  */
BOOL installerService(TypeDriver td, DWORD typeD�marrage, 
     BOOL modeEnregistrement, BOOL afficherMsg)
{   
    BOOL r�sultat = FALSE; char nom[50]; strcpy(nom, getNomService(td));
    WCHAR chemNomProgramme[MAX_PATH] = {0}, nomW[50] = {0};  
    WCHAR chemSysDrivers[MAX_PATH] = {0}; char nomFichierBinaire[MAX_PATH] = {0};
    strcpy(nomFichierBinaire, nom); 
    if (modeEnregistrement){
        if (STRLEN(gChemSysDrivers) == 0){ setChemSysDrivers(); }
    } else {
        strcpy(gChemSysDrivers, getCheminProgramme());
    }
    wcscpy(chemSysDrivers, convEnWCHAR(gChemSysDrivers));
    strcat(nomFichierBinaire, SUFX_SYS); wcscpy(nomW, constEnWCHAR(nom));
    if (modeEnregistrement){ v�rifierCheminProgrammes(nomFichierBinaire); }
    swprintf(chemNomProgramme, L"%ls%ls", chemSysDrivers, 
        convEnWCHAR(nomFichierBinaire)); if ( ! gethManager())
    {
        ghManager = OpenSCManager(NULL, NULL, SC_MANAGER_ALL_ACCESS);
    }
    if ( ! gethManager()){ return FALSE; }
    journaliser("Installer %ls.", chemNomProgramme); 
    char* mot = (td == TD_DISQUE ? MOT_VOLUME : MOT_FILTRE);
    WCHAR titre[MAX_PATH] = {0}; swprintf(titre, L"%ls %ls", 
        TITRE_W, constEnWCHAR(mot)); if (ghService[td]){ return FALSE; }
    ghService[td] = CreateService(ghManager, nomW, titre, SERVICE_ALL_ACCESS,
        SERVICE_KERNEL_DRIVER, typeD�marrage, SERVICE_ERROR_NORMAL, 
        chemNomProgramme, NULL, NULL, NULL, NULL, NULL);
    if (ghService[td] == NULL){
        ND_FIN();
    } else if (modeEnregistrement){
        fermerhService(td); if ( ! initialiser(td, TRUE)){ ND_FIN(); }        
    } else {
        return TRUE;
    }
    r�sultat = TRUE;
FIN: if (ghService != NULL)
     {
         if (afficherMsg && r�sultat){
             MessageBox(NULL, L"Le service a �t� install�.", titre, 0);
         } fermerhService(td);
     }
     DWORD err = GetLastError();
     if ( ! r�sultat && (err != ERROR_SERVICE_ALREADY_RUNNING))
     {
         char* msg = getErreurWindows(err); // winerror.h
         sprintf(msg, "%sLe service n'a pas �t� install� (%d).", msg, err);
         if (afficherMsg){ MessageBox(NULL, convEnWCHAR(msg), titre, 0); }
         journaliser(msg); gErreurService = err;
     } else {
         r�sultat = TRUE;
     }
     fermerSCManager(); init0(chemNomProgramme, sizeof(chemNomProgramme));
     return r�sultat;
}

BOOL d�sinstallerService(TypeDriver td)
{
    BOOL r�sultat = TRUE, fermerManager = FALSE;    
    SC_HANDLE lhService = ghService[td]; char* nom = getNomService(td);
    if ( ! initialiser(td, FALSE)){ return TRUE; } fermerManager = TRUE;
    if (estServiceInstall�(FALSE)){ r�sultat = arr�terService(td, TRUE); }
    fermerhService(TD_DISQUE); journaliser("D�sinstaller %s", nom);
    return r�sultat;
}

BOOL initialiser(TypeDriver td, BOOL d�marr)
{
    if (ghService[td] != NULL){ return TRUE; } HANDLE file;
    WIN32_FIND_DATA find = {0}; char v�rifFichier[MAX_PATH] = {0};
    char* nom = getNomService(td); char nomFichierBinaire[MAX_PATH] = {0};
    WCHAR* v�rifChemFichier; strcpy(nomFichierBinaire, nom); 
    strcat(nomFichierBinaire, SUFX_SYS);
    v�rifierCheminProgrammes(nomFichierBinaire);
    strcpy(v�rifFichier, getChemSysDrivers());    
    sprintf(v�rifFichier, "%s%s*", v�rifFichier, nom);     
    v�rifChemFichier = constEnWCHAR(v�rifFichier);    
    file = FindFirstFile(v�rifChemFichier, &find);
    if ((file == INVALID_HANDLE_VALUE) && installation && d�marr)
    {
         char message[MAX_PATH] = {0};
         sprintf(message, "Ne peut trouver le fichier %s.", nomFichierBinaire);
         MessageBoxA(NULL, message, nom, 0); return FALSE;
    }
    FindClose(file); setObjHEtatServiceN(td); if (ghManager == NULL){
        ghManager = OpenSCManager(NULL, NULL, SC_MANAGER_ALL_ACCESS);
    } if (ghManager == NULL)
    {
        if (GetLastError() == ERROR_ACCESS_DENIED){
            MessageBoxA(NULL, "Vous devez avoir les privil�ges "\
                "d'administrateur\n(�l�vation) pour initialiser le driver.",
                nom, MB_ICONINFORMATION);
        } Quitter(NULL, EN_ERREUR); return FALSE;
    }
    ghService[td] = OpenServiceA(ghManager, nom, SERVICE_ALL_ACCESS);
    return ((ghService[td] != NULL) ? TRUE : FALSE);
}

BOOL d�marrerService(TypeDriver td)
{
    char* nom = getNomService(td); if (ghManager == NULL){
        ghManager = OpenSCManager(NULL, NULL, SC_MANAGER_ALL_ACCESS);
    }
    if (ghService[td] == NULL){
        ghService[td] = OpenServiceA(ghManager, nom, SERVICE_ALL_ACCESS);
    } 
    return StartService(ghService[td], 0, NULL);
}


BOOL arr�terService(TypeDriver td, BOOL bUninstall)
{
    BOOL r�sultat= FALSE; SERVICE_STATUS �tat = {0}; 
    HANDLE hDriver = ghDriver[td]; BOOL bEssai1 = TRUE;
    SC_HANDLE hV�rifService = gethService(td);
    if ((hV�rifService == NULL) && 
        (hDriver == INVALID_HANDLE_VALUE)) { return TRUE; }
    char *nom = getNomService(td), nomFichierBinaire[MAX_PATH] = {0};
    sprintf(nomFichierBinaire, "%s%s", nom, SUFX_SYS);        
    if ( ! initialiser(td, FALSE))
    {
        r�sultat = TRUE; ND_FIN();
    }
    // Plusieurs essais sont parfois n�cessaires pour arr�ter le service.    
    for (int i = 0; i < NB_ESSAIS_ARR�T; i++)
    {   // Il arrive qu'un service prenne un peu de temps avant d'arr�ter.
        r�sultat = QueryServiceStatus(ghService[td], &�tat);
        if ( ! r�sultat){ goto ESSAI_SUPPR; }
        if ((�tat.dwCurrentState == SERVICE_STOP_PENDING) ||
            (�tat.dwCurrentState == SERVICE_STOPPED))
        {
            r�sultat = TRUE; break;
        } Sleep(500);
        r�sultat = ControlService(ghService[td], SERVICE_CONTROL_STOP, &�tat);
    } // for
    setStatutSCM(td, SERVICE_NOTIFY_DELETED, NO_ERROR, 0); goto D�SINSTALL;

ESSAI_SUPPR:
    fermerhService(td); fermerSCManager(); if ( ! initialiser(td, FALSE))
    {
        r�sultat = TRUE; ND_FIN();
    }

D�SINSTALL:

    if (bUninstall)
    {
        r�sultat = DeleteService(ghService[td]); if ( ! r�sultat)
        {        
            if (bEssai1 && 
                (GetLastError() == ERROR_SERVICE_MARKED_FOR_DELETE))
            {   
                fermerhService(td); fermerSCManager(); Sleep(1000); 
                bService�Supprimer = TRUE; bEssai1 = FALSE; goto ESSAI_SUPPR;
            } ND_ERREUR();
        }
    } 
    r�sultat = TRUE; fermerHandle(td);    
    HANDLE hArr�tEvent = CreateEventA(NON_ATTR_S�CURIT�, 
        R�INIT_MANUEL, NON_SIGNAL�, getNomService(td));
    if (hArr�tEvent){ SetEvent(hArr�tEvent); }
ERR: if (bUninstall && ! r�sultat && 
        (GetLastError() != ERROR_SERVICE_DOES_NOT_EXIST))
     {
         if ( ! bMessageErrD�j�Affich�)
         {
             traiterErreurWindows(); bMessageErrD�j�Affich� = TRUE;
         } r�sultat = FALSE;
     } else {
         r�sultat = TRUE;
     }
FIN: CoUninitialize(); fermerhService(td); fermerSCManager(); return r�sultat;
}

void fermerhService(TypeDriver td)
{
    if (ghService[td] != NULL)
    {
        CloseServiceHandle(ghService[td]); ghService[td] = NULL;
    }
}

NTSTATUS ouvrirHandlePilote(TypeDriver td, DWORD codeCtl, BOOL bV�rifVersion)
{    
    NTSTATUS r�sultat = STATUS_SUCCESS; 
    HANDLE hDrv = ghDriver[td];  if ((hDrv != NULL) && 
        (hDrv != INVALID_HANDLE_VALUE)){ return ERR_SUCCESS; }
    hDrv = CreateFile(ND_WIN_DEV_USER_MODE, 0, FILE_SHARE_READ | 
        FILE_SHARE_WRITE, NULL, OPEN_EXISTING, 0, NULL); 
    sethDriver(hDrv, td); if (hDrv == INVALID_HANDLE_VALUE){ 
        return ERR_DRIVER_PAS_D�MARR�_OU_EN_ERREUR; 
    } if (bV�rifVersion) __try 
    {   // Don't check version during setup to allow removal of
        NTSTATUS �tat; LONG v�rif = ERR_SUCCESS; // another version.
        r�sultat = appelerDriver(td, codeCtl,
            NULL, 0, &v�rif, DIM_LONG, &�tat, bV�rifVersion);        
        if ( ! r�sultat || ((v�rif != 0) && (v�rif != VERSION_NUM))){
            r�sultat = v�rif;
        } else if (NT_SUCCESS(r�sultat) && (�tat < 0)){
            r�sultat = �tat;
        } else {
            �tat = ERR_SUCCESS;
        }
    } __except(EXCEPTION_EXECUTE_HANDLER){
        r�sultat = GetExceptionCode();
        ND_JOURNALISER_EXCEPTION("ServiceCt", r�sultat, __LINE__);
    }
    if ( ! NT_SUCCESS(r�sultat)){ fermerHandle(td); } return r�sultat;
}

LONG getNombreVolumesMont�s()
{
    LONG r�sultat = ERR_SUCCESS; NTSTATUS �tat;
    if (appelerDriver(TD_DISQUE, TC_CTL_CODE_IS_ANY_VOLUME_MOUNTED, 
        NULL, 0, &r�sultat, DIM_LONG, &�tat, TRUE)){
    } return r�sultat;
}

LONG unVolumeAD�j��t�Mont�()
{
    LONG r�sultat = FALSE; NTSTATUS �tat;
    if (appelerDriver(TD_DISQUE, TC_CTL_CODE_UN_VOLUME_A_�T�_MONT�,
        NULL, 0, &r�sultat, DIM_LONG, &�tat, TRUE)){
    } return r�sultat;
}

BOOL d�chargerPilote(TypeDriver td)
{
    BOOL r�sultat = FALSE; uint nbRefs = 0;
    ouvrirHandlePilote(td, TC_CTL_CODE_GET_DRIVER_VERSION, FALSE);
    if (gethDriver(td) == INVALID_HANDLE_VALUE){ return TRUE; }
    if ((td == TD_DISQUE) && ! getNombreVolumesMont�s()){ ND_FIN(); }

    nbRefs = GetDriverRefCount(td); if (nbRefs > 1){ ND_FIN(); }
    r�sultat = TRUE; FIN: return r�sultat;
}

BOOL estActiv�(HANDLE hPilote, DWORD codeCtl)
{        
    if (hPilote != INVALID_HANDLE_VALUE) 
    {   
        // Exemple: TC_CTL_CODE_GET_DRIVER_VERSION
        DWORD dw; if (DeviceIoControl(hPilote, codeCtl,
            NULL, 0, NULL, 0, &dw, 0)){ return TRUE; }
    } 
    return FALSE;
}

LONG GetDriverRefCount(TypeDriver td)
{
    LONG r�sultat, n = 0; DWORD �tat; HANDLE ghDriver = gethDriver(td);
    r�sultat = DeviceIoControl(ghDriver, TC_CTL_CODE_GET_DEVICE_REFCOUNT,
        &n, DIM_LONG, &n, DIM_LONG, &�tat, NULL); return (r�sultat ? n : -1);
}


NTSTATUS appelerDriver(__in TypeDriver td, _In_ DWORD codeCtl,
    void* tabStructE, _In_ DWORD dimTabE, void* tabStructS,
    _In_ DWORD dimTabS, LONG* �tat, BOOL v�rifDrivErreur)
{
    NTSTATUS r�sultat = STATUS_SUCCESS; if (gNDrivErreur == ERR_SUCCESS) __try
    {
        HANDLE hDriver = gethDriver(td); if (hDriver == INVALID_HANDLE_VALUE)
        {
            r�sultat = ouvrirHandlePilote(TD_DISQUE, NULL, FALSE);
            ND_ASSERT_S(r�sultat); hDriver = gethDriver(td);
        }
        if (hDriver != INVALID_HANDLE_VALUE)
        {
            DWORD lpBytesReturned; r�sultat = DeviceIoControl(hDriver,
                codeCtl, tabStructE, dimTabE, tabStructS,
                dimTabS, &lpBytesReturned, NULL);
            if (tabStructS && (dimTabS == DIM_LONG))
            {
                r�sultat = *(LONG*)tabStructS;
                if ((r�sultat == ERR_SUCCESS) &&
                    (lpBytesReturned == 0) && v�rifDrivErreur){
                    r�sultat = *�tat = lir�tatDriver();
                } else {
                    *�tat = STATUS_SUCCESS;
                }
            } else if (NT_SUCCESS(r�sultat) && v�rifDrivErreur){
                r�sultat = lir�tatDriver(); if (r�sultat < ERR_FIN){
                    r�sultat = STATUS_SUCCESS;
                }
            }
        } else { journaliser("'ghDriver' est invalide."); }
    } __except(EXCEPTION_EXECUTE_HANDLER) {
        r�sultat = GetExceptionCode(); ND_JOURNALISER_EXCEPTION("ServiceCt",
            r�sultat, __LINE__); ND_ERREUR();
    } ND_FIN(); 
ERR: traiterErreurDict(gNDrivErreur); 
FIN: return r�sultat;
}


void fermerHandle(TypeDriver td)
{
    if ((ghDriver[td] != NULL) && (ghDriver[td] != INVALID_HANDLE_VALUE))
    {
        CloseHandle(ghDriver[td]); sethDriver(INVALID_HANDLE_VALUE, td);
    }
}


void BroadcastDeviceChange(WPARAM message, int noUnit�, DWORD driveMap)
{
    uint64 r�sultat = ERR_SUCCESS; DEV_BROADCAST_VOLUME dbv; 
    BOOL IgnoreWmDeviceChange = FALSE; LONG eventId = 0;
    if (broadcastChangeP�riphD�sactiv){ return; }
    
    if (message == DBT_DEVICEARRIVAL){
        eventId = SHCNE_DRIVEADD;
    } else if (message == DBT_DEVICEREMOVECOMPLETE){
        eventId = SHCNE_DRIVEREMOVED;
    } else if (IsOSAtLeast(WIN_7) && (message == DBT_DEVICEREMOVEPENDING)) {
        /* Explorer holds open handles of all drives when 'Computer' 
           is expanded in navigation pane. */
        eventId = SHCNE_DRIVEREMOVED;
    }    
    if (driveMap == 0){ driveMap = (1 << noUnit�); } if (eventId != 0)
    {
        for (uint i = MIN_UNIT_VOLUME; i < MAX_UNIT_VOLUME; i++)
        {
            if (driveMap & (1 << i))
            {
                char dossier0[] = {(char) i + 'A', ':', '\\', 0 };
                SHChangeNotify(eventId, SHCNF_PATH, dossier0, NULL);
            }
        }
    }
    dbv.dbcv_size = sizeof(dbv); dbv.dbcv_devicetype = DBT_DEVTYP_VOLUME;
    dbv.dbcv_reserved = 0; dbv.dbcv_unitmask = driveMap; dbv.dbcv_flags = 0;
    UINT timeOut = 1000; ND_JOURNALISER_ADRESSE_CODE();    
    if (getCurrentOSMajor() >= 6){ timeOut = 100; } IgnoreWmDeviceChange = TRUE;    
    SendMessageTimeout(HWND_BROADCAST, WM_DEVICECHANGE, message, (LPARAM)(&dbv),
        SMTO_ABORTIFHUNG, timeOut, &r�sultat);
    if (message == DBT_DEVICEARRIVAL) // Explorer sometimes fails to register.
    {    
        SendMessageTimeout(HWND_BROADCAST, WM_DEVICECHANGE, message,
            (LPARAM)(&dbv), SMTO_ABORTIFHUNG, 200, &r�sultat);
    } 

    IgnoreWmDeviceChange = FALSE;
}