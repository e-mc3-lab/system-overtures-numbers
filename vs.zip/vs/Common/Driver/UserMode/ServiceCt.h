/**
 @Auteurs: Copyright (c) 1998-2000 Paul Le Roux (E4M).  
 Copyright (c) 2003-2013 'Fondation TrueCrypt' and  
 SCLE (c) 2023-2025 */

#ifndef SERVICE_NETDISQ_H
#define SERVICE_NETDISQ_H

#include "Driver.h"


#define DOSSIER_DRIVERS       "drivers" 
#define DOSSIER_SERVICES      "services" // SCLE.
#define INSTANCE              "Instance" 
#define DEFAULT_INSTANCE      "DefaultInstance" 
#define D�LAI                 3000 // Maximum d'attente.

#define NB_DRIVERS            2 
#define NB_ESSAIS_ARR�T       3 

const LPSECURITY_ATTRIBUTES   NON_ATTR_S�CURIT� = NULL;

const BOOL R�INIT_MANUEL    = TRUE;
const BOOL NON_SIGNAL�      = FALSE;

typedef enum 
{
  TD_DISQUE = 0, // P�riph�rique, Volume
  TD_FILTRE,     // Fichiers et/ou paquets Web.
  TD_COUPEFEU, TD_MAX

} TypeDriver;

#ifdef __cplusplus
extern "C" {
#endif

void setInstallation(BOOL b); BOOL estMessageErrD�j�Affich�();
void setMessageErrD�j�Affich�(BOOL b); BOOL estService�Supprimer();
DWORD getErreurService(); void setCheminProgrammes(char* cp);
char* getChemSysDrivers(); void setChemSysDrivers();
BOOL existeCl�RegistreModeServeur();
SC_HANDLE gethManager(); char* getNomService(TypeDriver td);
SC_HANDLE gethService(TypeDriver td);
SERVICE_STATUS_HANDLE getObjHEtatService(TypeDriver td);
void setObjHEtatService(SERVICE_STATUS_HANDLE ssh, TypeDriver td);
SERVICE_STATUS getObjEtatService(TypeDriver td);
void setObjHEtatServiceN(TypeDriver td); TypeDriver getIndex(const char* nom);
HANDLE gethDriver(TypeDriver td); void sethDriver(HANDLE hd, TypeDriver td);


/**
 * CONTROL MANAGER
 */
void contr�ler(DWORD code); BOOL setStatutSCM(TypeDriver td, DWORD �tat, 
    DWORD codeSortie, DWORD d�lai); void fermerSCManager();

/**
 * SERVICE
 */
BOOL installerService(TypeDriver td, DWORD typeD�marrage, 
     BOOL modeEnregistrement, BOOL afficherMsg);
BOOL d�sinstallerService(TypeDriver tdarr�terEn1er);
BOOL initialiser(TypeDriver td, BOOL d�marr);
BOOL d�marrerService(TypeDriver td);
BOOL arr�terService(TypeDriver td, BOOL bUninstall);
void fermerhService(TypeDriver td);

/**
 * PILOTE
 */
NTSTATUS ouvrirHandlePilote(TypeDriver td, DWORD codeCtl, BOOL bV�rifVersion);
LONG getNombreVolumesMont�s(); LONG unVolumeAD�j��t�Mont�();
LONG GetDriverRefCount(TypeDriver td); void fermerHandle(TypeDriver td);
BOOL estActiv�(TypeDriver td, DWORD codeCtl);
NTSTATUS appelerDriver(__in TypeDriver td, _In_ DWORD codeCtl,
    void* tabStructE, _In_ DWORD dimTabE, void* tabStructS,
    _In_ DWORD dimTabS, LONG* �tat, BOOL v�rifDrivErreur);
void BroadcastDeviceChange(WPARAM message, int noUnit�, DWORD driveMap);

#ifdef __cplusplus
}
#endif 

#endif // SERVICE_NETDISQ_H