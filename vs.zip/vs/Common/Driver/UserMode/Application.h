/*
 Legal Notice: Some portions of the source code contained in this file were
 derived from the source code of Encryption. Modifications and additions to
 the original source code (contained in this file), and all other portions
 of this file are Copyright(c) 2003-2013 'Fondation TrueCrypt'. These are
 also governed by the SCLE License; the full text of which is contained 
 in the file Licence 1.0.txt included in NetDisq distribution packages. 
 SCLE: 2023-2025. */

#ifndef TC_APPLICATION
#define TC_APPLICATION

#include "Constantes.h"
#include "ServiceCt.h"

enum { TC_TBXID_LEGAL_NOTICES };


#define ND_APPLICATION_INI         "application.ini"
#define ND_CL�_ESPACE_SERVEUR      "nd.espace.serveur"

#define NOM_NB_PROCESSEURS_LIBRES  MOT_NETDISQ "NbProcesseursLibres"

#ifdef __cplusplus
extern "C" {
#endif
    
void InitApp(HINSTANCE hInstance, int ent�teRessources[]); 
int afficherDemandeRemplacement(char chemNomVolume[]);
void cleanup(TypeDriver td);

#ifdef __cplusplus
}
#endif 

#endif // TC_APPLICATION
