/*
 Copyright(c) 2003-2013 'Fondation TrueCrypt'. All rights reserved.

 Governed by the SCLE License, the full text of which is contained in the
 file Licence 1.0.txt included in NetDisq distribution packages. 
 SCLE: 2023-2025.
*/

#ifndef TC_HEADER_BASE_COM
#define TC_HEADER_BASE_COM

#include <windows.h> 
#include "CompatibX.h"

class BaseCom
{};
 
#ifdef __cplusplus
extern "C" {
#endif

BOOL IsBuiltInAdmin();
HRESULT CreateElevatedComObject(HWND hwnd, REFGUID guid, 
    REFIID iid, void **ppv);
BOOL ComGetInstanceBase(HWND hWnd, REFCLSID clsid, 
    REFIID iid, void** tcServer);

#ifdef __cplusplus
}
#endif

#define MSG_FONCTION_PAS_IMPLANT�E "Fonction pas implant�e" 

#ifdef __cplusplus
extern "C" {
#endif

#ifdef __cplusplus
}
#endif

#endif // TC_HEADER_BASE_COM