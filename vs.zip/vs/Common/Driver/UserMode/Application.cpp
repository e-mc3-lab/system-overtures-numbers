/*
 Legal Notice: Modifications and additions to the original source code 
(contained in this file) and all other portions of this file are 
 Copyright(c) 2003-2013 'Fondation TrueCrypt' and are governed 
 by the SCLE License; the full text of which is contained in the file 
 Licence 1.0.txt included in NetDisq distribution packages. 
 SCLE: 2023-2025 (anciennement DlgCode).
 */
#include <strsafe.h>
#include "CompatibX.h"
#include "Language.h"
#include "Message.h"
#include "Plateforme/Anomalie.h"
#include "ErreurDict.h"
#include "TexteTc.h"
#include "Memoire.h"
#include "Version.h"
#include "Application.h"


using namespace NetDisq;

HWND MainDlg = NULL;

/**
  * InitApp - initialize the application, this function is called once in the
  * applications WinMain function, but before the main dialog has been created.
  */
void InitApp(HINSTANCE hInstance, int ent�teRessources[])
{
    char langId[6]; /*hInst = hInstance;*/ InitOSVersionInfo();
    SetErrorMode(SetErrorMode(0) | SEM_FAILCRITICALERRORS 
        | SEM_NOOPENFILEERRORBOX); CoInitialize(NULL);
#ifndef SETUP
    // Application ID
    typedef HRESULT(WINAPI *SetAppId_t)(WCHAR* appID);
    HMODULE hmod = GetModuleHandleA("shell32.dll");
    SetAppId_t setAppId = NULL;
    if (hmod){ setAppId = (SetAppId_t)GetProcAddress(hmod, 
        "SetCurrentProcessExplicitAppUserModelID"); }
    if (setAppId){ setAppId(NOM_APPLICATION_ID); }
#endif
    langId[0] = 0; LoadLanguageFile(ent�teRessources); // setWnd(MainDlg);
    
    if (getCurrentOSMajor() < 5){
        AbortProcess("UNSUPPORTED_OS");
    } else {
        OSVERSIONINFOEX osEx = {0};
        // Service pack check & warnings about critical MS issues.
        osEx.dwOSVersionInfoSize = sizeof(OSVERSIONINFOEX);
        if (GetVersionExA((LPOSVERSIONINFOA) &osEx) != 0)
        {
            setCurrentOSServicePack(osEx.wServicePackMajor);
            switch (getCurrentOS())
            {
                case WIN_XP:
                    AbortProcess("UNSUPPORTED_OS"); break;
            }
        }
    }
#ifdef SETUP
  #include "../setup/resource.h"
    //wc.hIcon = LoadIcon(hInstance, MAKEINTRESOURCE(IDI_SETUP));
#endif
}

int afficherDemandeRemplacement(char chemNomVolume[])
{
    int r�sultat = IDNO; WCHAR txt[2*MAX_PATH] = {0};    
    _snwprintf(txt, sizeof(txt) / 2,
        GetString(errno == EACCES ? "READONLYPROMPT" : 
        "OVERWRITEPROMPT"), chemNomVolume);
    r�sultat = MessageBoxW(NULL, txt, TITRE_W, 
        YES_NO |MB_ICONWARNING|MB_DEFBUTTON1); return r�sultat;
}


void cleanup(TypeDriver td)
{    
    fermerHandle(td); CoUninitialize();
}