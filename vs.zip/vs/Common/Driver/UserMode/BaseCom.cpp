/*
 Copyright (c) 2003-2015 'Fondation TrueCrypt'. All rights reserved.

 Governed by the SCLE License; the full text of which is contained in
 the file Licence 1.0.txt included in NetDisq distribution packages. 
 SCLE: 2023-2025.
*/

#include "Config.h"
#include "Memoire.h"
#include "Erreur.h"
#include "MessageDict.h"
#include "Plateforme/Espace.h"
#include "Plateforme/Finally.h"
#include "BaseCom.h"


#define LONG_TAB   MAX_LONGUEUR_MSG // 1024


using namespace NetDisq;

BOOL IsBuiltInAdmin()
{
    HANDLE procToken; DWORD size;
    if ( ! IsAdmin() || ! OpenProcessToken(GetCurrentProcess(), TOKEN_QUERY, 
        &procToken)){ return FALSE; }

    finally_do_arg(HANDLE, procToken, { CloseHandle(finally_arg); });
    if (GetTokenInformation(procToken, TokenUser, NULL, 0, &size) || 
        (GetLastError() != ERROR_INSUFFICIENT_BUFFER)){ return FALSE; }
    TOKEN_USER *tokenUser = (TOKEN_USER *) NDAllouer(size);

    if ( ! tokenUser){ return FALSE; }

    finally_do_arg(void *, tokenUser, { NDFree(finally_arg); });
    if ( ! GetTokenInformation(procToken, TokenUser, tokenUser, size, &size)){
        return FALSE;
    }    
    return IsWellKnownSid(tokenUser->User.Sid, WinAccountAdministratorSid);
}

HRESULT CreateElevatedComObject(HWND hwnd, REFGUID guid, REFIID iid, void **ppv)
{
    WCHAR monikerName[LONG_TAB] = {0}, clsid[LONG_TAB] = {0};
    BIND_OPTS3 bndOptions;

    StringFromGUID2(guid, clsid, sizeof(clsid) / 2);
    swprintf_s(monikerName, sizeof(monikerName) / 2, 
        L"Elevation:Administrator!new:%s", clsid);
    init0(&bndOptions, sizeof(bndOptions)); 
    bndOptions.cbStruct = sizeof(bndOptions);
    bndOptions.hwnd = hwnd; bndOptions.dwClassContext = CLSCTX_LOCAL_SERVER;
    // Prevent the GUI from being half-rendered when the UAC prompt "freezes" it.
    HRESULT r�sultat = CoGetObject(monikerName, &bndOptions, iid, ppv);
    return r�sultat;
}

BOOL ComGetInstanceBase(HWND hWnd, REFCLSID clsid, REFIID iid, void** tcServer)
{
    BOOL r�sultat;    
    if (IsUacSupported ()){
        r�sultat = (CreateElevatedComObject(hWnd, clsid, iid, 
            tcServer) == S_OK);
    } else {
        r�sultat = CoCreateInstance(clsid, NULL, CLSCTX_LOCAL_SERVER,
            iid, tcServer) == S_OK;
    }
    if ( ! r�sultat){
        Error("UAC_INIT_ERROR");
    }
    return r�sultat;
}