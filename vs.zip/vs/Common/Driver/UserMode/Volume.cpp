/*
 Copyright(c) 2003-2015 'Fondation TrueCrypt'. See SCLE License 1.0; the 
 full text of which is contained in the file Licence.txt included in NetDisq 
 source and binary code distribution packages. SCLE: 2023-2025.
 */
#include <io.h>
#include <shlobj.h>
#include <dbt.h>
#include "Plateforme\Espace.h"
#include "Config.h"
#include "Version.h"
#include "Memoire.h"
#include "Fichier.h"
#include "MessageDict.h"
#include "ErreurDict.h"
#include "Pause.h"
#include "Langage.h"
#include "Language.h"
#include "TexteTc.h"
#include "ServiceCt.h"
#include "BaseCom.h"
#include "Driver.h"
#include "Journal.h"
#include "Volume.h"


using namespace NetDisq;

BOOL bAfficherMsg = TRUE, bMsgErrD�j�Affich� = FALSE;
BOOL bMultipleMountOperationInProgress = FALSE;
int gWrongPwdRetryCounter = 0;

BOOL CheckCapsLock(BOOL quiet)
{
    if ((GetKeyState(VK_CAPITAL) & 1) != 0)    
    {
        if ( ! quiet){ Info("CAPSLOCK_ON"); } return TRUE;
    }
    return FALSE;
}

void IncreaseWrongPwdRetryCount(int count){
    gWrongPwdRetryCounter += count;
}

void ResetWrongPwdRetryCount(void){
    gWrongPwdRetryCounter = 0;
}

BOOL WrongPwdRetryCountOverLimit(void){
    return(gWrongPwdRetryCounter > 3);
}

/**
 * Returns drive letter number assigned to device (-1 if none).
 */
int GetDiskDeviceDriveLetter(HANDLE hDriver, WCHAR cnf[])
{
    int i;
    WCHAR link[MAX_PATH], target[MAX_PATH], device[MAX_PATH];
    if ( ! TCResolveSymbolicLink(hDriver, cnf, device)){
        wcscpy(device, cnf);
    }
    for (i = 0; i < MAX_UNIT_VOLUME; i++)
    {
        WCHAR drive[] = {(WCHAR)(i + 'A'), ':', 0 };
        wcscpy(link, TEXT(PRFX_DOS_DEVICES)); wcscat(link, drive);
        TCResolveSymbolicLink(hDriver, link, target);
        if (wcscmp(device, target) == 0){  return i;  }
    } return -1;
}

LONG appelerDriverVolume(DWORD codeCtl,
    void* tabStructE, DWORD dimTabE, void* tabStructS,
    DWORD dimTabS, LONG* �tat)
{
    NTSTATUS r�sultat = appelerDriver(TD_DISQUE, codeCtl, tabStructE, dimTabE,
        tabStructS, dimTabS, �tat, TRUE);
    if ((dimTabS > 0) && (dimTabS == sizeof(MOUNT_STRUCT)))
    {
        MOUNT_STRUCT* ms = (MOUNT_STRUCT*)tabStructS;
        if (NT_SUCCESS(ms->r�sultat) && ! NT_SUCCESS(r�sultat)){
            ms->r�sultat = r�sultat;
        }
    } 
    if (NT_SUCCESS(r�sultat)){ r�sultat = lir�tatDriver(); }
    return r�sultat;
}

BOOL estVolumeMont�(const char nom[])
{
    BOOL r�sultat = FALSE; UNIT_VOLUME uv = {0}; 
    r�sultat = (getNoUnit�Volume(&uv, nom) > MIN_UNIT_VOLUME);
    if ( ! NT_SUCCESS(uv.r�sultat)){
        afficherErreurDict(uv.r�sultat, TRUE);        
    } 
    return r�sultat;
}

BOOL IsDriveAvailable(uint8 noUnit�){
    return (GetLogicalDrives() & (1 << noUnit�)) == 0;
}

std::string getCheminVolumeDisqueDur(const std::string &rnv)
{
    wstring chemVolume = SingleStringToWide(rnv);
    HANDLE hDriver = gethDriver(TD_DISQUE);
    for (int u = 0; u < MAX_HOST_DRIVE_NUMBER; u++)
    {
        for (int i = 0; i < MAX_HOST_PARTITION_NUMBER; i++)
        {
            WCHAR chemPartition[MAX_PATH] = {0}, chemR�solu[MAX_PATH] = {0};
            swprintf_s(chemPartition, ARRAYSIZE(chemPartition),
                TEXT(PRFX_NT_DEVICE) TEXT(MOT_DISQUE_DUR_EN) \
                L"%d\\" TEXT(MOT_PARTITION) L"%d", u, i);    
            if (TCResolveSymbolicLink(hDriver, chemPartition, chemR�solu))
            {
                if (chemVolume == chemR�solu){
                    return convEnCCHAR(chemPartition);
                }
            } else if (i == 0){ break; }
        }
    }
    return string();
}


std::string VolumeGuidToCheminP�riph(std::string volumeGuidPath)
{
    if (volumeGuidPath.find("\\" PRFX_CHEMIN_MN) == 0){
        volumeGuidPath = volumeGuidPath.substr(4);
    }
    if (volumeGuidPath.find(MOT_VOLUME "{") != 0 || 
        volumeGuidPath.rfind("}\\") != volumeGuidPath.size() - 2){
        return string();
    } 
    char chemDevVolume[MAX_PATH] = {0};
    if (QueryDosDeviceA(volumeGuidPath.substr(0, volumeGuidPath.size() - 1)
        .c_str(), chemDevVolume, MAX_PATH) == 0){ return string(); }
    string chemPartition = getCheminVolumeDisqueDur(chemDevVolume);

    return chemPartition.empty() ? chemDevVolume : chemPartition;
}

/**
 * Retourne la lettre d'unit� du volume si d�j� mont�, ou un code d'erreur.
 */ 
LONG getNoUnit�Volume(UNIT_VOLUME* uv, const char nom[])
{
    char volume[MAX_PATH] = {0}; if ( ! nom){ return ERR_INSUCC�S; }
    strcpy(volume, nom); if (strstr(nom, PRFX_NT_DEVICE) != nom){
        sprintf(volume, PRFX_CHEMIN_MN "%s", nom);
    }
    string chemR�solu = VolumeGuidToCheminP�riph(nom);
    if ( ! chemR�solu.empty()){
        strcpy_s(volume, sizeof(volume), chemR�solu.c_str());
    }
    wcscpy(uv->chemNomVolume, convEnWCHAR(volume)); NTSTATUS retour;
    appelerDriverVolume(TC_CTL_CODE_GET_NO_UNIT�_VOLUME,
        uv, sizeof(UNIT_VOLUME), uv, sizeof(UNIT_VOLUME), &retour);
    return (LONG)uv->r�sultat;
}

BOOL v�rifierSiSysFichiersValide(__in LONG code, uint noUnit�)
{    
    if ((code == ERR_SYS_FICHIERS_INCERTAIN) && ! bMsgErrD�j�Affich�)
    {
        WCHAR msg[MAX_LONGUEUR_MSG] = {0};
        WCHAR pointMontage[] = { (WCHAR)('A' + noUnit�), L':', 0 };
        wsprintfW(msg, GetString("�TAT_SYS_FICHIERS_INCERTAIN"), pointMontage);
        MessageBoxW(NULL, msg, TITRE_W, MB_ICONWARNING);
        ex�cuterDisqueV�rif(noUnit�, TRUE); bMsgErrD�j�Affich� = TRUE;
        return TRUE;
    } 
    return FALSE;
}

/**
 * Note that some code calling this relies on the content of the MOUNT_OPTIONS
 * struct to remain unmodified (don't remove the 'const' without proper 
 * revision). 
 *
 * Voir le commentaire dans s�curit�\exemples\service\LisezMoi.txt.
 *
 * Returns:
 *  -1 = user aborted mount / error
 *   0 = mount failed  1 = mount OK  2 = mount OK in shared mode.
 */
int monterVolume(__in uint8 noUnit�, const WCHAR cnf[],
    const MOT_DE_PASSE_DRV* mdp, BOOL pourFormatage, // TODO: changer en struct.
    BOOL sharedAccess, BOOL ReadOnly, BOOL quiet, BOOL bInitChemP�riph)
{
    BOOL r�sultat = ERR_SUCCESS, bDevice = FALSE; NTSTATUS �tat;
    const uint16 DIM_MOUNT = sizeof(MOUNT_STRUCT);
    MOUNT_STRUCT* mount = (MOUNT_STRUCT*)NDAllouer0(DIM_MOUNT);
    char dossier0[MAX_PATH] = {0}; BOOL bReportWrongMotDePasse = TRUE;
    char ccCnf[MAX_PATH] = {0}; string chemin = ccCnf;
    strcpy(ccCnf, constEnCCHAR(cnf)); ND_JOURNALISER_SIGNET("MonterVolume");
    if (estVolumeMont�(ccCnf))
    {
        if ( ! quiet){ afficherErreurDict("VOL_ALREADY_MOUNTED"); } 
        r�sultat = ERR_VOLUME_ALREADY_MOUNTED; ND_FIN();
    }
    if ( ! IsDriveAvailable(noUnit�))
    {
        if ( ! quiet){ afficherErreurDict("DRIVE_LETTER_UNAVAILABLE"); }
        r�sultat = FALSE; ND_FIN();
    }
    if ( ! existe(ccCnf))
    {
        afficherErreurDict("PAS_DE_FICHIER_HOTE"); 
        r�sultat = FALSE; ND_FIN();
    }
    mount->bExclusiveAccess = sharedAccess ? FALSE : TRUE;    

R�ESSAI:

    mount->noUnit� = noUnit�;
    if (mdp){
        RtlCopyMemory(&mount->moDPassUtilisateur, mdp, 
            sizeof(mount->moDPassUtilisateur));
    } else {
        mount->moDPassUtilisateur.longueur = 0;
    }

    mount->bReadOnly = ReadOnly;
    mount->bInitChemP�riph = bInitChemP�riph;    
    if (chemin.find("\\" PRFX_CHEMIN_MN) == 0)
    {        
        chemin = chemin.substr(4); // Remove \\?\ prefix
        strcpy_s(ccCnf, MAX_PATH, chemin.c_str());
    }    
    if ((chemin.find(MOT_VOLUME "{") == 0) && 
        (chemin.rfind("}\\") == chemin.size() - 2))
    {
        string resolvedPath = VolumeGuidToCheminP�riph(chemin);
        if ( ! resolvedPath.empty()){
            strcpy_s(ccCnf, MAX_PATH, resolvedPath.c_str());
        }
    }
    if ((chemin.length () >= 3) && (strncmp(chemin.c_str(), "ID:", 3) == 0)){
        journaliser("Volume ID %s.", chemin.c_str());
    }
    char* cStrVolume = ccCnf; LONG codeRetour = ERR_SUCCESS;
    if ( ! bDevice)
    {   // Chemin UNC .
        if (chemin.find("\\\\") == 0){
            strcpy_s(cStrVolume, array_capacity(mount->chemNomVolume),
                ("UNC" + chemin.substr(1)).c_str());
        }
        if (GetVolumePathNameA(ccCnf, dossier0, sizeof(dossier0) - 1))
        {
            DWORD bps, flags, d;
            if (GetDiskFreeSpaceA(dossier0, &d, &bps, &d, &d)){
                mount->bytesPerSector = bps;
            } // Read-only host filesystem.
            if ( ! mount->bReadOnly && GetVolumeInformationA(dossier0, NULL, 
                0, NULL, &d, &flags, NULL, 0)){
                mount->bReadOnly = ((flags & FILE_READ_ONLY_VOLUME) != 0);
            }
        }
    }
    wcscpy(mount->chemNomVolume, cnf);
    r�sultat = appelerDriverVolume(TC_CTL_CODE_MOUNT_VOLUME, mount,
        DIM_MOUNT, mount, DIM_MOUNT, &�tat);
    codeRetour = mount->r�sultat; 
    if ( ! r�sultat && (r�sultat != ERR_SUCCESS))
    {    // Volume already open by another process.
        if (GetLastError() == ERROR_SHARING_VIOLATION)
        {
            if ( ! mount->bExclusiveAccess)
            {
                if ( ! quiet){
                    Error("FICHIER_EN_UTILISATION_ECHEC");
                }
                r�sultat = -1; ND_FIN();
            } else if (mount->moDPassUtilisateur
                .longueur >= PASSWORD_LEN_MIN_WARNING){ 
                if (quiet)
                {
                    mount->bExclusiveAccess = ERR_MOTPASSE_INVALIDE;
                    goto R�ESSAI;
                }
                if (AskWarnNoYes("FICHIER_EN_UTILISATION") == IDYES)
                {
                    mount->bExclusiveAccess = ERR_FILE_OPEN; goto R�ESSAI;
                }
            }
            r�sultat = -1; ND_FIN();
        } else if (codeRetour == ERR_SUCCESS){
            codeRetour = r�sultat; 
        }
    } 
    if (codeRetour != ERR_SUCCESS) 
    {
        if ((codeRetour == ERR_MOTPASSE_INVALIDE) ||
            (codeRetour == ERR_MOTPASSE_OU_ENT�TE_INVALIDE))
        {    // Do not report wrong password, if not instructed to.
            if (bReportWrongMotDePasse)
            {    // We increase the count here only if it's TRUE.
                IncreaseWrongPwdRetryCount(1);
                if ( ! quiet)
                {
                    afficherErreurDict(codeRetour, bReportWrongMotDePasse);
                    r�sultat = codeRetour;
                }
            }
            codeRetour = FALSE; ND_FIN();
        }
        if ( ! quiet)
        {
           traiterErreurDict(codeRetour); bMsgErrD�j�Affich� = TRUE; 
           r�sultat = ERR_DONT_REPORT/*codeRetour*/; ND_FIN();
        } 
        codeRetour = FALSE; ND_FIN();
    } 
    if ( ! pourFormatage){ // Mount successful.
        v�rifierSiSysFichiersValide(codeRetour, noUnit�); 
    }    
    if (mount->readOnlyAfterAccessDenied && bAfficherMsg && ! bDevice && 
        ! bMsgErrD�j�Affich� && ! FileHasReadOnlyAttribute(ccCnf) && 
        ! estEnLectureSeule(ccCnf))
    {   
        WCHAR msg[MAX_LONGUEUR_MSG] = {0}; uint N = sizeof(MOUNT_STRUCT);
        WCHAR pointMontage[] = {(WCHAR)('A' + noUnit�), L':', 0 };
        wsprintfW(msg, GetString("MOUNTED_CONTAINER_FORCED_READ_ONLY"),
            pointMontage); afficherAttention(msg); bMsgErrD�j�Affich� = TRUE;
    }
    if (mount->readOnlyAfterAccessDenied && bAfficherMsg && 
        bDevice && ! bMsgErrD�j�Affich�)
    {
        WCHAR msg[MAX_LONGUEUR_MSG] = {0};
        WCHAR pointMontage[] = { (WCHAR)('A' + noUnit�), L':', 0 };
        wsprintfW(msg, GetString("MOUNTED_DEVICE_FORCED_READ_ONLY"),
            pointMontage); afficherAttention(msg); bMsgErrD�j�Affich� = TRUE;
    }
    r�sultat = ERR_SUCCESS; ResetWrongPwdRetryCount(); 
    BroadcastDeviceChange(DBT_DEVICEARRIVAL, noUnit�, 0);
FIN: NDFree0(mount, DIM_MOUNT); ERR_MEM: return r�sultat;
}

int retirerVolumeA(uint8 noUnit�, const MOT_DE_PASSE_DRV* mdp, BOOL forced)
{    
    int r�sultat; NTSTATUS �tat; ULONG DIM_UMOUNT = sizeof(UNMOUNT_STRUCT);    
    UNMOUNT_STRUCT* unmount = (UNMOUNT_STRUCT*)NDAllouer0(DIM_UMOUNT);
    unmount->noUnit� = noUnit�; unmount->ignoreOpenFiles = forced;    
    if (mdp){ RtlCopyMemory(&unmount->moDPassUtilisateur, mdp, DIM_MDP_DRV); }
    r�sultat = appelerDriverVolume(TC_CTL_CODE_DISMOUNT_VOLUME, unmount,
        DIM_UMOUNT, unmount, DIM_UMOUNT, &�tat); r�sultat = unmount->r�sultat;
    NDFree0(unmount, DIM_UMOUNT); ERR_MEM: return r�sultat;
}

BOOL retirerVolume(uint8 noUnit�, const MOT_DE_PASSE_DRV* mdp, 
     BOOL forceUnmount)
{
    int r�sultat; BOOL forced = forceUnmount;
    int dismountMaxRetries = UNMOUNT_MAX_AUTO_RETRIES;
R�ESSAI:
    BroadcastDeviceChange(DBT_DEVICEREMOVEPENDING, noUnit�, 0); do
    {
        r�sultat = retirerVolumeA(noUnit�, mdp, forced);
        if (r�sultat == ERR_FILE_OPEN){
            Sleep(UNMOUNT_AUTO_RETRY_DELAY);
        } else { 
            break;
        }
    } while (--dismountMaxRetries > 0); if (r�sultat != ERR_SUCCESS)
    {
        if ((r�sultat == ERR_FILE_OPEN) && bAfficherMsg)
        {
            if (AskWarnYesNoTopmost("UNMOUNT_LOCK_FAILED") == IDYES)
            {
                forced = TRUE; goto R�ESSAI;
            }
            if (IsOSAtLeast(WIN_VISTA)) // Undo SHCNE_DRIVEREMOVED.
            {
                char chem0[] = {(char) noUnit� + 'A', ':', '\\', 0 };
                SHChangeNotify(SHCNE_DRIVEADD, SHCNF_PATH, chem0, NULL);
            }
            return FALSE;
        }
        if ( ! v�rifierSiSysFichiersValide(r�sultat, noUnit�))
        {
            BroadcastDeviceChange(DBT_DEVICEQUERYREMOVEFAILED, noUnit�, 0);
            traiterErreurDict("UNMOUNT_FAILED", r�sultat);
        } 
        return FALSE;
    }
    BroadcastDeviceChange(DBT_DEVICEREMOVECOMPLETE, noUnit�, 0); return TRUE;
}