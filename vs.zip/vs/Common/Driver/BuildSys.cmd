::
:: Copyright (c) 2003-2015 'Fondation TrueCrypt'. All rights reserved.
::               2023-2024 SCLE. 
::
:: Governed by the SCLE License 1.0; the full text of which is contained in
:: the file Licence.txt included in Netdisq source and binary code distribution
:: packages.
::
@echo off
chcp 28591 > nul


set ND_ARG_CMD=%~1
shift
set ND_ARG_CONFIG=%~1
if "%~1"=="" goto args_erreur
shift
set ND_ARG_PLATFORM=%~1
shift
set ND_SUFFIXE_DRV=%~1

:: Initialisation

set CHEM_RELATIF=.
set ND_NOM_DRIVER=netdisq%ND_SUFFIXE_DRV%
set ND_NOM_DRIVER_SYS=%ND_NOM_DRIVER%.sys
set ND_BUILD_PLATFORM=%ND_ARG_PLATFORM%
set ND_C_DEFINES=-D_WIN64 -DTC_WINDOWS_DRIVER -DPROJET_DRIVER_DLL -D_UNICODE -DUNICODE 
set ND_C_FLAGS=-nologo -I..
REM set ND_C_WARNING_LEVEL=-W4
set ND_C_DISABLED_WARNINGS=-wd4024 -wd4047 -wd4100 -wd4127 -wd4152 -wd4700 -wd4706 -wd4995
set ND_LIBRARIAN_FLAGS=-nologo
set ND_BUILD_TYPE=fre
set ND_BUILD_ALT_DIR=
set ND_LINKER_FLAGS=-nologo -LTCG
set ND_SETUP_DIR=..\Setup\%ND_ARG_CONFIG%\%ND_ARG_PLATFORM%\dist\prg

:: Plateforme

if "%ND_ARG_PLATFORM%"=="x64" (    
    set ND_BUILD_PLATFORM_DIR=amd64
) else (
    set ND_BUILD_PLATFORM_DIR=ia64    
)

:: Session WDK

pushd .
call %WINDDK%\bin\SetEnv %WINDDK% %ND_BUILD_TYPE% %ND_BUILD_PLATFORM% no_oacr || exit /B %errorlevel%
popd

:: Construction

set WDK_PREFAST=
set DDK_LIB_WIN=%SDK_LIB_DEST%\%ND_BUILD_PLATFORM_DIR%
if "%ND_ARG_CMD%"=="-rebuild" (set OPTIONS_BUILD=-wcez)
if "%ND_ARG_CMD%"=="-prefast" (set WDK_PREFAST=prefast) 

pushd .

if "%ND_ARG_CMD%"=="-clean" (
    rmdir /s /q obj%ND_BUILD_ALT_DIR% 2>NUL:
) else (

    set DIR_R�SULTAT=%CHEM_RELATIF\obj%ND_BUILD_ALT_DIR%\%ND_BUILD_PLATFORM_DIR%\
    set USER_C_FLAGS=%ND_C_FLAGS% %ND_C_DISABLED_WARNINGS% /FAsc /Fa%DIR_R�SULTAT%  
    set MSC_WARNING_LEVEL=%ND_C_WARNING_LEVEL%\
    set C_DEFINES=%ND_C_DEFINES%
    if "%ND_SUFFIXE_DRV%"=="" (set C_DEFINES=%C_DEFINES% __STDC_WANT_SECURE_LIB__)
    set RCOPTIONS=/I %MFC_INC_PATH% /V
    set LIBRARIAN_FLAGS=%ND_LIBRARIAN_FLAGS%
    set LINKER_FLAGS=%ND_LINKER_FLAGS% 
    set BUILD_ALT_DIR=%ND_BUILD_ALT_DIR%
    rmdir /s /q obj%ND_BUILD_ALT_DIR% 2>NUL:
    REM %WINDDK0%\bin\x86\amd64\
    %WDK_PREFAST% build.exe %OPTIONS_BUILD% -nmake /S -nmake /C
)

:TERMIN�

popd
if "%ND_ARG_CMD%"=="-clean" goto fin

pushd .

:: Signature

set URL_VERISIGN_TS=http://timestamp.verisign.com/scripts/timestamp.dll     
set CHEM_RELATIF_ND_SYS=obj%ND_BUILD_ALT_DIR%\%ND_BUILD_PLATFORM_DIR%\%ND_NOM_DRIVER_SYS%

echo NB: l'installation automatique n'est pas prise en compte [instr. en commentaire].    
SignTool sign /v /s my /n "Certificat d'essai SCLE" /t %URL_VERISIGN_TS% %CHEM_RELATIF_ND_SYS%
REM if errorlevel 1 (  echo BuildSys.cmd: erreur lors de la signature du fichier .sys. )

:: Copie dans installation

copy /B /Y obj%ND_BUILD_ALT_DIR%\%ND_BUILD_PLATFORM_DIR%\%ND_NOM_DRIVER_SYS% %ND_SETUP_DIR% 
popd
goto fin

:args_erreur
echo Usage: BuildSys "<-build|-rebuild|-clean|-prefast> <Release|Debug> <x64|i64>" -suffixe

:fin
del /q *.cod 2>NUL:
:: exit /B 0