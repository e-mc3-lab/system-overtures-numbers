/*
 Copyright (c) 2003-2015 'Fondation TrueCrypt'. All rights reserved.

 Governed by the SCLE License; the full text of which is contained in
 the file Licence 1.0.txt included in NetDisq distribution packages.
 2024-2025.
*/

#include "ResourceC.h"
#include "Dictionary.h"
#include "Memoire.h"
#include "Register.h"
#include "Xml.h"
#include "Message.h"
#include "Language.h"


#define UNKNOWN_STRING_ID   L"[?]"
#define DIM_PRFX_LANG_ID    2

BOOL LocalizationActive; int LocalizationSerialNo;
WCHAR gUnknownString[MAX_LONGUEUR_MSG] = {0};
static char* gLanguageFileBuffer = NULL; int gIdrLang = IDR_LANGUAGE_EN;
static HANDLE gLanguageFileFindHandle = INVALID_HANDLE_VALUE;
static char gPrfxLangId[DIM_PRFX_LANG_ID + 1] = LANG_ID_EN;
static char *gLanguageResource = NULL, *HeaderResource[2];
static char gAttr[SHRT_MAX + 1]; static WCHAR gWattr[SHRT_MAX + 1] = {0};
static char gActiveLangPackVersion[6] = {0};

byte* MapResource(const char resourceType[], int resourceId, PDWORD size)
{
    HGLOBAL hResL; HRSRC hRes = FindResourceA(NULL,
        MAKEINTRESOURCEA(resourceId), resourceType); if (hRes)
    {
        if (size != NULL){ *size = SizeofResource(NULL, hRes); }
        hResL = LoadResource(NULL, hRes);
        if (hResL){ return (byte*)LockResource(hResL); }
    }
    return NULL;
}

void setLocaleLangId()
{    
    #define LOCALE_NAME "LocaleName"
    const WCHAR MSG_ERROR_REG_LOCALE[] = L"Can not read the register value " \
        L"for the key \"" TEXT(LOCALE_NAME) L"\".";
    HKEY hkey = 0; uchar szValue[32] = {0}; DWORD size = sizeof(szValue);

    if (RegOpenKeyExA(HKEY_CURRENT_USER, "Control Panel\\International\\",
        0, KEY_READ, &hkey) != EXIT_SUCCESS)
    {
        afficherAttention(MSG_ERROR_REG_LOCALE); return;
    }
    if (RegQueryValueExA(hkey, LOCALE_NAME, 0, 0, szValue,
        &size) == EXIT_SUCCESS)
    {
        gPrfxLangId[0] = tolower(szValue[0]);
        gPrfxLangId[1] = tolower(szValue[1]);
        if (strcmp(gPrfxLangId, LANG_ID_FR) != 0){
            strcpy(gPrfxLangId, LANG_ID_EN);
        }
    } else { afficherAttention(MSG_ERROR_REG_LOCALE); }
    RegCloseKey(hkey);
}

static char *MapDefaultLanguageFile()
{
    if (gLanguageFileFindHandle != INVALID_HANDLE_VALUE)
    {
        FindClose(gLanguageFileFindHandle);
        gLanguageFileFindHandle = INVALID_HANDLE_VALUE;
    }
    if (gLanguageResource == NULL)
    {
        DWORD size;
        if (strcmp(gPrfxLangId, LANG_ID_FR) == 0){
            gIdrLang = IDR_LANGUAGE_FR;
        } else if (strcmp(gPrfxLangId, LANG_ID_ES) == 0){
            gIdrLang = IDR_LANGUAGE_EN; // TODO.
        }
        gLanguageResource = (char*) MapResource("xml", gIdrLang, &size);
    }
    return gLanguageResource;
}

BOOL LoadLanguageFile()
{
    const int HEADERS[] = { IDR_COMMON_RSRC_HEADER, 0 };
    const char* XML_ELEMENTS[] = { "control", "string", 0 };

    BOOL r�sultat = TRUE; DWORD size; byte* res;
    char* xml, *header, key[128] = {0}; int i, intKey, len;
    BOOL bLanguageParsed = FALSE, bLangFound = FALSE;
    LocalizationActive = FALSE; gActiveLangPackVersion[0] = 0;
    setLocaleLangId(); ClearDictionaryPool();
    res = (byte*) MapDefaultLanguageFile();
    bLanguageParsed = (res != NULL);
    xml = (char*) res; xml = XmlFindElement(xml, "localization");
    if (xml)
    {
        // Required NETDISQ version
        XmlGetAttributeText(xml, "prog-version", gAttr, sizeof(gAttr));
        // Search language id in language file.
        if (bLanguageParsed)
        {
            while (xml = XmlFindElement(xml, "language"))
            {
                XmlGetAttributeText(xml, "langid", gAttr, sizeof(gAttr));
                if (strcmp(gAttr, gPrfxLangId) == 0)
                {
                    XmlGetAttributeText(xml++, "version", 
                        gActiveLangPackVersion, sizeof(gActiveLangPackVersion));
                    bLangFound = TRUE;
                }
                xml++;
            }            
        }
    }
    if (bLangFound)
    {
        // Create font dictionary 
        xml = (char*)res;
        while (xml = XmlFindElement(xml, "font")) 
        {
            XmlGetAttributeText(xml, "lang", gAttr, sizeof(gAttr));
            if ( ! bLanguageParsed || strcmp(gAttr, gPrfxLangId) == 0)
            {
                Font font; init0(&font, sizeof(font));
                XmlGetAttributeText(xml, "face", gAttr, sizeof(gAttr));
                len = MultiByteToWideChar(CP_UTF8, 0, gAttr, -1, gWattr,
                    sizeof(gWattr) / sizeof(gWattr[0]));
                font.FaceName = (WCHAR*)AddPoolData((void*)gWattr, len * 2);
                XmlGetAttributeText(xml, "size", gAttr, sizeof(gAttr));
                sscanf(gAttr, "%d", &font.Size); strcpy(gAttr, "font_");
                XmlGetAttributeText(xml, "class", gAttr + 5, sizeof(gAttr) - 5);
                AddDictionaryEntry((char*)AddPoolData((void*)gAttr,
                    strlen(gAttr) + 1), 0, AddPoolData((void*)&font,
                        sizeof(font)));
            }
            xml++;
        }
        // Create string and control dictionaries
        for (i = 0; XML_ELEMENTS[i] != 0; i++)
        {
            // Assign resource:
            xml = (char*)res; while (xml = XmlFindElement(xml, XML_ELEMENTS[i]))
            {
                void* key; void* text; if (bLanguageParsed)
                {
                    if (XmlGetAttributeText(xml, "key", gAttr, sizeof(gAttr)))
                    {
                        key = AddPoolData(gAttr, strlen(gAttr) + 1);
                        if (key == NULL){ r�sultat = FALSE; }
                        XmlGetNodeText(xml, gAttr, sizeof(gAttr));
                        // Parse \ escape sequences.
                        {
                            char* in = gAttr, * out = gAttr;
                            while (*in)
                            {
                                if (*in == '\\')
                                {
                                    in++;
                                    switch (*in++)
                                    {
                                        case '\\':  *out++ = '\\'; break;
                                        case 't':   *out++ = '\t'; break;
                                        case 'n':   *out++ = 13; *out++ = 10;
                                                    break;
                                    default: // NB: ne pas appeler dans
                                    MessageBoxA(0, (LPCSTR)key, // NWService
                                        "NetDisq: Unknown '\\' escape " \
                                        "sequence in string", MB_ICONERROR);
                                    r�sultat = FALSE; break;
                                    }
                                } else { *out++ = *in++; }
                            }
                            *out = 0;
                        }
                        // UTF8 => wide char
                        len = MultiByteToWideChar(CP_UTF8, 0, gAttr, -1,
                            gWattr, sizeof(gWattr) / sizeof(gWattr[0]));
                        if (len == 0 || len == ERROR_NO_UNICODE_TRANSLATION)
                        {
                            MessageBoxA(0, (LPCSTR)key, // Idem NWService.
                                "NetDisq: Error while decoding UTF-8 string",
                                MB_ICONERROR); r�sultat = FALSE; break;
                        }
                        // Add to dictionary
                        text = AddPoolData((void*)gWattr, len * 2);
                        if (text == NULL) { r�sultat = FALSE; break; }
                        AddDictionaryEntry((char*)key, 0, text);
                    }
                }
                xml++;
            }
        } 
    } else if ( ! bLanguageParsed){
        bLanguageParsed = TRUE;
        if ((gPrfxLangId[0] == 0) ||
            (strcmp(gPrfxLangId, LANG_ID_EN) == 0)){
            r�sultat = FALSE;
        }
    }
    LocalizationActive = bLangFound && (strcmp(gPrfxLangId, LANG_ID_EN) != 0);
    LocalizationSerialNo++; if (gLanguageFileBuffer != NULL)
    { 
        free(gLanguageFileBuffer); gLanguageFileBuffer = NULL;
    }
    if ( ! r�sultat){ return FALSE; } // NetDisq.
    // Create control ID dictionary. 
    AddDictionaryEntry(NULL, 1, GetString("IDOK")); 
    AddDictionaryEntry(NULL, 2, GetString("IDCANCEL")); 
    AddDictionaryEntry(NULL, 8, GetString("IDCLOSE")); 
    AddDictionaryEntry(NULL, 9, GetString("IDHELP")); 
    for (i = 0; HEADERS[i] != 0; i++)
    {
        if (HeaderResource[i] == NULL){
            HeaderResource[i] = (char*) MapResource("Header", 
                HEADERS[i], &size); 
        }
        header = HeaderResource[i]; if (header == NULL){ return FALSE; }
        do 
        {
            if (sscanf(header, "#define %s %d", key, &intKey) == 2)
            {
                WCHAR *str = GetString(key); 
                if (str != gUnknownString){
                    AddDictionaryEntry(NULL, intKey, str); 
                }
            }
        } while ((header = strchr(header, '\n') + 1) != (char *) 1);
    }
    return TRUE;
}

void UnloadLanguageFile(){ ClearDictionaryPool(); }

BOOL isLangFr(){ return (gIdrLang == IDR_LANGUAGE_FR); }

BOOL isLangEn(){ return (gIdrLang == IDR_LANGUAGE_EN); }

BOOL isLangEs(){ return (gIdrLang == IDR_LANGUAGE_ES); }

void SetPrfxLangId(const char id[]){ 
    strncpy(gPrfxLangId, id, DIM_PRFX_LANG_ID);
}

WCHAR* GetString(const char id[])
{
    WCHAR* str = (WCHAR*) GetDictionaryValue(id);
    if (str != NULL){ return str; }
    wsprintfW(gUnknownString, UNKNOWN_STRING_ID L"%hs" UNKNOWN_STRING_ID, id);
    return gUnknownString;
}

Font* GetFont(char fontType[]){ return(Font*) GetDictionaryValue(fontType); }