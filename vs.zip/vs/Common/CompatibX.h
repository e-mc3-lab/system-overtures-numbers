/*
 Legal Notice: Modifications and additions to the original source code 
 (contained in this file) and all other portions of this file are 
 Copyright(c) 2003-2015 'Fondation TrueCrypt' and are governed by the 
 SCLE license, the full text of which is contained in the file 
 Licence 1.0.txt. 2024-2026. */

#ifndef COMPATIBILIT_X_SYS
#define COMPATIBILIT_X_SYS

#ifndef NULL
#define NULL 0
#endif

typedef unsigned short      word;
typedef unsigned int        uint;

typedef unsigned __int8     uint8;
typedef unsigned __int16    uint16;
typedef unsigned __int32    uint32; // ulong (4).
typedef unsigned __int64    uint64; // ULONGLONG (8).

typedef __int8              int8;
typedef __int16             int16;
typedef __int32             int32;
typedef __int64             int64;
#define ENTIER              uint64 // Positive (0 and +).
typedef unsigned long       ulong;
typedef long long           llong;
typedef unsigned char       uchar;

#define ENUM_1              1

#ifndef BOOL
typedef int                 BOOL; // Should be uint8, otherwise would cause 
#endif                      // compilation errors with Windows softwares.

#ifndef TRUE
#define TRUE                1
#endif

#ifndef FALSE
#define FALSE               0
#endif

#ifndef DWORD
typedef ulong               DWORD;
#endif

#ifndef byte
typedef uchar               byte;
#endif

#ifndef WCHAR
#if defined(__cplusplus)
typedef wchar_t             WCHAR;
#else 
typedef wchar_t             WCHAR;
#endif // __cplusplus
#endif // WCHAR

#define ND_CC               (char*)
#define ND_CCX              (const char*)
#define ND_CB               (byte*)

#ifndef EOL
#define EOL                 '\0'
#endif

#if defined(ND_LINUX) && ! defined(MAXUINT16)
#define MAXUINT16           ((uint16)~(uint16)0))
#endif

#ifndef MAXLONG
#define MAXLONG             0x7fffffff
#endif

#ifndef MAXENTIER
#define MAXENTIER           ((ulong)~((ulong)0))
#endif

#ifndef MAXENTIER32
#define MAXENTIER32         32768
#endif 

#ifndef MAXENTIER64
#define MAXENTIER64         2 * MAXENTIER32
#endif 

#define DIM_LONG            alignof(long) 
#define DIM_WCHAR           sizeof(WCHAR) // = 2 (ie. 16 bits)

#define MILLE_VINGT_QUATRE  1024
#define BYTES_1024          1024UL
#define MEGA_BYTES          BYTES_1024 * BYTES_1024
#define GIGA_BYTES          MEGA_BYTES * BYTES_1024
#define TERA_BYTES          GIGA_BYTES * BYTES_1024

typedef struct _UINT64_STRUCT_
{
    uint32 LowPart; uint32 HighPart; uint64 Value;

} UINT64_STRUCT;

#if ! defined(ND_LINUX)
#include <windows.h>    
#include <process.h>    
#include <winioctl.h>
#include <stdio.h>

#define TC_EVENT                HANDLE
#define TC_SET_EVENT(EVENT)     SetEvent(EVENT)    
#define TC_MUTEX                HANDLE
#define TC_WAIT_OBJECT(OBJ)     WaitForSingleObject(OBJ, INFINITE) 
#define TC_ACQUIRE_MUTEX(MUTEX) WaitForSingleObject(*(MUTEX), INFINITE)
#define TC_RELEASE_MUTEX(MUTEX){ ReleaseMutex(*(MUTEX)); (*MUTEX) = NULL; }
#define ND_TYPE_FILEX           unsigned WINAPI // __stdcall
#define ND_SYNCHRO_VR_INTRL(){ static long verrou = 0; \
        InterlockedIncrement(&verrou); InterlockedDecrement(&verrou); }  

#endif // [!] ND_LINUX

#define DIM_4K                      ulong(4 * BYTES_1024)
#define DIM_8                       8
#define DIM_8K                      ulong(DIM_8 * BYTES_1024)
#define DIM_12K                     ulong(12 * BYTES_1024)
#define DIM_13K                     ulong(13 * BYTES_1024)
#define DIM_16                      16
#define DIM_32                      32
#define DIM_32K                     ulong(DIM_32 * BYTES_1024)
#define DIM_64                      64
#define DIM_256                     256
#define DIM_256K                    ulong(DIM_256 * BYTES_1024)
#define MOINS_UN_HEXA               0xFFFFFFFF // -1.

// For driver:
#ifndef INDEX_WDF_COINSTALLER_INSTALL_OPTIONS 
#define INDEX_WDF_COINSTALLER_INSTALL_OPTIONS 360
#endif 

#ifndef NTSTATUS
#define NTSTATUS                    int
#endif


// Authentication module:
#define UNMOUNT_MAX_AUTO_RETRIES    30
#define UNMOUNT_AUTO_RETRY_DELAY    50
#define MAX_HOST_DRIVE_NUMBER       64
#define MAX_HOST_PARTITION_NUMBER   32
#define ND_SECTOR_SIZE_BIOS         512ULL // NTFS

#define ND_VERSION_ENT�TE           0x0001
#define ND_MIN_VERSION_VOLUME       0x0100

#define ND_DIM_SECTEUR_NTFS         (1UL  * ND_SECTOR_SIZE_BIOS)
#define ND_MAX_VOLUME_SIZE          (13UL * GIGA_BYTES)
#define ND_KEYFILE_SIZE             (20UL * MEGA_BYTES) 
#define MASTER_KEYS_SIZE            DIM_256

#define NDH                         ND_DIM_SECTEUR_NTFS

#ifdef ND_LINUX
#define ALIGN_ADDRESS(x)            alignof(x) // TODO: tester.
#else // See winnt, WDM and FELICS:
#define ALIGN_ADDRESS(x)            DECLSPEC_ALIGN(x) 
#endif

#define MASQUE_CTR                  0xFF // 256-1
#define MASQUE_CRC                  0xffffffff

#ifndef __FILENAME__ // NB: ref�rence cyclique avec TexteCc et Fichier.
#define __FILENAME__ (getNomSansSuffixe(getDernierNom(__FILE__)))
#endif // TODO: int�grer au langage C.

#ifndef RAPPEL
#define RAPPEL CALLBACK
#endif

#endif // COMPATIBILIT_X_SYS