/*
 Copyright (c) 2003-2015 'Fondation TrueCrypt'. All rights reserved.

 Governed by the SCLE License; the full text of which is contained
 in the file Licence 1.0.txt of NetDisq.
 2024-2025.
*/

#include <windows.h>
#include <windef.h>
#include "Constantes.h"
#include "Language.h"
#include "Erreur.h"
#include "Anomalie.h"
#include "ErreurDict.h"


BOOL gSilencErr = FALSE;

void setSilencErr(BOOL b){
    gSilencErr = b;
}

void afficherErreurDict(const char* idTitre, const char* idTexte)
{
    WCHAR* titre = (WCHAR*)(idTitre == NULL ? TITRE_W : GetString(idTitre));
    MessageBoxW(NULL, GetString(idTexte), titre, MB_ICONEXCLAMATION);
}

void afficherErreurDict(const char* idTexte){
    MessageBoxW(NULL, GetString(idTexte), TITRE_W, MB_ICONEXCLAMATION);
}

void afficherErreurDict(const char* idTitre, __in long code, BOOL bForceMsg)
{    
    if (gSilencErr && ! bForceMsg){ return; }
    
    switch (code)
    {    
    case ERR_DRIVER_PAS_D�MARR�_OU_EN_ERREUR:
        Error("ERR_NO_DRIVER");
        break;
    case ERR_INVALID_USER:
        afficherErreurDict(idTitre, "ERR_INVALID_USER");
        break;
    case ERR_MOTPASSE_INVALIDE:
        afficherErreurDict(idTitre, "ERR_MOT_DE_PASSE");
        break;
    case ERR_MPASS_OU_ENT�TE:
        afficherErreurDict(idTitre, "ERR_MOT_DE_PASSE_OU_ENTETE");
        break;
    case ERR_OBJECT_NOT_FOUND:
        afficherErreurDict(idTitre, "ERR_OBJECT_NOT_FOUND");
        break;
    case ERR_FILE_OPEN:
        afficherErreurDict(idTitre, "ERR_OPENFILE");
        break;
    case ERR_FILE_READ:
        afficherErreurDict(idTitre, "ERR_FILE_READ");
        break;
    case ERR_FILE_WRITE:
        afficherErreurDict(idTitre, "ERR_FILE_WRITE");
        break;
    case ERR_OBJECT_SIZE_WRONG:
        afficherErreurDict("ERR_OBJECT_SIZE");
        break;
    case ERR_COMPRESSION_NOT_SUPPORTED:
        afficherErreurDict(idTitre, "ERR_COMPRESSION_NOT_SUPPORTED");
        break;
    case ERR_KEYFILE_NOT_FOUND:
        afficherErreurDict(idTitre, "ERR_KEYFILE_NOT_FOUND");
        break;
    case ERR_CIPHER_INIT_FAILURE:
        afficherErreurDict(idTitre, "ERR_CIPHER_INIT_FAILURE");
        break;
    case ERR_CIPHER_INIT_WEAK_KEY:
        afficherErreurDict(idTitre, "ERR_CIPHER_INIT_WEAK_KEY");
        break;
    case ERR_OBJECT_INIT:
        afficherErreurDict(idTitre, "ERR_OBJECT_INIT");
        break;   
    case ERR_NOUVEAU_DOA:
        afficherErreurDict(idTitre, "ERR_NOUVEAU_DOA");
        break;
    case ERR_ACCESS_DENIED:
        afficherErreurDict(idTitre, "ERR_ACCESS_DENIED");
        break;
    case ERR_SELF_TESTS_FAILED:
        Error("ERR_SELF_TESTS_FAILED");
        break;
    case ERR_MAX_ESPACE_MOT_DE_PASSE:
        afficherErreurDict(idTitre, "ERR_MAX_MOT_DE_PASSE");
        break;
    case ERR_INVALID_INIT:
        afficherErreurDict(idTitre, "ERR_INVALID_INITIALIZATION");
        break;
    case ERR_CHIFFREMENT_INVALIDE:
        afficherErreurDict(idTitre, "ERR_CHIFFREMENT_INVALIDE");
        break;        
    case ERR_AUTHENTIFICATION:
        afficherErreurDict(idTitre, "ERR_AUTHENTIFICATION");
        break;
    case ERR_SYS_FICHIERS_INCERTAIN:
        afficherErreurDict(idTitre, "ERR_ETAT_SYS_FICHIERS");
        break;
    case ERR_ARGUMENT_INVALIDE:
        afficherErreurDict(idTitre, "ERR_ARGUMENT_INVALIDE");
        break;
    case ERR_NO_ETHX_DB:
        afficherErreurDict(idTitre, "ERR_NO_ETHX_DB");
    break;
    case ERR_USER_ABORT: case ERR_DONT_REPORT:
        break; // A non-error.  
    case ERR_MAX_REFS_OBJET:
        Error("ERR_MAX_REFS_OBJET");
        break;
    case ERR_INVALID_FILE:
        Error("ERR_INVALID_FILE");
        break;
    case ERR_OBJET_�_NULL:
        Error("ERR_OBJET_NULL");
        break;      
    
    default: 
        {
            WCHAR szTmp[MAX_LONGUEUR_MSG] = {0};
            if (((code < 0) && (code >= ERR_OBJET_�_NULL)) || (code > 0))
            {
                if (afficherMsgErreurWindows(NULL, code)){ return; }
                else { wsprintfW(szTmp, L"%ls %d.", L"Erreur #", code); }
            } else {
                wsprintfW(szTmp, L"%ls (0x%x).", GetString("ERR_UNKNOWN"), code);
            } 
            MessageBoxW(NULL, szTmp, TITRE_W, MB_ICONEXCLAMATION);
       }
    }
}

void afficherErreurDict(__in long code, BOOL bForceMsg){
    afficherErreurDict(NULL, code, bForceMsg);
}

void traiterErreurDict(__in long code){
    afficherErreurDict(code, FALSE);
}

void traiterErreurDict(const char* idTitre, __in long code){
    afficherErreurDict(idTitre, code, FALSE);
}