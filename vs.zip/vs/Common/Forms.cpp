
/* Copyright(c) 2024-2026 'SCLE-CSES'. More details in the file 
   Licence 1.0.txt included in NetDisq packages (project Common). */

#include "ResourceC.h"
#include "Language.h"
#include "Forms.h"

static HINSTANCE ghInst = NULL; static HCURSOR ghCursor = NULL; 

BOOL IsButtonChecked(HWND hButton){
    return (SendMessage(hButton, BM_GETCHECK, 0, 0) == BST_CHECKED);
}

BOOL GetCheckBox(HWND hwndDlg, int dlgItem){
    return (IsButtonChecked(GetDlgItem(hwndDlg, dlgItem)));
}

void NormalCursor()
{
    static HCURSOR hcNormal = NULL; // TC.
    if (hcNormal == NULL){ hcNormal = LoadCursor(NULL, IDC_ARROW); }
    SetCursor(hcNormal); ghCursor = NULL;
}

void WaitCursor()
{
    static HCURSOR hcWait = NULL; // TC.
    if (hcWait == NULL) { hcWait = LoadCursor(NULL, IDC_WAIT); }
    SetCursor(hcWait); ghCursor = hcWait;
}

HINSTANCE gethInst(){ return ghInst; }


ATOM InitWndClass(HINSTANCE hInstance, WCHAR* szWndClass, WNDPROC wndp)
{
    WNDCLASSEXW wcex = {0}; wcex.cbSize = sizeof(WNDCLASSEX);
    wcex.style = CS_HREDRAW | CS_VREDRAW; WORD idcND = IDM_NETDISQ_EN;
    wcex.lpfnWndProc = wndp; wcex.hInstance = hInstance;
    wcex.cbClsExtra = 0; wcex.cbWndExtra = 0;
    wcex.hCursor = LoadCursor(NULL, IDC_ARROW);
    wcex.hIcon = LoadIcon(hInstance, MAKEINTRESOURCE(IDI_NETDISQ32));    
    if (isLangFr()){ idcND = IDM_NETDISQ_FR; }
    wcex.lpszMenuName = MAKEINTRESOURCEW(idcND);
    wcex.hbrBackground = (HBRUSH)(COLOR_WINDOW);
    wcex.lpszClassName = szWndClass;
    wcex.hIconSm = LoadIcon(wcex.hInstance, MAKEINTRESOURCE(idcND));
    return RegisterClassExW(&wcex);
}

HWND InitWndInstance(HINSTANCE hInstance, WCHAR szWndClass[],
                    int nCmdShow, WCHAR finTitre[])
{  
   ghInst = hInstance; WCHAR szTitle[DIM_256] = {0}, titre[DIM_256] = {0};
   LoadStringW(hInstance, IDS_TITRE_APP, szTitle, MAX_LOADSTRING);
   wsprintfW(titre, L"%ls [%ls]", szTitle, (finTitre ? finTitre : L""));
   HWND hWnd = CreateWindowW(szWndClass, titre, WS_OVERLAPPEDWINDOW,
      CW_USEDEFAULT, 0, 800, 600, NULL, NULL, hInstance, NULL);
   if (hWnd){ ShowWindow(hWnd, nCmdShow); } return hWnd;
}

// TODO: expliquer le contexte d'utilisation en mode commande.
LPARAM RAPPEL DialoguAide(HWND hFrm, UINT message, WPARAM wp, LPARAM lp)
{
    UNREFERENCED_PARAMETER(lp); int wmId = LOWORD(wp);
    switch (message)
    {

    case WM_INITDIALOG: { return (LPARAM)TRUE; }

    case WM_COMMAND:
    {
        if ((wmId == IDOK) || (wmId == IDCANCEL)){
            EndDialog(hFrm, wmId); return (LPARAM)TRUE;
        }
    }
    }
    return (LPARAM)FALSE;
}

LRESULT ListItemAdd(HWND list, int index, WCHAR txt[])
{
    LVITEM li; memset(&li, 0, sizeof(li));
    li.mask = LVIF_TEXT; li.pszText = txt; li.iItem = index;
    li.iSubItem = 0; return ListView_InsertItem(list, &li);
}

void AddComboItem(HWND hComboBox, char txt[])
{
	LPARAM nIndex = SendMessageA(hComboBox, CB_FINDSTRINGEXACT, (WPARAM) - 1, 
        (LPARAM)txt); if (nIndex == CB_ERR && *txt)
    {
		nIndex = SendMessageA(hComboBox, CB_ADDSTRING, 0, (LPARAM)txt);
        SendMessageA(hComboBox, CB_SETITEMDATA, nIndex, (LPARAM)txt);
	}
    if (nIndex != CB_ERR && *txt){
        nIndex = SendMessage(hComboBox, CB_SETCURSEL, nIndex, 0);
    }
}