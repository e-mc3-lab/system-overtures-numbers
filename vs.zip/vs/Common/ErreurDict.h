/*
 Copyright (c) 2003-2015 'Fondation TrueCrypt'. All rights reserved.

 Governed by the SCLE License; the full text of which is contained in
 the file Licence 1.0.txt included in NetDisq distribution packages.
 2023-2025.
*/
#ifndef ERREUR_DICT_H
#define ERREUR_DICT_H

#include "Erreur.h"
#include "MessageDict.h"

void setSilencErr(BOOL b);
void afficherErreurDict(const char* idTexte);
void afficherErreurDict(__in LONG code, BOOL bForceMsg);

/**
* PRE: appeler ces m�thodes avant journaliser qui modifie gNDR�sultat. TODO.
*/
void traiterErreurDict(__in LONG code);
void traiterErreurDict(const char* idTitre, __in LONG code);

#endif // ERREUR_DICT_H