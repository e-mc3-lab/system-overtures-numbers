/**
 *  @auteurs Microsoft, TrueCrypt et SCLE/CSES.
 */
#ifdef TC_WINDOWS_DRIVER 
   #include "Driver.h" 
#else 
   #include "Langage.h"
   #include <tchar.h> 
#endif   
#include <windows.h>
#include <strsafe.h>
#include "Memoire.h"
#include "TexteCc.h"

#pragma warning(disable:4018)
#pragma warning(disable:4995)

// using namespace NetDisq;
 
 // NB: variables � usage unique, temporaire et final.
char gTxtTravailA[MAX_CC] = {0}; WCHAR gTxtTravailW[MAX_CC] = {0};

char* getMessage(const char format[], const char txt[])
{
    const ENTIER N = STRLEN(format) + (txt != NULL ? STRLEN(txt) : 0) + 1;
    if (format){ formaterA(ND_CC gTxtTravailA, 
        min(N, sizeof(gTxtTravailA)), format, txt); } return gTxtTravailA;
}

int ConvertToMBCSa(const WCHAR txt[], char r�sultat[], ENTIER cchDst);
int ConvertToMBCSb(const WCHAR txt[], int cchSrc, char r�sultat[], int cchDst);

/** 
 * Provient de WSDK et TrueCrypt (LPWSTR = WCHAR* [UNICODE]). Voir aussi 
 * mbstowcs. NB: pour les params. 'const...' ou 'c_str', utiliser constEnWCHAR.
 */
WCHAR* convEnWCHARMax(const char txt[], int n) 
{ 
    ENTIER Na = STRLEN_CB(txt, (n == 0 ? MAX_PATH : MAX_CC)), Nb = (Na + 1) * 2;
    WCHAR* nouvTxt = NULL; if ( ! txt || (txt[0] == EOL)){ return NULL; }
    if ((n > 0) && (Nb > n))
    {
        char msg[MAX_PATH] = {0}; formaterA(msg, MAX_PATH, 
            "convEnWCHARMax:\nla longueur de 'txt' est invalide (%d).", n);
        printf(msg); return NULL;
    }
    nouvTxt = (WCHAR*)NDAllouer(Nb);
    MultiByteToWideChar(CP_ACP, 0L, txt, (int)(Nb), nouvTxt, (int)(Na+1));
    StringCbCopyW(gTxtTravailW, MAX_CC, nouvTxt);
    NDFree(nouvTxt); return gTxtTravailW;
}

WCHAR* convEnWCHAR(const char txt[]){ return convEnWCHARMax(txt, 0); }

/*
 * Provient de common.cpp (SDK).
 */ 
int ConvertToMBCSa(const WCHAR txt[], char r�sultat[], ENTIER cchDst){ 
    return ConvertToMBCSb(txt, -1, r�sultat, (int)cchDst);
}

int ConvertToMBCSb(const WCHAR txt[], int cchSrc, char r�sultat[], int cchDst)
{
    int cchWritten = 0; if (r�sultat == NULL){ return 0; }
    if ( ! txt && r�sultat)
    {   // Convenience for the caller: always make sure 
        // the result is null-terminated - if there is enough room.
        if (cchDst >= 1)
        {
            r�sultat[0] = EOL; return 1;
        }
        return 0;
    }
    // Convert the string to MBCS.
    cchWritten = WideCharToMultiByte(CP_ACP, 0, txt, 
        cchSrc/*cch*/, r�sultat, cchDst/*cb*/, NULL, NULL);

    // Since the buffer we passed in may be smaller than the actual data returned
    // we may not actually get to copy the NULL terminator, so make sure there is 
    // one at least at the end of the buffer...
    if (cchDst && (cchDst < cchSrc))
    {
        cchWritten = cchDst; r�sultat[cchWritten-1] = EOL;
    }
    return cchWritten;
}

/*****************************************************************************
  SBCS: Single Byte Character String. Auteurs de la 'Fondation TrueCrypt'.org.
  ***************************************************************************/
char* convEnSBCS(const WCHAR txt[], uint16 Mx) // PRE: Mx <= MAX_CC.
{
    ENTIER j; if ( ! txt){ return NULL; } j = wcsnlen_s(txt, Mx-3);
    if (j == 0)
    {
        strcpy_s(ND_CC(txt), 3, ND_CCX("...")); return ND_CC(txt);
    } else {
        j = WideCharToMultiByte(CP_ACP, 0L, txt, -1, gTxtTravailA,
            (int) j + 1, NULL, NULL);
        if (j == 0){ strcpy_s(gTxtTravailA, 3, "..."); }
    }
    return gTxtTravailA;
}

/**
 * De LPCSTR � char* : faire simplement un cast (char*). PRE: Mx <= MAX_CC.
 */
char* convEnCCHAR(const WCHAR txt[], uint16 Mx){ return convEnSBCS(txt, Mx); }

char* trim(const char txt[]) // PRE: longueur(txt) <= MAX_CC.
{    
    char* r�sultat = gTxtTravailA; int i = 0; ENTIER lnTxt = 0, N = 0;
    init0(gTxtTravailA, MAX_CC); if ( ! txt || (txt[0] == EOL)){ return NULL; }
    lnTxt = STRLEN_CB(txt, MAX_CC - 1); if (lnTxt == 0){ return gTxtTravailA; }
    strncpy(gTxtTravailA, txt, lnTxt); // D�but
    while ((txt[i] != EOL) && ((txt[i] == ' ') ||
        (txt[i] == '\t') || (txt[i] == '\n'))){ i++; }
    N = lnTxt - i; if (i > 0)
    { 
        memmove_s(r�sultat, lnTxt, &txt[i], N); r�sultat[N] = EOL;
    } 
    // Fin
    for (i = (int)N-1; i >= 0 && ((txt[i] == ' ') || (txt[i] == '\t') || 
        (txt[i] == '\n') || (txt[i] == '\r')); i--){ r�sultat[i] = EOL; } 
    return r�sultat;
}

WCHAR* trimW(WCHAR txt[], uint16 Mx){ 
    return convEnWCHARMax(trim(convEnCCHAR(txt, Mx)), Mx); }

char* constEnCCHAR(const WCHAR txt[], uint16 Mx)
{
    const uint16 M = sizeof(gTxtTravailA);
    ENTIER j = wcsnlen_s(txt, min(M-1, Mx)); const ENTIER N = min(j, M); 
    init0(gTxtTravailA, M); if ( ! txt){  return NULL; } 
    gTxtTravailA[M-1] = EOL; if (j > 0){ ConvertToMBCSa(txt, gTxtTravailA, j); }
    return gTxtTravailA;
}

WCHAR* constEnWCHAR(const char txt[]) 
{
    const ENTIER N = min(STRLEN(txt), sizeof(gTxtTravailA));
    const ENTIER M = min(N, sizeof(gTxtTravailA)-1); gTxtTravailA[M] = EOL;
    if (txt){ strncpy_s(gTxtTravailA, N, txt, M); }
    return convEnWCHAR(gTxtTravailA);
}

// @return le nom de fichier sans suffixe (suivant un '.' ou '-').
char* getNomSansSuffixe(const char nf[])
{
    const char* rechS�par; ENTIER ln = STRLEN(nf), ls, i; if (nf == NULL){ 
        return NULL; } strncpy_s(gTxtTravailA, sizeof(gTxtTravailA), nf, min(ln,
        sizeof(gTxtTravailA))); rechS�par = strrchr(nf, '.'); if (rechS�par){ 
        ls = STRLEN(rechS�par), i = ln - ls; gTxtTravailA[i] = EOL;
    } else {
        rechS�par = strrchr(gTxtTravailA, '-'); if (rechS�par)
        {   // TODO: � r�essayer car non test� suite � un changement.
            i = STRLEN(gTxtTravailA) - STRLEN(rechS�par); gTxtTravailA[i] = EOL;
        } else { gTxtTravailA[0] = EOL; } } return gTxtTravailA;
}

char* convEnMinuscules(const char txt[])
{
    const ENTIER N = STRLEN(txt); int i; if (N >= MAX_CC)
    {
        char msg[MAX_PATH] = {0}; formaterA(msg, MAX_PATH, "convEnMinuscules:"
            "\nla longueur de 'txt' ne doit pas d�passer %d.", MAX_CC);
        printf(msg); return NULL;
    }
    gTxtTravailA[N] = EOL; for (i=0; i < N; i++){
        gTxtTravailA[i] = (char) tolower(txt[i]);
    }
    return gTxtTravailA;
}

char* convEnMajuscules(const char txt[])
{
    const ENTIER N = STRLEN(txt); int i; 
    if (N >= MAX_CC)
    {
        char msg[MAX_PATH] = {0}; formaterA(msg, MAX_PATH, "convEnMajuscules:"
            "\nla longueur de 'txt' ne doit pas d�passer %d.", MAX_CC);
        printf(msg); return NULL;
    }
    for (i=0; i < N; i++){ gTxtTravailA[i] = (char) toupper(txt[i]); }
    gTxtTravailA[N] = EOL; return gTxtTravailA;
}

BOOL estEnMajuscules(const char txt[])
{
    const ENTIER N = STRLEN(txt); for (ENTIER i=0; i < N; i++)
    {
        if (txt[i] != (char)toupper(txt[i])){ return FALSE; }
    } return TRUE;
}

char* d�calerGauche(char txt[], int len, int targetLen, char filler)
{
    int i; if (targetLen <= len){ return txt; } for (i = targetLen-1; 
    i >= (targetLen-len); i--){ txt[i] = txt[i-(targetLen-len)]; }
    memset(txt, filler, int(targetLen-len)); txt[targetLen] = EOL; 
    return txt;
}

/**
 * @return the address of the first occurrence of str in txt.
 * Otherwise, NULL if str is not found.
 */
const char* chercherTexte(const char txt[], uint64 dimTxt, 
    const char str[], uint64 dimStr)
{
    if ( ! txt || ! str || (dimTxt < 1) || (dimStr < 1) ||
        (dimStr > dimTxt)){ return NULL; } return strstr(txt, str);
}

BOOL commencePar(const char txt[], const char prfx[])
{
    return (txt && prfx ? (strncmp(txt, prfx, STRLEN(prfx)) == 0) : FALSE);
}

BOOL seTerminePar(const char txt[], const char sufx[])
{
    BOOL r�sultat = FALSE; char v�riTxt[MAX_PATH] = {0}; 
    ENTIER M = STRLEN(sufx), N = STRLEN(txt) - M;
    if (txt && (N > 0) && (N < MAX_PATH))
    {
        memcpy(v�riTxt, (txt + N), M); v�riTxt[M] = EOL;
        r�sultat = (sufx ? (_strcmpi(v�riTxt, sufx) == 0) : FALSE);
    }
    return r�sultat;
}

void ajouterGuillemetD�but(char txt[], __in ENTIER dimTab)
{
    if ((txt != NULL) && ! commencePar(txt, TXT_GUILLEMET))
    {
        ENTIER N = STRLEN(txt); if (N < dimTab)
        {
            memmove_s(&txt[1], N, txt, N); txt[0] = CAR_GUILLEMET;
        }
    }
}

void ajouterGuillemetFin(char txt[], __in ENTIER dimTab)
{
    if ((txt != NULL) && ! seTerminePar(txt, TXT_GUILLEMET))
    {
        if (STRLEN(txt) < dimTab){ strcat(txt, TXT_GUILLEMET); }
    }
}

void mettreEntreGuillemets(char txt[], __in ENTIER dimTab)
{
    ajouterGuillemetD�but(txt, dimTab); ajouterGuillemetFin(txt, dimTab);
}

BOOL estVide0(const byte tab[], uint64 n, uint8 pourcentSignificatif)
{
    uint M = (pourcentSignificatif * uint(n))/100;
    for (uint i = 0, j = 0; i < n; i++){
        if (tab[i] == EOL){ j++; if (j >= M){
            return (((i+DIM_32)%DIM_256) + DIM_32); }}
    } return FALSE;
}

BOOL estVide100(const byte tab[], uint64 n){ return estVide0(tab, n, 100); }

void setNonVide(byte tab[], uint n, BOOL bCodUtil, BOOL bModPasse)
{
    byte s; uint8 M = (bModPasse ? 0x20 : 0x00); for (uint i = 0; i < n; i++)
    {
        s = tab[i]; if ((s >= 0x00) && (s <= M)){
            tab[i] = byte(i + M + 1); } if (bCodUtil && (s >= 0x80)
                && (s <= 0xA0)){ tab[i] = byte(tab[i] + DIM_32); }
    }
}

char* remplacerMot(char txt[], uint max, const char motA[], const char motB[])
{
    ENTIER i = 0, NB = STRLEN(motB); char* rech = strstr(txt, motA); 
    if (rech){ i = STRLEN(txt) - STRLEN(rech); } if (i > 0)
    {
        char* finTxt = gTxtTravailA; strcpy(finTxt, 
            ND_CC(txt + i + STRLEN(motA)));
        if ((i + NB) < max){ strcpy(txt + i, motB); } else { return NULL; }
        memcpy(txt + i + NB, finTxt, STRLEN(finTxt));
    } else { return NULL; }
    return txt;
}

#ifndef _CONSOLE

void GetSizeString(__in uint64 size, __in WCHAR str[])
{
    static const WCHAR *b, *kb, *mb, *gb, *tb, *pb; static int serNo;
    if (b == NULL){
        kb = KB; mb = MB; gb = GB; tb = TB; pb = GB; b = TC_BYTE;
    }
    if (size > 1024I64*1024*1024*1024*1024*99){
        formaterW(str, MAX_PATH, L"%I64d %s", 
            double(size/1024/1024/1024/1024/1024), pb);
    } else if (size > 1024I64*1024*1024*1024*1024){
        formaterW(str, MAX_PATH, L"%.1f %s", 
            double(size/1024.0/1024/1024/1024/1024), pb);
    } else if (size > 1024I64*1024*1024*1024*99){
        formaterW(str, MAX_PATH, L"%I64d %s",size/1024/1024/1024/1024, tb);
    } else if (size > 1024I64*1024*1024*1024){
        formaterW(str, MAX_PATH, L"%.1f %s", 
            double(size/1024.0/1024/1024/1024), tb);
    } else if (size > 1024I64*1024*1024*99){
        formaterW(str, MAX_PATH, L"%I64d %s",size/1024/1024/1024, gb);
    } else if (size > 1024I64*1024*1024){
        formaterW(str, MAX_PATH, L"%.1f %s", 
            double(size/1024.0/1024/1024), gb);
    } else if (size > 1024I64*1024*99){
        formaterW(str, MAX_PATH, L"%I64d %s", size/1024/1024, mb);
    } else if (size > 1024I64*1024){
        formaterW(str, MAX_PATH, L"%.1f %s", double(size/1024.0/1024), mb);
    } else if (size >= 1024I64){
        formaterW(str, MAX_PATH, L"%I64d %s", size/1024, kb);
    } else {
        formaterW(str, MAX_PATH, L"%I64d %s", size, b);
    }
}

void GetSpeedString(__in uint64 speed, __in WCHAR str[])
{
    static const WCHAR *b, *kb, *mb, *gb, *tb, *pb; if (b)
    {
        b  = B_PER_SEC;  kb = KB_PER_SEC; mb = MB_PER_SEC;
        gb = GB_PER_SEC; tb = TB_PER_SEC; pb = PB_PER_SEC;
    }
    if (speed > 1024I64*1024*1024*1024*1024*99){
        formaterW(str, MAX_PATH, L"%I64d %s", 
            speed/1024/1024/1024/1024/1024, pb);
    } else if (speed > 1024I64*1024*1024*1024*1024){
        formaterW(str, MAX_PATH, L"%.1f %s", 
        double(speed/1024.0/1024/1024/1024/1024), pb);
    } else if (speed > 1024I64*1024*1024*1024*99){
        formaterW(str, MAX_PATH, L"%I64d %s",speed/1024/1024/1024/1024, tb);
    } else if (speed > 1024I64*1024*1024*1024){
        formaterW(str, MAX_PATH, L"%.1f %s", 
        double(speed/1024.0/1024/1024/1024), tb);
    } else if (speed > 1024I64*1024*1024*99){
        formaterW(str, MAX_PATH, L"%I64d %s", speed/1024/1024/1024, gb);
    } else if (speed > 1024I64*1024*1024){
        formaterW(str, MAX_PATH, L"%.1f %s", 
        double(speed/1024.0/1024/1024), gb);
    } else if (speed > 1024I64*1024*99){
        formaterW(str, MAX_PATH, L"%I64d %s", speed/1024/1024, mb);
    } else if (speed > 1024I64*1024){
        formaterW(str, MAX_PATH, L"%.1f %s", (double)(speed/1024.0/1024), mb);
    } else if (speed > 1024I64){
        formaterW(str, MAX_PATH, L"%I64d %s", speed/1024, kb);
    } else {
        formaterW(str, MAX_PATH, L"%I64d %s", speed, b);
    }
}

#endif // ! _CONSOLE