
#ifndef COMMON_SORTIE_H
#define COMMON_SORTIE_H

#include "CompatibX.h"
#include "Constantes.h"

#ifdef __cplusplus
extern "C" {
#endif

#define PRFX_CHEMIN_MN        "\\??\\"

#define UNIT�_INSTALL         "C:/" 
#define SCLE_DONN�ES          TEXT(UNIT�_INSTALL) TEXT(SCLE) L"/" \
                              TEXT(DOSSIER_DONN�ES)

#define NOM_FICHIER_SORTIE    "cmdresult"
#define NOM_FICHIER_SORTIE_W  TEXT(NOM_FICHIER_SORTIE)
#define NOM_FICHIER_JOURNAL   "journal.txt"
#define MOT_ERREUR            "Erreur"

#define R�SULTAT_PROGRESSION  "PROGRS="
#define N_R�SULTAT_PROGRES    33

extern char gMessageErrSys[]; 

void setD�laiApr�s�criture(int secondes); BOOL sontMessagesDiff�r�s();
void diff�rerMessages(BOOL b, int64 nbSecondesAvantMaj);
void journaliser(const char format[], ...);
void Quitter(const char lettreVolume[], int code);
void QuitterF(const char lettreVolume[], int code, BOOL sortieFichier);


#ifdef TC_WINDOWS_DRIVER // (M)ode (N)oyau [Kernel Mode].

#define C_SCLE_DONN�ES        TEXT(PRFX_CHEMIN_MN) SCLE_DONN�ES

#else // (M)ode (U)tilisateur [User Mode].

#define C_SCLE_DONN�ES        SCLE_DONN�ES

void setNomFichierSortie(const char nf[]); // Mettre � NULL pour d�sactiver.
char* getChemNomFichierSortie(); void setCodeSortie(BOOL �tat);
int �crireFichierSortie(const char contenu[]);
void set�crireInfosExtra(BOOL b);
void setSautDeLigne(BOOL b);
void supprimerFichierSortie();
void supprimerFichierSortieF(char cnf[]);
int nettoyer(FILE* fichier);
void AbortProcessSilent(void); // Quitter (le programme) sans �criture.
void journaliserW(const WCHAR txt[]);
void ajouterNLSiMultiple(const int i, const uint N);
void journaliserTabHexa(const char tab[], const uint N, 
    BOOL bS�parVirgule, uint M);

void �crireProgression(int n, BOOL viaCmd);
LONG lir�tatDriver(); void supprimer�tatDriver();
uint getEstampille();
void TCSleep(int milliSeconds);

#ifndef TCAttendre 
  #define TCAttendre TCSleep                    
#endif

#endif // [!] TC_WINDOWS_DRIVER

#define CHEM_JOURNAL          C_SCLE_DONN�ES

#ifdef __cplusplus
}
#endif 

#endif     // COMMON_SORTIE_H
