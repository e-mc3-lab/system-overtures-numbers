/**
 *  @auteurs TrueCrypt et SCLE.
 */
#ifndef MESSAGE_DICTIONNAIRE_H
#define MESSAGE_DICTIONNAIRE_H

#include "Message.h"

#define YES_NO MB_YESNO

#ifdef __cplusplus
extern "C" {
#endif




int Info(const char stringId[]);
int InfoTopMost(const char stringId[]);
int Warning(const char stringId[]);
int Error(const char stringId[]);
int ErrorTopMost(const char stringId[]);
int AskYesNo(const char stringId[]);
int AskYesNoTopmost(const char stringId[]);
int AskNoYes(const char stringId[]);
int AskOkCancel(const char stringId[]);
int AskWarnYesNo(const char stringId[]);
int AskWarnYesNoTopmost(const char stringId[]);
int AskWarnYesNoStringTopmost(const WCHAR string[]);
int AskWarnNoYes(const char stringId[]);
int AskWarnNoYesTopmost(const char stringId[]);
int AskWarnOkCancel(const char stringId[]);
int AskWarnCancelOk(const char stringId[]);
int AskErrYesNo(const char stringId[]);
void AbortProcess(const char stringId[]);

#ifdef __cplusplus
}
#endif // __cplusplus

#endif // MESSAGE_DICTIONNAIRE_H