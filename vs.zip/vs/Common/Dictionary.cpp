/*
 Copyright (c) 2003-2015 'Fondation TrueCrypt'. All rights reserved.

 Governed by the SCLE License; the full text of which is contained in 
 the file Licence 1.0.txt included in NetDisq distribution packages.
 2024-2026.
*/

#include <map>
#include <string>
#include "Dictionary.h"

using namespace std;

static map<string, void *> StringKeyMap;
static map<int, void *> IntKeyMap;

static void *gDataPool = NULL;
static size_t gDataPoolSize = 0;

void AddDictionaryEntry(char* key, int intKey, void* value)
{
    if (key){
        StringKeyMap[key] = value;
    }
    if (intKey != 0){
        IntKeyMap[intKey] = value;
    }
}

void* GetDictionaryValue(const char* key)
{
    map<string, void *>::const_iterator i = StringKeyMap.find(key);    
    if (i == StringKeyMap.end()){
        return NULL;
    }
    return i->second;
}

void* GetDictionaryValueByInt(int intKey)
{
    map<int, void *>::const_iterator i = IntKeyMap.find(intKey);

    if (i == IntKeyMap.end()){
        return NULL;
    }
    return i->second;
}

void* AddPoolData(void *data, size_t dataSize)
{
    if (gDataPoolSize + dataSize > DATA_POOL_CAPACITY){ return NULL; }

    if (gDataPool == NULL)
    {
        gDataPool = (void*)malloc(DATA_POOL_CAPACITY);
        if (gDataPool == NULL){ return NULL; }
    }
    memcpy((byte*)gDataPool + gDataPoolSize, data, dataSize);

    // Ensure 32-bit alignment for next entries
    dataSize = (dataSize + 3) & (~(size_t)3);

    gDataPoolSize += dataSize; 
    return (byte*)gDataPool + gDataPoolSize - dataSize;
}

void ClearDictionaryPool ()
{
    if (gDataPool){ free(gDataPool); gDataPool = NULL; } gDataPoolSize = 0;
    StringKeyMap.clear(); IntKeyMap.clear();
}