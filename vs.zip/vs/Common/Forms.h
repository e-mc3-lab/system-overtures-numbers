/*
 Copyright(c) 2024-2026 'SCLE-CSES'. More details in the file Licence 1.0.txt. */

#ifndef COMMON_FORMS
#define COMMON_FORMS

#include "CompatibX.h"
#include <CommCtrl.h>

#define MAX_LOADSTRING 100

BOOL IsButtonChecked(HWND hButton); BOOL GetCheckBox(HWND hwndDlg, int dlgItem);
void NormalCursor(); void WaitCursor(); HINSTANCE gethInst();
ATOM InitWndClass(HINSTANCE hInstance, WCHAR* szWndClass, WNDPROC wndp);
HWND InitWndInstance(HINSTANCE hInstance, WCHAR szWndClass[], int nCmdShow,
    WCHAR finTitre[]);

LPARAM RAPPEL DialoguAide(HWND hFrm, UINT message, WPARAM wp, LPARAM lp);
LRESULT ListItemAdd(HWND list, int index, WCHAR txt[]);
void AddComboItem(HWND hComboBox, char txt[]);


#endif // COMMON_FORMS