/*
 Copyright (c) 2003-2015 'Fondation TrueCrypt'. All rights reserved.
 Governed by the NetDisq License 1.0. SCLE: 2024-2025. 
*/
#ifndef MEMOIRE_H
#define MEMOIRE_H

#include "CompatibX.h"
#include "Erreur.h"
#include "Journal.h"

#ifdef __cplusplus
extern "C" {
#endif

#define ND_TAG_MEM      (ulong)'CMDN'

#ifndef NDInit0
#define NDInit0(m, dim) init0(&m, dim)
#endif

typedef enum _TypeAdresse
{
    M�MOIRE, R�F�RENCE, FILEX, REQU�TE_ES

} TypeAdresse;

 #ifdef TC_WINDOWS_DRIVER
   #include <ntddk.h>
#endif

NTSTATUS NDV�riRefsOubli�es(BOOL bInitCompteur); 
BOOL yaTilDesRequ�tESNonR�solues();
   
#define init0 safErase64

#define CHECK_MEMORY(p){\
    if ( ! (p) ){ MessageBoxA(NULL, "Erreur d'allocation",\
        "M�moire", MB_ICONHAND); }}

#ifndef init0
  #define init0(mem, size) \
    if (mem){ memset(mem, 0, size); }  
#endif

void* safe_malloc(ENTIER n, const char nomModule[], uint noLigne); 
void* safe_malloc0(ENTIER n, const char nomModule[], uint noLigne);
void* safe_malloc0M(ENTIER n, const char nomModule[], uint noLigne, uint max);

#ifndef NDAllouer

  #define NDAllouer(N)              (safe_malloc(N, __FILE__, __LINE__))
  #define NDAllouer0(N)             (safe_malloc0(N, __FILE__, __LINE__))
  #define NDAllouer0M(N, M)         (safe_malloc0M(N, __FILE__, __LINE__, M))  
  #define NDAllouer0LM(N, NM, L, M) (safe_malloc0M(N, NM, L, M))  
  #define NDAllouer0NM(N, NM, L)    (safe_malloc0(N, NM, L))   
  
#endif

int safe_free(void** mem);

void setNDDrivErreur(int code);

#ifndef NDFree
  #define NDFree(m) \
  { \
      if ( ! safe_free((void**)&m)){ \
          setNDDrivErreur(ERR_REFS_M�MOIRE_NON_LIB�R�ES); \
      } \
  }
#endif

#ifndef NDFree0
  #define NDFree0(m, dimMem) \
  { \
      safErase64((void*)m, dimMem); if ( ! safe_free((void**)&m)) \
      { \
          setNDDrivErreur(ERR_REFS_M�MOIRE_NON_LIB�R�ES); goto ERR_MEM; \
      } \
  }
#endif

int comparerMem(const void* a, const void* b, uint64 n, BOOL bJournal);

void safErase64(void* mem, const uint64 dim);

NTSTATUS copierM�moire(void* dest, const void* src, __in ENTIER n);

#define ND_COPIER_MEM_TABLE(DEST, SRC, N) \
{ \
    NTSTATUS r = copierM�moire(DEST, 0, SRC, N); ND_ASSERT_S(r); \
}

#define ND_COPIER_M�MOIRE(DEST, SRC, N) \
{ \
    NTSTATUS r = copierM�moire(DEST, 0, SRC, N); ND_ASSERT_S(r); \
}

#ifdef _JOURAMEM 
  #define journaliserRM(format, ...){ \
    journaliser(format, __VA_ARGS__); \
  }
#else 
  #define journaliserRM(format, ...){ }
#endif

#ifdef __cplusplus
}
#endif

#endif // MEMOIRE_H