/**
 *  @auteurs Truecrypt et SCLE. TODO: convertir en 'C' standard.
 */
#include <io.h>
#include <shlobj.h>
#include <strsafe.h>
#include "Message.h"
#include "TexteCc.h"
#include "TextHexa.h"
#include "Fichier.h"
#include "Sortie.h"

#define MAX_CODE_MSG 100

const WCHAR R�SULTAT_MONTAGE[] = L"DLETTRE=";
const WCHAR R�SULTAT_ACTION[]  = L"CODE=";

static char gCnfSortie[MAX_PATH] = {0};
char gNomFichierSortie[MAX_CODE_MSG] = {0};
char gMessage[MAX_LONGUEUR_MSG] = {0};
BOOL bSortieFichierCode = FALSE, bInfosExtra = TRUE, bNL = TRUE;

void setNomFichierSortie(const char nfs[])
{
    gCnfSortie[0] = EOL; strcpy_s(gNomFichierSortie, MAX_CODE_MSG, nfs);
}

/**
 * @return le chemin complet du fichier de sortie (g�n�ralement cmdresult).
 * Celui-ci se trouve dans le m�me dossier que le programme.
 */
char* getChemNomFichierSortie()
{
    if (gNomFichierSortie[0] == EOL) {
        setNomFichierSortie(NOM_FICHIER_SORTIE);
    }
    if (gCnfSortie[0] == EOL)
    {
        char* r�sultat = gCnfSortie; uint N; char* cp = getCheminProgramme();
        strcpy(r�sultat, cp); N = UI16_STRLEN(r�sultat)-1;
        if ((r�sultat[N] != CAR_S�PAR_DIR) && // Ajouter un s�parateur � 
            ((N+1) < sizeof(gNomFichierSortie))){ // la fin si inexistant.
            r�sultat[N+1] = CAR_S�PAR_DIR;
        }  
        strcat_s(r�sultat, MAX_CODE_MSG, gNomFichierSortie); return r�sultat;
    } else { return gCnfSortie; }
}

/**
  * �crire ou non la date, l'heure et un saut de ligne.
  */
void set�crireInfosExtra(BOOL b){
    bInfosExtra = b;
}

void setSautDeLigne(BOOL b){
    bNL = b;
}

void setCodeSortie(BOOL �tat){
    bSortieFichierCode = �tat;
}

HANDLE ouvrirFichierSortieB(char rnf[], 
    DWORD dispositionCr�ation, DWORD flagsAndAttr)
{     
    HANDLE r�sultat = NULL;
    if ((dispositionCr�ation != CREATE_ALWAYS) && existe(rnf)){
        dispositionCr�ation = OPEN_EXISTING;
    } else {
        r�sultat = CreateFileA(rnf, ACC�S_LECTURE_�CRITURE,
            MODE_PARTAG�, NULL, CREATE_ALWAYS, 0, NULL);
    } 
    SetFileAttributesA(rnf, FILE_ATTRIBUTE_NORMAL); if ( ! r�sultat)
    {
        r�sultat = CreateFileA(rnf, ACC�S_LECTURE_�CRITURE, MODE_PARTAG�, 
            NULL, dispositionCr�ation, flagsAndAttr, NULL);
    }
    if (r�sultat == INVALID_HANDLE_VALUE){ r�sultat = NULL; } return r�sultat;
}

BOOL �crireFichierSortieB(const char txt[], DWORD dispositionCr�ation, 
                          DWORD flagsAndAttr)
{     
    boolean r�sultat = TRUE; char* cnfs = NULL; HANDLE file = NULL;
    if (STRLEN(gNomFichierSortie) == 0){
        setNomFichierSortie(NOM_FICHIER_SORTIE);
    }
    cnfs = getChemNomFichierSortie(); if ( ! cnfs){ return FALSE; }    
    file = ouvrirFichierSortieB(cnfs, dispositionCr�ation, flagsAndAttr);
    if (file)
    {
        DWORD bytesWritten; SetFilePointer(file, 0, NULL, FILE_END);
        if ( ! WriteFile(file, txt, (DWORD)STRLEN(txt), &bytesWritten, NULL)) {
            r�sultat = FALSE;
        }
    } else { r�sultat = FALSE; } fermerFichier(&file); return r�sultat;
}

BOOL �crireFichierSortie(const char txt[]){        
    return �crireFichierSortieB(txt, CREATE_ALWAYS, FLAGS_ET_ATTRIBUTS);
}

void supprimerFichierSortieF(char cnf[]) { supprimerFichier(cnf); }

void supprimerFichierSortie()
{
    char* rnfs = getChemNomFichierSortie(); supprimerFichierSortieF(rnfs);
}

BOOL nettoyer(FILE* fichier)
{
    HANDLE hf = (HANDLE) _get_osfhandle(_fileno(fichier));        
    fflush(fichier); if (hf == INVALID_HANDLE_VALUE){ return FALSE; }
    return (FlushFileBuffers(hf) != 0);
}

void AbortProcessSilent(void){ Quitter(NULL, ANNULATION); }

// Appeler la commande Sleep. 
void TCSleep(int milliSeconds){ Sleep(milliSeconds); }

void �crireProgression(int n, BOOL viaCmd)
{         
    char texte[N_R�SULTAT_PROGRES] = {0};
    sprintf_s(texte, N_R�SULTAT_PROGRES, "%s%d\n", R�SULTAT_PROGRESSION, n);
    if ( ! viaCmd) // Pas � partir de commande.exe?
    {    
        fflush(stdout); fprintf(stdout, "%s", texte);
    }
    setNomFichierSortie(NOM_FICHIER_SORTIE); 
    if ( ! �crireFichierSortie(texte)){ supprimerFichierSortie(); }
}

BOOL sontMessagesDiff�r�s(){ return FALSE; }

void diff�rerMessages(BOOL b, int64 nbSecondesAvantMaj){ journaliser(""); }

void setD�laiApr�s�criture(int secondes){}

void journaliser(const char format[], ...)
{     // PRE: ne pas passer gNDR�sultat,
      char* txt = gMessage; ENTIER N = MAX_LONGUEUR_MSG; 
      va_list liste; if (STRLEN(format) == 0){ return; } 
      memset(gMessage, 0, N); va_start(liste, format); // parfois = 0.
      StringCchVPrintfA(gMessage, N, format, liste); ND_SYNCHRO_VR_INTRL();
      { 
          SYSTEMTIME st = {0}; char texte[MAX_LONGUEUR_MSG+50] = {0};
          GetLocalTime(&st); if (bInfosExtra){
              sprintf_s(texte, N-10, "%04d-%02d-%02d %02d:%02d:%02d %s\n",
                st.wYear, st.wMonth, st.wDay, st.wHour, st.wMinute,
                st.wSecond, txt);
          } else {
              char format[10] = "%s"; if (bNL){ strcat(format, NL); }
              sprintf_s(texte, N-10, format, txt);
          }
          if (STRLEN(gNomFichierSortie) == 0){
              setNomFichierSortie(NOM_FICHIER_JOURNAL);
          }
          �crireFichierSortieB(texte, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL);
      }
      va_end(liste);
}

void journaliserW(const WCHAR txt[])
{
    const uint16 N = MAX_LONGUEUR_MSG; WCHAR txtW[MAX_LONGUEUR_MSG] = {0};
    wcscpy_s(txtW, N, txt); journaliser(convEnCCHAR(txtW, N));
}

void ajouterNLSiMultiple(const int i, const uint N)
{
    if ((i > 0) && ((i+1) % N == 0)){ journaliser(NL); }
}

void journaliserTabHexa(const char tab[], const uint N,
                        BOOL bS�parVirgule, uint M)
{
    uint i; const char* formatTxt = (bS�parVirgule ? "0x%02x, " : "\\x%02x");
    char* tmp = (char*)malloc(N); memcpy(tmp, tab, N);
    set�crireInfosExtra(FALSE); setSautDeLigne(FALSE); for (i=0; i < N; i++)
    {
        journaliser(formatTxt, (byte)tmp[i]); ajouterNLSiMultiple(i, M);
    }
    journaliser("\n\n"); free(tmp);
}

long lir�tatDriver()
{
    long r�sultat = ERROR_SUCCESS; char cnf[MAX_PATH] = {0}; HANDLE file = NULL;
    sprintf_s(cnf, MAX_PATH, "%ls%s", CHEM_JOURNAL, NOM_FICHIER_SORTIE);
    file = ouvrirFichierSortieB(cnf, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL);
    if (file)
    {
        DWORD nbLus = 0; char txt[DIM_16] = {0};
        SetFilePointer(file, 0, NULL, FILE_BEGIN);
        if (ReadFile(file, txt, (DWORD) DIM_8, &nbLus, NULL) && 
            (nbLus == DIM_8)){
            r�sultat = (long)getValeurHexa8((const byte*)txt);
        }
    }
    fermerFichier(&file); return r�sultat;
}

void supprimer�tatDriver()
{
    char cnf[MAX_PATH] = {0}; sprintf_s(cnf, MAX_PATH, "%ls%ls", CHEM_JOURNAL,
        NOM_FICHIER_SORTIE_W); supprimerFichier(cnf);
}

/**
 * PRE: La longueur de lettreVolume ne doit pas d�passer 3.
 *
 * @param code est une valeur entre 0 et 50. 0: ANNUL� 1: CONFORME >=2: ERREUR.
 */
void Quitter(const char lettreVolume[], int code)
{    
    QuitterF(lettreVolume, code, bSortieFichierCode);
}

// @param sortieFichier devrait �tre � TRUE quand il y a une �l�vation.
//
void QuitterF(const char lettreVolume[], int code, BOOL sortieFichier)
{    
    int i = 0; char* r�sultat = NULL; WCHAR* str = NULL; int N = MAX_CODE_MSG;
    char msg[15] = "", codeR�sultat[10] = "", msgA[MAX_CODE_MSG] = {0};
    BOOL sortieF = sortieFichier; sprintf_s(msgA, N, "Sortie: %d", code);
    if (lettreVolume != NULL)
    {
        sortieF = FALSE; /* Pas d'UAC */ if (code == 1)
        {
            str = (WCHAR*) R�SULTAT_MONTAGE;
            if (lettreVolume != NULL)
            {
                for (i=0; i < sizeof(codeR�sultat); i++)
                {
                    if (lettreVolume[i] != EOL){
                        codeR�sultat[i] = lettreVolume[i];
                    } else { 
                        break; // Sortir.
                    }
                }
            } else { codeR�sultat[0] = EOL; }
        }
    } else {        
        str = (WCHAR*) R�SULTAT_ACTION;
        if (code < 0)
        { 
            codeR�sultat[0] = '-'; codeR�sultat[1] = '1';
        } else {
            int i = (code / 10);
            if (i < 1){
                codeR�sultat[0] = (char)code + '0';
            } else {
                int j = (code % 10);
                codeR�sultat[0] = (char)i + '0';
                codeR�sultat[1] = (char)j + '0';
            }
        }
    }

    if (str != NULL) for (i=0; ; i++)
    {
        if (str[i] != 0){ msg[i] = (char) str[i]; } else { break; }
    }
    {
        char r�sultat[MAX_CODE_MSG] = {0};
        sprintf_s(r�sultat, MAX_CODE_MSG, "%s%s\n", msg, codeR�sultat);
        fprintf(stdout, "%s", r�sultat); if (sortieF)
        {
            strcpy_s(gNomFichierSortie, MAX_CODE_MSG, NOM_FICHIER_SORTIE);
            gCnfSortie[0] = EOL;
            if ( ! �crireFichierSortie(r�sultat)){ supprimerFichierSortie(); }
        } 
    }
}

uint getEstampille()
{
    const char* tab = __TIMESTAMP__; const ENTIER DIM_TAB = STRLEN(tab);
    uint r = 0; for (int i = 0; i < DIM_TAB; i++){ r += tab[i]; } return r;
}