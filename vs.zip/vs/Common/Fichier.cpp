/*
 Legal Notice: Modifications and additions to the original source code
 (contained in this file) and all other portions of this file are
 Copyright (c) 2003-2013 'Fondation Truecrypt' and are governed 
 by the SCLE License; the full text of which is contained in the 
 file Licence 1.0.txt included in NetDisq distribution packages. */

#include <string.h>
#include <errno.h>
#include <io.h>
#include <stdio.h>
#include <direct.h>
#include <sys/stat.h>
#include "Constantes.h"
#include "Erreur.h"
#include <commctrl.h>
#include "Memoire.h"
#include "Langage.h"
#include "TexteCc.h"
#include "Journal.h"
#include "Fichier.h"

int makedirInterne(const char path[]);

static char gChemProgramme[MAX_PATH] = {0}, gChemin[MAX_PATH] = {0},
    gChemNomFichier[MAX_PATH] = {0}; // NB: � usage unique (final).

/* Create full directory tree. returns 0 for success, -1 if failure */
int cr�erDossiers(const char chemin[], BOOL bVerifSeulement)
{
    struct _stat st = {0}; char* uniq_file; char chem[MAX_PATH] = {0};
    strcpy_s(chem, MAX_PATH, chemin);
    if ((STRLEN_CB(chem, MAX_PATH) == 3) && (chem[1] == ':')){
        ND_FIN(); /* Keep final slash in root if present. */
    }
    /* Strip final forward or backslash if we have one. */
    uniq_file = strrchr(chem, CAR_S�PAR_DIR);
    if (uniq_file && (uniq_file[1] == EOL)){
        uniq_file[0] = EOL;
    } else {

        uniq_file = strrchr(chem, CAR_S�PAR_DIR);
        if (uniq_file && (uniq_file[1] == EOL)){
            uniq_file[0] = EOL;
        }
    }
FIN: if (bVerifSeulement){ return _stat(chem, &st); }
     if (_stat(chem, &st)){
         return makedirInterne(chem);
     } else {
         return 0;
     }
}
// TODO: autant que possible, utiliser des fonctions 'C' standards.

int makedirInterne(const char chem[])
{
    char* jeton = NULL; struct _stat st = {0};
    static char chemin[MAX_PATH] = {0}, trajet[MAX_PATH] = {0};
    strcpy_s(chemin, MAX_PATH, chem); trajet[0] = EOL;
    jeton = strtok(chemin, S�PAR_DIR);
    if ((chemin[0] == CAR_S�PAR_DIR) && (chemin[1] == CAR_S�PAR_DIR))
    {    // U (Windows) Naming Convention (UNC).
        trajet[0] = chemin[0]; trajet[1] = chemin[1]; trajet[2] = EOL;
        strcat_s(trajet, MAX_PATH, jeton); strcat(trajet, S�PAR_DIR);
        jeton = strtok(NULL, S�PAR_DIR); if (jeton)
        {
            strcat(trajet, jeton); strcat(trajet, S�PAR_DIR);
        }
        jeton = strtok(NULL, S�PAR_DIR);
    }
    if (chemin[1] == ':')
    {    // Drive letter.
        strcat(trajet, chemin); strcat(trajet, S�PAR_DIR);
        jeton = strtok(NULL, S�PAR_DIR);
    }
    while (jeton)
    {
        int x; strcat(trajet, jeton);
        x = _mkdir(trajet); strcat(trajet, S�PAR_DIR);
        jeton = strtok(NULL, S�PAR_DIR);
    }
    return _stat(chem, &st);
}

char* getCheminProgramme()
{
    if (gChemProgramme[0] == EOL)
    {
        char chemin[MAX_PATH]; char* rechS�par; // MC: en cours/courant.
        GetModuleFileNameA(NULL, chemin, sizeof(chemin));
        strcpy_s(gChemProgramme, MAX_PATH, chemin);
        rechS�par = strrchr(gChemProgramme, CAR_S�PAR_DIR);
        if (STRLEN(rechS�par) > 1){ // Mettre un caract�re de fin
            rechS�par[1] = EOL; // apr�s le dernier s�parateur.
        }
    }
    return gChemProgramme;
}

void setCheminProgramme(const char chem[])
{
    ENTIER N = MAX_PATH, M = STRLEN(chem);
    N = (M < N - 1 ? M : N - 1); gChemProgramme[N] = EOL;
    if (M > 0){ strncpy(gChemProgramme, chem, sizeof(gChemProgramme)); }
}

char* getChemRelatif2Absolu(const char nf[])
{
    char* r�sultat = NULL; if (nf == NULL){ return NULL; }
    if ((nf[0] != CAR_S�PAR_DIR) && (strchr(nf, ':') == 0) &&
        (strstr(nf, MOT_VOLUME "{") != nf))
    {
        init0(gChemin, sizeof(gChemin));
        r�sultat = gChemin; GetCurrentDirectoryA(MAX_PATH, r�sultat);
        if (r�sultat[STRLEN(r�sultat) - 1] != CAR_S�PAR_DIR){
            strcat_s(r�sultat, MAX_PATH, S�PAR_DIR);
        }
        strcat_s(r�sultat, MAX_PATH, nf);
    }
    return r�sultat;
}

char* getCheminFichier(const char cnf[], BOOL ajouterGuillemetFinSiD�but)
{
    char* v�riFin = NULL; if ( ! cnf){ return NULL; }
    init0(gChemin, sizeof(gChemin)); strcpy(gChemin, cnf);
    v�riFin = strrchr(gChemin, CAR_S�PAR_DIR);
    if (gChemin && v�riFin)
    { 
        ENTIER i = STRLEN(gChemin) - STRLEN(v�riFin);
        gChemin[i] = CAR_S�PAR_DIR; gChemin[i+1] = EOL;
        if (ajouterGuillemetFinSiD�but &&
            commencePar(gChemin, TXT_GUILLEMET) &&
            ! seTerminePar(gChemin, TXT_GUILLEMET)){
                strcat(gChemin, TXT_GUILLEMET);
        }
    } else {
        journaliser("Le r�pertoire %s\nne doit contenir que "
            "des s�parateurs valides.", cnf); 
        init0(gChemin, sizeof(gChemin));
    }
    return gChemin;
}

char* getChemNomFichier(const char nf[])
{
    strcpy(gChemNomFichier, getCheminProgramme()); if (nf){
        strcat_s(gChemNomFichier, 
            STRLEN(gChemNomFichier) + STRLEN(nf) + 1, nf);
    }
    return gChemNomFichier;
}


char* getDernierNom(const char chemin[])
{
    char* r�sultat = NULL; ENTIER N = STRLEN(chemin);
    if (N == 0){ return NULL; }
    r�sultat = supprimerS�parSiTermine(chemin);
    r�sultat = strrchr(r�sultat, CAR_S�PAR_DIR); if (r�sultat)
    {
        r�sultat = &gChemin[N - STRLEN(r�sultat)];
        if (r�sultat[0] == CAR_S�PAR_DIR){ r�sultat++; }
    } return r�sultat;
}

char* supprimerS�parSiTermine(const char chemin[])
{
    ENTIER i, N = STRLEN(chemin); if (N == 0){ return NULL; }
    i = N-1; init0(gChemin, N); strcpy(gChemin, chemin);
    if ((gChemin[i] == CAR_S�PAR_DIR) || 
        (gChemin[i] == CAR_S�PAR_WEB)){ gChemin[i] = EOL; }
    return gChemin;
}


BOOL StatRemoveDirectory(const char lpszDir[])
{
    struct __stat64 st = {0};
    return (_stat64(lpszDir, &st) == 0) ? RemoveDirectoryA(lpszDir) : TRUE;
}

/**
 * Checks whether the file extension is not used for executable files or 
 * similarly problematic, or again just invalid for a given context.
 */
BOOL estSuffixeFichierValide(const char cnf[])
{
    int i = 0; char* ext = NULL; char tabSufxFichiers[][6] = 
    {   // These are protected by the OS resource. 
        ".asa", ".asp", ".aspx", ".ax", ".bas", ".bat", ".bin", ".cer", ".chm",
        ".clb", ".cmd", ".cnt", ".cnv", ".com", ".cpl", ".cpx", ".crt", ".csh", 
        ".dll", ".drv", ".dtd", ".exe", ".fxp", ".grp", ".h1s", ".hlp", ".hta", 
        ".ime", ".inf", ".ins", ".isp", ".its", ".js", ".jse", ".ksh", ".lnk", 
        ".mad", ".maf", ".mag", ".mam", ".man", ".maq", ".mar", ".mas", ".mat",
        ".mau", ".mav", ".maw", ".mda", ".mdb", ".mde", ".mdt", ".mdw", ".mdz",
        ".msc", ".msi", ".msp", ".mst", ".mui", ".nls", ".ocx", ".ops", ".pal", 
        ".pcd", ".pif", ".prf", ".prg", ".pst", ".reg", ".scf", ".scr", ".sct", 
        ".shb", ".shs", ".sys", ".tlb", ".tsp", ".url", ".vb", ".vbe", ".vbs", 
        ".vsma", ".vss", ".vst", ".vsw", ".ws", ".wsc", ".wsf", ".wsh", ".xsd",
        ".xsl", ".rpm", ".deb", // Additional file extensions:
        ".386", ".acm", ".ade", ".adp", ".ani", ".app", ".asd", ".asf", ".asx", 
        ".awx", ".ax", ".boo",  ".bz2", ".cdf", ".clas", ".dhtm", ".dlo", ".eml",
        ".flt", ".fot", ".gz",  ".hlp", ".ini", ".j2k", ".jar", ".jff", ".jif",
        ".jmh", ".jng", ".jp2", ".jpe", ".jpeg", ".jpg", ".lsp", ".mod", ".nws",
        ".obj", ".olb", ".osd", ".ov1", ".ov2", ".ov3", ".ovl", ".ovl", ".ovr",
        ".pdr", ".pgm", ".php", ".pkg", ".pl", ".png", ".pps", ".ppt", ".ps1",
        ".ps1x", ".psc1", ".py", ".rar", ".rpl", ".rtf", ".sbf", ".scri", ".sh", 
        ".sha", ".shtm", ".shtm", ".spl", ".swf", ".tar", ".tgz", ".tmp", ".ttf", 
        ".vcs", ".vlm", ".vxd", ".vxo", ".wiz", ".wll", ".wmd", ".wmf",  ".wms", 
        ".wmz", ".wpc", ".wsc", ".wsh", ".wwk", ".xl", ".zip", ".7z", ".tif", 
        ".lib", ".gam", ".nd" };
    
    if ( ! cnf){ return FALSE; } init0(gChemin, sizeof(gChemin)); 
    const int N_SUFX = sizeof(tabSufxFichiers) / 6; strcpy(gChemin, cnf); 
    ext = strrchr(gChemin, '.');
    if ( ! ext){ return TRUE; } while (tabSufxFichiers[i] && (i < N_SUFX))
    {
        if (_stricmp(ext, tabSufxFichiers[i++]) == 0){ return FALSE; }
    }
    return TRUE;
}

int existe(const char cnf[]) // TC: may be in quotations.
{
    char cheminFichier[MAX_PATH] = {0}; ENTIER N;
    if (cnf[0] == '"'){ // Supprimer le 1er guillemet (si pr�sent).
        strcpy_s(cheminFichier, MAX_PATH, cnf + 1);
    } else {
        strcpy_s(cheminFichier, MAX_PATH, cnf);
    }    
    N = STRLEN(cheminFichier); // Supprimer le dernier guillemet (si pr�sent).
    if ((N > 0) && (cheminFichier[N-1] == '"')){ cheminFichier[N-1] = EOL; }
    return (_access(cheminFichier, 0) >= 0);
}

BOOL estEnUtilisation(const char cnf[])
{
    HANDLE v�rif = NULL; if (cnf == NULL){ return FALSE; }
    v�rif = CreateFileA(cnf, GENERIC_READ | 
        GENERIC_WRITE, MODE_PARTAG�, NULL, OPEN_EXISTING, 0, NULL);    
    if (v�rif != INVALID_HANDLE_VALUE){
        CloseHandle(v�rif);
    } else if (GetLastError() == ERROR_SHARING_VIOLATION){
        return TRUE;
    } return FALSE;
}

BOOL FileHasReadOnlyAttribute(const char chemin[])
{
    DWORD attributes = GetFileAttributesA(chemin);
    return attributes != INVALID_FILE_ATTRIBUTES && 
        ((attributes & FILE_ATTRIBUTE_READONLY) != 0);
}

BOOL estEnLectureSeule(const char chemin[])
{
    char chem0[MAX_PATH] = {0}; DWORD flags, d;

    if ( ! GetVolumePathNameA(chemin, chem0, sizeof(chem0))){
        return FALSE;
    }    
    if ( ! GetVolumeInformationA(chem0, NULL, 0,  NULL, &d, &flags, NULL, 0)){
        return FALSE;
    }
    return (flags & FILE_READ_ONLY_VOLUME) ? TRUE : FALSE;
}

DWORD getTailleFichier(HANDLE fh){ return GetFileSize(fh, NULL); }
// More standard: fseek(fichier, 0, SEEK_END); dimF = ftell(fichier);

/**
 * If bAppend is TRUE, the text is appended to an existing file. If bAppend is 
 * FALSE, any existing file is replaced. If an error occurs, the incomplete file 
 * is deleted (provided that bAppend is FALSE). Anciennement writebuffertofile.
 */
BOOL �crireContenu(const char cnf[], const char txt[], 
                  DWORD inputLength, BOOL bAppend) 
{
    BOOL r�sultat = TRUE; HANDLE dst; DWORD bytesWritten;
    dst = CreateFileA(cnf, GENERIC_WRITE, FILE_SHARE_READ |  
        FILE_SHARE_WRITE, NULL, bAppend ? OPEN_EXISTING : CREATE_ALWAYS, 0, NULL);
    if (dst == INVALID_HANDLE_VALUE)
    {
        journaliser("Le fichier %s est invalide.", cnf); return FALSE;
    }
    if (bAppend){ SetFilePointer(dst, 0, NULL, FILE_END); }
    if ( ! WriteFile(dst, txt, inputLength, &bytesWritten, NULL) || 
        (inputLength != bytesWritten)){ r�sultat = FALSE; }
    if ( ! r�sultat)
    {   // Successful overwrite of an existing file is not an error.
        if ( ! (GetLastError() == ERROR_ALREADY_EXISTS && ! bAppend) ){
            ;//  traiterErreurWindows();
        }
    }
    CloseHandle(dst); if ( ! r�sultat && ! bAppend){ /*remove(gChemNomFichier);*/ }
    return r�sultat;
}

/** 
 * System copies source file attributes (like FILE_ATTRIBUTE_ENCRYPTED).
 */
BOOL copierContenu(const char cnfSrc[], char* cnfDst)
{
    BOOL r�sultat; int8 *tab; HANDLE hSrc, hDst; FILETIME fileTime;
    DWORD bytesRead, bytesWritten; const int N = MEGA_BYTES / 2;
    hSrc = CreateFileA(cnfSrc, GENERIC_READ,
        FILE_SHARE_READ | FILE_SHARE_WRITE, NULL, OPEN_EXISTING, 0, NULL);
    if (hSrc == INVALID_HANDLE_VALUE){ return FALSE; }
    hDst = CreateFileA(cnfDst, GENERIC_WRITE, 0, NULL, CREATE_ALWAYS, 0, NULL);
    if (hDst == INVALID_HANDLE_VALUE)
    {
        CloseHandle(hSrc); return FALSE;
    }
    tab = (char*)NDAllouer0(N); if ( ! tab)
    {
        CloseHandle(hSrc); CloseHandle(hDst); return FALSE;
    } 
    while (r�sultat = ReadFile(hSrc, tab, N, &bytesRead, NULL))
    {
        if (bytesRead == 0)
        {
            r�sultat = 1; break;
        }
        if ( ! WriteFile(hDst, tab, bytesRead, &bytesWritten, NULL) || 
            bytesRead != bytesWritten)
        {
            r�sultat = 0; break;
        }
    }    
    GetFileTime(hSrc, NULL, NULL, &fileTime);
    SetFileTime(hDst, NULL, NULL, &fileTime);
    CloseHandle(hSrc); CloseHandle(hDst); NDFree(tab); return r�sultat != 0;
}

BOOL copierFichier(const char cnfSrc[], const char cnfDst[]){
    return CopyFileA(cnfSrc, cnfDst, FALSE);
}

BOOL supprimerFichier(const char cnf[])
{
    struct __stat64 st = {0}; 
    return (_stat64(cnf, &st) == 0) ? DeleteFileA(cnf) : 
        (existe(cnf) ? FALSE : TRUE);
}

BOOL supprimerFichier0(const char cnf[]){
    return supprimerFichier0D(NULL, cnf);
}

BOOL supprimerFichier0D(HWND hwProgsBar, const char cnf[])
{
    BOOL r�sultat = TRUE; byte* tab0; HANDLE hf = NULL; DWORD nb�crit;
    const int N = MEGA_BYTES; hf = CreateFileA(cnf, GENERIC_WRITE,
        FILE_SHARE_READ | FILE_SHARE_WRITE, NULL, OPEN_EXISTING, 0, NULL);
    if (hf == INVALID_HANDLE_VALUE){ return FALSE; }
    ulong dim = GetFileSize(hf, NULL); const DWORD M = dim / N, R = dim % N;
    tab0 = (byte*)NDAllouer0(N); if ( ! tab0)
    {
        CloseHandle(hf); return FALSE;
    }     
    if (hwProgsBar){ SendMessage(hwProgsBar, PBM_SETRANGE32, 1, M); }
    nb�crit = N; // TODO: ajouter plusieurs it�rations ?
    for (ENTIER i = 0; i < M; i++)
    {
        if ( ! WriteFile(hf, tab0, nb�crit, &nb�crit, NULL) || (nb�crit != N))
        {
            r�sultat = FALSE; break;
        }
        if (hwProgsBar){ SendMessage(hwProgsBar, PBM_SETPOS, i, 0); }
    }
    if (R > 0)
    {
        nb�crit = R;
        if ( ! WriteFile(hf, tab0, nb�crit, &nb�crit, NULL) || (nb�crit != R)){
            r�sultat = FALSE;
        }
    }
    CloseHandle(hf); NDFree(tab0); supprimerFichier(cnf); return r�sultat;
}

BOOL renommerFichier(const char cnfSrc[], const char cnfDst[])
{
    BOOL r�sultat = CopyFileA(cnfSrc, cnfDst, TRUE);
    if (r�sultat){ r�sultat = supprimerFichier0(cnfSrc); } return r�sultat;
}

BOOL estDossierVide(const char cnd[], const char sufx[])
{ 
    BOOL r = TRUE; WIN32_FIND_DATAA findData; 
    sprintf(gChemNomFichier, "%s*%s", cnd, sufx);
    HANDLE find = FindFirstFileA(gChemNomFichier, &findData);
    if (find != INVALID_HANDLE_VALUE){ r = FALSE; }
    else { CloseHandle(find); } return r;
}

void fermerFichier(HANDLE* fh){ if (fh && *fh){ CloseHandle(*fh); *fh = NULL; }}