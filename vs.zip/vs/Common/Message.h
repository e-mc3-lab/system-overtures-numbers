#ifndef ND_MESSAGE_H
#define ND_MESSAGE_H

#include "CompatibX.h"


#ifdef __cplusplus
extern "C" {
#endif

int afficherInfo(const WCHAR txt[]);
int afficherAttention(const  WCHAR txt[]);
int afficherErreur(const WCHAR txt[]);
int poserQuestionOuiNon(const WCHAR txt[]);
int poserQuestionAttentionOuiNon(const WCHAR txt[]);
int poserQuestionAttentionNonOui(const WCHAR txt[]);

#ifdef __cplusplus
}
#endif


#endif // ND_MESSAGE_H