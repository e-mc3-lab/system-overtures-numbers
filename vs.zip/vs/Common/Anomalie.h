/*
 Copyright (c) 2003-2014 'Fondation TrueCrypt'. All rights reserved.

 Governed by the SCLE License 1.0, the full text of which is contained in
 the file Licence.txt included in Netdisq source and binary code distribution.
*/
#ifndef TC_HEADER_ANOMALIE
#define TC_HEADER_ANOMALIE

#include "Constantes.h"

#define MAX_MSGEX   4 * MAX_PATH

#define CK_CALLBACK_FUNCTION(RET_TYPE, NAME) RET_TYPE (* NAME)

static BOOL afficherMsgErreurWindows(HWND parent, DWORD err) // ���~TC
{
    WCHAR txtMsg[MAX_MSGEX] = {0}; int dimTab = MAX_MSGEX;
    if (FormatMessageW(FORMAT_MESSAGE_FROM_SYSTEM, NULL, err,
        MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT), // Default language.
        txtMsg, dimTab, NULL))
    {
        MessageBoxW(parent, txtMsg, TITRE_W, MB_ICONEXCLAMATION); return TRUE;
    } return FALSE;
}

static void afficherMsgErreur(HWND parent, const WCHAR txt[]){
    MessageBoxW(parent, txt, TITRE_W, MB_ICONERROR | MB_SETFOREGROUND);
}

// using namespace NetDisq;

struct Exception
{
    virtual void Show (HWND parent) const = 0;
};

struct SystemException : public Exception
{
    SystemException () : ErrorCode (GetLastError()) { }

    void Show (HWND parent) const
    {
        SetLastError(ErrorCode);
        afficherMsgErreurWindows(parent, ErrorCode);
    }

    DWORD ErrorCode;
};

#define throw_sys_if(condition) \
    do { if (condition) throw SystemException(); } while (false)

#endif // TC_HEADER_ANOMALIE