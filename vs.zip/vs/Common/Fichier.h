/**
 *  @auteurs TrueCrypt et SCLE.
 */
#ifndef FICHIER_H
#define FICHIER_H

#include "CompatibX.h"

#define ACC�S_LECTURE           GENERIC_READ
#define ACC�S_LECTURE_�CRITURE  GENERIC_READ | GENERIC_WRITE
#define MODE_PARTAG�            FILE_SHARE_READ | FILE_SHARE_WRITE
#define FLAGS_ET_ATTRIBUTS      FILE_ATTRIBUTE_HIDDEN   | \
                                FILE_ATTRIBUTE_READONLY | \
                                FILE_ATTRIBUTE_SYSTEM
#ifdef __cplusplus
extern "C" {
#endif

#define C_USERS_PUBLIC          L"C:\\Users\\Public\\" 

#define CAR_S�PAR_WIN           '\\' 
#define CAR_S�PAR_DIR           CAR_S�PAR_WIN
#define S�PAR_WIN               "\\" // TODO: changer si Linux, ou
#define S�PAR_DIR               S�PAR_WIN // ajouter #if def(ND_LINUX)
 
#define CAR_S�PAR_WEB           '/'
#define S�PAR_WEB               "\\/"

#ifndef MAX_PATH
#define MAX_PATH                260
#endif

#ifndef TC_WINDOWS_DRIVER
    
char* getCheminFichier(const char cnf[], BOOL ajouterGuillemetFinSiD�but);
// Cr�er tous les dossiers inexistants faisant partie de chemin (mkdir).
int cr�erDossiers(const char chemin[], BOOL bVerifSeulement);
// MC: current folder, dossier courant, en cours.
char* getCheminProgramme(); void setCheminProgramme(const char chem[]);
char* getChemRelatif2Absolu(const char nomFichier[]);
char* getChemNomFichier(const char nf[]);
// PRE: chemin est une variable instanci�e (non une constante).
char* getDernierNom(const char chemin[]);
char* supprimerS�parSiTermine(const char chemin[]);

BOOL StatRemoveDirectory(const char lpszDir[]);
BOOL estSuffixeFichierValide(const char cnf[]);
int existe(const char cnf[]); int estEnUtilisation(const char cnf[]);
BOOL FileHasReadOnlyAttribute(const char chemin[]);
BOOL estEnLectureSeule(const char chemin[]); DWORD getTailleFichier(HANDLE fh);
BOOL �crireContenu(const char cnf[], const char txt[], DWORD inputLength, 
    BOOL bAppend); int copierContenu(const char cnfSrc[], char* cnfDst);
// NB: l'ordre des param�tres est invers� (contrairement � la coutume).
BOOL copierFichier(const char cnfSrc[], const char cnfDst[]);
BOOL supprimerFichier(const char cnf[]);
BOOL supprimerFichier0(const char cnf[]);
BOOL supprimerFichier0D(HWND hwProgsBar, const char cnf[]);
BOOL renommerFichier(const char cnfSrc[], const char cnfDst[]);
BOOL estDossierVide(const char cnd[], const char sufx[]);
void fermerFichier(HANDLE* fh);

#endif // ! TC_WINDOWS_DRIVER

#ifdef __cplusplus
}
#endif 

#endif // FICHIER_H