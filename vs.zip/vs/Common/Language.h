/*
 Copyright (c) 2003-2015 'Fondation TrueCrypt'. All rights reserved.

 Governed by the SCLE License; the full text of which is contained in
 the file Licence 1.0.txt included in NetDisq distribution packages.
 2024-2025.
*/

#ifndef COMMON_LANGUAGE_H
#define COMMON_LANGUAGE_H

#include <windows.h>

#define LANG_ID_FR          "fr"
#define LANG_ID_EN          "en"
#define LANG_ID_ES          "es"

#define IDL_ENCRYPT         "IDC_ENCRYPT"
#define IDL_DECRYPT         "IDC_DECRYPT"
#define IDL_CREATE          "IDT_CREATE"
#define IDL_CANCEL          "IDCANCEL"
#define IDL_FERMER          "IDFERMER"

#ifdef __cplusplus
extern "C" {
#endif

__if_not_exists(Font)
{
    typedef struct
    {
        WCHAR *FaceName; int Size;

    } Font;
}

BOOL LoadLanguageFile(); void UnloadLanguageFile();
WCHAR* GetString(const char id[]); Font* GetFont(char fontType[]);
BOOL isLangFr(); BOOL isLangEn(); BOOL isLangEs();
void SetPrfxLangId(const char id[]);

#ifdef __cplusplus
}
#endif

#endif // COMMON_LANGUAGE_H