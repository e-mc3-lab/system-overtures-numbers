/*
 Copyright (c) 2003-2013 'Fondation TrueCrypt'. All rights reserved.

 Governed by the SCLE License; the full text of which is contained in 
 the file Licence 1.0.txt included in NetDisq distribution packages. 
 SCLE: 2025-2026.
*/
#ifndef ND_COMMON_REGISTRE_H
#define ND_COMMON_REGISTRE_H

#ifdef  __cplusplus
extern "C" {
#endif

#define DISPLAY_NAME            "DisplayName" 
#define GROUP                   "Group" 
#define DEPEND_ON_SERVICE       "DependOnService" // =FltMgr
#define DESCRIPTION             "Description" 

#define POLICIES                "Policies\\"
#define ENABLE_LUA              "EnableLUA"

#define MICROSOFT               "Microsoft\\"
#define WINDOWS                 "Windows\\" 
#define CURRENT_VERSION         "CurrentVersion\\"
#define SHELL                   "Shell\\"
#define START                   "Start"
#define WOW_6432_NODE           "Wow6432Node\\"
#define SOFTWARE                "Software\\"
#define CLASS                   "Class\\"
#define SOFTWARE_CLASSES        SOFTWARE "Classes\\"
#define SYSTEM                  "System\\" 
#define CONTROL_SET_SANS_SEPAR  "ControlSet"
#define CONTROL_SET             CONTROL_SET_SANS_SEPAR "\\"
#define CURRENT_CONTROL_SET     "CurrentControlSet\\"
#define SERVICE                 "Service\\"
#define SERVICES                "Services\\"
#define DRIVERS                 "drivers\\" 
#define ENUM_ROOT               "Enum\\Root\\"
#define CONTROL                 "Control\\"
#define MODIFY_PATH             "ModifyPath"
#define CLASSES                 "Classes\\"
#define MOUNT_MANAGER           "MountMgr"
#define UNINSTALL               "Uninstall"

BOOL ReadLocalMachineRegistryStringNonReflected(const char *subKey, 
    char *name, char *str, DWORD *size);
BOOL getLocalMachineRegistryDword(const char subKey[], const char name[], 
    DWORD *value);
BOOL getLocalMachineRegistryMultiString(const char subKey[], 
    const char name[], const char value[], DWORD *size);
BOOL setLocalMachineRegistryMultiString(const char subKey[], 
    const char name[], const char multiString[], DWORD size);
BOOL getLocalMachineRegistryString(const char subKey[], const char name[], 
    const char value[], DWORD *size);
BOOL setLocalMachineRegistryString(const char subKey[], const char name[],
    const char str[], BOOL expandable);
BOOL deleteLocalMachineRegistryKey(const char parentKey[], 
    const char subKeyToDelete[]);
BOOL getLocalMachineRegistryStringNonReflected (const char subKey[], 
    const char name[], const char str[], DWORD *size);
BOOL setLocalMachineRegistryDword(const char subKey[], const char name[],
    DWORD value);
char* getRegistryString(const char subKey[], const char name[], 
    const char defaultValue[], int maxLen);
void setRegistryString(const char subKey[], const char name[], 
    const char str[]);
int getRegistryInt(const char subKey[], const char name[], int defaultValue);
void setRegistryInt(const char subKey[], const char name[], int value);
DWORD getRegistryBytes(const char path[], const char name[], 
    const char value[], int maxLen);
BOOL setRegistryBytes(const char path[], const char name[], 
    const char str[], DWORD size);
void deleteRegistryValue(const char subKey[], const char name[]);
char* getStartupRegKeyName();

#ifdef  __cplusplus
}
#endif 

#endif // ND_COMMON_REGISTRE_H