/**
 *  @auteurs: TrueCrypt et SCLE.
 */
#include <string.h>

#ifndef TC_WINDOWS_DRIVER
#include <ShlObj.h>
#include <winerror.h>
#include "Constantes.h" 
#include "Message.h"
#include "Register.h"
#include "Erreur.h"
#include "Langage.h" // TODO

#define CL� TEXT(SYSTEM) TEXT(CURRENT_CONTROL_SET) TEXT(SERVICE) \
        TEXT(MOUNT_MANAGER)

 /**
 * PRE: � usage unique (final).
 *
 * C'est � dire inutilisable une deuxi�me fois comme argument � une fonction, 
 * si un pr�c�dent s'en sert d�j�. S'applique surtout aux variables globales 
 * dans TexteCc.
 */
char gErrCha�neTravail[MILLE_VINGT_QUATRE] = {0};

void traiterErreurUnit�NonDisponible()
{
    HKEY hkey = 0; DWORD value = 0, size = sizeof(DWORD);
    if (RegOpenKeyEx(HKEY_LOCAL_MACHINE, CL�, 0, KEY_READ, 
        &hkey) != ERROR_SUCCESS){ return; }

    if (RegQueryValueExW(hkey, L"NoAutoMount", 0, 0, (LPBYTE) &value,
        &size) == ERROR_SUCCESS && value != 0){
        afficherAttention(SYS_AUTOMOUNT_DISABLED);
    } else {
        afficherAttention(DEVICE_NOT_READY_ERROR);
    }
    RegCloseKey(hkey);
}

BOOL estDisqueEnErreur(DWORD code){
    return estErreurLectureDisque(code) || estErreur�critureDisque(code);
}

BOOL estErreurLectureDisque(DWORD code)
{
    return (code == ERROR_CRC || code == ERROR_IO_DEVICE ||
        code == ERROR_BAD_CLUSTERS || code == ERROR_SECTOR_NOT_FOUND ||
        code == ERROR_READ_FAULT || code == ERROR_SEM_TIMEOUT ||
        code == ERROR_INVALID_FUNCTION  ); // From certain chipset drivers.
}

BOOL estErreur�critureDisque(DWORD code)
{
    return (code == ERROR_IO_DEVICE || code == ERROR_BAD_CLUSTERS ||
        code == ERROR_SECTOR_NOT_FOUND || code == ERROR_WRITE_FAULT ||
        code == ERROR_SEM_TIMEOUT) || code == ERROR_INVALID_FUNCTION;    
}

char* getErreurWindows(DWORD code)
{    
    gErrCha�neTravail[0] = EOL;
    if (FormatMessageA(FORMAT_MESSAGE_FROM_SYSTEM, NULL, code, 0, // Id langue.
        gErrCha�neTravail, sizeof(gErrCha�neTravail), NULL)) {
        SetLastError(code); // Preserve the original error code.
    } return gErrCha�neTravail;
}

DWORD traiterErreurWindows()
{
    DWORD r�sultat = GetLastError(); BOOL Silent = FALSE;
    if (Silent || (r�sultat == 0) || (r�sultat == ERROR_INVALID_WINDOW_HANDLE)){
        return r�sultat;
    }    
    if ((r�sultat == ERROR_ACCESS_DENIED) && ! IsUserAnAdmin())
    {
        afficherErreur(ERR_OS_ACCESS_DENIED);
        SetLastError(r�sultat); return r�sultat;
    }
    getErreurWindows(r�sultat);
    MessageBoxA(NULL, gErrCha�neTravail, NOM_SERVICE_SCLE, 0);
    if (estDisqueEnErreur(r�sultat)){ afficherErreur(ERR_HARDWARE_ERROR); }
    if (r�sultat == ERROR_NOT_READY){ traiterErreurUnit�NonDisponible(); }
    SetLastError(r�sultat); // Keep the original error code.
    return r�sultat;
}

#endif // ! TC_WINDOWS_DRIVER