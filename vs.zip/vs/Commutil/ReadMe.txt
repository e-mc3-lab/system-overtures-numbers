
For the other .lib/.dll and projects. 