/*
Copyright (c) 2003-2015 'Fondation TrueCrypt'. All rights reserved.
Governed by the SCLE License; the full text of which is contained in
the file Licence 1.0.txt included in NetDisq distribution packages.
2024-2026.
*/

#include "Memoire.h"
#include "ProcesSpace.h"

ND_TYPE_FILEX filExec(void* fx); void terminerFx(const uint8 i);

typedef struct
{
    HANDLE filEx; TC_EVENT d�but, fin;
    BOOL sp, nouveau, enCours, demandArr�t;

} OBJET_FX; 

const uint8 DIM_POOL_FX = DIM_32; static OBJET_FX gObjFx[DIM_POOL_FX] = {0};
static uint16 isync = 0;

static uint8 getPosFx(HANDLE filEx, BOOL attacherAuParent)
{
    uint8 i = 0; OBJET_FX* obj; while (gObjFx[i].filEx && (i < DIM_POOL_FX))
    {
        obj = &gObjFx[i]; if (( ! obj->nouveau) && attacherAuParent)
        {
            if (obj->filEx == filEx){ break; }
            if (obj->demandArr�t){ terminerFx(i); }
        } i++;
    }
    return i;
}

static ND_TYPE_FILEX filExec(void* ffx)
{
    NTSTATUS r = EXIT_SUCCESS; FONCTION_FX* fct = (FONCTION_FX*)ffx;
    OBJET_FX* obj = &gObjFx[fct->i]; obj->nouveau = TRUE;
    while ( ! obj->demandArr�t)
    {
        TC_WAIT_OBJECT(obj->d�but); if (obj->demandArr�t){ ND_FIN(); }
        obj->enCours = TRUE; r = fct->ex�cuter(fct->ctx); ND_ASSERT_S(r);
        obj->enCours = FALSE; obj->nouveau = ! fct->sp;
        if (obj->nouveau){ obj->demandArr�t = TRUE; } 
        TC_SET_EVENT(obj->fin);
    } ND_FIN(); ERR: if (fct){ fct->enErreur = TRUE; } 
    if (obj){ TC_SET_EVENT(obj->fin); } 
FIN:return NULL;
}

void d�marrerFx(FONCTION_FX* ffx)
{
    const uint8 i = getPosFx(ffx->filEx, ffx->sp); OBJET_FX* obj = NULL;
    ND_ASSERT_CS(i < DIM_POOL_FX, ERR_MAX_REFS_OBJET);
    obj = &gObjFx[i]; if ( ! obj->filEx)
    {
        obj->sp = ffx->sp; obj->d�but = CreateEvent(NULL, FALSE, FALSE, NULL);
        ND_ASSERT_CS(obj->d�but, ERR_INVALID_INIT);
        obj->fin = CreateEvent(NULL, FALSE, FALSE, NULL);
        ND_ASSERT_CS(obj->fin, ERR_INVALID_INIT); if (obj->sp){ isync++; }
        if ( ! (obj->filEx = (HANDLE)_beginthreadex(NULL, 0, 
            filExec, ffx, 0, NULL))){ ND_ERREUR(); }
        ffx->filEx = obj->filEx; obj->nouveau = FALSE;
    } ffx->i = i; ND_FIN();
ERR:journaliser("Erreur d�marrerFx"); if (obj){ obj->demandArr�t = TRUE; }
// Attention: quand il y a deux 'filex' imbriqu�s, le premier
// doit avoir comme argument 'sp'= FALSE; le 2�me, 3�me, ... = TRUE. */
FIN:if (obj && obj->d�but){ TC_SET_EVENT(obj->d�but); }
    if (NT_SUCCESS(gNDR�sultat) && ! obj->nouveau && obj->fin){
        TC_WAIT_OBJECT(obj->fin);
    } terminerFx(i);
}

static void terminerFx(const uint8 i)
{
    if ( ! gObjFx[i].enCours)
    {
        OBJET_FX* obj = &gObjFx[i]; if (obj->nouveau)
        {  
            obj->enCours = obj->demandArr�t = TRUE; TC_SET_EVENT(obj->fin);
            if (obj->d�but){ CloseHandle(obj->d�but); obj->d�but = NULL; }
            if (obj->fin){ CloseHandle(obj->fin); obj->fin = NULL; }
            if (obj->filEx){ CloseHandle(obj->filEx); obj->filEx = NULL; }
            obj->demandArr�t = FALSE; obj->enCours = FALSE;
        } else if (obj->sp && (isync > 0)){ isync--; }
    }
}

void execFilEx(FONCTION_FX* ffx, BOOL sp){ ffx->sp = sp; d�marrerFx(ffx); }

void finListeFilExA(BOOL bV�rifSp)
{
    for (uint8 i = 0; i < DIM_POOL_FX; i++)
    {
        if (gObjFx[i].filEx && ( ! bV�rifSp || gObjFx[i].sp))
        {
            gObjFx[i].demandArr�t = TRUE; gObjFx[i].nouveau = TRUE;
            gObjFx[i].enCours = FALSE; terminerFx(i);
        }
    }
}

void finListeFilEx(){ finListeFilExA(FALSE); }

void finListeFilsFx(){ finListeFilExA(TRUE); }