/*
 Copyright(c) 2024-2026 'SCLE-CSES'. More details in the file Licence 1.0.txt 
 included in NetDisq packages (project Common).
 */

#include "CompatibX.h"

#ifdef __cplusplus
extern "C" {
#endif

#define HAS_ARGUMENT	        1
#define HAS_NO_ARGUMENT         ! HAS_ARGUMENT
#define MAX_NB_ARGS             13

const int TAILLE_TAB_MAX        = (3 * MAX_PATH);
const int MILLISECONDES         = 1000;
const int CENT_SECONDES         = (100 * MILLISECONDES);

#define MOT_ID_MESSAGE          "Id.msg"
#define MOT_ID_ERREUR           "Id.err"

typedef struct 
{
	int Id; char long_name[DIM_32]; char short_name[DIM_8];

} Argument;

typedef struct 
{
    Argument* args; int	arg_cnt;

} ArgumentSpec;

uint Win32CommandLine(WCHAR* lpszCommandLine, char lpszArgs[][MAX_PATH]);
int GetArgumentID(ArgumentSpec* as, char* lpszArgument, uint* nArgPos);
int GetArgumentValue(char lpszCommandLineArgs[][MAX_PATH], uint nArgPos,
    uint* nArgIdx, uint nNoCommandLineArgs, char lpszValue[], uint nValueSize);
byte* getR�ponseCmd(); void finR�ponseCmd();

int ex�cuterCommande(char cnfCmd[], char cnfR[], int argn, char argv[][DIM_64]);
BOOL estMessageCmdSucc�s(char txt[]); BOOL estMessageCmd�chec(char txt[]);


#ifdef __cplusplus
}
#endif
