 /*
 Copyright (c) 2003-2015 'Fondation TrueCrypt'. All rights reserved.

 Governed by the SCLE License; the full text of which is contained in 
 the file Licence 1.0.txt included in NetDisq distribution packages. 
 2024-2026.
*/

#ifndef ND_HEADER_PROCESS_SPACE
#define ND_HEADER_PROCESS_SPACE

#ifdef __cplusplus
extern "C" {
#endif

typedef struct 
{
    NTSTATUS(*ex�cuter)(void* param); void* ctx; 
    uint8 i; HANDLE filEx; BOOL sp, enErreur;

} FONCTION_FX;

void execFilEx(FONCTION_FX* ffx, BOOL sp);
void finListeFilEx(); void finListeFilsFx();

#ifdef __cplusplus
}
#endif

#endif // ND_HEADER_PROCESS_SPACE