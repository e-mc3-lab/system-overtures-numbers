/*
 Legal Notice: Some portions of the source code contained in this file were
 derived from the source code of Encryption for the Masses 2.0, which is
 Copyright (c) 1998-2000 Paul Le Roux and which is governed by the 'Licence
 Agreement for Encryption for the Masses'. Modifications and additions to
 the original source code (contained in this file) and all other portions
 of this file are Copyright (c) 2003-2013 'Fondation TrueCrypt' and are
 governed by the SCLE license, the full text of which is contained in the 
 file Licence 1.0.txt included in NetDisq distribution packages. 2024-2025.
 */

#ifndef TC_BYTE_ORDER_H
#define TC_BYTE_ORDER_H

#include "CompatibX.h"


#define SBO                        1234 // Standard Byte Order.

#define RBO                        4321 // Reverse Byte Order.


#if defined(WIN64) || defined(_WIN64)

   #ifdef _RBO 
      #define PLATFORM_BYTE_ORDER  RBO // Examples: Motorola, Solaris (SUN).
   #else
      #define PLATFORM_BYTE_ORDER  SBO
   #endif

#endif

#define EST_STD_BYTE_ORDER         (PLATFORM_BYTE_ORDER == SBO)

#define EST_REVERSE_BYTE_ORDER     (PLATFORM_BYTE_ORDER == RBO)


#if defined(__cplusplus)
extern "C" 
{
#endif

BOOL estRBO();

/** 
   Macros to read and write 16, 32, and 64-bit quantities in a portable manner.
   These functions are implemented as macros rather than true functions as
   the need to adjust the memory pointers makes them somewhat painful to call
   in user code. SCLE: en d'autres mots, il n'est pas n�cessaire de faire un 
   "cast" pour �viter une erreur de compilation. De plus, l'adresse de tab 
   avance (n/char* ou byte*[8]), ce qui n'est pas le cas avec une fonction. 
   Sinon, il faudrait un param�tre avec double adresse (**).
*/
#define setMemBytes(tab, data, len, avnc) \
{ \
    memcpy(tab, data, len); \
    if (avnc){ tab += len; } \
}

#define setMemWord(tab, data, avnc) \
{ \
    tab[0] = (uchar)((data >> 8) & MASQUE_CTR); \
    tab[1] = (uchar) (data & MASQUE_CTR); \
    if (avnc){ tab += 2; } \
}

/*#define getMemInt32(tab, avnc) \
{ \
    ( ((uint32) tab[0] << 24 ) | ((uint32) tab[1] << 16) | \
      ((uint32) tab[2] << 8 ) | (uint32) tab[3]) \
    if (avnc){ tab += 4;  } \
}*/

#define setMemInt32(tab, data, avnc) \
{ \
    tab[0] = (uchar)((data >> 24) & MASQUE_CTR); \
    tab[1] = (uchar)((data >> 16) & MASQUE_CTR); \
    tab[2] = (uchar)((data >> 8)  & MASQUE_CTR); \
    tab[3] = (uchar)(data & MASQUE_CTR); \
    if (avnc){ tab += 4; } \
}

#define setMemInt64(tab, data, avnc) \
{ \
    tab[0] = (uchar)((data >> 56) & MASQUE_CTR ); \
    tab[1] = (uchar)((data >> 48) & MASQUE_CTR ); \
    tab[2] = (uchar)((data >> 40) & MASQUE_CTR ); \
    tab[3] = (uchar)((data >> 32) & MASQUE_CTR ); \
    tab[4] = (uchar)((data >> 24) & MASQUE_CTR ); \
    tab[5] = (uchar)((data >> 16) & MASQUE_CTR ); \
    tab[6] = (uchar)((data >> 8)  & MASQUE_CTR ); \
    tab[7] = (uchar) (data & MASQUE_CTR); \
    if (avnc){ tab += 8;  } \
}

#if EST_STD_BYTE_ORDER
   #define LE16(x) (x)
   #define LE32(x) (x)
   #define LE64(x) (x)
#elif EST_REVERSE_BYTE_ORDER
   #define LE16(x) MirrorBytes16(x)
   #define LE32(x) MirrorBytes32(x)
   #define LE64(x) MirrorBytes64(x)
#endif

#if EST_STD_BYTE_ORDER
   #define BE16(x) MirrorBytes16(x)
   #define BE32(x) MirrorBytes32(x)
   #define BE64(x) MirrorBytes64(x)
#else
   #define BE16(x) (x)
   #define BE32(x) (x)
   #define BE64(x) (x)
#endif

uint16 MirrorBytes16(uint16 x);
uint32 MirrorBytes32(uint32 x);
uint64 MirrorBytes64(uint64 x);
void LongReverse(uint32 tab[], uint byteCount);
uint16 getMotInt16(byte tab[], int offset);
uint32 getMotInt32(byte tab[], int offset);
UINT64_STRUCT getMotInt64(byte tab[], int offset);
uint64 getValeurHexa64(const byte txt8[]);

#if defined(__cplusplus)
}
#endif

#endif /* TC_BYTE_ORDER_H */
