/*
 Legal Notice: Some portions of the source code contained in this file were
 derived from the source code of Encryption. Modifications and additions to
 the original source code (contained in this file), and all other portions
 of this file are Copyright(c) 2003-2013 'Fondation TrueCrypt'. These are
 also governed by the SCLE License; the full text of which is contained 
 in the file Licence 1.0.txt included in NetDisq distribution packages. 
 SCLE/CSES: 2024-2026. */

#include "TexteCc.h"
#include "Memoire.h"
#include "Fichier.h" 
#include "Erreur.h" 
#include "ErreurDict.h"
#include "Sortie.h"
#include "Cmdline.h"


/**
 * PRE: lpszArgs est un tableau statique (initialis�).
 *      Le nombre d'arguments ne doit pas d�passer MAX_NB_ARGS.
 */
uint Win32CommandLine(WCHAR* lpszCommandLine, char lpszArgs[][MAX_PATH])
{
	int nbArgs=0, i=0, len, argLen; char* arg = NULL;
    LPWSTR* arguments = CommandLineToArgvW(GetCommandLineW(), &nbArgs);
	if ((nbArgs < 1) || (nbArgs-- > MAX_NB_ARGS))
	{
		afficherErreurDict("ERR_ARGUMENT_INVALIDE"); nbArgs=0; ND_FIN();		
	}
	if ( ! arguments)
	{
		traiterErreurWindows(); return FALSE;
	}   
    for (i = 0; i < nbArgs; ++i)
    {
        argLen = (int) wcslen((WCHAR*)arguments[i + 1]);
        if (argLen > 0)
        { 
			arg = new char[argLen+uint8(1)]; ND_ASSERT_CS((arg != NULL), 
                ERR_SUCCESS); len = WideCharToMultiByte(CP_ACP, 0, 
                    LPCWCH(arguments[i+1]), -1, arg, argLen + int(1), 
                    NULL, NULL); if (len == 0)
            {                
                delete[] arg; ND_ERREUR();
            }
            strcpy(lpszArgs[i], arg); delete[] arg; arg = NULL;
        } else if (arg != NULL){
            arg[0] = EOL;
        }
    } // for

	ND_FIN();
ERR: afficherErreurDict("ERR_ARGUMENT_INVALIDE"); nbArgs = 0; 
FIN: LocalFree(arguments); return nbArgs;
}

int GetArgSepPosOffset(char *lpszArgument)
{
	if (lpszArgument[0] == '/'){ return 1; } return 0;
}

int GetArgumentID(ArgumentSpec* as, char* lpszArgument, uint* nArgPos)
{
	char* szTmp = convEnMinuscules(lpszArgument);
	for (int i = 0; i < as->arg_cnt; i++)
	{
		ENTIER k = STRLEN(as->args[i].long_name);
		if (memcmp(as->args[i].long_name, szTmp, k * sizeof (char)) == 0)
		{
			ENTIER x; for (x = ENTIER(i) + 1; x < as->arg_cnt; x++)
			{
				ENTIER m = STRLEN(as->args[x].long_name);
				if (memcmp(as->args[x].long_name, szTmp, 
					m * sizeof(char)) == 0){ break; }
			}
			if (x == as->arg_cnt)
			{
				if (STRLEN(lpszArgument) != k){
					*nArgPos = (int) k;
				} else {
					*nArgPos = EOL;
				}
				return as->args[i].Id;
			}
		}
	}

	for (int i = 0; i < as->arg_cnt; i++)
	{
		ENTIER y; if (as->args[i].short_name[0] == EOL){ continue; }
		y = STRLEN(as->args[i].short_name);
		if (memcmp(as->args[i].short_name, szTmp, y * sizeof(char)) == 0)
		{
			ENTIER x, m; for (x = ENTIER(i) + 1; x < as->arg_cnt; x++)
			{
				if (as->args[x].short_name[0] == EOL){ continue; }
				m = STRLEN(as->args[x].short_name);
				if (memcmp(as->args[x].short_name, szTmp, 
					m * sizeof(char)) == 0){ break; }
			}
			if (x == as->arg_cnt)
			{
				if (STRLEN(lpszArgument) != y){
					*nArgPos = (int) y;
				} else {
					*nArgPos = EOL;
				}
				return as->args[i].Id;
			}
		}
	}
	return -1;
}

int GetArgumentValue(char lpszCommandLineArgs[][MAX_PATH], uint nArgPos,
	uint* nArgIdx, uint nNoCommandLineArgs, char lpszValue[], uint nValueSize)
{
	*lpszValue = 0; if (nArgPos)
	{	
        // Handles the case of no space between parameter code and value.
		strncpy(lpszValue, &lpszCommandLineArgs[*nArgIdx][nArgPos], 
			nValueSize); lpszValue[nValueSize - 1] = EOL;
		return HAS_ARGUMENT;
	} else if ((*nArgIdx + 1) < nNoCommandLineArgs){
		int x = GetArgSepPosOffset(lpszCommandLineArgs[*nArgIdx + 1]);		
		if (x == 0)
		{	
            // Handles the case of space between argument code and value. 
			strncpy(lpszValue, &lpszCommandLineArgs[*nArgIdx + 1][x], 
				nValueSize); lpszValue[nValueSize - 1] = EOL;
			(*nArgIdx)++; return HAS_ARGUMENT;
		}
	}
	return HAS_NO_ARGUMENT;
}

char gParams[TAILLE_TAB_MAX]; static byte* gContenu = NULL;

byte* getR�ponseCmd(){ return gContenu; } 
void finR�ponseCmd(){ NDFree(gContenu); }

int getTailleSortieCmd(char cnfMsg[]) // FILE* f
{   
    // Pour LINUX ? fseek(f, 0, SEEK_END); // Instable avec Microsoft C.
    // dimF = ftell(f); fseek(f, 0, SEEK_SET);
    int dimF = 0; HANDLE hf = CreateFileA(cnfMsg, GENERIC_READ, 
        FILE_SHARE_READ, NULL, OPEN_EXISTING, 0, NULL); if (hf){
    dimF = getTailleFichier(hf); fermerFichier(&hf); } return dimF;
}

int getCompteHorloge(){ return int(GetTickCount64()); }

FILE* ouvrir(char chemNomFichier[])
{
    FILE* fSortie = fopen(chemNomFichier, "rb"); return fSortie;
}

void fermer(FILE** hf){ if (hf && *hf){ fclose(*hf); } }

// PRE: n'utiliser que dans les applications client.
//      la longueur de chaque 'argv' ne doit pas d�passer 64.
// POST: lib�rer 'gContenu' apr�s utilisation (finR�ponseCmd). 
int ex�cuterCommande(char cnfCmd[], char cnfR[], int argn, char argv[][DIM_64])
{    
    gNDR�sultat = STATUS_SUCCESS; FILE* fSortie = NULL; ENTIER lecture;
    int pass� = 0; char param[DIM_64] = {0}; uint8 m = 1; ENTIER j = 0, s = 0;
    HINSTANCE hInst = NULL; const int D�LAI = MILLISECONDES / 2;
    if (estEnUtilisation(cnfCmd)){
        ND_ASSERT_S(ERR_ARGUMENT_INVALIDE); }
    if ( ! existe(cnfCmd)){ ND_ASSERT_S(ERR_ARGUMENT_INVALIDE); }
    ND_ASSERT_CS(cnfR && (STRLEN(cnfR) > 0), ERR_ARGUMENT_INVALIDE); 
    supprimerFichier(cnfR); for (int i = 0; i < argn; i++)
    {
        strcpy(param, argv[i]); s = STRLEN(argv[i]); param[s] = EOL;
        if ((i == 0) && (argv[i][0] != '/')){ 
            mettreEntreGuillemets(param, s); m = 3; } else { m = 1; }
        sprintf((gParams + j), "%s ", param); j += s + m;
    } 
    hInst = ShellExecuteA(NULL, "" /* runas */, cnfCmd, gParams, NULL, 0);
    if (hInst)
    {   // Attendre la r�ponse...
        while ((fSortie == NULL) && (pass� < CENT_SECONDES))
        {
            fSortie = ouvrir(cnfR); Sleep(D�LAI); pass� += D�LAI;
        }
        if (fSortie) 
        {
            int dimF = getTailleSortieCmd(cnfR); if (dimF > 0)
            {
                gContenu = (byte*)NDAllouer0(dimF+1);
                lecture = fread(gContenu, 1, dimF, fSortie);
                gContenu[dimF] = EOL;
                ND_ASSERT_CS(lecture > 0, ERR_FILE_READ);
            } else { ND_ASSERT_S(ERR_FILE_READ); }
        }
    } else { ND_ASSERT_S(ERR_ARGUMENT_INVALIDE); } ND_FIN();
ERR:ND_JOURNALISER_ERREUR(__FILENAME__); traiterErreurDict(gNDR�sultat); 
FIN:fermer(&fSortie); return gNDR�sultat;
}

BOOL estMessageCmdSucc�s(char txt[]){ return commencePar(txt, MOT_ID_MESSAGE); }

BOOL estMessageCmd�chec(char txt[]){ return commencePar(txt, MOT_ID_ERREUR); }