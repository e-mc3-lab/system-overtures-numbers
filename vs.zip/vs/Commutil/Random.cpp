/*
 Copyright(c) 2003-2013 'Fondation TrueCrypt'. Also governed by the SCLE
 License; of which the text is contained in Licence 1.0.txt included in
 NetDisq packages. 2024-2026.
 */

#include <stdlib.h>
#include <process.h>
#include "TexteCc.h"
#include "TextHexa.h"
#include "Register.h"
#include "Memoire.h"
#include "Random.h"

#pragma warning(disable:4302)
#pragma warning(disable:4311)

 /* Type definitions for function pointers to call NetAPI32 functions */
typedef DWORD(WINAPI* NETSTATISTICSGET) (WCHAR* szServer, WCHAR* szService,
    DWORD dwLevel, DWORD dwOptions, byte** lpBuffer);
typedef DWORD(WINAPI* NETAPIBUFFERSIZE) (void* lpBuffer, LPDWORD cbBuffer);
typedef DWORD(WINAPI* NETAPIBUFFERFREE) (void* lpBuffer);

/* SCLE: message impr�cis, mais... */
#define MSG_NOMBRES_INSUFFISANTS "Il n'y a pas assez de nombres vs germe."

static uchar gTabEspaceHasard[RANDOMPOOL_ALLOCSIZE] = {0};
static int nRandIndex = 0; void ajouterTableHasard(void* tab, int len);

/* Macro to add a single byte to the pool */
#define RandaddByte(x) \
{ \
    if (nRandIndex == RNG_POOL_SIZE){ nRandIndex = 0; } \
    gTabEspaceHasard[nRandIndex] = (uchar) ((uchar)x + \
         gTabEspaceHasard[nRandIndex]); nRandIndex++; \
} \

#define RandaddInt32(x){ RandAddInt((uint32)x); } // Add 4 bytes to the pool.

void RandAddInt(uint32 x)
{
    RandaddByte(x); RandaddByte((x >> 8)); 
    RandaddByte((x >> 16)); RandaddByte((x >> 24));
}

static uint8 gTabEspace[RNG_POOL_SIZE] = {0};
static BOOL bRandInitialized = FALSE; static int randPoolReadIndex = 0;
static BOOL bSondageActiv = FALSE;
BOOL volatile bSondageRapideActiv = TRUE; // R�duit la charge de traitement
static HANDLE PeriodicFastPollThreadHandle = NULL; // du processeur.
HHOOK hMouse = NULL, hKeyboard = NULL; NETSTATISTICSGET statsR�seau = NULL; 
NETAPIBUFFERSIZE dimTabR�seau = NULL; NETAPIBUFFERFREE tabR�seauLibre = NULL;

/* Variables for thread control, the thread is used to gather up info about
   the system in the background */ BOOL initialiserHasard();
CRITICAL_SECTION sectionCritique; // Volatile parce que partag�e par 
BOOL volatile bThreadTerminate = FALSE; // plusieurs threads.
HANDLE ghNetAPI32 = NULL; HCRYPTPROV ghProv = NULL; // CryptoAPI.

HCRYPTPROV getCtxChiffre()
{ 
    if ( ! initialiserHasard()){ return NULL; } else { return ghProv; }
}

/**
 * Init the random number generator and start the thread.
 * 
 * @return TRUE si initialisation valide ou d�j� initialis�e.
 */
BOOL initialiserHasard()
{
    if (bRandInitialized){ return TRUE; }
    InitializeCriticalSection(&sectionCritique);
    if (gTabEspaceHasard == NULL)
    {
        init0(gTabEspaceHasard, RANDOMPOOL_ALLOCSIZE);
        bSondageActiv = FALSE;
        VirtualLock(gTabEspaceHasard, RANDOMPOOL_ALLOCSIZE);
    }    
    if ( ! CryptAcquireContext(&ghProv, NULL, NULL, PROV_RSA_FULL, 0) && 
         ! CryptAcquireContext(&ghProv, NULL, NULL, PROV_RSA_FULL, 
             CRYPT_NEWKEYSET)){ 
        ghProv = (HCRYPTPROV)NULL; ND_ASSERT_S(ERR_OBJECT_INIT);
    } 
    bRandInitialized = TRUE; return TRUE; ERR:journaliser("Erreur Random %d.", 
        gNDR�sultat); terminerHasard(TRUE); return FALSE;
}

/** 
   Close everything down, including the thread which is closed down by
   setting a flag which eventually causes the thread function to 
   exit. */
void terminerHasard(BOOL bLib�rer)
{
    if ( ! bRandInitialized && bLib�rer && gTabEspaceHasard){ ND_FIN(); }
    if ( ! bRandInitialized){ return; }
    EnterCriticalSection(&sectionCritique);
    if (hMouse != NULL){ UnhookWindowsHookEx(hMouse); }
    if (hKeyboard != NULL){ UnhookWindowsHookEx(hKeyboard); }
    bThreadTerminate = TRUE; LeaveCriticalSection(&sectionCritique);
    if (PeriodicFastPollThreadHandle){
        WaitForSingleObject(PeriodicFastPollThreadHandle, INFINITE);
    }
    if (ghNetAPI32 != NULL)
    {
        FreeLibrary((HMODULE)ghNetAPI32); ghNetAPI32 = NULL;
        statsR�seau = NULL; dimTabR�seau = NULL; tabR�seauLibre = NULL;
    }
    if (ghProv){ CryptReleaseContext(ghProv, 0); ghProv = NULL; }
    hMouse = NULL; hKeyboard = NULL; bThreadTerminate = FALSE;
    DeleteCriticalSection(&sectionCritique); bRandInitialized = FALSE;
FIN:if (bLib�rer)
    {
        bSondageActiv = FALSE; init0(gTabEspaceHasard, RANDOMPOOL_ALLOCSIZE);
    }
}

/**
 * Gather up network/hard drive performance data for the random pool.
 */
BOOL appliquerSondage(void)
{
    static int isWorkstation = -1; static int cbPerfData = 0x10000;
    HANDLE hDevice; LPBYTE lpBuffer = NULL; DWORD dwSize, status; int nDrive;
    WCHAR lpszLanW[] = L"LanmanWorkstation", lpszLanS[] = L"LanmanServer";
    WCHAR szDevice[24] = {0};    
    if (isWorkstation == -1)
    {   // Find out whether this is an NT server or workstation if necessary.
        HKEY hKey; if (RegOpenKeyExA(HKEY_LOCAL_MACHINE,
            SYSTEM CURRENT_CONTROL_SET CONTROL "ProductOptions",
            0, KEY_READ, &hKey) == ERROR_SUCCESS)
        {
            uchar szValue[32]; dwSize = sizeof(szValue); isWorkstation = TRUE;
            status = RegQueryValueExW(hKey, L"ProductType", 0, NULL,
                szValue, &dwSize);
            if (status == ERROR_SUCCESS && _stricmp((char*)szValue, "WinNT"))
            {
                /* Note that there are (at least) three cases :
                   WinNT = NT Workstation,
                   ServerNT = NT Server, LanmanNT = NT Server
                   acting as a Domain Controller. */ isWorkstation = FALSE;
            }
            RegCloseKey(hKey);
        }
    }
    // Initialize the NetAPI32 function pointers if necessary.
    if (ghNetAPI32 == NULL)
    {
        // Obtain a handle to the module containing the Lan Manager functions.
        ghNetAPI32 = LoadLibraryW(L"NETAPI32.DLL"); if (ghNetAPI32 != NULL)
        {
            // Now get pointers to the functions.
            statsR�seau = (NETSTATISTICSGET)GetProcAddress((HMODULE)ghNetAPI32,
                "NetStatisticsGet");
            dimTabR�seau = (NETAPIBUFFERSIZE)GetProcAddress((HMODULE)ghNetAPI32,
                "NetApiBufferSize");
            tabR�seauLibre = (NETAPIBUFFERFREE)GetProcAddress((HMODULE)ghNetAPI32,
                "NetApiBufferFree");
            // Make sure we got valid pointers for every NetAPI32 function.
            if ((statsR�seau == NULL) || (dimTabR�seau == NULL) ||
                (tabR�seauLibre == NULL))
            {    // Free the library reference and reset the static handle.
                FreeLibrary((HMODULE)ghNetAPI32); ghNetAPI32 = NULL;
            }
        }
    }
    /* Get network statistics. Note: NT Workstation and NT Server
       by default will be running both the workstation and server
       services. The heuristic below is probably useful though on the
       assumption that the majority of the network traffic will be via
       the appropriate service. */
    if (ghNetAPI32 && statsR�seau(NULL,
        isWorkstation ? lpszLanW : lpszLanS, 0, 0, &lpBuffer) == 0)
    {
        dimTabR�seau(lpBuffer, &dwSize);
        ajouterTableHasard((uchar*)lpBuffer, dwSize);
        tabR�seauLibre(lpBuffer);
    }
    // Get disk I/O statistics for all the hard drives.
    for (nDrive = 0;; nDrive++)
    {
        DISK_PERFORMANCE dp = {0}; // Is device accessible ?
        wsprintfW(szDevice, TEXT(CHEM_P�RIPH_RELATIF_COURANT) \
            TEXT(NOM_UNIT�_DISQUE_EN) L"%d", nDrive);
        hDevice = CreateFileW(szDevice, 0, FILE_SHARE_READ |
            FILE_SHARE_WRITE, NULL, OPEN_EXISTING, 0, NULL);
        if (hDevice == INVALID_HANDLE_VALUE) { break; }
        /* Note: this only works if you have turned on the disk
           performance counters with 'diskperf -y'. These counters
           are off by default. */
        if (DeviceIoControl(hDevice, IOCTL_DISK_PERFORMANCE, NULL, 0,
            &dp, sizeof(DISK_PERFORMANCE), &dwSize, NULL)) {
            ajouterTableHasard((uchar*)&dp, dwSize);
        }
        CloseHandle(hDevice);
    }
    if (ghProv && // CryptoAPI
        CryptGenRandom(ghProv, sizeof(gTabEspace), gTabEspace)) {
        ajouterTableHasard(gTabEspace, sizeof(gTabEspace));
    }
    init0(gTabEspace, sizeof(gTabEspace)); return TRUE;
}

// This is the function which gathers up info by calling various api's.
BOOL appliquerSondageRapide(void)
{
    int nOriginalRandIndex = nRandIndex; static BOOL addedFixedItems = FALSE;
    FILETIME creationTime, exitTime, kernelTime, userTime;
    int64 minimumWorkingSetSize, maximumWorkingSetSize;
    LARGE_INTEGER performanceCount; MEMORYSTATUSEX memoryStatus;
    HANDLE hFilExec; POINT point = {0};
    // Get various basic pieces of system information.
    RandaddInt32(GetActiveWindow());
    RandaddInt32(GetCapture());
    RandaddInt32(GetClipboardOwner());
    RandaddInt32(GetClipboardViewer());
    RandaddInt32(GetCurrentProcess());
    RandaddInt32(GetCurrentProcessId());
    RandaddInt32(GetCurrentThread());
    RandaddInt32(GetCurrentThreadId());
    RandaddInt32(GetTickCount64());
    RandaddInt32(GetDesktopWindow());  // Handle of desktop window.
    RandaddInt32(GetFocus());          // Handle of window with kb.focus.
    RandaddInt32(GetInputState());     // Whether sys.queue has any events.
    RandaddInt32(GetMessagePos());     // Cursor pos. for last message.
    RandaddInt32(GetMessageTime());    // 1 ms time for last message.
    RandaddInt32(GetOpenClipboardWindow());
    RandaddInt32(GetProcessHeap());
    RandaddInt32(GetProcessWindowStation());
    // Types of events in input queue.
    RandaddInt32(GetQueueStatus(QS_ALLEVENTS)); 
    // Get multiword system information.
    GetCaretPos(&point); // Current caret position.
    ajouterTableHasard((uchar*)&point, sizeof(POINT));
    GetCursorPos(&point); // Current mouse cursor position.
    ajouterTableHasard((uchar*)&point, sizeof(POINT));
    memoryStatus.dwLength = sizeof(MEMORYSTATUS);
    GlobalMemoryStatusEx(&memoryStatus);
    ajouterTableHasard((uchar*)&memoryStatus, sizeof(MEMORYSTATUS));
    /* Get thread and process creation time, exit time, time in kernel
       mode, and time in user mode in 100ns intervals. */
    hFilExec = GetCurrentThread();
    GetThreadTimes(hFilExec, &creationTime, &exitTime, &kernelTime, &userTime);
    ajouterTableHasard((uchar*)&creationTime, sizeof(FILETIME));
    ajouterTableHasard((uchar*)&exitTime, sizeof(FILETIME));
    ajouterTableHasard((uchar*)&kernelTime, sizeof(FILETIME));
    ajouterTableHasard((uchar*)&userTime, sizeof(FILETIME));
    hFilExec = GetCurrentProcess();
    GetProcessTimes(hFilExec, &creationTime, &exitTime, &kernelTime, &userTime);
    ajouterTableHasard((uchar*)&creationTime, sizeof(FILETIME));
    ajouterTableHasard((uchar*)&exitTime, sizeof(FILETIME));
    ajouterTableHasard((uchar*)&kernelTime, sizeof(FILETIME));
    ajouterTableHasard((uchar*)&userTime, sizeof(FILETIME));
    // CryptoAPI
    if (ghProv && CryptGenRandom(ghProv, sizeof(gTabEspace), gTabEspace)){
        ajouterTableHasard(gTabEspace, sizeof(gTabEspace));
    }
    /* Get the minimum and maximum working set size for the current process. */
    GetProcessWorkingSetSize(hFilExec, (uint64*)&minimumWorkingSetSize,
        (ENTIER*)&maximumWorkingSetSize);
    RandaddInt32(minimumWorkingSetSize); RandaddInt32(maximumWorkingSetSize);
    /* The following are fixed for the lifetime of the process so we only
       add them once. */
    if (addedFixedItems == 0)
    {
        STARTUPINFO startupInfo = {0};
        startupInfo.cb = sizeof(STARTUPINFO); GetStartupInfo(&startupInfo);
        ajouterTableHasard((uchar*)&startupInfo, sizeof(STARTUPINFO));
        addedFixedItems = TRUE;
    }
    /* NB: it hasn't been tested for RISC. */
    if (QueryPerformanceCounter(&performanceCount)){
        ajouterTableHasard((uchar*)&performanceCount, sizeof(LARGE_INTEGER));
    } else {
        DWORD dwTicks = (DWORD)GetTickCount64();
        ajouterTableHasard((uchar*)&dwTicks, sizeof(dwTicks));
    }
    // Restore the original pool cursor position.
    nRandIndex = nOriginalRandIndex;  return TRUE;
}

/**
 * Get len random bytes (max. RNG_POOL_SIZE bytes per a single call).
 */
BOOL getRandBytes(uchar tab[], int len, BOOL forceSlowPoll)
{       
    BOOL r�sultat = TRUE; int i; tab[len-1] = EOL; 
    if ( ! initialiserHasard())
    {
        journaliser("Erreur getRandBytes."); return FALSE;
    }        
    EnterCriticalSection(&sectionCritique);
    if ( ! bSondageActiv || forceSlowPoll)
    {
        if ( ! appliquerSondage()){ r�sultat = FALSE;
        } else { bSondageActiv = TRUE; }
    }
    if ( ! appliquerSondageRapide()){ r�sultat = FALSE; }
    // There's never more than RNG_POOL_SIZE worth of randomess.
    if (len > RNG_POOL_SIZE)
    {   
        journaliser(MSG_NOMBRES_INSUFFISANTS); len = RNG_POOL_SIZE;
    }
    // Requested number of bytes is copied from pool to output 'gTabEspace',
    // and the table is XORed with new data.
    for (i = 0; i < len; i++)
    {
        tab[i] = gTabEspaceHasard[randPoolReadIndex++];
        if (randPoolReadIndex == RNG_POOL_SIZE){ randPoolReadIndex = 0; }
    }
    // Invert the pool.
    for (i = 0; i < RNG_POOL_SIZE / 4; i++){
        ((uint32*) gTabEspaceHasard)[i] = ~((uint32*) gTabEspaceHasard)[i];
    }
    // Mix the pool.
    if ( ! appliquerSondageRapide()){ r�sultat = FALSE; }
    // XOR the current pool content into the output gTabEspace 
    for (i = 0; i < len; i++) // to prevent pool state leaks.
    {
        tab[i] ^= gTabEspaceHasard[randPoolReadIndex++];
        if (tab[i] == EOL){ tab[i] = (uchar)(i+1); }
        if (randPoolReadIndex == RNG_POOL_SIZE){ randPoolReadIndex = 0; }
    }
    LeaveCriticalSection(&sectionCritique);
    if ( ! r�sultat){ journaliser("Erreur getRandBytes."); } return r�sultat;
}

BOOL peekRandBytes(uchar tab[], int len)
{
    if ( ! initialiserHasard()){ return FALSE; }
    if (len > RNG_POOL_SIZE)
    {   
        journaliser(MSG_NOMBRES_INSUFFISANTS); len = RNG_POOL_SIZE;
    }
    EnterCriticalSection(&sectionCritique); memcpy(tab, gTabEspaceHasard, len);
    LeaveCriticalSection(&sectionCritique); return TRUE;
}

/* Add a tab to the pool. */
void ajouterTableHasard(void* tab, int len)
{
    int i; for (i = 0; i < len; i++){ RandaddByte(((uchar*) tab)[i]); }
}

/* This is the thread function which will poll the system for randomness. */
static unsigned __stdcall PeriodicFastPollThreadProc(void* dummy)
{
    UNREFERENCED_PARAMETER(dummy); 
    while (TRUE)
    {
        EnterCriticalSection(&sectionCritique); if (bThreadTerminate)
        {
            bThreadTerminate = FALSE;
            LeaveCriticalSection(&sectionCritique); _endthreadex(0);
        } else if (bSondageRapideActiv){
            appliquerSondageRapide(); 
        }
        LeaveCriticalSection(&sectionCritique); Sleep(FASTPOLL_INTERVAL);
    }
}

uint getNombreAl�atoire(int n)
{
    uint r; uint64 al�atoire = 0; uint i; 
    uint m = (GetCurrentProcessId() % GetCurrentThreadId() % 23) + 1;
    const int N0 = n; int32 j = max(randx(), 50);
    uint germe = getEstampille(); srand(germe); r = (germe % 80) + 30;
    for (uint j = 0; j < r; j++){ srand(r); srand(r); srand(r); }
    for (i = 0; i < m; i++, j++){ al�atoire += (uint64(randx()) * uint64(j)); }
    r = uint(al�atoire * uint(randx()) % N0);
    while (r >= uint(n)){ r = i++ % N0; } return r;
}

// PRE: longueur de 'tab' doit �tre multiple de RNG_POOL_SIZE.
NTSTATUS getDataTest(byte tab[], uint n, BOOL bModPasse)
{
    const uint16 NET_DIV = RNG_POOL_SIZE;
    for (uint i = 0; i < n; i += NET_DIV)
    {
        if ((n - i) >= NET_DIV)
        {
            if ( ! getRandBytes(tab + i, NET_DIV, TRUE)){
                return ERR_CIPHER_INIT_WEAK_KEY; }
        } else { break; }
    } /*for*/ setNonVide(tab, n, FALSE, bModPasse); return EXIT_SUCCESS;
}