/*
 Legal Notice: Some portions of the source code contained in this file were
 derived from the source code of Encryption. Modifications and additions to
 the original source code (contained in this file), and all other portions
 of this file are Copyright(c) 2003-2013 'Fondation TrueCrypt'. These are
 also governed by the SCLE License; the full text of which is contained
 in the file Licence 1.0.txt included in NetDisq distribution packages.
 SCLE: 2024-2025. */

#ifndef RANDOM_CRYPTO_H
#define RANDOM_CRYPTO_H

#include "CompatibX.h"

#ifdef __cplusplus
extern "C" {
#endif

#define RNG_POOL_SIZE            320 // Must be divisible by the size
    // of the output of each implemented hash functions (in bytes).

#define RANDOMPOOL_ALLOCSIZE     RNG_POOL_SIZE

// After each RANDMIX_BYTE_INTERVAL-th byte written to the pool, 
// it is mixing function that is applied to the entire pool.
#define RANDMIX_BYTE_INTERVAL    DIM_16

#define FASTPOLL_INTERVAL        500 // milliseconds.

#ifndef TC_WINDOWS_DRIVER

HCRYPTPROV getCtxChiffre(); void terminerHasard(BOOL bLib�rer);
BOOL getRandBytes(uchar tab[], int len, BOOL forceSlowPoll);
uint getNombreAl�atoire(int n);
NTSTATUS getDataTest(byte tab[], uint n, BOOL bModPasse);

#endif // ! TC_WINDOWS_DRIVER

#ifdef __cplusplus
}
#endif

#endif // RANDOM_CRYPTO_H