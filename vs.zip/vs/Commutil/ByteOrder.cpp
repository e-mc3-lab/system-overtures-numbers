/*
 Legal Notice: Some portions of the source code contained in this file were
 derived from the source code of Encryption for the Masses 2.0, which is
 Copyright (c) 1998-2000 Paul Le Roux and which is governed by the 'Licence
 Agreement for Encryption for the Masses'. Modifications and additions to
 the original source code (contained in this file) and all other portions
 of this file are Copyright (c) 2003-2013 'Fondation TrueCrypt' and are 
 governed by the SCLE license, the full text of which is contained in the
 file Licence 1.0.txt included in NetDisq distribution packages. 2024-2025.
 */

#include "ByteOrder.h"

BOOL estRBO() 
{   // Check the least significant byte value. Author: Kalyna.
    uint num = 1; return (*((uint8*)&num) == 0);
}

uint16 MirrorBytes16(uint16 x){ return (x << 8) | (x >> 8); }

uint32 MirrorBytes32(uint32 x)
{
    uint32 n = (uint8) x;
    n <<= 8; n |= (uint8) (x >> 8);
    n <<= 8; n |= (uint8) (x >> 16);
    return (n << 8) | (uint8) (x >> 24);
}

uint64 MirrorBytes64(uint64 x)
{
    uint64 n = (uint8) x;
    n <<= 8; n |= (uint8) (x >> 8);
    n <<= 8; n |= (uint8) (x >> 16);
    n <<= 8; n |= (uint8) (x >> 24);
    n <<= 8; n |= (uint8) (x >> 32);
    n <<= 8; n |= (uint8) (x >> 40);
    n <<= 8; n |= (uint8) (x >> 48);
    return (n << 8) | (uint8) (x >> 56);
}

void LongReverse(uint32 tab[], uint byteCount)
{
    uint32 value; byteCount /= sizeof(uint32); 
    while (byteCount--)
    {
        value = *tab; value = ((value & 0xFF00FF00L) >> 8) | \
            ((value & 0x00FF00FFL) << 8);
        *tab++ = (value << 16) | (value >> 16);
    }
}

uint16 getMotInt16(byte tab[], int offset){
    return BE16(*(uint16*)(tab + offset));
}

uint32 getMotInt32(byte tab[], int offset){
    return BE32(*(uint32*)(tab + offset));
}

UINT64_STRUCT getMotInt64(byte tab[], int offset)
{
    UINT64_STRUCT uint64Struct = {0};
    uint64Struct.Value = BE64(*(uint64*)(tab + offset));
    return uint64Struct;
}

/**
 * PRE: la longueur de txt8 doit �tre au plus 8. Sinon, retourne 0.
 */
uint64 getValeurHexa64(const byte txt8[])
{
    const uint8 N = (txt8 ? (uint8)strlen((const char *)txt8) : 0);
    if ((N == 0) || (N > 8)) { return 0L; } return BE64(*(uint64*)txt8);
}