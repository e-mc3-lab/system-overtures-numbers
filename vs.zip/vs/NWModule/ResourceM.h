//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by NetDisq.rc
//
#define IDC_MYICON                      3

#define IDD_NOUVDOA                     300
#define IDC_MOTDEPASSE1                 303
#define IDC_MOTDEPASSE2                 304
#define IDM_AUTHENTIFICATION            308
#define IDM_OPTIONS                     309
#define IDD_DOCUMENT                    319
#define IDC_PROGRESS_BAR                321
#define IDC_SUR_DISQUE                  323
#define IDC_AFFICHER_MOTSDEPASSE        324

#define IDC_TEXTE                       1001
#define IDT_MOTDEPASSE                  1002
#define IDT_MOTDEPASSE1                 1003
#define IDT_MOTDEPASSE2                 1004
#define IDC_MOTDEPASSE                  1005
#define IDB_ENREGISTRER                 1030

#define IDD_OPTIONS                     1100
#define IDT_ADR_NOM_SITE_WEB            1103
#define IDC_ADR_NOM_SITE_WEB            1104
#define IDT_CODE_UTILISATEUR            1105
#define IDC_CODE_UTILISATEUR            1106
#define IDT_COURRIEL                    1110
#define IDC_COURRIEL                    1111

#define IDM_OUVRIR_FICHIER              32001
#define IDB_CHIFFRER                    32003

#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        326
#define _APS_NEXT_COMMAND_VALUE         32005
#define _APS_NEXT_CONTROL_VALUE         1036
#define _APS_NEXT_SYMED_VALUE           110
#endif
#endif
