/*
Copyright(c) 2024-2026 SCLE-CSES. Governed by the SCLE License 1.0; the
full text of which is contained in the file Licence.txt included in
NetDisq packages. TODO: convertir en donn�es relationnelles (SQL).
*/

#include "Fichier.h" 
#include "Doa.h"
#include "NWService.h"
#include "NWKeys.h"
#include "NWSData.h"
#include "NWMData.h"

static char gCnfMEthxDb[MAX_PATH] = {0}; byte gMPasse[MAX_PASSWORD] = {0};

NTSTATUS initChemKeysNd(const char codUtil[], int nc, BOOL bV�rifCypDll)
{
    char cnfCl�[MAX_PATH] = {0}; const char* SD = S�PAR_DIR; HMODULE hmCDll;
    char* chMod = getCheminModule(); sprintf(cnfCl�, FMT_CHEM_KEYS, chMod, 
        SD, nc, codUtil, SD, NOM_CYPTUR_DLL); setChemCypturDll(cnfCl�);
    if (bV�rifCypDll)
    {   // Ouvrable ?
        hmCDll = getCypturDll(); ND_ASSERT_CS(hmCDll, ERR_OBJECT_INIT);
        finCypturDll(NULL);
    }        
    sprintf(cnfCl�, FMT_CHEM_KEYS, chMod, SD, nc, codUtil, SD, NOM_DAA_DLL);
    setChemDaaDll(cnfCl�); sprintf(cnfCl�, FMT_CHEM_KEYS, chMod, SD, nc,
        codUtil, SD, NOM_KEYSPACE_ND); setChemSmartkeyNd(cnfCl�);
ERR:/*FIN*/ return gNDR�sultat;
}

void setChemMEthxDb(const char codUtil[], int nc)
{    
    if ((gCnfMEthxDb[0] == EOL) || (nc > 0))
    {
        sprintf(gCnfMEthxDb, FMT_CHEM_KEYS, getCheminModule(), S�PAR_DIR, 
            nc, codUtil, S�PAR_DIR, NOM_ETHX_DB);
    }
}

NTSTATUS renommerDossierCl�s0(const char codUtil[], int i)
{
    int r = 0; char cnfDaaDll0[MAX_PATH] = {0}, cnfDaaDllI[MAX_PATH] = {0},
        cnfCypDll0[MAX_PATH] = {0}, cnfCypDllI[MAX_PATH] = {0},
        cnfSk0[MAX_PATH] = {0}, cnfSkI[MAX_PATH] = {0},
        cnfEthxDb0[MAX_PATH] = {0}, cnfEthxDbI[MAX_PATH] = {0},
        chemCl�s[MAX_PATH] = {0}, *chMod = getCheminModule(); 
    sprintf(chemCl�s, "%s%s.%d.%s", chMod, S�PAR_DIR, i, codUtil);
    cr�erDossiers(chemCl�s, FALSE);
    {
        const int EFW = ERR_FILE_WRITE;
        r = initChemKeysNd(codUtil, 0, TRUE); ND_ASSERT_S(r);
        strcpy(cnfDaaDll0, getChemDaaDll());
        strcpy(cnfCypDll0, getChemCypturDll()); strcpy(cnfSk0, 
            getChemSmartkeyNd()); setChemMEthxDb(codUtil, 0);
        strcpy(cnfEthxDb0, gCnfMEthxDb); r = initChemKeysNd(codUtil, i, FALSE);
        ND_ASSERT_S(r); strcpy(cnfDaaDllI, getChemDaaDll());
        strcpy(cnfCypDllI, getChemCypturDll()); strcpy(cnfSkI, 
            getChemSmartkeyNd()); setChemMEthxDb(codUtil, i);
        strcpy(cnfEthxDbI, gCnfMEthxDb); 
        r = renommerFichier(cnfDaaDll0, cnfDaaDllI); ND_ASSERT_CS(r, EFW);
        r = renommerFichier(cnfCypDll0, cnfCypDllI); ND_ASSERT_CS(r, EFW);
        r = renommerFichier(cnfSk0, cnfSkI); ND_ASSERT_CS(r, EFW);
        r = renommerFichier(cnfEthxDb0, cnfEthxDbI); ND_ASSERT_CS(r, EFW);
    }
ERR:/*FIN*/ if ( ! NT_SUCCESS(gNDR�sultat)){ RemoveDirectoryA(chemCl�s); }
    sprintf(chemCl�s, "%s%s.%d.%s", chMod, S�PAR_DIR, 0, codUtil); 
    RemoveDirectoryA(chemCl�s); return gNDR�sultat;
}

byte* getLocalPassword()
{
    FILE* fichier = NULL; char txt[DIM_256], *lect = NULL;
    if ( ! existe(gCnfMEthxDb)){ return NULL; }
    fichier = fopen(gCnfMEthxDb, "r"); if ( ! fichier){ return NULL; }
    lect = fgets(txt, MLN, fichier); if (lect){ strcpy(ND_CC(gMPasse), 
        trim(txt + NCARSUTIL + 1)); } if (fichier){ fclose(fichier); } 
    return gMPasse;
}

void init0Passw(){ init0(gMPasse, sizeof(gMPasse)); }