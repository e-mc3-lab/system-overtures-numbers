/*
 Legal Notice: Some portions of the source code contained in this file were
 derived from the source code of Encryption. Modifications and additions to
 the original source code (contained in this file), and all other portions
 of this file are Copyright(c) 2024-2026 'SCLE/CSES'. These are
 also governed by the SCLE License; the full text of which is contained
 in the file Licence 1.0.txt included in NetDisq distribution packages. 
 */

#include "Memoire.h"
#include <commctrl.h>
#include "MotDePasse.h"
#include "Random.h"
#include "ErreurDict.h"
#include "Language.h"
#include "Fichier.h"
#include "ProcesSpace.h"
#include "Cmdline.h"
#include "Doa.h"
#include "Cyptur.h"
#include "Forms.h"
#include "NWKeys.h"
#include "NWMData.h"
#include "NWService.h"
#include "NWModule.h"

LRESULT CALLBACK MainWndProc(HWND, UINT, WPARAM, LPARAM);
LPARAM CALLBACK DialogueDocument(HWND, UINT, WPARAM, LPARAM);
LPARAM CALLBACK DialogueOptions(HWND, UINT, WPARAM, LPARAM);
void set�tatMenuOuvrir(BOOL activ); void quitter();

HINSTANCE ghInst; static HWND gWndG = NULL, gFrmD = NULL;
DOCUMENT_ND gDnd = {0}; static CONTEXTE_VOLUME gCv = {0}; uint8 gNbEssais = 0;
HCURSOR ghCursor = NULL; BOOL bEstAuthentifi� = FALSE;
static char gTabUtils[DIM_256][NCARSUTIL + 1] = {0};
static char gConfig[DIM_8 + 1] = { MOT_CONFIG_RELEASE };
WCHAR MOT_CHIFFRER[DIM_16] = {0}, MOT_DECHIFFRER[DIM_16] = {0};


BOOL estMotDePasseValide(char mpass[])
{
    ENTIER lmdp = STRLEN(mpass); if ((lmdp < PASSWORD_LEN_MIN_WARNING) ||
        (lmdp > MAX_PASSWORD)){ return FALSE; }
    if ((GetKeyState(VK_CAPITAL) & 1) != 0)
    {
        Warning("CAPSLOCK_ON"); return FALSE;
    }
    if (estEnMajuscules(mpass))
    {
        Warning("MOT_DE_PASSE_MAJUSCULES"); return FALSE;
    } 
    return TRUE; // TODO: ne pas accepter d'espace.
}

void set�tatMenuOuvrir(BOOL activ)
{
    HMENU gmn = GetMenu(gWndG); const int POS_SOUS_MENU_OUVRIR = 0;
    HMENU mno = GetSubMenu(gmn, POS_SOUS_MENU_OUVRIR);
    EnableMenuItem(mno, IDM_OUVRIR_FICHIER, (activ ? MF_ENABLED : MF_DISABLED));
}

void set�tatFormNouvDoa(HWND hFrm, BOOL b)
{
    gDnd.bTraitementEnCours = ( ! b);
    if (b){ NormalCursor(); } else { WaitCursor(); }
    HWND btn = GetDlgItem(hFrm, IDOK); if (btn){ EnableWindow(btn, b); }
    btn = GetDlgItem(hFrm, IDCANCEL); if (btn){ EnableWindow(btn, b); }
}

void set�tatBoutonChiffrement(HWND hFrm, BOOL b){
    HWND btn = GetDlgItem(hFrm, IDB_CHIFFRE); if (btn){ EnableWindow(btn, b); }
}

void setTxtBoutonChiffrement(HWND hFrm, BOOL b){    
    SetDlgItemText(hFrm, IDB_CHIFFRE, (b ? MOT_DECHIFFRER : MOT_CHIFFRER));
}

void set�tatBoutonEnregistrer(HWND hFrm, BOOL b)
{
    HWND btn = GetDlgItem(hFrm, IDB_ENREGISTRER); if (btn)
    {
        if (NT_SUCCESS(gNDR�sultat)){ EnableWindow(btn, b); }
    }
}

// Lib�rer le tableau des 'ciphers' et autres ..:
void quitter()
{   
    finCypturDll(&gCv); finListeFilEx(); init0(&gCv.mpass, DIM_MP);
    UnloadLanguageFile(); NDV�riRefsOubli�es(FALSE);
}

// PRE: gDnd.poign�e n'est pas � NULL.
DWORD getTailleViaFichier(DWORD dm0) 
{   
    HANDLE hf = gDnd.poign�e; DWORD dm = dm0, nbCars = DIM_64, nbLus, i = 0;
    LARGE_INTEGER dimF = {0}; dimF.QuadPart = dm - DIM_64;
    char tab[DIM_64] = {0}, tab16[DIM_16] = {0}; BOOL bLecture = TRUE; 
    ND_ASSERT_CS(SetFilePointerEx(hf, dimF, NULL, FILE_BEGIN),
        ERR_FILE_READ); bLecture = ReadFile(hf, tab, nbCars, &nbLus, NULL);
    ND_ASSERT_CS(bLecture, ERR_FILE_READ); // La taille est-elle � la fin ?
    if ( ! estVide100(ND_CB(tab), DIM_32)){ ND_FIN(); } 
    memcpy(tab16, tab + DIM_32, DIM_16); i = atol(tab16); // Revenir au d�but:
    ND_ASSERT_CS(i > 0, ERR_INSUCC�S); dm = i; ND_FIN(); ERR:dm = dm0; 
FIN:dimF.QuadPart = 0; SetFilePointerEx(hf, dimF, NULL, FILE_BEGIN); return dm;
}

NTSTATUS setTailleInitialeFichier(HANDLE hf, DWORD totalMultiplUD)
{
    DWORD nb�crits = DIM_64; DWORD dm = 0; char tab[DIM_64] = {0}; 
    LARGE_INTEGER dimF = {0}; dm = getTailleViaFichier(gDnd.taille);
    if ( ! gDnd.bChiffr�) // UD: Unit� de Donn�es.
    {
        dimF.QuadPart = dm; ND_ASSERT_CS(SetFilePointerEx(hf, dimF, NULL, 
            FILE_BEGIN), ERR_FILE_WRITE); ND_ASSERT_CS(SetEndOfFile(hf), 
                ERR_FILE_WRITE); ND_FIN();
    } 
    dimF.QuadPart = totalMultiplUD; // Se positionner � la fin (divise 512).
    ND_ASSERT_CS(SetFilePointerEx(hf, dimF, NULL, FILE_BEGIN), ERR_FILE_READ); 
    sprintf(tab + DIM_32, "%0I64d", UI64(dm)); // �crire la taille du fichier
    if ( ! WriteFile(hf, tab, nb�crits, &nb�crits, NULL) || // non chiffr�.
        (nb�crits != DIM_64)){ ND_ASSERT_S(ERR_FILE_WRITE); } 
    ND_FIN();
ERR:journaliser("Erreur setTailleViaFichier %d (%d).", gNDR�sultat, gNoLigne);
FIN:return gNDR�sultat;
}

NTSTATUS ouvrirFichier(const char cnf[])
{
    HANDLE hf = NULL; DWORD dm = 0; hf = CreateFileA(cnf, GENERIC_READ, 0, NULL,
        OPEN_EXISTING, 0, NULL); ND_ASSERT_CS(hf && (hf != INVALID_HANDLE_VALUE),
            ERR_FILE_OPEN); gDnd.poign�e = hf; dm = getTailleFichier(hf);
    ND_ASSERT_CS((dm > 0), ERR_FILE_READ); gDnd.taille = getTailleViaFichier(dm);
    ND_ASSERT_CS((gDnd.taille > 0), ERR_FILE_READ); gDnd.bEnregistr� = FALSE;
    ERR:/*FIN*/ return gNDR�sultat;
}

NTSTATUS lireSegment2048(DWORD nbCars, BOOL bBoucle)
{   
    HANDLE hf = gDnd.poign�e; DWORD dm = 0; DWORD nbLus = 0; BOOL bl = TRUE; 
    DWORD nc = (bBoucle ? MC : min(nbCars, MC + DIM_64 - UN64));
    memset(gDnd.contenu, 0, UI64(nc) + UN64); bl = ReadFile(hf, gDnd.contenu, 
        nc, &nbLus, NULL); ND_ASSERT_CS(bl, ERR_FILE_READ); 
    if (nbLus == 0){ gNDR�sultat = FIN_FICHIER; } ND_FIN(); 
ERR:journaliser("Erreur lireSegment2048 %d (%d).", gNDR�sultat, gNoLigne); 
FIN:return gNDR�sultat;
}

void setVides0(byte a[]) // TODO: cause un probl�me � l'affichage...
{   // Remplacer les cars. 0 par un espace.
    const int N = gDnd.bChiffr� ? MC : min(gDnd.taille, MC);
    for (int i = 0; i < N; i++){ if (a[i] == EOL){ a[i] = ' '; } }
}

BOOL estChiffr�(const char txt[])
{
    BOOL r�sultat = FALSE; char v�riTxt[MAX_PATH] = {0};
    ENTIER M = STRLEN(SUFX_ND), N = STRLEN(txt) - M - 1;
    if (txt && (N > 0) && (N + 1 < MAX_PATH))
    {   
        // TODO: actuellement, un utilisateur ne peut pas avoir plus de
        memcpy(v�riTxt, (txt + N), M); v�riTxt[M] = EOL; // 9 comptes.
        r�sultat = (_strcmpi(v�riTxt, SUFX_ND) == 0);
        r�sultat = r�sultat && isdigit(txt[N + 3]);
    }
    return r�sultat;
}

NTSTATUS ouvrirFormDocument(BOOL bAfficher)
{
    NTSTATUS r = 0; byte* mpass = gCv.nwModule.util.mpassd.texte;
    OPENFILENAME dlgf = {0}; dlgf.lStructSize = sizeof(dlgf);
    dlgf.nMaxFile = MAX_PATH; DWORD t = 0; dlgf.Flags = OFN_EXPLORER |
        OFN_PATHMUSTEXIST; dlgf.lpstrFile = gDnd.wcnf;
    dlgf.lpstrFilter = L"(*)\0"; dlgf.hwndOwner = gWndG; HWND hWnd = NULL;
    HWND hwcMdp = NULL; if ( ! GetOpenFileName(&dlgf)){ return FALSE; }
    const char* cnf = constEnCCHAR(dlgf.lpstrFile, MAX_PATH);
    ND_ASSERT_CS(estSuffixeFichierValide(cnf), ERR_INVALID_FILE);
    if (estChiffr�(cnf) &&
        (cnf[strlen(cnf) - 1] != char(gCv.nwModule.util.noInscrip + 0x30))){
        ND_ASSERT_S(ERR_INVALID_FILE);
    }
    hWnd = CreateDialog(ghInst, MAKEINTRESOURCE(IDD_DOCUMENT),
        gWndG, DialogueDocument); SetWindowText(hWnd, gDnd.wcnf);
    SendMessage(GetDlgItem(hWnd, IDC_SUR_DISQUE), BM_SETCHECK, TRUE, 0);
    SetDlgItemText(hWnd, IDC_SUR_DISQUE, GetString("IDC_SUR_DISQUE"));
    SetDlgItemText(hWnd, IDT_MOTDEPASSE, GetString("IDT_MOTDEPASSE"));
    SetDlgItemText(hWnd, IDB_CHIFFRER, GetString("IDC_ENCRYPT"));
    SetDlgItemText(hWnd, IDB_ENREGISTRER, GetString("IDB_ENREGISTRER"));
    SetDlgItemText(hWnd, IDCANCEL, GetString(IDL_FERMER));
    r = ouvrirFichier(cnf); ND_ASSERT_S(r); gDnd.bChiffr� = estChiffr�(cnf);
    t = (gDnd.bChiffr� ? MC : gDnd.taille); r = lireSegment2048(t, FALSE);
    ND_ASSERT_S(r); fermerFichier(&gDnd.poign�e); SetDlgItemTextA(hWnd,
        IDC_TEXTE, ND_CC(gDnd.contenu)); mpass = getLocalPassword();
    hwcMdp = GetDlgItem(hWnd, IDC_MOTDEPASSE); if (STRLEN(mpass) > 0)
    {
        SetDlgItemTextA(hWnd, IDC_MOTDEPASSE, ND_CC(mpass)); if (bAfficher)
        {
            SendMessage(hwcMdp, EM_SETPASSWORDCHAR, NULL, 0);
            InvalidateRect(hwcMdp, NULL, TRUE);
        }
        EnableWindow(hwcMdp, FALSE);
        HWND hwChiffre = GetDlgItem(hWnd, IDB_CHIFFRE); SetFocus(hwChiffre);
    } else { SetFocus(hwcMdp); } gDnd.bEnregistr� = FALSE;
    setTxtBoutonChiffrement(hWnd, gDnd.bChiffr�);
    set�tatMenuOuvrir(FALSE); /*:modalisation:*/ ShowWindow(hWnd, SW_NORMAL);
    ND_FIN(); ERR:r = gNDR�sultat; journaliser("Erreur ouvrirFormDocument %d "
        "(%d).", gNDR�sultat, gNoLigne); traiterErreurDict(r);
FIN:EnableWindow(GetDlgItem(hWnd, IDB_ENREGISTRER), FALSE);
    fermerFichier(&gDnd.poign�e); return r;
}

BOOL estTraitementEnCours()
{
    if (gDnd.bTraitementEnCours) 
    {
        if (poserQuestionAttentionOuiNon(GetString("MSG_STOP_EXEC")) == IDYES)
        {
            gDnd.bTraitementEnCours = FALSE; gDnd.stilde = NULL;
            TCSleep(1000); return FALSE;
        }
        return TRUE;
    } return FALSE;
}

BOOL estNum�roGagnant(){ return getNombreAl�atoire(6) == 4; }

int getComptesUtilisateur()
{
    const char DOT[] = ".", DOT2[] = ".."; char chemMod[MAX_PATH] = {0};
    WIN32_FIND_DATAA wFD; HANDLE fRech = NULL; int i = 0;
    sprintf(chemMod, "%s%s.*", getCheminModule(), S�PAR_DIR);
    fRech = FindFirstFileA(chemMod, &wFD); init0(gTabUtils, 
        sizeof(gTabUtils)); if (fRech != INVALID_HANDLE_VALUE)
    {
        do
        {
            if ( ! (strcmp(wFD.cFileName, DOT) == 0) &&
                 ! (strcmp(wFD.cFileName, DOT2) == 0) &&
                   (wFD.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY)){
                strcpy(gTabUtils[i++], (wFD.cFileName + 3)); // Sans '.' et ch.
            }
        } while (FindNextFileA(fRech, &wFD)); FindClose(fRech);
    }
    return i;
}

NTSTATUS inscrireUtilisateur(int nc)
{
    int r = STATUS_SUCCESS, j = 0; char argv[DIM_8][DIM_64] = {0};
    strcpy(argv[j++], "/" PARAM_SRC_PRG); strcpy(argv[j++], MOT_SOURCE_MODULE);
    strcpy(argv[j++], "/" PARAM_NOUV_UTIL);
    strcpy(argv[j++], "/" PARAM_CONFIG); strcpy(argv[j++], gConfig);
    r = ex�cuterCommandeNws(j, argv); if (NT_SUCCESS(r))
    {
        byte* contenu = getR�ponseCmd(); if (contenu)
        {
            char *chMod = getCheminModule(), *codUtil = gCv.nwModule.util.code,
                *msg = ND_CC(contenu); if (estMessageCmdSucc�s(msg))
            { 
                strcpy(codUtil, msg + strlen(MOT_ID_MESSAGE) + 3);
                r = renommerDossierCl�s0(codUtil, nc);
            } else { r = atoi(msg + DIM_MOT_ID_ERR + 3); } // TODO
        } else { r = ERR_OBJET_�_NULL; }
    } 
    finR�ponseCmd(); return r;
}

NTSTATUS confirmInscription(UTILISATEUR* util)
{
    int r = STATUS_SUCCESS, i = 0; char argv[DIM_8][DIM_64] = {0};
    strcpy(argv[i++], "/" PARAM_SRC_PRG); strcpy(argv[i++], MOT_SOURCE_MODULE);
    strcpy(argv[i++], "/" PARAM_CONFIRM_INSC); strcpy(argv[i++], util->code);
    strcpy(argv[i++], "/" PARAM_CONFIG); strcpy(argv[i++], gConfig);
    r = ex�cuterCommandeNws(i, argv); if (NT_SUCCESS(r))
    {
        byte* contenu = getR�ponseCmd(); if (contenu)
        {
            char* msg = ND_CC(contenu); if (estMessageCmdSucc�s(msg)){
                afficherInfo(GetString("MSG_SUBSCRIPTION_SUCCESS"));
            } else { r = atoi(msg + DIM_MOT_ID_ERR + 3); }
        } else { r = ERR_OBJET_�_NULL; }
    }
    finR�ponseCmd(); return r;
}

int choisirAuHasard(int nc, char codUtil[])
{
    uint j = getNombreAl�atoire(nc);
    strcpy(gCv.nwModule.util.code, gTabUtils[j]); j++;
    NTSTATUS r = initChemKeysNd(codUtil, j, TRUE);
    if ((r == ERR_OBJECT_INIT) || (r == ERR_INVALID_INIT))
    {
        char chemMod[MAX_PATH] = {0}; sprintf(chemMod, "%s%s.1.%s",
            getCheminModule(), S�PAR_DIR, gTabUtils[0]);
        if (existe(chemMod))
        {
            if (codUtil && (codUtil[0] == EOL))
            {
                strcpy(codUtil, gTabUtils[0]);
                strcpy(gCv.nwModule.util.code, codUtil);
                r = initChemKeysNd(codUtil, j, TRUE);
            }
        } else {
            journaliser("choisirAuHasard: dossier invalide .%d.", j);
        }
    }
    if (j == 0){ j = 1; }  
    if ( ! NT_SUCCESS(r)){ j = r; } return j;
}

NTSTATUS initInfosUtilNwm()
{      
    int r = STATUS_SUCCESS; char* codUtil = gCv.nwModule.util.code;
    HMODULE hmCDll = NULL; int nc = getComptesUtilisateur();
    if (nc > 0)
    {
        if (estNum�roGagnant()) // Variabilit� pour les essais.
        {
            r = inscrireUtilisateur(++nc);
            if (NT_SUCCESS(r)){ r = confirmInscription(&gCv.nwModule.util); }            
            if ( ! NT_SUCCESS(r))
            {
                nc = choisirAuHasard(--nc, codUtil); ND_ASSERT_S(nc);
            }
        } else { nc = choisirAuHasard(nc, codUtil); ND_ASSERT_S(nc); }
    } else { 
        nc = 1; r = inscrireUtilisateur(nc); ND_ASSERT_S(r);
        r = confirmInscription(&gCv.nwModule.util); ND_ASSERT_S(r);
    }
    gCv.nwModule.util.noInscrip = nc; setChemMEthxDb(codUtil, nc);
ERR:if (gNDR�sultat == ERR_OBJECT_INIT){ ND_JOURNALISER_ERREUR(NOM_NW_MODULE); }
    return gNDR�sultat;
}

LRESULT CALLBACK MainWndProc(HWND hWnd, UINT message, 
    WPARAM wParam, LPARAM lParam) // Messages applicatifs.
{
    gNDR�sultat = ERR_SUCCESS; int wmId = LOWORD(wParam);
    if ( ! gWndG){ gWndG = hWnd; } switch (message)
    {
    case WM_COMMAND: // Menus.
    {
        switch (wmId)
        {
        case IDM_OUVRIR_FICHIER:
        {
            if (existe(getChemDaaDll()))
            {
                BOOL bAfficher = LOWORD(lParam);
                gNDR�sultat = ouvrirFormDocument(bAfficher);
            } else {
                afficherAttention(GetString("ERR_DAA_INTROUVABLE"));
            }
        } break;

        case IDM_OPTIONS: {
            DialogBox(ghInst, MAKEINTRESOURCE(IDD_OPTIONS), hWnd,
                DialogueOptions);
        } break;

        case IDM_AIDE: 
        {
            WORD iddAide = IDD_AIDE_EN;
            if (isLangFr()){ iddAide = IDD_AIDE_FR; } 
            DialogBox(ghInst, MAKEINTRESOURCE(iddAide), hWnd, DialoguAide);
        } break;

        case IDM_FERMER: 
            if ( ! estTraitementEnCours()){ DestroyWindow(hWnd); } break;

        default:
            gNDR�sultat = (NTSTATUS)DefWindowProc(hWnd, message, 
                wParam, lParam); break;
        }
    }
    break;

    case WM_PAINT: 
    {
        PAINTSTRUCT ps = {0}; HDC hdc = BeginPaint(hWnd, &ps); 
        EndPaint(hWnd, &ps);
    } break;

    case WM_DESTROY: 
    {
        quitter(); PostQuitMessage(0);
    }  break;

    default: // NB: ne pas utiliser cette fonction en param�tre de ND_ASSERT_CS.
        gNDR�sultat = (NTSTATUS)DefWindowProc(hWnd, message, wParam, lParam);
    }
    return gNDR�sultat;
}

HWND initTraitementChiffre(HWND hFrm, const ENTIER N)
{
    HWND hwProgsBar = GetDlgItem(hFrm, IDC_PROGRESS_BAR);
    if ( ! hwProgsBar){ return NULL; } gDnd.bTraitementEnCours = TRUE; 
    WaitCursor(); SendMessage(hwProgsBar, PBM_SETRANGE32, 1, N);
    ShowWindow(hwProgsBar, SW_SHOW); SendMessage(hwProgsBar, 
        PBM_SETSTEP, 1, 0); InvalidateRect(hwProgsBar, NULL, TRUE); 
    HWND hwcDisque = GetDlgItem(hFrm, IDC_SUR_DISQUE);
    if (hwcDisque){ ShowWindow(hwcDisque, SW_HIDE); } return hwProgsBar;
}

void finTraitementChiffre(HWND hFrm, HWND hwProgsBar)
{
    if (hwProgsBar){ ShowWindow(hwProgsBar, SW_HIDE); }
    HWND hwcDisque = (hFrm ? GetDlgItem(hFrm, IDC_SUR_DISQUE) : NULL);
    if (hwcDisque){ ShowWindow(hwcDisque, SW_SHOW); }
    gDnd.bTraitementEnCours = FALSE; NormalCursor();
}

uint32 getNbUnit�s(DWORD taille)
{   
    // Le r�sultat est 4 ou moins.
    const DWORD M = taille / UDM, RE = taille % UDM; 
    uint32 result = M + (RE > 0 ? 1 : 0); 
    result = min(result, MC / UDM); return result;
}

void fxChiffrerDocument(void* arg)
{
    NTSTATUS r = ERR_SUCCESS; HWND hwcMdp = NULL, hFrm = (HWND)gFrmD;
    INFO_CRYPTO* ci = NULL; uint idUnit = 0; char mpass[MAX_PATH] = {0};
    byte tab0[UDM] = {0}, tab1[UDM] = {0}, *tab = NULL; uint32 nbUnits;
    DWORD t, M = gDnd.taille / MC, RE = gDnd.taille % MC; t = gDnd.taille;
    const char SD[] = S�PAR_DIR; char* cnf = convEnCCHAR(gDnd.wcnf, MAX_PATH);
    HMODULE hmCDll = NULL; gDnd.bChiffr� = estChiffr�(cnf);
    EncryptUnits fcEncryptUnits = NULL; DecryptUnits fcDecryptUnits = NULL;
    const int EII = ERR_INVALID_INIT; if (gDnd.bEnregistr�) // Actualiser:
    {   
        r = ouvrirFichier(cnf); ND_ASSERT_S(r);
        r = lireSegment2048((gDnd.bChiffr� ? MC : t), FALSE); ND_ASSERT_S(r);
        fermerFichier(&gDnd.poign�e);
    }
    if (gDnd.bChiffr� && RE > 0){ gDnd.taille = MC; M = 1; RE = 0; }
    set�tatBoutonEnregistrer(hFrm, FALSE);
    hwcMdp = GetDlgItem(hFrm, IDC_MOTDEPASSE); EnableWindow(hwcMdp, FALSE); 
    GetWindowTextA(hwcMdp, mpass, MAX_PATH); 
    strcpy(ND_CC(gCv.nwModule.util.mpassd.texte), mpass); 
    gCv.nwModule.util.mpassd.longueur = UI16(strlen(mpass));
    ND_ASSERT_CS(estMotDePasseValide(mpass), ERR_MOTPASSE_INVALIDE);
    strcpy(gCv.nwModule.chemKeyNd, getChemSmartkeyNd()); WaitCursor();
    ND_ASSERT_CS(existe(gCv.nwModule.chemKeyNd), ERR_KEYFILE_NOT_FOUND);
    set�tatBoutonChiffrement(hFrm, FALSE); if ( ! bEstAuthentifi�)
    {
        r = nwAuthentifier(&gCv); if ( ! NT_SUCCESS(r) && 
            (r != ERR_DONT_REPORT)){ ND_ASSERT(r); } bEstAuthentifi� = TRUE;
    } 
    hmCDll = getCypturDll(); ND_ASSERT_CS(hmCDll, EII);
    fcEncryptUnits = (EncryptUnits)GetProcAddress(hmCDll,
        NOM_FCT_ENCRYPT_UNITS); ND_ASSERT_CS(fcEncryptUnits, EII);
    fcDecryptUnits = (DecryptUnits)GetProcAddress(hmCDll,
        NOM_FCT_DECRYPT_UNITS); ND_ASSERT_CS(fcDecryptUnits, EII);
    EnableWindow(hwcMdp, FALSE); gNbEssais = 0; ci = &gCv.ci;
    ci->mode = XTS; nbUnits = getNbUnit�s(gDnd.taille);
    tab = gDnd.contenu; memcpy(tab0, gDnd.contenu, UDM);
    if (gDnd.bChiffr�)
    {
        fcDecryptUnits(tab, idUnit, nbUnits, ci);
    } else {
        fcEncryptUnits(tab, idUnit, nbUnits, ci);
    }
    ND_ASSERT_S(ci->r�sultat); gDnd.bChiffr� = ( ! gDnd.bChiffr�); 
    memcpy(tab1, gDnd.contenu, UDM); if (gDnd.bChiffr�)
    {   
        // Validation sommaire:
        fcDecryptUnits(tab1, idUnit, 1, ci); ND_ASSERT_S(ci->r�sultat); 
        ND_ASSERT_CS((comparerMem(tab0, tab1, UDM, FALSE) == 0),
            ERR_CHIFFREMENT_INVALIDE); gDnd.bChiffr� = TRUE;
        if ( ! estChiffr�(cnf)){ sprintf(cnf, "%s%s%d", cnf, SUFX_ND, 
            gCv.nwModule.util.noInscrip); }        
    } else {
        fcEncryptUnits(tab1, idUnit, 1, ci); ND_ASSERT_S(ci->r�sultat);
        ND_ASSERT_CS((comparerMem(tab0, tab1, UDM, FALSE) == 0),
            ERR_CHIFFREMENT_INVALIDE); gDnd.bChiffr� = FALSE;
        if (estChiffr�(cnf)){ cnf = getNomSansSuffixe(cnf); }
    }  
    SetWindowTextA(hFrm, cnf); wsprintfW(gDnd.wcnf, L"%ls", convEnWCHAR(cnf));
    if (gDnd.bChiffr�){ gDnd.contenu[MC] = EOL; }
    else { gDnd.contenu[min(t, MC)] = EOL; }
    set�tatBoutonChiffrement(hFrm, FALSE);
    SetDlgItemTextA(hFrm, IDC_TEXTE, ND_CC(gDnd.contenu)); ND_FIN();
ERR:r = gNDR�sultat; traiterErreurDict(r);
    journaliser("Erreur NWModule-Main %d (%d).", gNDR�sultat, gNoLigne);
    if (gNbEssais >= 3)
    { 
        afficherInfo(GetString("ERR_CHIFFRER_DOCUMENT")); TCSleep(10*60*1000);
    }
FIN:gNbEssais = 0; fermerFichier(&gDnd.poign�e); NormalCursor();
    if (existe(cnf)){ set�tatBoutonEnregistrer(hFrm, FALSE); }
    else { set�tatBoutonEnregistrer(hFrm, TRUE); }
}

void genCaract�resAl�atoires(byte tab[], uint i) // PRE: i < MC.
{
    uint m = getNombreAl�atoire(MAXENTIER64 / 80);
    for (uint j = i; j < MC; j++){ tab[j] = (byte)((m + 1) * randx()); }
}

void fxEnregistrer(void* arg)
{
    NTSTATUS r = ERR_SUCCESS; HANDLE hf = NULL; HWND hFrm = (HWND)arg;
    const ENTIER UD = UDM; HWND hwProgsBar = NULL; ENTIER i = 0, j = 0, PAS = 1;
    DWORD taille; const uint32 NBU = MC / UD; char cnfLe[MAX_PATH] = {0},
        cnfEc[MAX_PATH] = {0}, cnf[MAX_PATH] = {0}; byte* tab; ENTIER nhbar;
    DWORD nb�crits = MC, tlNb�cr = 0, M = 0, RE = 0; uint idUnit = 0;
    CRYPTO_INFO* ci = &gCv.ci; strcpy(cnfEc, convEnCCHAR(gDnd.wcnf, MAX_PATH));
    BOOL bChiffr� = FALSE; char* txt; sprintf(cnf, "%s~", cnfEc);    
    EncryptUnits fcEncryptUnits = NULL; DecryptUnits fcDecryptUnits = NULL;
    const int EII = ERR_INVALID_INIT; HMODULE hmCDll = NULL;
    if (existe(cnf)){ supprimerFichier0(cnf); } 
    hf = CreateFileA(cnf, GENERIC_WRITE, FILE_SHARE_READ | FILE_SHARE_WRITE, 
        NULL, CREATE_NEW, 0, NULL); 
    ND_ASSERT_CS(hf != INVALID_HANDLE_VALUE, ERR_INVALID_FILE); 
    ND_ASSERT_CS(arg, ERR_INVALID_INIT); if (existe(cnfEc))
    {
        WCHAR msg[MAX_LONGUEUR_MSG] = {0}; wsprintfW(msg,
            GetString("CONFIRM_REMPLACE_FICHIER"),
            convEnWCHAR(getDernierNom(cnfEc))); 
        if (poserQuestionOuiNon(msg) == IDYES){ supprimerFichier0(cnfEc); }
        else { ND_FIN(); }
    }
    hmCDll = getCypturDll(); ND_ASSERT_CS(hmCDll, EII);
    fcEncryptUnits = (EncryptUnits)GetProcAddress(hmCDll,
        NOM_FCT_ENCRYPT_UNITS); ND_ASSERT_CS(fcEncryptUnits, EII);
    fcDecryptUnits = (DecryptUnits)GetProcAddress(hmCDll,
        NOM_FCT_DECRYPT_UNITS); ND_ASSERT_CS(fcDecryptUnits, EII);
    set�tatBoutonEnregistrer(hFrm, FALSE); strcpy(cnfLe, cnfEc); 
    if (gDnd.bChiffr� && estChiffr�(cnfLe))
    {   
        // Mise � jour:
        txt = getNomSansSuffixe(cnfLe); strcpy(cnfLe, txt); 
    } else { 
        sprintf(cnfLe, "%s%s%d", cnfEc, SUFX_ND, gCv.nwModule.util.noInscrip);
        bChiffr� = TRUE;
    }
    r = ouvrirFichier(cnfLe); ND_ASSERT_S(r); gDnd.stilde = hf;
    taille = gDnd.taille; M = (taille / MC), RE = taille % MC;
    nhbar = UI64(M) + UI64(RE > 0 ? 1 : 0); if (M > MAXENTIER32)
    {
        nhbar = MAXENTIER32; PAS = ((M + uint64(1.3 * RE)) / MAXENTIER32);
    }
    hwProgsBar = initTraitementChiffre(hFrm, nhbar);
    ND_ASSERT_CS(hwProgsBar, ERR_OBJET_�_NULL);
    for (i=0; i < M && M > 0 && gDnd.bTraitementEnCours; i++)
    {
        r = lireSegment2048(MC, TRUE); if (r != FIN_FICHIER){ ND_ASSERT_S(r); }
        tab = gDnd.contenu; if (gDnd.bChiffr�){
            fcEncryptUnits(tab, idUnit, NBU, ci);
        } else {
            fcDecryptUnits(tab, idUnit, NBU, ci);
        }
        ND_ASSERT_S(ci->r�sultat);
        if (PAS > 1){ if (i % PAS == 0){ j++; } } else { j++; }
        if ( ! WriteFile(hf, tab, nb�crits, &nb�crits, NULL) || 
            (nb�crits != MC)){ ND_ASSERT_S(ERR_FILE_WRITE); }
        tlNb�cr += nb�crits; memset(gDnd.contenu, 0, MC);
        SendMessage(hwProgsBar, PBM_SETPOS, j, 0);
    }
    if (RE > 0 && gDnd.bTraitementEnCours)
    {   
        // �crire les caract�res de fin.
        uint32 nbUnits = getNbUnit�s(RE); const BOOL F = FALSE;
        tab = gDnd.contenu; if (gDnd.bChiffr�)
        {
            r = lireSegment2048(RE, F); if (r != FIN_FICHIER){ ND_ASSERT_S(r); }
            genCaract�resAl�atoires(tab, RE); fcEncryptUnits(tab, idUnit,
                nbUnits, ci); nb�crits = (nbUnits * UD);
        } else {
            r = lireSegment2048(MC, F); if (r != FIN_FICHIER){ ND_ASSERT_S(r); }
            fcDecryptUnits(tab, idUnit, nbUnits, ci); nb�crits = RE;
        }
        ND_ASSERT_S(ci->r�sultat); if ( ! WriteFile(hf, tab, nb�crits,
            &nb�crits, NULL) || (nb�crits <= 0)){ ND_ASSERT_S(ERR_FILE_WRITE); }
        if (PAS > 1){ if (i % PAS == 0){ j++; } } else { j++; }
        SendMessage(hwProgsBar, PBM_SETPOS, j, 0); tlNb�cr += nb�crits;
    }
    r = setTailleInitialeFichier(hf, tlNb�cr); ND_ASSERT_S(r);
    fermerFichier(&gDnd.poign�e); fermerFichier(&hf);
    if (gDnd.stilde != NULL)
    {
        if ( ! renommerFichier(cnf, cnfEc)){ ND_ASSERT_S(ERR_FILE_WRITE); }
        gDnd.bEnregistr� = TRUE; char* txt;
        SetWindowTextA(hFrm, cnfEc); if (estChiffr�(cnfEc))
        {
            txt = getNomSansSuffixe(cnfEc); strcpy(cnfEc, txt);
        } else { sprintf(cnfEc, "%s%s%d", cnfEc, SUFX_ND,
            gCv.nwModule.util.noInscrip);
        }
        r = supprimerFichier0D(hwProgsBar, cnfEc);
        ND_ASSERT_CS(r, ERR_FILE_WRITE); // Traitement arr�t�:
    } else { r = supprimerFichier0(cnf); ND_ASSERT_CS(r, ERR_FILE_WRITE); }
    if (gDnd.bChiffr�){ setTxtBoutonChiffrement(hFrm, TRUE); }
    else { setTxtBoutonChiffrement(hFrm, FALSE); }
    set�tatBoutonChiffrement(hFrm, TRUE); ND_FIN();
ERR: r = gNDR�sultat; traiterErreurDict(r);
    journaliser("Erreur fxEnregistrer %d (%d).", gNDR�sultat, gNoLigne);
    fermerFichier(&hf); supprimerFichier0(cnf);
FIN:fermerFichier(&gDnd.poign�e); fermerFichier(&hf);
    set�tatBoutonEnregistrer(hFrm, FALSE); gDnd.stilde = NULL;
    finTraitementChiffre(hFrm, hwProgsBar);
}

LPARAM CALLBACK DialogueDocument(HWND hFrm, UINT message, WPARAM wp, LPARAM lp)
{
    UNREFERENCED_PARAMETER(lp); int wmId = LOWORD(wp); BOOL r�sultat = TRUE;
    // Formulaire 'non modal' modalis�.
    switch (message) 
    {
    case WM_INITDIALOG:
    {
        gFrmD = hFrm; ND_FIN();
    }

    case WM_COMMAND:
    {
        switch (wmId)
        {
            case IDB_CHIFFRER:
            {          
                _beginthread(fxChiffrerDocument, 0, hFrm); ND_FIN();
            } break;

            case IDB_ENREGISTRER:
            {
                _beginthread(fxEnregistrer, 0, hFrm); ND_FIN();
            } break;

            case IDOK: case IDCANCEL:
            {
                if ( ! estTraitementEnCours())
                {
                    init0Passw(); EndDialog(hFrm, wmId);
                    gFrmD = NULL; set�tatMenuOuvrir(TRUE); ND_FIN();
                }
            } break;
        }
    }
    }
    r�sultat = FALSE; 
FIN: return (LPARAM)r�sultat;
}

LPARAM CALLBACK DialogueOptions(HWND hFrm, UINT message, WPARAM wp, LPARAM lp)
{
    UNREFERENCED_PARAMETER(lp); int r = TRUE, wmId = LOWORD(wp);    
    switch (message)
    {
    case WM_INITDIALOG:
    {
        HWND hwcAdrSiteWeb = GetDlgItem(hFrm, IDC_ADR_NOM_SITE_WEB);
        HWND hwcCodeUtilisateur = GetDlgItem(hFrm, IDC_CODE_UTILISATEUR);
        HWND hwcCourriel = GetDlgItem(hFrm, IDC_COURRIEL);
        EnableWindow(hwcAdrSiteWeb, FALSE); EnableWindow(hwcCodeUtilisateur,
            FALSE); EnableWindow(hwcCourriel, FALSE);
        SetWindowText(hFrm, GetString("IDD_OPTIONS"));
        SetDlgItemText(hFrm, IDT_ADR_NOM_SITE_WEB,
            GetString("IDT_ADR_NOM_SITE_WEB"));
        SetDlgItemText(hFrm, IDT_CODE_UTILISATEUR,
            GetString("IDT_CODE_UTILISATEUR"));
        SetDlgItemText(hFrm, IDT_COURRIEL, GetString("IDT_COURRIEL"));
        SetDlgItemText(hFrm, IDCANCEL, GetString(IDL_CANCEL));
        return (LPARAM)TRUE;   
    }

    case WM_COMMAND:
    {
        switch (wmId)
        {
        case IDOK:
        {
            afficherAttention(GetString("MSG_FONCTION_NAVIG_WEB"));
            ND_ASSERT_S(ERR_DONT_REPORT);
        } break;

        case IDCANCEL:
        {
            if ( ! estTraitementEnCours())
            {
                EndDialog(hFrm, wmId); ND_FIN();
            }
        }
        }
    }
    } 
    r = FALSE; ND_FIN();
ERR:r = gNDR�sultat; journaliser("Erreur DialogueOptions %d (%d).", r,
    gNoLigne); traiterErreurDict(r);
FIN: return (LPARAM)r;
}

NTSTATUS getParam�tresCmd(WCHAR lpszCommandLine[])
{
    NTSTATUS r = EXIT_SUCCESS; char argsLigneCmd[MAX_NB_ARGS][MAX_PATH] = {0};
    uint8 idxLigneCmd = Win32CommandLine(lpszCommandLine, argsLigneCmd);
    const uint8 NO_PARAM = 2; ENTIER n = 0; if (idxLigneCmd > 0)
    {
        enum { Configuration }; Argument args[] =
        {
            { Configuration, "/configuration", "/" PARAM_CONFIG},
        };

        for (uint i = 0; i < idxLigneCmd; i++)
        {
            ArgumentSpec as; as.args = args; uint nArgPos = 0;
            as.arg_cnt = sizeof(args) / sizeof(args[0]);
            switch (GetArgumentID(&as, argsLigneCmd[i], &nArgPos))
            {
            case Configuration:
            {
                if (HAS_ARGUMENT == GetArgumentValue(argsLigneCmd,
                    0, &i, NO_PARAM, gConfig, DIM_8)){}
                setConfiguration(gConfig); break;
            }

            default: ND_ASSERT_S(ERR_ARGUMENT_INVALIDE);
            }
        }
    } else {} ND_FIN(); ERR: r = gNDR�sultat; FIN: return r;
}

int APIENTRY wWinMain(_In_ HINSTANCE hInstance, HINSTANCE hPrevInstance,
    _In_ LPWSTR arguments, _In_ int nCmdShow)
{
    UNREFERENCED_PARAMETER(hPrevInstance); MSG msg = {0}; uint uId;
    NTSTATUS r = STATUS_SUCCESS; WCHAR szWndClass[MAX_LOADSTRING] = {0};
    if ( ! LoadLanguageFile()){ ND_ASSERT_S(ERR_INVALID_INIT); }
    HACCEL hAccelTable = NULL; if (wcslen(arguments) > 0)
    {
        gNDR�sultat = getParam�tresCmd(arguments); ND_ASSERT_S(gNDR�sultat);
    }
    setParamSource(MOT_SOURCE_MODULE);
    r = initInfosUtilNwm(); ND_ASSERT_S(r);
    LoadStringW(hInstance, IDC_NETDISQ, szWndClass, MAX_LOADSTRING);
    InitWndClass(hInstance, szWndClass, MainWndProc);
    if ( ! InitWndInstance(hInstance, szWndClass, nCmdShow,
        convEnWCHAR(gCv.nwModule.util.code))){ ND_ASSERT_S(ERR_INVALID_INIT); }    
    uId = (isLangFr() ? IDM_NETDISQ_FR : IDM_NETDISQ_EN);
    LoadStringW(hInstance, uId, szWndClass, MAX_LOADSTRING);
    wcscpy(MOT_CHIFFRER, GetString(IDL_ENCRYPT));
    wcscpy(MOT_DECHIFFRER, GetString(IDL_DECRYPT));
    hAccelTable = LoadAccelerators(hInstance, MAKEINTRESOURCE(IDC_NETDISQ));
    while (GetMessage(&msg, NULL, 0, 0)) // Traitement des messages:
    {
        if ( ! TranslateAccelerator(msg.hwnd, hAccelTable, &msg)){
            TranslateMessage(&msg); DispatchMessage(&msg);
        }
    }
    ND_FIN();
ERR:traiterErreurDict(gNDR�sultat); journaliser("Erreur " 
       "wWinMain %d (%d).", gNDR�sultat, gNoLigne); quitter(); 
FIN:return r;
}