
How to integrate this project in a browser ? A user has accounts at many
places. Then he would have a folder containing the keys modules and/or
smart cards. A menu must be added to search the mounted folder, or another
folder; to save in a preferences file (navig.pref). The way for a browser
to know which is the right version would be to do the mapping between the
address or commercial name, with the CRC value of the module. A search of
the good module would be done.

Equally, read automatically words via an integrated program, would be a
practical 'Single Sign-On' (SSO) solution. The conditions of utilization
must be precised. The first is to state that a process other than the 
browser can not read the data. Also, the user code would be anonymized
by a random generation of 13 letters/digits, and saved in ethx.db.
