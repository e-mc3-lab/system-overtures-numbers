/*
Copyright(c) 2024-2026 SCLE-CSES. Governed by the SCLE License 1.0; the
text of which is contained in Licence.txt included in
NetDisq packages.
*/

#ifndef NWM_HEADER_DATA
#define NWM_HEADER_DATA

#include "Cyptur.h"
#include "Doa.h"

#define NOM_NWM_DATA        "NWMData"
#define MC                  uint64(2 * MAX_CC)

typedef struct _DOCUMENT_ND
{
    WCHAR wcnf[2 * MAX_PATH]; byte contenu[MC + DIM_64]; DWORD taille;
    HANDLE poign�e, stilde; BOOL bChiffr�, bTraitementEnCours, bEnregistr�;

} DOCUMENT_ND;

NTSTATUS initChemKeysNd(const char codUtil[], int nc, BOOL bV�rifCypDll);
void setChemMEthxDb(const char codUtil[], int nc);
NTSTATUS renommerDossierCl�s0(const char codUtil[], int i);
byte* getLocalPassword(); void init0Passw();

#endif // NWM_HEADER_DATA
