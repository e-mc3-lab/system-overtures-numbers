
#ifndef ENT�TE_NWMODULE
#define ENT�TE_NWMODULE

#include "ResourceC.h"
#include "ResourceM.h"

#define FIN_FICHIER 1

#endif // ENT�TE_NWMODULE