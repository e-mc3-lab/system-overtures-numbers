
Cyptur.dll, as Daa.dll, is one the components 
of the unique user key.