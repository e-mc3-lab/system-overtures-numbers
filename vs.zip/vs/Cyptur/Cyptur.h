/*
Copyright(c) 2024-2026 SCLE-CSES. Governed by the SCLE License 1.0; the 
full text of which is contained in the file Licence.txt included in 
NetDisq packages.
*/

#ifndef ND_HEADER_CYPTUR
#define ND_HEADER_CYPTUR

#include "Doa.h"

#define MOT_CYPTUR              "Cyptur"
#define NOM_CYPTUR_DLL          MOT_CYPTUR SUFX_DLL
  
#define NOM_FCT_INIT_CYPTUR     "init" MOT_CYPTUR
#define NOM_FCT_FIN_CYPTUR      "fin" MOT_CYPTUR

#define NOM_FCT_ENCRYPT_UNITS   "encryptUnits"
#define NOM_FCT_DECRYPT_UNITS   "decryptUnits"

#endif // ND_HEADER_CYPTUR