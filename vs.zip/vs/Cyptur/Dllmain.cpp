/*
 Modifications to the original source code (contained in this file), and all
 other portions are Copyright(c) 2024-2026 'SCLE/CSES'. These are also governed
 by the NetDisq License. */

#include "Memoire.h"
#include "Crypto.h"
#include "ModXyz.h"
#include "Random.h"
#include "Cyptur.h"

extern "C"
{

NETDISQ_DLL_EXPORT void initCyptur(INFO_CRYPTO* ci){
    ci->r�sultat = initialisec(ci);
}

NETDISQ_DLL_EXPORT void finCyptur(INFO_CRYPTO* ci)
{
    ci->r�sultat = finalisec(ci, TRUE); terminerHasard(TRUE);
}

NETDISQ_DLL_EXPORT void encryptUnits(uint8 tab[], uint64 idUnit,
    uint32 nbUnits, INFO_CRYPTO* ci)
{
    NTSTATUS r = EncryptDataUnits(tab, idUnit, nbUnits, ci); ND_ASSERT_S(r);
    ND_FIN(); ERR: ND_JOURNALISER_ERREUR(NOM_CYPTUR_DLL);
FIN:if (ci){ ci->r�sultat = gNDR�sultat; }
}

NETDISQ_DLL_EXPORT void decryptUnits(uint8 tab[], uint64 idUnit,
    uint32 nbUnits, INFO_CRYPTO* ci)
{
    NTSTATUS r = DecryptDataUnits(tab, idUnit, nbUnits, ci); ND_ASSERT_S(r);
    ND_FIN(); ERR: ND_JOURNALISER_ERREUR(NOM_CYPTUR_DLL);
FIN:if (ci){ ci->r�sultat = gNDR�sultat; }
}
 
BOOL APIENTRY DllMain(HMODULE hModule,
    DWORD ul_reason_for_call, LPVOID lpReserved)
{
    switch (ul_reason_for_call)
    {

    case DLL_PROCESS_ATTACH: case DLL_THREAD_ATTACH:

    case DLL_THREAD_DETACH: case DLL_PROCESS_DETACH: break;
    
    }
    
    return TRUE;
}

} // extern "C"
