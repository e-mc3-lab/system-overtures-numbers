/*
 Legal Notice: Some portions of the source code contained in this file were
 derived from the source code of Encryption. Modifications and additions to
 the original source code (contained in this file), and all other portions
 of this file are Copyright(c) 2024-2026 'SCLE/CSES'. These are also
 governed by the SCLE License; the full text of which is contained in
 the file Licence 1.0.txt included in NetDisq distribution packages.
 */

#include "CmdLine.h"
#include <commctrl.h>
#include "Forms.h"
#include "Random.h"
#include "Crc.h"
#include "ByteOrder.h"
#include "ProcesSpace.h"
#include "CadentKey.h"
#include "ErreurDict.h"
#include "Fichier.h"
#include "Language.h"
#include "Crypto.h"
#include "ModXyz.h"
#include "AutoTest.h"
#include "NWSData.h"
#include "FormDesign.h"
#include "Cyptur.h"
#include "Doa.h"
#include "NWKeys.h"
#include "NWSData.h"
#include "NWSMessage.h"
#include "NWService.h"

const uint8 MAX_ND_USERS = 100;

LPARAM  CALLBACK DialogueFrm(HWND, UINT, WPARAM, LPARAM);
NTSTATUS getParam�tresCmd(WCHAR lpszCommandLine[]); void quitter();

HWND gWndG = NULL, gFrmD = NULL; static char gCnfProgram[MAX_PATH] = {0},    
    gCnfMsgS[MAX_PATH] = {0}, gParamMPass[MAX_PASSWORD + 2] = {0};
static CRYPTO_INFO gCi; static CONTEXTE_VOLUME gCv = {0}; static long gCrc;
static char gParamCodUtil[DIM_32] = {0}; static BOOL bDesignForm = FALSE,
    bNouvCl�s = FALSE, bNouvUtil = FALSE, bConfIns = FALSE, bAuthentif = FALSE,
    bSupprInfosRef = FALSE, bSupprInscrip = FALSE, bEnvoiCl�s = FALSE;
static uint16 gNbEssais = 0; static char gChemCl�sRef[MAX_PATH] = {0};

LRESULT CALLBACK MainWndProc(HWND hWnd, UINT message,
    WPARAM wParam, LPARAM lParam) // Traiter les messages 'applicatifs'.
{
    gNDR�sultat = ERR_SUCCESS; int wmId = LOWORD(wParam);    
    
    switch (message)
    {
    case WM_COMMAND: // Menus.
    {
        switch (wmId)
        {
        case IDM_AFFICHER_DESIGN:

            DialogBox(gethInst(), MAKEINTRESOURCE(IDD_FORM), hWnd, DialogueFrm);
            break;

        case IDM_AIDE:

            DialogBox(gethInst(), MAKEINTRESOURCE(IDM_AIDE), hWnd, DialoguAide);
            break;

        case IDM_FERMER:

            DestroyWindow(hWnd); break;

        default:

            gNDR�sultat = (NTSTATUS)DefWindowProc(hWnd, message,
                wParam, lParam); break;
        }
    } break;

    case WM_PAINT:
    {
        PAINTSTRUCT ps = {0}; HDC hdc = BeginPaint(hWnd, &ps); 
        EndPaint(hWnd, &ps);
    } 
    break;

    case WM_DESTROY:
    {
        quitter(); PostQuitMessage(0);
    } break;
        
    default: 
        // NB: ne pas utiliser cette fonction en param�tre de ND_ASSERT_CS.
        gNDR�sultat = (NTSTATUS)DefWindowProc(hWnd, message, wParam, lParam);
    }
    return gNDR�sultat;
}

LPARAM CALLBACK DialogueFrm(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
    UNREFERENCED_PARAMETER(lParam); switch (message)
    {
    case WM_INITDIALOG: return (LPARAM)TRUE;

    case WM_COMMAND:

        if (LOWORD(wParam) == IDOK)
        {
            EndDialog(hDlg, LOWORD(wParam)); return (LPARAM)TRUE;
        } else if (LOWORD(wParam) == IDCANCEL){
            PostQuitMessage(EXIT_SUCCESS);
        }
        break;
    }
    return (LPARAM)FALSE;
}

void quitter()
{   
    // :.. Lib�rer le tableau des 'ciphers' et autres ..:
    finCypturDll(&gCv); terminerHasard(TRUE); // UnloadLanguageFile();
    NDV�riRefsOubli�es(FALSE); lib�rerTabInfosEthxDb(); finListeFilEx();
}

uint8 genLongueurMPasse()
{   
    uint8 r = getNombreAl�atoire(MAX_PASSWORD); while (r < MIN_PASSWORD_LEN){
        r = getNombreAl�atoire(MAX_PASSWORD); } return r;
}

NTSTATUS getMPassAl�atoire(CONTEXTE_VOLUME* cv)
{
    NTSTATUS r = EXIT_SUCCESS; byte* tab = cv->nwModule.util.mpassd.texte;
    if ( ! getRandBytes(tab, MAX_PASSWORD, TRUE)){
        return ERR_MOTPASSE_INVALIDE; } 
    uint8 n = genLongueurMPasse(); cv->nwModule.util.mpassd.longueur = n;
    setNonVide(tab, n, FALSE, TRUE); tab[n] = EOL; for (uint i = 0; i < n; i++)
    {
        if ((tab[i] == ':') || (tab[i] == ' ')){ tab[i] = byte(i + DIM_64); }
    } return r;
}

char* getDernierDossierCl�(BOOL bNouveau)
{  
    // Ce dossier est cr�� via CxRef (ndbuild.cmd).
    int i = 0; char* chem = gCnfProgram; static char gCnf[MAX_PATH] = {0}; do 
    { 
        sprintf(gCnf, FMT_DOSSIER_TMPA, chem, i + 1, S�PAR_DIR); i++;
    } while (existe(gCnf) && ! estRefEnUtilisation(i) && i < MAXUINT16);
    i--; sprintf(gCnf, FMT_DOSSIER_TMPA, chem, i, S�PAR_DIR);
    if (bNouveau && existe(gCnf))
    { 
        ajouterRefUtilisation(i); setNoDossierRef(i); 
    } return gCnf;
}
 
void  posterMessagEssaiNwS(int noLigne){
    posterMessagEssaiClt(NOM_NW_SERVICE "-Main", gNDR�sultat, noLigne);
}

void fxNouveauUtil(void* arg)
{
    NTSTATUS r = STATUS_SUCCESS; CONTEXTE_VOLUME* cv = (CONTEXTE_VOLUME*)arg;
    NouveauDaa fcNouveauDaa = NULL; HMODULE hmGDll = getDaaDll();
    ND_ASSERT_CS(arg, ERR_INVALID_INIT); cv->r�sultat = ERR_DONT_REPORT;
    ND_ASSERT_CS(hmGDll, ERR_KEYFILE_NOT_FOUND);
    fcNouveauDaa = (NouveauDaa)GetProcAddress(hmGDll, NOM_FCT_NOUVEAU_DAA);
    ND_ASSERT_CS(fcNouveauDaa, ERR_INVALID_INIT); cv->nwModule.util.mpassd
        .nouveau = TRUE; fcNouveauDaa(cv); ND_ASSERT_S(cv->r�sultat);
    ND_FIN(); ERR:r = gNDR�sultat; posterMessagEssaiNwS(gNoLigne);
FIN:lib�rerTabInfosEthxDb(); finDaaDll(hmGDll, cv); 
    if ( ! NT_SUCCESS(r)){ quitter(); }
}

NTSTATUS FxNouveauDaa(void* arg)
{
    CONTEXTE_VOLUME* ctx = (CONTEXTE_VOLUME*)arg; gNDR�sultat = EXIT_SUCCESS;
    ctx->nwModule.util.mpassd.nouveau = TRUE; 
    fxNouveauUtil(ctx); return gNDR�sultat;
}

FONCTION_FX gNouveauDaaFx = { FxNouveauDaa, &gCv };

void fxConfirmerNouveauDaa(void* arg)
{
    NTSTATUS r = STATUS_SUCCESS; const uint N = NCARSUTIL;
    CONTEXTE_VOLUME* cv = (CONTEXTE_VOLUME*)arg; byte tab0[UDM] = {0};
    byte tab[UDM] = {0}; cv->r�sultat = ERR_DONT_REPORT; HMODULE hmCDll = NULL;
    ND_ASSERT_CS(arg, ERR_INVALID_INIT); r = nwAuthentifier(cv); ND_ASSERT_S(r);
    hmCDll = getCypturDll(); ND_ASSERT_CS(hmCDll, ERR_OBJECT_INIT);
    r = getDataTest(tab, UDM, FALSE); ND_ASSERT_S(r); memcpy(tab0, tab, UDM);
    EncryptUnits fcEncryptUnits = (EncryptUnits)GetProcAddress(hmCDll,
        NOM_FCT_ENCRYPT_UNITS); ND_ASSERT_CS(fcEncryptUnits, ERR_INVALID_INIT);
    fcEncryptUnits(tab, 0, 1, &cv->ci); // : validation pr�liminaire :
    DecryptUnits fcDecryptUnits = (DecryptUnits)GetProcAddress(hmCDll,
        NOM_FCT_DECRYPT_UNITS); ND_ASSERT_CS(fcDecryptUnits, ERR_INVALID_INIT);
    fcDecryptUnits(tab, 0, 1, &cv->ci); 
    if (comparerMem(tab0, tab, UDM, FALSE) != 0){ ND_ASSERT_S(ERR_NOUVEAU_DOA) }
    r = setConfirmNouveauDaa(&cv->nwModule.util); ND_ASSERT_S(r);
    posterMessageTexteClt("NEW_DAA_SUCCESS"); ND_FIN();
ERR:r = gNDR�sultat; posterMessagEssaiNwS(gNoLigne); finCypturDll(cv);
    if (cv){ init0(&cv->nwModule.util.mpassd, DIM_MP_DRV); }
FIN:finCypturDll(cv); if (!NT_SUCCESS(r)){ quitter(); }
}

NTSTATUS confirmerNouveauDaaFx(void* arg)
{
    CONTEXTE_VOLUME* ctx = (CONTEXTE_VOLUME*)arg; 
    fxConfirmerNouveauDaa(ctx); return gNDR�sultat;
}

FONCTION_FX gConfirmNouveauDaaFx = { confirmerNouveauDaaFx, &gCv };

#define NB_IT�R_CHIFFR_AUTHEN   3

byte* genMessageInit()  
{
    static byte gMsgInit[DIM_MESSAGE_INIT] = {0}; 
    const int HDIV = DIM_256;
    for (int i = 0; i < NB_UNITS_AUTHEN; i++){
        getRandBytes(gMsgInit + int(i * HDIV), HDIV, TRUE);
    }
    setNonVide(gMsgInit, DIM_MESSAGE_INIT, TRUE, FALSE); return gMsgInit;
}

uint16 getIndexCrc(){
    return DIM_MESSAGE_INIT / 3; // TODO: appeler 'getNombreAl�atoire'.
}

NTSTATUS chiffrerMessageA(HMODULE hmCDll, CRYPTO_INFO* ci, byte msgD[], BOOL bm)
{
    uint32 crcA = 0, crcB, crc; byte* txt; uint16 iCrc = getIndexCrc();
    byte *msgA = NULL, *msgB = NULL; const uint16 N = sizeof(uint32),
    M = DIM_MESSAGE_INIT - (iCrc + N); EncryptUnits fcEncryptUnits = NULL;
    ND_ASSERT_CS(iCrc > 0 && iCrc < (DIM_MESSAGE_INIT - DIM_16),
        ERR_OBJECT_INIT); const uint8 NBUNITS = NB_UNITS_AUTHEN / 2;
    msgA = (byte*)NDAllouer0(iCrc); msgB = (byte*)NDAllouer0(M);
    memcpy(msgA, msgD, iCrc); memcpy(msgB, (msgD + iCrc + N), M);
    crcA = getCrc32(msgA, iCrc); crcB = getCrc32(msgB, M); txt = (msgD + iCrc);
    crc = crcA + crcB; if ( ! bm){ crc /= 3; } setMemInt32(txt, crc, TRUE);
    memcpy(msgD, msgA, iCrc); memcpy(txt, msgB, M);
    fcEncryptUnits = (EncryptUnits)GetProcAddress(hmCDll,
        NOM_FCT_ENCRYPT_UNITS); ND_ASSERT_CS(fcEncryptUnits, ERR_OBJECT_INIT);  
    for (uint i = 0; i < NB_IT�R_CHIFFR_AUTHEN; i++)
    {
        fcEncryptUnits(msgD, 0, NBUNITS, ci); ND_ASSERT_S(ci->r�sultat);
    } ND_FIN(); ERR:posterMessagEssaiNwS(gNoLigne); 
FIN:NDFree(msgA); NDFree(msgB); return gNDR�sultat;
}

NTSTATUS chiffrerMessageB(CRYPTO_INFO* ci, byte msgE[])
{
    HMODULE hmCDll = getCypturDll(); DecryptUnits fcDecryptUnits = NULL;
    const uint8 NBUNITS = NB_UNITS_AUTHEN / 2; 
    ND_ASSERT_CS(hmCDll, ERR_OBJECT_INIT);
    fcDecryptUnits = (DecryptUnits)GetProcAddress(hmCDll,
        NOM_FCT_DECRYPT_UNITS); ND_ASSERT_CS(fcDecryptUnits, ERR_OBJECT_INIT);
    for (uint i = 0; i < NB_IT�R_CHIFFR_AUTHEN; i++){
        fcDecryptUnits(msgE, 0, NBUNITS, ci); ND_ASSERT_S(ci->r�sultat);
    }
    NTSTATUS r = chiffrerMessageA(hmCDll, ci, msgE, TRUE); ND_ASSERT_S(r);
    ND_FIN(); ERR: posterMessagEssaiNwS(gNoLigne); FIN: return gNDR�sultat;
}

NTSTATUS d�chiffrerMessageC(CRYPTO_INFO* ci, byte msgE[])
{
    byte *msgA = NULL, *msgB = NULL; uint16 iCrc = getIndexCrc();
    HMODULE hmCDll = getCypturDll(); byte msgD[DIM_MESSAGE_INIT] = {0};
    memcpy(msgD, msgE, DIM_MESSAGE_INIT); const uint16 N = sizeof(uint32),
        M = DIM_MESSAGE_INIT - (iCrc + N); DecryptUnits fcDecryptUnits = NULL;
    ND_ASSERT_CS(hmCDll, ERR_OBJECT_INIT);
    fcDecryptUnits = (DecryptUnits)GetProcAddress(hmCDll,
        NOM_FCT_DECRYPT_UNITS); ND_ASSERT_CS(fcDecryptUnits, ERR_OBJECT_INIT);
    ND_ASSERT_CS(iCrc > 0 && iCrc < (DIM_MESSAGE_INIT - DIM_16),
        ERR_OBJECT_INIT); const uint8 NBUNITS = NB_UNITS_AUTHEN / 2;
    for (uint i = 0; i < NB_IT�R_CHIFFR_AUTHEN; i++)
    {
        fcDecryptUnits(msgD, 0, NBUNITS, ci); ND_ASSERT_S(ci->r�sultat);
    }
    msgA = (byte*)NDAllouer0(iCrc); msgB = (byte*)NDAllouer0(M);
    memcpy(msgA, msgD, iCrc); memcpy(msgB, (msgD + iCrc + N), M);
    uint32 crcA = getCrc32(msgA, iCrc); uint32 crcB = getCrc32(msgB, M);
    uint32 crc = crcA + crcB; crcB = getMotInt32(msgD, iCrc);
    ND_ASSERT_CS(crc == crcB, ERR_AUTHENTIFICATION); ND_FIN();
ERR:posterMessagEssaiNwS(gNoLigne); 
FIN:NDFree(msgA); NDFree(msgB); return gNDR�sultat;
}

void fxAuthentifierUtil(void* arg)
{
    NTSTATUS r = STATUS_SUCCESS; CONTEXTE_VOLUME* cv = (CONTEXTE_VOLUME*)arg; 
    int EOI = ERR_OBJECT_INIT; byte* msg = NULL; HMODULE hmCDll = NULL;
    r = nwAuthentifier(cv); ND_ASSERT_S(r); msg = genMessageInit();
    hmCDll = getCypturDll(); ND_ASSERT_CS(hmCDll, EOI); cv->ci.mode = XTS;
    r = chiffrerMessageA(hmCDll, &cv->ci, msg, FALSE); ND_ASSERT_S(r);
    posterMessage(getCnfMsg(), NULL, msg, DIM_MESSAGE_INIT);
    r = chiffrerMessageB(&cv->ci, msg); ND_ASSERT_S(r); // R�ponse:
    r = d�chiffrerMessageC(&cv->ci, msg); ND_ASSERT_S(r);
    finCypturDll(cv); ND_ASSERT_S(cv->ci.r�sultat);
    posterMessageTexteClt("AUTHENTICATION_SUCCESS"); ND_FIN();
ERR:if (bSupprInscrip && cv){ supprimerInfoDEthxDb(&cv->nwModule.util); }
    posterMessagEssaiNwS(gNoLigne); FIN:finCypturDll(cv); bSupprInscrip = FALSE;
}

NTSTATUS FxAuthentifUtil(void* arg)
{
    CONTEXTE_VOLUME* ctx = (CONTEXTE_VOLUME*)arg; 
    fxAuthentifierUtil(ctx); return gNDR�sultat;
}

FONCTION_FX gAuthentifUtilFx = { FxAuthentifUtil, &gCv };

void setCnfDaaDll(const char codUtil[])
{
    char cnfDaaDll[MAX_PATH] = {0};
    sprintf(cnfDaaDll, "%s.%s%s%s", gCnfProgram, codUtil,
        S�PAR_DIR, NOM_DAA_DLL); setChemDaaDll(cnfDaaDll);
}

void setCnfCypturDll(const char codUtil[])
{
    char cnfCyptDll[MAX_PATH] = {0};
    sprintf(cnfCyptDll, "%s.%s%s%s", gCnfProgram, codUtil,
        S�PAR_DIR, NOM_CYPTUR_DLL); setChemCypturDll(cnfCyptDll);
}

void setCnfKeySpace(const char codUtil[]){
    sprintf(gCv.nwModule.chemKeyNd, "%s.%s%s%s", gCnfProgram, codUtil,
        S�PAR_DIR, NOM_KEYSPACE_ND);
}

NTSTATUS initInfosCl�Util(BOOL bNouveau) // TODO: convertir en BLOBs.
{   
    const char FMT_TXT[] = "%s%s"; char* chemCl�sRef, codt[NCARSUTIL + 1] = {0};
    int ERRFW; char cnfDaaDll[MAX_PATH] = {0}, lChemCypDll[MAX_PATH] = {0};
    strncpy(codt, gCv.nwModule.util.code, NCARSUTIL); ERRFW = ERR_FILE_WRITE;
    char lCnfCl�Nd[MAX_PATH]; chemCl�sRef = getDernierDossierCl�(bNouveau);
    const char SD[] = S�PAR_DIR; ND_ASSERT_CS(chemCl�sRef != NULL && 
        chemCl�sRef[0] != EOL, ERR_OBJECT_NOT_FOUND); strcpy(gChemCl�sRef, 
            chemCl�sRef); sprintf(lCnfCl�Nd, "%s.%s", gCnfProgram, codt); 
    if ( ! NT_SUCCESS(cr�erDossiers(lCnfCl�Nd, FALSE))){ ND_ASSERT_S(ERRFW); }
    sprintf(gCv.nwModule.chemKeyNd, "%s%s%s", lCnfCl�Nd, SD, NOM_KEYSPACE_ND);
    sprintf(cnfDaaDll, FMT_TXT, chemCl�sRef, NOM_DAA_DLL); journaliser("codt: %s", codt);  setCnfDaaDll(codt);
    if (bNouveau && ! copierFichier(cnfDaaDll, getChemDaaDll())){ // Cas o� il 
        ND_ASSERT_S(ERR_KEYFILE_NOT_FOUND); } // n'y a pas de dossier .1, ...
    sprintf(lChemCypDll, FMT_TXT, chemCl�sRef, NOM_CYPTUR_DLL);
    setCnfCypturDll(codt); if (bNouveau && ! copierFichier(lChemCypDll, 
        getChemCypturDll())){ ND_ASSERT_S(ERR_KEYFILE_NOT_FOUND); } ND_FIN(); 
ERR:posterMessagEssaiNwS(gNoLigne); FIN: return gNDR�sultat;
}

void supprimerInfosCl�sRef()  
{
    char lCnfCl�[MAX_PATH] = {0}; char* cnp = gCnfProgram;
    int iNoRef = getNoDossierRef(); ND_ASSERT_CS(iNoRef > 0, 
        ERR_ARGUMENT_INVALIDE); sprintf(lCnfCl�, FMT_DOSSIER_TMP, cnp,
            S�PAR_DIR, iNoRef, S�PAR_DIR); supprimerRefUtilisation(iNoRef);
    sprintf(lCnfCl�, "%s%s%s", gChemCl�sRef, S�PAR_DIR, NOM_DAA_DLL);
    supprimerFichier0(lCnfCl�); sprintf(lCnfCl�, "%s%s%s", gChemCl�sRef,
        S�PAR_DIR, NOM_CYPTUR_DLL); supprimerFichier0(lCnfCl�);
    sprintf(lCnfCl�, "%s%s%s", gChemCl�sRef, S�PAR_DIR, NOM_KEYSPACE_ND);
    supprimerFichier0(lCnfCl�); RemoveDirectoryA(gChemCl�sRef);
    ERR: /*FIN*/ posterMessageTexteClt("REFKEY_SUPPRESS");
}

void supprimerInscription(char codUtil[])
{
    char lCnfCl�Nd[MAX_PATH] = {0}; finListeFilsFx(); setCnfDaaDll(codUtil);
    supprimerFichier0(getChemDaaDll()); setCnfCypturDll(codUtil);
    supprimerFichier0(getChemCypturDll()); setCnfKeySpace(codUtil);
    supprimerFichier0(gCv.nwModule.chemKeyNd); sprintf(lCnfCl�Nd,
        "%s.%s", gCnfProgram, codUtil); RemoveDirectoryA(lCnfCl�Nd);
    supprimerRefUtilisation(getNoDossierRef()); strcpy(gCv.nwModule.util
        .code, codUtil); supprimerInfoDEthxDb(&gCv.nwModule.util);
    posterMessageTexteClt("UTILF_SUPPRESS");
}

ENTIER getParamCodeUtilisateur(uint* i, char argsLigneCmd[][MAX_PATH])
{
    const uint8 NO_PARAM = 4; if (HAS_ARGUMENT == GetArgumentValue(argsLigneCmd,
        0, i, NO_PARAM, gParamCodUtil, DIM_16)){} return STRLEN(gParamCodUtil);
}

NTSTATUS getParam�tresCmd(WCHAR lpszCommandLine[])
{
    NTSTATUS r = EXIT_SUCCESS; char argsLigneCmd[MAX_NB_ARGS][MAX_PATH] = {0};
    uint8 idxLigneCmd = Win32CommandLine(lpszCommandLine, argsLigneCmd); 
    const uint8 NO_PARAM = 2; ENTIER n = 0; if (idxLigneCmd > 0)
    {
        enum {  SourceAppel, NouveauDaa, NouvelUtil, ConfirmInscrip, 
                Authentif, SuppressRef, SuppressInscrip, Configuration,
                NoDossierRef, DemandeCl�s };
        
        Argument args[] =
        {
            { SourceAppel,      "/sourceappel",     "/" PARAM_SRC_PRG       },
            { NouveauDaa,       "/nouveaudaa",      "/" PARAM_NOUV_DAA      },
            { NouvelUtil,       "/nouvelutil",      "/" PARAM_NOUV_UTIL     },
            { ConfirmInscrip,   "/confirminsc",     "/" PARAM_CONFIRM_INSC  },
            { Authentif,        "/authentif",       "/" PARAM_AUTHENTIF     },
            { SuppressRef,      "/supprimref",      "/" PARAM_SUPPRESS_REF  },
            { SuppressInscrip,  "/suppriminsc",     "/" PARAM_SUPPRESS_INSC },
            { Configuration,    "/config",          "/" PARAM_CONFIG        },
            { NoDossierRef,     "/nodossieref",     "/" PARAM_NO_REF        },
            { DemandeCl�s,      "/demandecl�s",     "/" PARAM_GET_KEYS      },
        };

        CONTEXTE_VOLUME* cv = &gCv;
        for (uint i = 0; i < idxLigneCmd; i++)
        {
            ArgumentSpec as; as.args = args; uint nArgPos = 0;
            as.arg_cnt = sizeof(args) / sizeof(args[0]);  
            switch (GetArgumentID(&as, argsLigneCmd[i], &nArgPos))
            {

            case SourceAppel: {
                GetArgumentValue(argsLigneCmd,
                    0, &i, NO_PARAM, getParamSource(), DIM_8); break;
            }

            case NouveauDaa:
            {
                // param�tres: /nouv ["code_utilisateur"]
                n = getParamCodeUtilisateur(&i, argsLigneCmd); if (n == 0)
                {
                    getCodUtilAl�atoire(gParamCodUtil);
                    n = STRLEN(gParamCodUtil);
                }
                strncpy(cv->nwModule.util.code, gParamCodUtil, n);
                r = getMPassAl�atoire(cv); ND_ASSERT_S(r);
                r = chiffrerMPasse(&cv->nwModule.util); ND_ASSERT_S(r);
                bNouvCl�s = TRUE; break;
            } 

            case NouvelUtil:
            {
                bNouvUtil = TRUE; break;
            }

            case ConfirmInscrip:
            {
                // param�tres: /confr "code_utilisateur"
                n = getParamCodeUtilisateur(&i, argsLigneCmd); if (n == 0){
                    ND_ASSERT_S(ERR_ARGUMENT_INVALIDE);
                }
                strncpy(cv->nwModule.util.code, gParamCodUtil, n);
                bConfIns = TRUE; break;
            }

            case DemandeCl�s:
            {
                bEnvoiCl�s = TRUE; break;
            }

            case Authentif:
            {
                // param�tres: /aut "code_utilisateur" ["nom_dossier"]
                n = getParamCodeUtilisateur(&i, argsLigneCmd);
                ND_ASSERT_CS(n > 0, ERR_ARGUMENT_INVALIDE);
                strncpy(cv->nwModule.util.code, gParamCodUtil, n);
                bAuthentif = TRUE; break;
            }

            case SuppressRef: 
            {
                char param[DIM_16] = {0}; if ((gChemCl�sRef[0] == EOL) &&
                    (HAS_ARGUMENT == GetArgumentValue(argsLigneCmd,
                        0, &i, NO_PARAM + i + 1, param, DIM_16))){}
                char* txtNo = trim(param); 
                if (txtNo != NULL){ setNoDossierRef(atoi(txtNo)); }
                bSupprInfosRef = TRUE; break;
            }

            case SuppressInscrip:
            {
                if (n == 0){ n = getParamCodeUtilisateur(&i, argsLigneCmd); }
                ND_ASSERT_CS(n > 0, ERR_ARGUMENT_INVALIDE);
                bSupprInscrip = TRUE; break;
            }

            case Configuration: 
            {
                char param[DIM_8] = { MOT_CONFIG_RELEASE };
                if (HAS_ARGUMENT == GetArgumentValue(argsLigneCmd,
                    0, &i, NO_PARAM + i + 1, param, DIM_8)){
                    setConfiguration(param); } break;
            }

            case NoDossierRef:
            {
                char param[DIM_8] = {0};
                if (HAS_ARGUMENT == GetArgumentValue(argsLigneCmd,
                    0, &i, NO_PARAM + i + 1, param, DIM_8)){
                    setNoDossierRef(atoi(param));
                } break;
            }

            default: ND_ASSERT_S(ERR_ARGUMENT_INVALIDE);
            }
        }
    } else { 
        bDesignForm = TRUE; DialogBox(gethInst(),
            MAKEINTRESOURCEW(IDD_FORM), gWndG, DialogueFrm);
    }
ND_FIN(); ERR: r = gNDR�sultat; posterMessagEssaiNwS(gNoLigne);
FIN:init0(argsLigneCmd, sizeof(argsLigneCmd)); return r;
}

int APIENTRY wWinMain(_In_ HINSTANCE hInstance, HINSTANCE hPrevInstance,
    _In_ LPWSTR arguments, _In_ int nCmdShow)
{
    UNREFERENCED_PARAMETER(hPrevInstance); const uint8 I = 1;
    HeapSetInformation(NULL, HeapEnableTerminationOnCorruption, NULL, 0);
    WCHAR szWndClass[MAX_LOADSTRING] = {0}; MSG msg = {0};
    strcpy(gCnfProgram, convEnMinuscules(getCheminProgramme()));
    LoadStringW(hInstance, IDC_NETDISQ, szWndClass, MAX_LOADSTRING); 
    NTSTATUS r�sultat = STATUS_SUCCESS; 
    if (wcslen(arguments) > 0)
    {
        r�sultat = getParam�tresCmd(arguments); ND_ASSERT_S(r�sultat);
    }
    if (bDesignForm)
    {
        InitWndClass(hInstance, szWndClass, MainWndProc);
        HACCEL hAccelTable = LoadAccelerators(hInstance,
            MAKEINTRESOURCE(IDC_NETDISQ));
        if ( ! InitWndInstance(hInstance, szWndClass, nCmdShow, NULL)){
            ND_ASSERT_S(ERR_INSUCC�S);
        }
        gCv.hInst = hInstance; ShowWindow(gWndG, nCmdShow);
        while (GetMessage(&msg, NULL, 0, 0))
        {
            if ( ! TranslateAccelerator(msg.hwnd, hAccelTable, &msg))
            {
                TranslateMessage(&msg); DispatchMessage(&msg);
            }
        }
    } else { // Commande.
        r�sultat = initInfosCl�Util(bNouvCl�s); ND_ASSERT_S(r�sultat); 
        if (bNouvCl�s)
        {
            uint8 MAX_ESSAIS = 1, i = 0; gNDR�sultat = ERR_DONT_REPORT;
            for (; i < MAX_ESSAIS; i++)
            {
                execFilEx(&gNouveauDaaFx, FALSE); ND_ASSERT_S(gNDR�sultat);
                execFilEx(&gConfirmNouveauDaaFx, FALSE);
                if ((gNDR�sultat == ERR_OBJECT_INIT) ||
                    (gNDR�sultat == ERR_INVALID_INIT)){
                    ND_ASSERT_S(gNDR�sultat);
                }
                if (NT_SUCCESS(gNDR�sultat)){ break; } // Arr�ter: succ�s.
                r�sultat = getMPassAl�atoire(&gCv); ND_ASSERT_S(r�sultat);
                r�sultat = chiffrerMPasse(&gCv.nwModule.util); 
                ND_ASSERT_S(r�sultat);
            }
            if (i == MAX_ESSAIS){ ND_ASSERT_S(ERR_AUTHENTIFICATION); }
        } else if (bNouvUtil){
            r�sultat = getInfoDisponible(&gCv.nwModule.util); 
            ND_ASSERT_S(r�sultat);
            if (estVide100((byte*)gCv.nwModule.util.code, NCARSUTIL)){
                ND_ASSERT_S(ERR_KEYFILE_NOT_FOUND);
            }
            r�sultat = envoyerCl�sNd(&gCv.nwModule.util); ND_ASSERT_S(r�sultat);
        } else if (bConfIns){
            r�sultat = setConfirmInscription(&gCv.nwModule.util); 
            ND_ASSERT_S(r�sultat);
        } else if (bEnvoiCl�s){
            r�sultat = envoyerCl�sNd(&gCv.nwModule.util); ND_ASSERT_S(r�sultat);
        } else if (bAuthentif){
            r�sultat = getInfoViaConnexChiffr�e(&gCv.nwModule.util); 
            ND_ASSERT_S(r�sultat);
            execFilEx(&gAuthentifUtilFx, FALSE); ND_ASSERT_S(gNDR�sultat);
        } else if (bSupprInscrip){ supprimerInscription(gParamCodUtil);
        } else if (bSupprInfosRef){ supprimerInfosCl�sRef(); }
    }
    ND_FIN();
ERR:posterMessagEssaiNwS(gNoLigne); FIN:quitter(); return abs(gNDR�sultat); 
}