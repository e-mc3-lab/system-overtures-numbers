/*
 * Copyright(c) 2024-2026 SCLE-CSES. Governed by the SCLE License 1.0; the
 * full text of which is contained in ~/Common/Resources/Licence.txt
 */

#ifndef NW_HEADER_KEYS
#define NW_HEADER_KEYS

#include "Doa.h"


const char FMT_CHEM_KEYS[DIM_16] = "%s%s.%d.%s%s%s";

typedef void (WINAPI* NouveauDaa)(CONTEXTE_VOLUME*);
typedef void (WINAPI* EncryptUnits)(uint8*, uint64, uint32, INFO_CRYPTO*);
typedef void (WINAPI* DecryptUnits)(uint8*, uint64, uint32, INFO_CRYPTO*);

char* getChemDaaDll(); void setChemDaaDll(char cnfDll[]);
char* getChemCypturDll(); void setChemCypturDll(char cnfDll[]);
char* getChemSmartkeyNd(); void setChemSmartkeyNd(char cnfSkNd[]);

HMODULE getDaaDll(); HMODULE getCypturDll(); void finDaaDll(HMODULE hmGDll,
    CONTEXTE_VOLUME* cv); void finCypturDll(CONTEXTE_VOLUME* cv);

NTSTATUS nwAuthentifier(CONTEXTE_VOLUME* cv);

#endif // NW_HEADER_KEYS