/*
Copyright(c) 2024-2026 SCLE-CSES. Governed by the SCLE License 1.0; the
full text of which is contained in the file Licence.txt included in 
NetDisq packages.
*/

#ifndef ENT�TE_NWSERVICE
#define ENT�TE_NWSERVICE

#include "ResourceC.h" 
#include "ResourceS.h" 
#include "Cyptur.h"
#include "Doa.h"

#ifdef __cplusplus
extern "C"
{
#endif

#define NOM_NW_ADMIN        "NWAdmin"
#define NOM_NW_MODULE       "NWModule"
#define NOM_NW_SERVICE      "NWService" 

#define NOM_ETHX_DB         "Ethx.db"
#define NOM_NW_SEC_MSG      "Nwsecur.msg"

#define FMT_DOSSIER_TMP     "%s%s.%d%s" // ~.1, .2, .3, etc.
#define FMT_DOSSIER_TMPA    "%s.%d%s"   // Idem.

#define NOM_DOSSIER_VS      "vs" // Abr�viation de 'Visual Studio'.
#define MOT_PLATEFORM_X64   "x64"
#define MOT_CONFIG_DEBUG    "Debug"
#define MOT_CONFIG_RELEASE  "Release"
#define MOT_UTILIZE         "utilize"

#define MOT_SOURCE_ADMIN    "A" // Administration locale.
#define MOT_SOURCE_MODULE   "M" // Navigation Web int�gr�e.
#define MOT_SOURCE_HTTPS    "H" //     ""        'classique'.

#define PARAM_SRC_PRG       "src"
#define PARAM_NOUV_DAA      "nouvaa"
#define PARAM_NOUV_UTIL     "nouvl"
#define PARAM_CONFIRM_INSC  "confr"
#define PARAM_AUTHENTIF     "aut"
#define PARAM_SUPPRESS_REF  "sup"
#define PARAM_SUPPRESS_INSC "sin"
#define PARAM_CONFIG        "confg"
#define PARAM_NO_REF        "ref"
#define PARAM_GET_KEYS      "gk"

#define MIN_PASSWORD_LEN    3 * PASSWORD_LEN_MIN_WARNING
#define NB_UNITS_AUTHEN     12
#define DIM_MESSAGE_INIT    NB_UNITS_AUTHEN * DIM_256

#define S�PAR_CODE_MSG      ":"
#define DIM_MOT_ID_ERR      int(strlen(MOT_ID_ERREUR))

char* getParamSource(); void setParamSource(char ps[]);
BOOL estSourceAdmin(); BOOL estSourceModule();
char* getCheminDev(char chemProgramme[]); 
char* getCheminService(); void setCheminService(); void finLib(HMODULE* hm);
char* getCheminModule(); char* getChemSEthxDb(); 
char* getConfiguration(); void setConfiguration(char conf[]); 
BOOL estRefEnUtilisation(int i); uint getDernierDossierRef(char chemin[]);
char* getChemNomFichierMsgA(); char* getChemNomFichierMsgM(); 
char* getChemNomFichierMsgS(); int getNoDossierRef(); 
void setNoDossierRef(int i); int getNoDossierRefA(const char msg[]);
char* getCnRefEnUtilisation(int i); char* getCnfMsg();
NTSTATUS cr�erFichier(const char cnf[]);
int ex�cuterCommandeNws(int argn, char argv[][DIM_64]);

#if defined(__cplusplus)
}
#endif

#endif // ENT�TE_NWSERVICE