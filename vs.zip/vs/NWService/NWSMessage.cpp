/*
 Legal Notice: Modifications to the original source code and all other
 portions of this file are governed by the SCLE License; the full text
 of which is contained in Licence 1.0.txt included in NetDisq packages. */

#include "Fichier.h"
#include "Cmdline.h"
#include "NWService.h"
#include "NWSMessage.h"


int getCodeMessage(const char txt[])
{   // txt est de format: "id.err=0999:-99"
    char* msg = ND_CC(txt), * rech = strstr(msg, S�PAR_CODE_MSG);
    return atoi(rech ? rech + 1 : "-1");
}

void posterMessage(char cnfMsg[], char idTxt[], byte txt[], uint16 n)
{   // TODO: HTTPS..
    NTSTATUS r = EXIT_SUCCESS; char txtIdMsg[DIM_32] = {0}, * text = ND_CC(txt);
    FILE* fichier = NULL; ENTIER nb = 0; if ( ! existe(cnfMsg)){
        r = cr�erFichier(cnfMsg); ND_ASSERT_S(r);
    }
    fichier = fopen(cnfMsg, "w"); ND_ASSERT_CS(fichier, ERR_FILE_WRITE);
    if (idTxt){
        sprintf(txtIdMsg, "%s=%d:%s", (idTxt[0] != '-' ?
            MOT_ID_MESSAGE : MOT_ID_ERREUR), n, idTxt); text = txtIdMsg;
    }
    fseek(fichier, 0, SEEK_SET); if ( ! txt)
    {
        r = fputs(txtIdMsg, fichier); ND_ASSERT_CS(r != EOF, ERR_FILE_WRITE);
    } else if (text){
        nb = fwrite(text, 1, n, fichier); ND_ASSERT_CS(nb == n, ERR_FILE_WRITE);
    } ND_FIN();
ERR:ND_JOURNALISER_ERREUR(NOM_NWS_MESSAGE); FIN:if (fichier){ fclose(fichier); }
}

void posterMessageTexte(char cnfMsg[], uint16 noRef, char idTxt[]){
    posterMessage(cnfMsg, idTxt, NULL, noRef);
}

void posterMessagEssai(char nomModule[], int noRef, int code, int ligne)
{
    if (code != ERR_DONT_REPORT)
    {
        char idTxt[DIM_16] = {0}; sprintf(idTxt, "%d", code);
        ND_JOURNALISER_EXCEPTION(nomModule, code, ligne);
        posterMessage(getCnfMsg(), idTxt, NULL, noRef);
    }
}

void posterMessagErreur(char nomModule[], int code, int ligne){
    posterMessagEssai(nomModule, getNoDossierRef(), code, ligne);
}

void posterMessageTexteClt(char idTxt[]){
    posterMessageTexte(getCnfMsg(), getNoDossierRef(), idTxt);
}

void posterMessagEssaiClt(char nomModule[], int code, int noLigne){
    posterMessagEssai(nomModule, getNoDossierRef(), code, noLigne);
}

void posterMessagErreurClt(char nomModule[], int noLigne){
    posterMessagErreur(nomModule, gNDR�sultat, noLigne);
}

NTSTATUS envoyerCl�sNd(UTILISATEUR* util)
{   // TODO: se fait d'ordinaire par courrier.
    NTSTATUS r�sultat = STATUS_SUCCESS;
    char chemCl�s[MAX_PATH] = {0}, chemModUtil[MAX_PATH] = {0},
        cnSource[MAX_PATH] = {0}, cnDest[MAX_PATH] = {0},
        SD[] = S�PAR_DIR, *codUtil = util->code;
    FILE* fichier = NULL; sprintf(chemModUtil, "%s%s.0.%s%s",
        getCheminModule(), SD, codUtil, SD);
    BOOL r = TRUE; const char FAUX = '0'; ND_ASSERT_CS(util,
        ERR_ARGUMENT_INVALIDE); sprintf(chemCl�s, "%s%s.%s%s",
            getCheminService(), SD, codUtil, SD);
    cr�erDossiers(chemModUtil, FALSE);
    sprintf(cnSource, "%s%s", chemCl�s, NOM_DAA_DLL);
    sprintf(cnDest, "%s%s", chemModUtil, NOM_DAA_DLL);
    r = copierFichier(cnSource, cnDest); ND_ASSERT(r);
    sprintf(cnSource, "%s%s", chemCl�s, NOM_CYPTUR_DLL);
    sprintf(cnDest, "%s%s", chemModUtil, NOM_CYPTUR_DLL);
    r = copierFichier(cnSource, cnDest); ND_ASSERT(r);
    sprintf(cnSource, "%s%s", chemCl�s, NOM_KEYSPACE_ND);
    sprintf(cnDest, "%s%s", chemModUtil, NOM_KEYSPACE_ND);
    r = copierFichier(cnSource, cnDest); ND_ASSERT(r);
    sprintf(cnSource, "%s%s", chemModUtil, NOM_ETHX_DB); cr�erFichier(cnSource);
    fichier = fopen(cnSource, "w"); ND_ASSERT_CS(fichier, ERR_FILE_WRITE);
    r = fputs(util->code, fichier); fputc(FAUX, fichier);
    r = fputs(ND_CC(util->mpassd.texte), fichier);
    ND_ASSERT_CS(r >= 0, ERR_FILE_WRITE); fclose(fichier);
    fichier = NULL; posterMessageTexteClt(codUtil); ND_FIN();
ERR:r�sultat = EXIT_FAILURE; ND_JOURNALISER_ERREUR(NOM_NWS_MESSAGE);
    journaliser("%s\n%s", cnSource, cnDest);
    RemoveDirectoryA(chemModUtil); posterMessagErreurClt(NOM_NWS_MESSAGE,
        gNoLigne); FIN: if (fichier){ fclose(fichier); } 
    return r�sultat;
}