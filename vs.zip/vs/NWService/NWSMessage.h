/*
Copyright(c) 2024-2026 SCLE-CSES. Governed by the SCLE License 1.0; the
full text of which is contained in the file Licence.txt included in
NetDisq packages. */ 

#ifndef NWS_HEADER_MESSAGE
#define NWS_HEADER_MESSAGE

#include "NWService.h"

#define NOM_NWS_MESSAGE     "NWSMessage"

int getCodeMessage(const char txt[]);
void posterMessage(char cnfMsg[], char idTxt[], byte txt[], uint16 n);
void posterMessageTexte(char cnfMsg[], uint16 noRef, char idTxt[]);
void posterMessagEssai(char nomModule[], int noRef, int code, int ligne);
void posterMessagErreur(char nomModule[], int code, int ligne);
void posterMessageTexteClt(char idTxt[]);
void posterMessagEssaiClt(char nomModule[], int code, int noLigne);
void posterMessagErreurClt(char nomModule[], int noLigne);
NTSTATUS envoyerCl�sNd(UTILISATEUR* util);

#endif // NWS_HEADER_MESSAGE