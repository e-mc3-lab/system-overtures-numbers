/*
Copyright(c) 2024-2026 SCLE-CSES. Governed by the SCLE License 1.0; 
of which the text is contained in the Licence.txt, itself
included in NetDisq packages. 
*/

#ifndef NWS_HEADER_DATA
#define NWS_HEADER_DATA

#include "Cyptur.h"
#include "Doa.h"

#define NOM_NWS_DATA        "NWSData" 
#define MAX_UTILS           DIM_8 * MILLE_VINGT_QUATRE
#define MLN                 DIM_32 + NCARSUTIL + MAX_PASSWORD // Ligne.


NTSTATUS getCodUtilAl�atoire(char tab[]);

void ajouterRefUtilisation(int i);
void supprimerRefUtilisation(int i);

NTSTATUS chiffrerMPasse(UTILISATEUR* util);
NTSTATUS d�chiffrerMPasse(byte mpassc[]);

FILE* getInfoViaEthxDb(UTILISATEUR* util);
NTSTATUS setConfirmNouveauDaa(UTILISATEUR* util);
void supprimerInfoDEthxDb(UTILISATEUR* util);
NTSTATUS getInfoViaConnexChiffr�e(UTILISATEUR* util);
NTSTATUS getInfoDisponible(UTILISATEUR* util);
NTSTATUS setConfirmInscription(UTILISATEUR* util);

char* getUtil0EthxDb(); char* getUtilNextEthxDb(uint i);
void lib�rerTabInfosEthxDb();

#endif // NWS_HEADER_DATA