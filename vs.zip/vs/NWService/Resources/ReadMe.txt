
This project simulates a Web server that builds the components KeySpace.nd,
Daa.dll and Cyptur.dll for each user (prepared in compiling CxRef [rebuild]).
To facilate the process, the user code and the password are random and saved in
a file, or preferably in a database (ex: ethx.db). In general, these data would
be printed in a letter (or in a secure file). All would work in HTTPS/SSL/TLS
(following the good practices in WS-Security). To note that the time, apparently
long (sometime few minutes), is not a factor because the authentication
information are built in advance.

On the other hand, the application executes in a SandBox [SB] which restricts
the memory access (RAM and/or permanent). Only the SB can read/write the memory
of which the maximal quantity is determined at starting (ex: 2, 3, or 6 Gb).
The operations are dealt only by registered applications and owner of their
memory (encapsulation). The author access are done by SB, not per user. The
operating system itself is not able to know what is the content of this memory
(which is encodable). This adds an enforcement against non authorized access.

Authentication: this scenario describes the functionality to implement (which
is is made by simulation):

1. The contacted Web site creates a message of 3000 (+32) random characters
   and encrypts it (+3 times).
2. The user receives the message and decodes (via his key Daa and the module
   NW integrated in his browser [a plug-in to develop]). A CRC-32 calculation
   of this message is done. The result is inserted in the message, then is
   encrypted again (+3 times). The length stays the same.
3. The Web site receives the message, decrypts it and validates the CRC
   included. Then it insures that the user is the good one. In option,
   a verification of the IP address could be done to know if this one is
   probable. It would impose that the server of the company must be in
   the region where is the user (principle of autonomy and localization).

Hence, there is no public key, trust third party, nor certificate, but a
same private key on each side. That one is never transmitted by the Web;
or it is by a connection already secure. Which would constitute then an
intermediary level.

About the dictionary referenced in NetDisq.rc: it is necessary to add
#include "..\\Commun\\Common.rc" at the end. Otherwise, the messages 
would not be significative. Further the application would stop at the
beginning. The problem is when we do changes with the resource editor
of VS 2019+: this last line is deleted. It happens that we forget to
readd it. It may be due to the free version, as it adds automatically
spaces when editing the code; or deletes. It is suggested to edit and
test the screens (design) with Forms.rc. Copy and paste the modifi-
cations after in NW<NomModule>.rc.

To note that the module Daa "consumes" +311 Kb of memory (for the 
multiuser environments), but is freed after the initialization.
The loading of Cyptur.dll takes +250 Kb. Their separation permits to 
economize memory. It must be tested eventually when many users authenticate
themselves at the same time. Each call to NWModule/NWService is then managed
separately. These data must however be precised by a more detailed analysis...
What is important is that the task executes itself in less than one second
(or almost). The deployment of a queue on the server side would attenuate
these "side effects".