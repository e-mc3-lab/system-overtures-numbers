/*
Copyright(c) 2024-2026 SCLE-CSES. Governed by the SCLE License 1.0; the
full text of which is contained in the file Licence.txt included in
NetDisq packages.
*/

#include "Fichier.h"
#include "Random.h"
#include "Cmdline.h"
#include "NWService.h"

static char gChemDev[MAX_PATH] = {0}, gChemService[MAX_PATH] = {0},
    gCnfMsgA[MAX_PATH] = {0}, gCnfMsgM[MAX_PATH] = {0},
    gCnfMsgS[MAX_PATH] = {0}, gConfig[DIM_8] = {MOT_CONFIG_RELEASE},
    gParamSource[DIM_8] = {0}, gCnfSEthxDb[MAX_PATH] = {0},
    gChemModUtil[MAX_PATH] = {0}; static int gNoDossierRef = 0;

char* getParamSource(){ return gParamSource; }

void setParamSource(char ps[]){ strcpy(gParamSource, ps); }

BOOL estSourceAdmin()
{ 
    BOOL r�sultat = (_strcmpi(gParamSource, MOT_SOURCE_ADMIN) == 0);
    if (r�sultat){ getChemNomFichierMsgA(); } return r�sultat;
}

BOOL estSourceModule()
{ 
    BOOL r�sultat = (_strcmpi(gParamSource, MOT_SOURCE_MODULE) == 0);
    if (r�sultat){ getChemNomFichierMsgM(); } return r�sultat;
}

char* getCheminDev(char chemProgramme[])
{
    if (gChemDev[0] != EOL){ return gChemDev; }
    char *s, chem[MAX_PATH] = {0}; strcpy(chem, chemProgramme);
    s = strrchr(chem, CAR_S�PAR_DIR); if (s){ s[0] = EOL; }
    BOOL bEstDossierVs = FALSE; while ( ! bEstDossierVs) // ../.
    {   // ~/nwservice/x64/debug ou release.
        s = strrchr(chem, CAR_S�PAR_DIR); if (s){ s[0] = EOL; }
        bEstDossierVs = (_strcmpi(getDernierNom(chem), NOM_DOSSIER_VS) == 0);
        if (bEstDossierVs){ memcpy(gChemDev, chem, MAX_PATH); }
    } setCheminProgramme(""); /*R�initialiser*/ return gChemDev;
}

void setDossierProgrammeNW(char cnf[], const char nomDossier[])
{   // POST: NWModule pourrait se trouver dans un autre dossier.
    const char FMT[] = "%s%s%s%s%s%s%s"; if (cnf[0] == EOL)
    {   // PRE: pour la simulation, il doit rester au m�me endroit.
        char* cnfDev = getCheminDev(getCheminProgramme());
        sprintf(cnf, FMT, cnfDev, S�PAR_DIR, nomDossier,
            S�PAR_DIR, MOT_PLATEFORM_X64, S�PAR_DIR, gConfig);
    }
}

char* getCheminService()
{
    setCheminService(); return gChemService;
}

void setCheminService()
{ 
    if (gChemService[0] == EOL){ setDossierProgrammeNW(gChemService,
            NOM_NW_SERVICE); }
}

char* getCheminModule()
{
    setDossierProgrammeNW(gChemModUtil, NOM_NW_MODULE); return gChemModUtil;
}

char* getChemSEthxDb()
{
    setCheminService(); if (gCnfSEthxDb[0] == EOL){
        sprintf(gCnfSEthxDb, "%s%s%s", gChemService, S�PAR_DIR, NOM_ETHX_DB);
    }
    return gCnfSEthxDb;
}

char* getConfiguration(){ return gConfig; }

void setConfiguration(char conf[]){ strcpy(gConfig, conf); }

int getNoDossierRef(){ return gNoDossierRef; }

void setNoDossierRef(int i){ gNoDossierRef = i; }

int getNoDossierRefA(const char msg[])
{
    int i = 0; for (; i < strlen(msg) && msg[i] != S�PAR_CODE_MSG[0]; ){ i++; }
    if (i < DIM_MOT_ID_ERR){ return 0; } const int N = i - DIM_MOT_ID_ERR - 1;
    char result[DIM_8] = {0}; strncpy(result, (msg + DIM_MOT_ID_ERR + 1), N);
    result[min(N, DIM_8-1)] = EOL; return atoi(result);
}

BOOL estRefEnUtilisation(int i){
    return (existe(getCnRefEnUtilisation(i)) && (i != gNoDossierRef));
}

uint getDernierDossierRef(char chemin[])
{
    const int MAX_UI16 = MAXUINT16; int i = 0; char cnf[MAX_PATH] = {0}; do
    {
        sprintf(cnf, FMT_DOSSIER_TMP, chemin, S�PAR_DIR, i + 1, S�PAR_DIR);
        i++; if (estDossierVide(cnf, SUFX_DLL))
        {
            RemoveDirectoryA(cnf); i--; break;
        }
    } while (existe(cnf) && ! estRefEnUtilisation(i) && i < MAX_UI16); return i;
}

char* getChemNomFichierMsg(char cnfMsg[], const char nomDossierNw[])
{
    char cnfPrg[MAX_PATH] = {0}; setDossierProgrammeNW(cnfPrg,
        nomDossierNw); sprintf(cnfMsg, "%s%s%s", cnfPrg, S�PAR_DIR,
        NOM_NW_SEC_MSG); strcpy(cnfMsg, convEnMinuscules(cnfMsg));
    return cnfMsg;
}

char* getChemNomFichierMsgA(){
    return getChemNomFichierMsg(gCnfMsgA, NOM_NW_ADMIN);
}

char* getChemNomFichierMsgM(){
    return getChemNomFichierMsg(gCnfMsgM, NOM_NW_MODULE);
}

char* getChemNomFichierMsgS(){
    return getChemNomFichierMsg(gCnfMsgS, NOM_NW_SERVICE);
}

char* getChemRef(int i)
{
    static char gChemR[MAX_PATH] = {0}; setCheminService();
    sprintf(gChemR, FMT_DOSSIER_TMP, getCheminService(),
        S�PAR_DIR, i, S�PAR_DIR); return gChemR;
}

char* getCnRefEnUtilisation(int i)
{
    static char gCnRef[MAX_PATH] = {0};
    sprintf(gCnRef, "%s%s", getChemRef(i), MOT_UTILIZE); return gCnRef;
}

char* getCnfMsg()
{
    static char cmsg[MAX_PATH] = {0}; 
    if (estSourceAdmin()){
        strcpy(cmsg, getChemNomFichierMsgA());
    } else if (estSourceModule()){
        strcpy(cmsg, getChemNomFichierMsgM());
    } else { 
        if (gCnfMsgS[0] == EOL){ getChemNomFichierMsgS(); }
        strcpy(cmsg, gCnfMsgS); } return cmsg;
}

NTSTATUS cr�erFichier(const char cnf[])
{
    FILE* fichier = fopen(cnf, "w+"); if ( ! fichier){ return ERR_FILE_WRITE; }
    fclose(fichier); return EXIT_SUCCESS;
}

int ex�cuterCommandeNws(int argn, char argv[][DIM_64])
{
    static char gCnfCmd[MAX_PATH] = {0}; if (gCnfCmd[0] == EOL){ 
        sprintf(gCnfCmd, "%s%s%s%s", getCheminService(), S�PAR_DIR, 
            NOM_NW_SERVICE, SUFX_EXE); 
    }
    return ex�cuterCommande(gCnfCmd, getCnfMsg(), argn, argv); 
}