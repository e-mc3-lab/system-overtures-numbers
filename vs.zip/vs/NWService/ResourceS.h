//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by NetDisq.rc
//

#define IDC_MOTDEPASSE1                 303
#define IDC_MOTDEPASSE2                 304
#define IDM_NOUVEAU_DOA                 307
#define IDM_AUTHENTIFICATION            308
#define IDM_AFFICHER_DESIGN             309

#define IDC_TEXTE                       1001
#define IDT_MOTDEPASSE                  1002
#define IDT_MOTDEPASSE1                 1003
#define IDT_MOTDEPASSE2                 1004
#define IDC_MOTDEPASSE                  1005

#define IDM_OUVRIR_FICHIER              32001
#define IDB_CHIFFRE                     32003

#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        326
#define _APS_NEXT_COMMAND_VALUE         32005
#define _APS_NEXT_CONTROL_VALUE         1036
#define _APS_NEXT_SYMED_VALUE           110
#endif
#endif 
