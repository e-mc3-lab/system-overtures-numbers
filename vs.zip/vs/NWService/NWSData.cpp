/*
Copyright(c) 2024-2026 SCLE-CSES. Governed by the SCLE License 1.0; the
full text of which is contained in the file Licence.txt included in
NetDisq packages. TODO: convertir en donn�es relationnelles (SQL).
*/

#include "Fichier.h" 
#include "Random.h" 
#include "Cmdline.h"
#include "NWSMessage.h"
#include "NWSData.h"

static char *gTabLignes[DIM_256] = {0};


NTSTATUS getCodUtilAl�atoire(char tab[])
{
    const uint8 N = NCARSUTIL; if ( ! getRandBytes((uchar*)tab, N, TRUE)){
        return ERR_MOTPASSE_INVALIDE;
    } 
    char s; tab[N - 1] = EOL; setNonVide(ND_CB(tab), N, TRUE, FALSE); 
    for (uint8 i = 0; i < NCARSUTIL && tab[i]; i++)
    {
        s = tab[i];  if ((s == '\\') || (s == '/') || (s == ':')    ||
            (s == '*') || (s == '?') || (s == '"') || (s == '<')    ||
            (s == '>') || (s == '|') || (s == ' ') || (s < DIM_32)  ||
            (s == '[') || (s == ']') || (s == '{') || (s == '}')    ||
            (s == '`') || (s == '\'') || (s == '(') || (s == ')')   ||
            (s == '-') || (s == ',') || (s == NL[0])){ tab[i] = 'a' + i; }
    }
    return EXIT_SUCCESS;
}

void ajouterRefUtilisation(int i)
{
    char* cnf = getCnRefEnUtilisation(i), txt[DIM_8] = { "1" };
    FILE* fichier = fopen(cnf, "w"); if (fichier){
        fwrite(txt, 1, 1, fichier); fclose(fichier);
    }
}

void supprimerRefUtilisation(int i){
    supprimerFichier0(getCnRefEnUtilisation(i));
}

NTSTATUS chiffrerMPasse(UTILISATEUR* util){ return EXIT_SUCCESS; } // TODO
NTSTATUS d�chiffrerMPasse(byte mpassc[]){ return EXIT_SUCCESS; }

uint16 getLongueurLigne(FILE* fichier)
{   // Il peut y avoir des blancs (espaces) apr�s un mot de passe.
    int r = 0, i = 1, j = 0, pos = ftell(fichier); char s = fgetc(fichier);
    while ( ! feof(fichier) && (s != NL[0]) && (s != '\r'))
    { 
        i++; if (s == ' '){ j++; } s = fgetc(fichier);
    } // Est-ce une ligne vide (longueur 0) ?
    r = ((j == (i - 1)) ? 0 : i + 1); fseek(fichier, pos, SEEK_SET); return r;
}

void getLignesEthxDb(FILE* fichier, long pos)
{
    uint i = 0, j = 0, M = MAX_PASSWORD; lib�rerTabInfosEthxDb();
    char txt[DIM_256] = {0}, *ln, *ttx; fseek(fichier, pos, SEEK_SET); 
    long lLigne = getLongueurLigne(fichier);
    ln = fgets(txt, min(lLigne, MLN), fichier);
    while (ln && ! feof(fichier) && (STRLEN(txt) > NCARSUTIL) && 
          (i < MAX_UTILS))
    {
        ttx = trim(txt); if (STRLEN(ttx) > 0)
        {
            lLigne = long(STRLEN(txt))+1; 
            gTabLignes[i] = (char*)NDAllouer0(lLigne+1);
            strncpy(gTabLignes[i], ttx, lLigne);
            gTabLignes[i++][lLigne] = NL[0];
        }
        lLigne = getLongueurLigne(fichier);
        ln = fgets(txt, min(lLigne, MLN), fichier);
    } 
    fseek(fichier, pos, SEEK_SET);
}

FILE* getInfoViaEthxDb(UTILISATEUR* util)
{   
    FILE *fichier = NULL; char txt[DIM_256], *rech = NULL, *cnfProg = NULL;
    const char CNL = NL[0]; char* cnfEthxDb; cnfProg = getCheminProgramme();
    cnfEthxDb = getChemSEthxDb(); if ( ! existe(cnfEthxDb)){
        cr�erFichier(cnfEthxDb); return NULL; // Mot de passe � cr�er.
    }
    long pos = 0, lLigne = 0; fichier = fopen(cnfEthxDb, "r+");
    const uint M = NCARSUTIL; char mpassnl[MAX_PASSWORD + 2] = {0};
    ND_ASSERT_CS(fichier, ERR_FILE_READ); lLigne = getLongueurLigne(fichier);
    rech = fgets(txt, min(MLN, lLigne), fichier); lLigne = UI32_STRLEN(txt);
    if (rech) do
    {
        if (memcmp(trim(txt), util->code, M) == 0)
        {
            if (util->mpassd.longueur == 0)
            {
                char* txtm = trim(txt) + M + 1;
                uint16 lmp = min(uint16(STRLEN(txtm)), MAX_PASSWORD);
                memcpy(mpassnl, txtm, lmp);
                if (mpassnl[lmp] != CNL){ mpassnl[lmp] = CNL; }
                util->mpassd.longueur = lmp; util->mpassd.nouveau = TRUE;
                memcpy(util->mpassd.texte, mpassnl, lmp);
                if (seTerminePar(ND_CC(util->mpassd.texte), NL))
                {   // Pr�caution inutile, quoique...
                    util->mpassd.texte[--lmp] = EOL; 
                    util->mpassd.longueur = lmp;
                } else { util->mpassd.texte[lmp+1] = EOL; }
                pos = ftell(fichier) - lmp - NCARSUTIL + 1;
            }
            fseek(fichier, pos, SEEK_SET); ND_FIN();
        }
        pos += lLigne; lLigne = getLongueurLigne(fichier);
        rech = fgets(txt, min(lLigne, MLN), fichier);
    } while (rech && (lLigne > NCARSUTIL));
    if (rech){ getLignesEthxDb(fichier, pos); }
    else { util->mpassd.nouveau = TRUE; }
    ND_FIN();
ERR:posterMessagErreurClt(NOM_NWS_DATA, gNoLigne);
FIN:return fichier;
}

NTSTATUS setConfirmNouveauDaa(UTILISATEUR* util)
{
    FILE* fichier = getInfoViaEthxDb(util); char* mpassnl = NULL;
    const uint N = NCARSUTIL, M = N + MIN_PASSWORD_LEN + 1;
    ENTIER l = util->mpassd.longueur; char code[N + 1] = {0}; 
    const char CNL = NL[0]; const char FAUX = '0';
    ND_ASSERT_S(gNDR�sultat); ND_ASSERT_CS(fichier, ERR_FILE_READ);
    strncpy(code, util->code, N); code[N] = EOL;
    mpassnl = new char[l + uint64(2)]; strncpy(mpassnl,
        ND_CC(util->mpassd.texte), l); mpassnl[l] = CNL; mpassnl[l + 1] = EOL;
    if ( ! gTabLignes || ! gTabLignes[0])
    {
        fputs(code, fichier); fputc(FAUX, fichier); fputs(mpassnl, fichier);
    } 
    ND_FIN(); ERR: posterMessagErreurClt(NOM_NWS_DATA, gNoLigne); 
FIN:if (mpassnl){ delete[] mpassnl; } if (fichier){ fclose(fichier); } 
    return gNDR�sultat;
}

void supprimerInfoDEthxDb(UTILISATEUR* util)
{   
    FILE* fichier = getInfoViaEthxDb(util); BOOL yaDesLignesApr�s = FALSE;
    if (fichier)
    {
        uint i = 1, l = 0; for (; i < DIM_256 && gTabLignes[i]; i++)
        {
            l = uint(strlen(gTabLignes[i])); gTabLignes[i][l] = NL[0];
            fwrite(gTabLignes[i], 1, l + 1, fichier); yaDesLignesApr�s = TRUE;
        }
        long lf = (yaDesLignesApr�s ? long(max(STRLEN(gTabLignes[0]),
            STRLEN(gTabLignes[i-1]))) + 6 : getLongueurLigne(fichier));
        for (int i = 0; i < lf; i++){ fputc(' ', fichier); }
        fclose(fichier); posterMessageTexteClt("SUPPRESS_SUCCESS");
    }
}

NTSTATUS getInfoViaConnexChiffr�e(UTILISATEUR* util)
{
    FILE* fichier = getInfoViaEthxDb(util); ND_ASSERT_S(gNDR�sultat);
    if (fichier){ fclose(fichier); } ND_ASSERT_CS(util->mpassd.longueur > 0,
        ERR_ARGUMENT_INVALIDE); d�chiffrerMPasse(util->mpassd.texte); ND_FIN();
ERR:posterMessagErreurClt(NOM_NWS_DATA, gNoLigne);
FIN:if (fichier){ fclose(fichier); } return gNDR�sultat;
}

NTSTATUS getInfoDisponible(UTILISATEUR* util)
{
    const uint16 MU = MAX_UTILS / 2; uint i = 0, j = 0, l; FILE* fichier = NULL;
    const uint N = MLN, S = NCARSUTIL; char* rech = NULL; const char FAUX = '0';
    static UTILISATEUR* gRSUtilDispo[MU] = {0}; char txt[DIM_256] = {0}, *ttx;
    const uint DIMUTIL = sizeof(UTILISATEUR); char* cnfEthxDb = getChemSEthxDb();
    int lLigne = 0; ND_ASSERT_CS(existe(cnfEthxDb), ERR_NO_ETHX_DB);
    fichier = fopen(cnfEthxDb, "r"); ND_ASSERT_CS(fichier, ERR_FILE_READ);    
    rech = fgets(txt, N, fichier); if (rech) do
    {   
        ttx = trim(txt); if (ttx[S] == FAUX)
        {
            gRSUtilDispo[i] = (UTILISATEUR*)NDAllouer0(DIMUTIL);
            strncpy(gRSUtilDispo[i]->code, ttx, NCARSUTIL);
            ttx += NCARSUTIL + 1; l = uint(STRLEN(ttx));
            memcpy(gRSUtilDispo[i]->mpassd.texte, (byte*)ttx, l);
            gRSUtilDispo[i]->mpassd.texte[l] = EOL;
            gRSUtilDispo[i++]->mpassd.longueur = l;
        }
        lLigne = getLongueurLigne(fichier); rech = fgets(txt, 
            min(DIM_256, lLigne), fichier);
    } while (rech && (i < MAX_UTILS)); if (fichier){ fclose(fichier); } 
    init0(util->code, NCARSUTIL); if (i > 0)
    {
        int j = getNombreAl�atoire(i);
        strncpy(util->code, gRSUtilDispo[j]->code, NCARSUTIL);
        memcpy(&util->mpassd, &gRSUtilDispo[j]->mpassd, DIM_MP_DRV);
    } else { ND_ASSERT_S(ERR_NO_ETHX_DB); }
    ND_FIN(); ERR:posterMessagErreurClt(NOM_NWS_DATA, gNoLigne);
FIN:if (fichier){ fclose(fichier); } for (j = 0; j < i; j++){ 
    NDFree0(gRSUtilDispo[j], DIMUTIL); ERR_MEM:; } return gNDR�sultat;
}

NTSTATUS setConfirmInscription(UTILISATEUR* util)
{
    FILE* fichier = getInfoViaEthxDb(util); if (fichier)
    {
        long pos = ftell(fichier), sautLn = 0; 
        if (fgetc(fichier) == NL[0]){ sautLn = 1; }
        pos += NCARSUTIL + sautLn; const char VRAI = '1'; 
        fseek(fichier, pos, SEEK_SET); fputc(VRAI, fichier); fclose(fichier);
        posterMessageTexteClt(util->code);
    } else { return ERR_ARGUMENT_INVALIDE; } 
    return EXIT_SUCCESS;
}

void init0MPassEthxDb(uint i)
{   // Effacer le mot de passe.
    ENTIER dimLn = STRLEN(gTabLignes[i]);
    if (dimLn){ init0(gTabLignes[i] + NCARSUTIL, dimLn - NCARSUTIL); }
}

char* getUtil0EthxDb()
{   // POST: appeler lib�rerTabInfosEthxDb apr�s utilisation.
    char* cnfEthxDb = getChemSEthxDb(); FILE* fichier = NULL;
    int lLigne = 0; ND_ASSERT_CS(existe(cnfEthxDb), ERR_FILE_READ);
    fichier = fopen(cnfEthxDb, "r"); ND_ASSERT_CS(fichier, ERR_FILE_READ);
    getLignesEthxDb(fichier, 0); init0MPassEthxDb(0); ND_FIN();
ERR:posterMessagErreurClt(NOM_NWS_DATA, gNoLigne);
FIN:if (fichier){ fclose(fichier); } return gTabLignes[0];
}

char* getUtilNextEthxDb(uint i)
{
    if (i < DIM_256){ init0MPassEthxDb(i); return gTabLignes[i]; } return NULL;
}

void lib�rerTabInfosEthxDb()
{   for (int i = 0; i < DIM_256 && gTabLignes[i]; i++){ NDFree(gTabLignes[i]); } }