/*
Copyright(c) 2024-2026 SCLE-CSES. Governed by the SCLE License 1.0;  
the full text of which is contained Licence.txt included in 
NetDisq packages. 
*/

#include "Fichier.h"
#include "ProcesSpace.h"
#include "NWService.h"
#include "NWKeys.h"


typedef void (WINAPI* Authentifier)(CONTEXTE_VOLUME*);
typedef void (WINAPI* FinDaa)(CRYPTO_INFO*);
typedef void (WINAPI* InitCyptur)(CRYPTO_INFO*);
typedef void (WINAPI* FinCyptur)(CRYPTO_INFO*);

static char gCnfDaaDll[MAX_PATH] = {0}, gCnfCypDll[MAX_PATH] = {0},
    gCnfSmartkeyNd[MAX_PATH] = {0}; HMODULE gHmCDll = NULL;

char* getChemDaaDll(){ return gCnfDaaDll; }
void setChemDaaDll(char cnfDll[]){ strcpy(gCnfDaaDll, cnfDll); }

char* getChemCypturDll(){ return gCnfCypDll; }
void setChemCypturDll(char cnfDll[]){ strcpy(gCnfCypDll, cnfDll); }

char* getChemSmartkeyNd(){ return gCnfSmartkeyNd; }
void setChemSmartkeyNd(char cnfSkNd[]){ strcpy(gCnfSmartkeyNd, cnfSkNd); }

HMODULE getDaaDll(){ return LoadLibraryA(gCnfDaaDll); }

HMODULE getCypturDll()
{
    if ( ! gHmCDll){ gHmCDll = LoadLibraryA(gCnfCypDll); } return gHmCDll;
}

void finLib(HMODULE* hm)
{
    finListeFilsFx(); if (hm  && *hm){ if (FreeLibrary(*hm)){ *hm = NULL; }}
}

void finDaaDll(HMODULE hmDaaDll, CONTEXTE_VOLUME* cv)
{
    if (hmDaaDll)
    {
        FinDaa fcFinDaa = (FinDaa)GetProcAddress(hmDaaDll, NOM_FCT_FIN_DAA);
        if (fcFinDaa && cv){ fcFinDaa(&cv->ci); } finLib(&hmDaaDll);
    }
}

void finCypturDll(CONTEXTE_VOLUME* cv)
{
    if (gHmCDll)
    {
        FinCyptur fcFinCypt = (FinCyptur)GetProcAddress(gHmCDll,
            NOM_FCT_FIN_CYPTUR);
        if (fcFinCypt && cv){ fcFinCypt(&cv->ci); } finLib(&gHmCDll);
    }
}

NTSTATUS nwAuthentifier(CONTEXTE_VOLUME* cv)
{
    NTSTATUS r = 0; int EOI = ERR_OBJECT_INIT; Authentifier fcAuthentifDaa;
    FinDaa fcFinDaa = NULL; InitCyptur fcInitCyptur = NULL;
    FinCyptur fcFinCyptur = NULL; static HMODULE hmDaaDll = NULL;
    CRYPTO_INFO ci = {0}; hmDaaDll = getDaaDll(); ND_ASSERT_CS(hmDaaDll, EOI);
    ND_ASSERT_CS(cv, EOI); fcAuthentifDaa = (Authentifier)GetProcAddress(hmDaaDll,
        NOM_FCT_AUTHENTIFIER); ND_ASSERT_CS(fcAuthentifDaa, EOI); 
    cv->ci.mode = XTS; cv->r�sultat = ERR_DONT_REPORT;
    for (int i = 0; i < 1 && ! NT_SUCCESS(cv->r�sultat); i++){
        fcAuthentifDaa(cv);
    }
    ND_ASSERT_S(cv->r�sultat); r = copierCI(&ci, &cv->ci); ND_ASSERT_S(r);
    fcFinDaa = (FinDaa)GetProcAddress(hmDaaDll, NOM_FCT_FIN_DAA);
    ND_ASSERT_CS(fcFinDaa, EOI); fcFinDaa(&cv->ci); // Changement de lib.
    ND_ASSERT_S(cv->ci.r�sultat); fcFinDaa = NULL; finLib(&hmDaaDll);
    if ( ! gHmCDll){
        gHmCDll = LoadLibraryA(gCnfCypDll); ND_ASSERT_CS(gHmCDll, EOI);
    }
    r = copierCI(&cv->ci, &ci); ND_ASSERT_S(r);
    fcInitCyptur = (InitCyptur)GetProcAddress(gHmCDll, NOM_FCT_INIT_CYPTUR);
    ND_ASSERT_CS(fcInitCyptur, EOI); fcInitCyptur(&cv->ci);
    ND_ASSERT_S(cv->ci.r�sultat); ND_FIN();
ERR: FIN:finDaaDll(hmDaaDll, cv); return gNDR�sultat;
}
