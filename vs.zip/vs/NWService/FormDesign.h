//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by NetDisq.rc
//
#define IDD_FORM                        1100
#define IDT_ADR_NOM_SITE_WEB            1103
#define IDC_ADR_NOM_SITE_WEB            1104
#define IDT_CODE_UTILISATEUR            1105
#define IDC_CODE_UTILISATEUR            1106
#define IDT_COURRIEL                    1110
#define IDC_COURRIEL                    1111

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        326
#define _APS_NEXT_COMMAND_VALUE         32005
#define _APS_NEXT_CONTROL_VALUE         1200
#define _APS_NEXT_SYMED_VALUE           110
#endif
#endif
