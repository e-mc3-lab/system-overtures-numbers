The folder "vs" is for the section 3: P =? NP of the document
"systematic-deductive-overtures".

For file limit size reason in github, we created two archives:
the first is for the sources and programs, and the other are for the keyfiles.