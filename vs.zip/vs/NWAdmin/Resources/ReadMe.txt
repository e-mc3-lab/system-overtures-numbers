
Create keyfiles KeySpace.nd via those available in 
~/NWService/../.1, .2, .3/, etc. 

NB: sometimes after few automatic tries, we do not get result. In this
case, the last reference folder in NWService (ex: .3) is deleted. Try
again. This time, .2 will be used, and .1 after if necessary.

When we tested the algorithm "Rectangle", the build of keys became less
effective. It is the same thing with algorithms that handle too much
the registers, like ChaCha-Poly and others (should they utilize NASM ?).
Hence, we replace it by a better as Camellia, that uses modifiable arrays
(S-Box). One indicator showing that the unified algorithms (6) are good,
is when the auto-test (executes at the end of CxRef construction) prints
the lines DoAutoTestAlgorithm...succeeded one time, without other tries,
and often. Then we know that the compositions are optimal.

We can automatize the creation of keys, but we must obviously modify the
NWAdmin module (including CxRef [+ disable the display of error messages]).
The process is done on free periods, to create keys in advance.