//{{NO_DEPENDENCIES}} Microsoft Visual C++ generated include file.
// Used by NWAdmin.rc

#define IDD_NOUV_FCLEF                  200
#define IDB_NOUV_FCLEF                  250
#define IDT_TEST_AUTHENTIF              252
#define IDC_TEST_AUTHENTIF              256
#define IDB_VERIF_AUTO                  258
#define ID_SUPP_DREF                    260
#define IDM_AUTHENTIFICATION            308
#define IDM_OPTIONS                     309
#define IDC_PROGRESS_BAR                321
#define IDC_SUR_DISQUE                  323
#define IDC_AFFICHER_MOTSDEPASSE        324
#define ID_NOUV_FCLEF                   325
#define IDC_TEXTE_CONSOLE               326

#define IDC_TEXTE                       1001
#define IDT_MOTDEPASSE                  1002
#define IDT_MOTDEPASSE1                 1003
#define IDT_MOTDEPASSE2                 1004
#define IDC_MOTDEPASSE                  1005
#define IDB_ENREGISTRER                 1030

#define IDM_OUVRIR_FICHIER              32001
#define IDB_CHIFFRE                     32003

#define IDC_STATIC                      -1

// Next default values for new objects 
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        328
#define _APS_NEXT_COMMAND_VALUE         32005
#define _APS_NEXT_CONTROL_VALUE         1036
#define _APS_NEXT_SYMED_VALUE           110
#endif
#endif
