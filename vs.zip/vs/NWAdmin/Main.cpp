/*
 Copyright(c) 2024-2026 'SCLE+CSES'. This is governed by the 
 SCLE License; the full text of which is contained in the file 
 Licence 1.0.txt included in NetDisq distribution packages.
 */

#include "Random.h"
#include "Language.h"
#include "Fichier.h"
#include "Cmdline.h"
#include "Forms.h"
#include "ErreurDict.h"
#include "NWSData.h"
#include "NWMData.h"
#include "NWSMessage.h"
#include "NWService.h"
#include "NWAdmin.h"

LRESULT RAPPEL MainWndProc(HWND, UINT, WPARAM, LPARAM);
HWND initDialogueNouvCl�s(HWND hFrm); LPARAM RAPPEL DialogueNouvCl�s(HWND, 
    UINT, WPARAM, LPARAM); void quitter();

const uint8 MAX_ESSAIS = 8; char gToDelete[2048] = "abc";

BOOL bEnregUtil = FALSE, bUtil�V�rifier = FALSE, bTestAuthentif = FALSE;
static char gConfig[DIM_8 + 1] = { MOT_CONFIG_RELEASE },
    *gResultSetUtils[MAX_UTILS] = {0}, gCodUtil[NCARSUTIL + 1] = {0}; 
    
LRESULT RAPPEL MainWndProc(HWND hWnd, UINT message,
    WPARAM wParam, LPARAM lParam) // Messages applicatifs.
{
    gNDR�sultat = ERR_SUCCESS; int wmId = LOWORD(wParam); if (bEnregUtil)
    {
        bEnregUtil = FALSE; HWND hWnd1 = initDialogueNouvCl�s(hWnd);
        ShowWindow(hWnd1, SW_NORMAL);

    } else switch (message){

        case WM_COMMAND: // Menus.
        {
            switch (wmId)
            {
            case ID_NOUV_FCLEF:
            {
                HWND hWnd1 = initDialogueNouvCl�s(hWnd); 
                ShowWindow(hWnd1, SW_NORMAL);
            } break;

            case IDM_OPTIONS:
            {
                afficherInfo(GetString("MSG_TO_IMPLEMENT"));
            } break;

            case IDM_AIDE:
            {
                WORD iddAide = IDD_AIDE_EN;
                if (isLangFr()){ iddAide = IDD_AIDE_FR; } DialogBox(gethInst(),
                    MAKEINTRESOURCE(iddAide), hWnd, DialoguAide);
            } break;

            case IDM_FERMER: 
                DestroyWindow(hWnd); break;

            default:
                gNDR�sultat = (NTSTATUS)DefWindowProc(hWnd, message, 
                    wParam, lParam); break;
            }
        }
        break;

        case WM_PAINT: 
        {
            PAINTSTRUCT ps = {0}; 
            HDC hdc = BeginPaint(hWnd, &ps); EndPaint(hWnd, &ps);
        } 
        break;

        case WM_DESTROY: 
        {
            quitter(); PostQuitMessage(0); break;
        }

        default: 
            // NB: n'utiliser pas cette fonction avec ND_ASSERT_CS.
            gNDR�sultat = (NTSTATUS)DefWindowProc(hWnd, message, wParam, 
                lParam); break;
        }
    // switch.
    return gNDR�sultat;
}

HWND initDialogueNouvCl�s(HWND hFrm)
{
    char txt[DIM_256], *util, *ligneInfos; int i = 0; HWND hcbx = NULL;
    byte texte[MAX_PATH] = {0}; HWND hWnd = CreateDialog(gethInst(),
        MAKEINTRESOURCE(IDD_NOUV_FCLEF), hFrm, DialogueNouvCl�s);
    SetWindowText(hWnd, GetString("IDD_NOUV_KEYF")); // Titre.
    hcbx = GetDlgItem(hWnd, IDC_TEST_AUTHENTIF); for (i = 0; i < 50; i++)
    {
        getRandBytes(texte, MAX_PATH, FALSE); SendDlgItemMessageA(hWnd,
            IDC_TEXTE_CONSOLE, LB_ADDSTRING, i, (LPARAM)texte);
    }
    SendDlgItemMessageA(hWnd, IDC_TEXTE_CONSOLE, LB_ADDSTRING, 0, (LPARAM)"");
    SendMessage(GetDlgItem(hWnd, IDC_TEXTE_CONSOLE), LB_SETCURSEL, 50, 0);
    SetDlgItemText(hWnd, IDB_NOUV_FCLEF, GetString(IDL_CREATE));
    SetDlgItemText(hWnd, IDT_TEST_AUTHENTIF, GetString("IDT_TEST_AUTHENTIF"));
    SetDlgItemText(hWnd, IDB_VERIF_AUTO, GetString("IDB_VERIF_AUTO"));
    SetDlgItemText(hWnd, IDCANCEL, GetString(IDL_FERMER));
    ligneInfos = getUtil0EthxDb(); i = 0; while (ligneInfos)
    {
        gResultSetUtils[i] = (char*)NDAllouer0(NCARSUTIL + 1);
        util = gResultSetUtils[i]; strncpy(util, ligneInfos, NCARSUTIL);
        util[NCARSUTIL] = EOL; AddComboItem(hcbx, util); i++;
        ligneInfos = getUtilNextEthxDb(i);
    }
    init0(txt, DIM_256); lib�rerTabInfosEthxDb(); return hWnd;
}

void quitter(){ UnloadLanguageFile(); }

void set�tatBouton(HWND hFrm, int id, BOOL b)
{
    HWND btn = GetDlgItem(hFrm, id); if (btn){ EnableWindow(btn, b); }
}

int getUtilS�lectionn�(HWND hFrm, HWND hcbx)
{
    LRESULT nIndex = SendMessage(hcbx, CB_GETCURSEL, 0, 0);
    if (nIndex > MAX_UTILS){ return ERR_INVALID_INIT; };
    if (nIndex >= 0){ strcpy(gCodUtil, gResultSetUtils[min(nIndex, MAX_UTILS)]);
    } else { set�tatBouton(hFrm, IDB_VERIF_AUTO, FALSE); } 
    return int(nIndex);
}

void supprimerCl�R�f�rence(int j) // .1, .2, .3, ...
{
    char argv[DIM_8][DIM_64] = {0}; int argn = 0; uint8 i = 0;
    strcpy(argv[i++], "/" PARAM_SRC_PRG); strcpy(argv[i++], MOT_SOURCE_ADMIN);
    strcpy(argv[i++], "/" PARAM_SUPPRESS_REF); strcpy(argv[i++],
        "/" PARAM_NO_REF); sprintf(argv[i++], "%d", j);
    strcpy(argv[i++], "/" PARAM_CONFIG); strcpy(argv[i++], gConfig); argn = i;
    ex�cuterCommandeNws(argn, argv); finR�ponseCmd();
}

/*
 * Le dossier de l'utilisateur.
 */ 
void supprimerPr�Inscription() 
{   
    char argv[DIM_8][DIM_64] = {0}; int argn = 0; uint8 i = 0;
    strcpy(argv[i++], "/" PARAM_SRC_PRG); strcpy(argv[i++],
        MOT_SOURCE_ADMIN); strcpy(argv[i++], "/" PARAM_SUPPRESS_INSC);
    strcpy(argv[i++], gCodUtil); strcpy(argv[i++], "/" PARAM_CONFIG);
    strcpy(argv[i++], gConfig); strcpy(argv[i++], "/" PARAM_NO_REF);
    sprintf(argv[i++], "%d", getNoDossierRef()); argn = i;
    ex�cuterCommandeNws(argn, argv); finR�ponseCmd();
}

void actualiserListUtils(HWND hcbx, int j)
{
    SendMessage(hcbx, CB_RESETCONTENT, 0, 0); uint SELUTIL = CB_SETCURSEL;
    for (int i = 0; i < j; i++){ AddComboItem(hcbx, gResultSetUtils[i]); }
    for (int i = j; i < (MAX_UTILS - 1); i++)
    {
        gResultSetUtils[i] = trim(gResultSetUtils[i + 1]);
        if ((STRLEN(gResultSetUtils[i]) >= NCARSUTIL)){
            AddComboItem(hcbx, gResultSetUtils[i]);
        }
    } 
    gResultSetUtils[MAX_UTILS-1] = NULL; SendMessage(hcbx, SELUTIL, j, 0);
}

void cr�erNouvCl�s(HWND hFrm)
{
    char argv[DIM_8][DIM_64] = {0}; int argn = 0, r = 0; char* message = NULL;
    uint8 i = 0, j; strcpy(argv[i++], "/" PARAM_SRC_PRG); strcpy(argv[i++],
        MOT_SOURCE_ADMIN); strcpy(argv[i++], "/" PARAM_NOUV_DAA);
    HWND hcbx = GetDlgItem(hFrm, IDC_TEST_AUTHENTIF); byte* contenu;
    const ENTIER M = strlen(MOT_ID_ERREUR); set�tatBouton(hFrm,
        IDB_NOUV_FCLEF, FALSE); set�tatBouton(hFrm, IDB_VERIF_AUTO, FALSE);
    WaitCursor(); strcpy(argv[i++], gCodUtil); 
    strcpy(argv[i++], "/" PARAM_CONFIG); strcpy(argv[i++], gConfig);
    argn = i; char msg[DIM_64] = {0}; char *cnfMsg = getCnfMsg(); 
    for (j = 0; j < MAX_ESSAIS; j++)
    {
        r = ex�cuterCommandeNws(argn, argv); ND_ASSERT_S(r);
        contenu = getR�ponseCmd(); ND_ASSERT_CS(contenu, ERR_OBJET_�_NULL);
        message = ND_CC(contenu); strncpy(msg, message, max(STRLEN(message),
            DIM_64)); r = getNoDossierRefA(message); setNoDossierRef(r);
        if (j == 0)
        {
            strcpy(argv[i++], "/" PARAM_NO_REF);
            sprintf(argv[i++], "%d", r); argn = i;
        } 
        if (estMessageCmdSucc�s(message)){ break; } // Arr�ter.
        else {
            if ((r = getCodeMessage(message)) != ERR_AUTHENTIFICATION){
                ND_ASSERT_S(r);
            }
        }
        finR�ponseCmd();
    }
    ND_ASSERT_CS((j < MAX_ESSAIS), ERR_NOUVEAU_DOA); // V�rifier encore:
    ND_ASSERT_CS(estMessageCmdSucc�s(msg), ERR_NOUVEAU_DOA); NormalCursor();
    afficherInfo(GetString("MSG_NEWKEYF_SUCCESS"));
    j = (int)SendMessage(hcbx, CB_GETCOUNT, 0, 0);
    ND_ASSERT_CS(j < MAX_UTILS, ERR_INVALID_INIT); bUtil�V�rifier = TRUE; 
    EnableWindow(GetDlgItem(hFrm, IDC_TEST_AUTHENTIF), FALSE);
    gResultSetUtils[j] = (char*)NDAllouer0(NCARSUTIL + 1);
    strncpy(gResultSetUtils[j], gCodUtil, NCARSUTIL); 
    gResultSetUtils[j][NCARSUTIL] = EOL; AddComboItem(hcbx, gResultSetUtils[j]);
    SendMessage(hcbx, CB_SETCURSEL, j, 0); set�tatBouton(hFrm, IDB_VERIF_AUTO, 
        TRUE); SetFocus(GetDlgItem(hFrm, IDB_VERIF_AUTO)); ND_FIN(); 
ERR:traiterErreurDict(gNDR�sultat); supprimerPr�Inscription();
    int nod = getNoDossierRef(); supprimerRefUtilisation(nod);
    supprimerCl�R�f�rence(nod); ND_JOURNALISER_ERREUR(NOM_NW_ADMIN);
    set�tatBouton(hFrm, IDB_VERIF_AUTO, FALSE); 
FIN:NormalCursor(); finR�ponseCmd();
}

NTSTATUS v�rifierAuthentification(HWND hFrm, char codUtil[]) 
{
    NTSTATUS r = 0; char argv[DIM_8][DIM_64] = {0}, *util = codUtil, *msg;
    HWND hcbx = GetDlgItem(hFrm, IDC_TEST_AUTHENTIF); uint8 i; uint j = 0;
    byte* contenu; int argn = 0, nIndex = getUtilS�lectionn�(hFrm, hcbx);
    if (nIndex < 0){ return r; } i = 0; strcpy(argv[i++], "/" PARAM_SRC_PRG);
    if ( ! codUtil || (codUtil[0] == EOL)){ util = gCodUtil; }
    strcpy(argv[i++], MOT_SOURCE_ADMIN); strcpy(argv[i++], "/" PARAM_AUTHENTIF);
    strcpy(argv[i++], util); strcpy(argv[i++], "/" PARAM_CONFIG);
    strcpy(argv[i++], gConfig); strcpy(argv[i++], "/" PARAM_NO_REF);
    j = getNoDossierRef(); sprintf(argv[i++], "%d", j); argn = i;
    set�tatBouton(hFrm, IDB_NOUV_FCLEF, FALSE);
    set�tatBouton(hFrm, IDB_VERIF_AUTO, FALSE);
    r = ex�cuterCommandeNws(argn, argv); ND_ASSERT_S(r);
    contenu = getR�ponseCmd(); msg = ND_CC(contenu);
    ND_ASSERT_CS(contenu, ERR_OBJET_�_NULL); if (estMessageCmdSucc�s(msg))
    {
        afficherInfo(GetString("AUTHENTICATION_SUCCESS")); if (bUtil�V�rifier)
        { 
            supprimerCl�R�f�rence(j);
            EnableWindow(GetDlgItem(hFrm, IDC_TEST_AUTHENTIF), TRUE);
        }
    } else if ( ! codUtil){
        WCHAR txt[DIM_256] = {0}; swprintf(txt, DIM_256,
            GetString("AUTHENTICATION_FAILED"), convEnWCHAR(gCodUtil));
        afficherErreur(txt); NDFree(gResultSetUtils[nIndex]);
        actualiserListUtils(hcbx, nIndex); supprimerPr�Inscription();
        r = ERR_AUTHENTIFICATION; SendMessage(hcbx, CB_SETCURSEL, nIndex, 0);
    } 
    ND_FIN(); ERR: traiterErreurDict(gNDR�sultat);
FIN:set�tatBouton(hFrm, IDB_NOUV_FCLEF, TRUE); set�tatBouton(hFrm,
    IDB_VERIF_AUTO, TRUE); bUtil�V�rifier = FALSE; finR�ponseCmd(); return r;
}

NTSTATUS d�boguerAuthentifDoa()
{
    typedef void (WINAPI* Authentifier)(CONTEXTE_VOLUME*);
    NTSTATUS r�sultat = STATUS_SUCCESS; Authentifier fcAuthentifDoa = NULL;
    char cnfDll[MAX_PATH] = {0}, chemProgram[MAX_PATH]; HMODULE hmDoaDll = NULL;
    strcpy(chemProgram, getCheminService()); sprintf(cnfDll, "%s%s.%s%s%s", 
        chemProgram, S�PAR_DIR, gCodUtil, S�PAR_DIR, NOM_DAA_DLL);
    CONTEXTE_VOLUME cv = {0}; hmDoaDll = LoadLibraryA(cnfDll);
    ND_ASSERT_CS(hmDoaDll, ERR_OBJECT_INIT); strncpy(cv.nwModule.util.code,
        gCodUtil, NCARSUTIL); r�sultat = getInfoViaConnexChiffr�e(&cv.nwModule
            .util); ND_ASSERT_S(r�sultat); cv.ci.mode = XTS;    
    sprintf(cv.nwModule.chemKeyNd, "%s%s.%s%s%s", chemProgram, S�PAR_DIR,
        gCodUtil, S�PAR_DIR, NOM_KEYSPACE_ND);    
    fcAuthentifDoa = (Authentifier)GetProcAddress(hmDoaDll,
        NOM_FCT_AUTHENTIFIER); ND_ASSERT_CS(fcAuthentifDoa, ERR_OBJECT_INIT);
    fcAuthentifDoa(&cv); ND_ASSERT_S(cv.r�sultat); ND_FIN();
ERR:ND_JOURNALISER_ERREUR(NOM_NW_ADMIN); r�sultat = gNDR�sultat;
FIN:if (hmDoaDll){ FreeLibrary(hmDoaDll); hmDoaDll = NULL; }
    return r�sultat;
}

LPARAM CALLBACK DialogueNouvCl�s(HWND hFrm, UINT message, WPARAM wp, LPARAM lp)
{
    UNREFERENCED_PARAMETER(lp); int r = STATUS_SUCCESS, wmId = LOWORD(wp);    
    switch (message)
    {
    case WM_INITDIALOG:

        return (LPARAM)TRUE;

    case WM_COMMAND:
    {
        switch (wmId)
        {
        case IDB_VERIF_AUTO:

            v�rifierAuthentification(hFrm, NULL); break;

        case IDB_NOUV_FCLEF:
        {
            WCHAR titre[DIM_64] = {0}; int r = getCodUtilAl�atoire(gCodUtil);
            if NT_SUCCESS(r)
            {
                swprintf(titre, DIM_64, GetString("MSG_TITRE_NOUV_UTIL"),
                    convEnWCHAR(gCodUtil));
                if (MessageBox(hFrm, GetString("MSG_NOUV_UTIL"), titre, 
                    MB_ICONQUESTION | MB_OKCANCEL) == IDOK){ 
                    cr�erNouvCl�s(hFrm); }
            } else { afficherErreur(GetString("MSG_INVALID_UTIL")); }
        } break;

        case IDCANCEL:
        {
            if (bUtil�V�rifier)
            {
                int i = (int)SendMessage(GetDlgItem(hFrm, IDC_TEST_AUTHENTIF), 
                    CB_GETCOUNT, 0, 0); if (i < MAX_UTILS)
                {
                    WCHAR msg[DIM_256] = {0}; swprintf(msg, DIM_256,                        
                        GetString("MSG_VERIF_UTIL"), gResultSetUtils[i-1]);
                    afficherAttention(msg);
                }
            } else { 
                for (int i = 0; i < MAX_UTILS; i++){ 
                    NDFree(gResultSetUtils[i]); } EndDialog(hFrm, wmId);
            } break;
        }        
        }
    }
    }
    return (LPARAM)FALSE;
}

NTSTATUS getParam�tresCmd(WCHAR lpszCommandLine[])
{
    NTSTATUS r = EXIT_SUCCESS; char argsLigneCmd[MAX_NB_ARGS][MAX_PATH] = {0};
    uint8 idxLigneCmd = Win32CommandLine(lpszCommandLine, argsLigneCmd);
    const uint8 NO_PARAM = 2; ENTIER n = 0; if (idxLigneCmd > 0)
    {
        enum { Nouveau, Authentification, Configuration };        
        Argument args[] =
        {
            { Nouveau,              "/nouveau",         "/" PARAM_NOUV_UTIL },
            { Authentification,     "/authentif",       "/" PARAM_AUTHENTIF },
            { Configuration,        "/configuration",   "/" PARAM_CONFIG },
        };
                
        for (uint i = 0; i < idxLigneCmd; i++)
        {
            ArgumentSpec as; as.args = args; uint nArgPos = 0;
            as.arg_cnt = sizeof(args) / sizeof(args[0]);
            
            switch (GetArgumentID(&as, argsLigneCmd[i], &nArgPos))
            {
            case Nouveau:
            {
                bEnregUtil = TRUE; break;
            }

            case Authentification:
            {
                bTestAuthentif = TRUE; break;
            }

            case Configuration:
            {
                if (HAS_ARGUMENT == GetArgumentValue(argsLigneCmd,
                    0, &i, NO_PARAM+1, gConfig, DIM_8)){} 
                setConfiguration(gConfig);
                if (HAS_ARGUMENT == GetArgumentValue(argsLigneCmd,
                    0, &i, NO_PARAM+2, gCodUtil, NCARSUTIL+1)){} break;
            }

            default: ND_ASSERT_S(ERR_ARGUMENT_INVALIDE);
            }
        }
    } else {} ND_FIN(); 
ERR:r = gNDR�sultat; FIN:return r;
}

int APIENTRY wWinMain(_In_ HINSTANCE hInstance, HINSTANCE hPrevInstance,
        _In_ LPWSTR arguments, _In_ int nCmdShow)
{
    UNREFERENCED_PARAMETER(hPrevInstance); NTSTATUS r = STATUS_SUCCESS; HWND hw;
    byte* contenu = NULL; WCHAR szWndClass[MAX_LOADSTRING] = {0}; MSG msg = {0};
    uint uId; if ( ! LoadLanguageFile()){ ND_ASSERT_S(ERR_INVALID_INIT); }
    if (wcslen(arguments) > 0)
    {
        r = getParam�tresCmd(arguments); ND_ASSERT_S(r);
    }
    if (bTestAuthentif)
    {
        r = d�boguerAuthentifDoa(); ND_ASSERT_S(r); ND_FIN();
    }
    setParamSource(MOT_SOURCE_ADMIN); setConfiguration(gConfig);
    LoadStringW(hInstance, IDC_NETDISQ, szWndClass, MAX_LOADSTRING);
    InitWndClass(hInstance, szWndClass, MainWndProc);
    if ( ! (hw = InitWndInstance(hInstance, szWndClass, nCmdShow, NULL))){
        ND_ASSERT_S(ERR_INVALID_INIT);
    }
    uId = (isLangFr() ? IDM_NETDISQ_FR : IDM_NETDISQ_EN);
    LoadStringW(hInstance, uId, szWndClass, MAX_LOADSTRING);
    HACCEL hAccelTable = LoadAccelerators(hInstance,
        MAKEINTRESOURCE(IDC_NETDISQ));

    while (GetMessage(&msg, NULL, 0, 0)) // Traitement des messages.
    {
        if ( ! TranslateAccelerator(msg.hwnd, hAccelTable, &msg)){
            TranslateMessage(&msg); DispatchMessage(&msg);
        }
    }
    ND_FIN(); ERR:traiterErreurDict(gNDR�sultat); journaliser("Erreur "
       "wWinAdmin %d (%d).", gNDR�sultat, gNoLigne); quitter(); 
FIN:NDFree(contenu); return gNDR�sultat; }