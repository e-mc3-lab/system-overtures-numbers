::
:: Copyright (c) 2003-2015 'Fondation TrueCrypt'. All rights reserved.
::               2024-2026 NetDisq
::
:: Governed by the SCLE License 1.0; the full text of which is contained in
:: the file Licence.txt included in Netdisq source and binary code distribution
:: packages.
::
@echo off
chcp 28591 > nul
set CHEM_ND_PROGRAMME=%1
set CONFIG=%2
set CHEM_VS=%DC%\proj\vs
set NOM_CXREF=CxRef
set CHEM_CXREF=%CHEM_VS%\NOM_CXREF%
set NO_ESSAI=1

:: Ouvrir un terminal "Native Tools for VS"
call %VSCMDIR%vcvars64

cd CHEM_CXREF=%
msbuild -t:rebuild -property:Configuration=%CONFIG%
if NOT %ERRORLEVEL% == 0 (goto FIN)

:FIN