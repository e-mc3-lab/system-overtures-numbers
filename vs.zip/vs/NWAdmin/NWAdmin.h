
#ifndef ENT�TE_NWADMIN
#define ENT�TE_NWADMIN

#include "ResourceC.h"
#include "ResourceA.h"

#endif // ENT�TE_NWADMIN