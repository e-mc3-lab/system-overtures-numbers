/**
 * @auteur: SCLE/CSES.
 */
#include "ResourceC.h"
#include "TextHexa.h"
#include "Random.h"
#include "Fichier.h"
#include "Language.h"
#include "ErreurDict.h"
#include "CoreAlgo.h"
#include "Cyptur.h"
#include "AutoTest.h"
#include "GenKey.h"
#include "NWSData.h"
#include "NWService.h"
#include "CxRef.h"

#define TXT_UVERSION   L"Usage: " NOM_CORE_XREF "[/c ou /s] /g $(Configuration)"


typedef struct
{
    char ent�te[MAX_PATH], nom[MAX_PATH];

} CoreModule;

static CoreModule gTabModulesAlgo[] =
{    
    { NOM_ENT�TE_THEO,      NOM_MODULE_THEO    },
    { NOM_ENT�TE_ANTHOA,    NOM_MODULE_ANTHOA  },
    { NOM_ENT�TE_CRC,       NOM_MODULE_CRC     },
    { NOM_ENT�TE_MODYZ,     NOM_MODULE_MODYZ   },
    { NOM_ENT�TE_RIPEMD,    NOM_MODULE_RIPEMD  },
    { NOM_ENT�TE_SHA,       NOM_MODULE_SHA     },
    { NOM_ENT�TE_WHRPOOL,   NOM_MODULE_WHRPOOL }
};

const uint8 NB_MODULES_ALGO = sizeof(gTabModulesAlgo) / sizeof(CoreModule);

char *gChemDev = NULL, gConfig[DIM_32] = {0}, gChemProgram[MAX_PATH] = {0};
static int gi = -1; char gCodUtil[NCARSUTIL + 1] = {0}; 

BOOL genConstanteRef(uchar tab[], uint len)
{
    uint i; POINT cp = {0}; uint n = (GetCurrentProcessId() % 
        GetCurrentThreadId() % 67) + 3; const int M = DIM_256;
    GetPhysicalCursorPos(&cp); int32 j = cp.x; static uint s = 0; s++;
    static uint germe = j; germe += getEstampille() * n; srand(germe);
    uint8 r = uint8(s * randx()); for (i = 0; i < r; i++){ srand(i); srand(j);
    srand(r); srand(r); } for (i = 0; i < len; i++, j += 3)
    {
        tab[i] = byte((UI64(randx()) + UI64(randx()) * UI64(j) + UI64(cp.y))%M);
        if ((tab[i] == EOL) || (tab[i] == ' ')){ tab[i] = i + M; }
    } return TRUE;
}

typedef struct { uint8 fr�quence; byte valeur; } ConstanteRem;

byte setCRem(ConstanteRem tabR[], byte* c)
{
    byte r = EOL; const uint M = 3; int n = (*c + 1);
    if (n > DIM_256){ n = n - DIM_256 + 1; } for (uint i = 0; i < NDH; i++)
    {
        if (tabR[i].fr�quence > M)
        {
            // R�gle g�n�rale, la fr�quence varie entre 1 et 3, parfois 6.
            tabR[i].valeur = *c = r = n; r = n; tabR[i].fr�quence++; break;
        }
    } return r;
}

void ajouterCRem(ConstanteRem tabR[], byte tabM[])
{   // convEnNombres2Hexa(tabM);
    // TODO: ne sert plus, car Rem.cpp n'est pas modifiable.
    byte c, r; for (uint i = 0; i < DIM_NB_2HEXA; i++)
    {
        c = tabM[i]; for (uint j = 0; j < NDH; j++)
        { 
            if (c == tabR[j].valeur){ tabR[j].fr�quence++; }
            r = setCRem(tabR, &c); if (r != EOL){ j = 0; tabM[i] = r; }
        } 
    }
}

void ajouterAes(ConstanteRem tabR[])
{
    uint8 pos = 0; const uint16 M = uint16(NDH) / 2; byte tab[DIM_16] = {0};
    init0(tabR, M); for (uint16 i = 0; i < M; i++)
    {
        genConstanteRef(tab, DIM_8); pos = tab[0] % M;
        while (tabR[pos].valeur != EOL)
        {
            genConstanteRef(tab, DIM_8); pos = tab[0] % M;
        } tabR[pos].valeur = byte(i);
    }
}

void modifierAES(byte tabM[], char* txt, int i, ULONG dimF)
{   // NB: les tableaux d'AES ne sont pas modifiables (.cpp et .asm).       
    const uint16 M = uint16(NDH) / 2; BOOL bDecryp = FALSE;
    ConstanteRem tabE[M] = {0}, tabD[M] = {0}; const char* rech;
    ajouterAes(tabE); ajouterAes(tabD);
    while (rech = chercherTexte(txt, dimF, TXT_2HEXA, DIM_NB_2HEXA))
    {
        if ( ! bDecryp && (i < M)){
            tabM[0] = tabE[i++].valeur;
        } else if (i == M){
            bDecryp = TRUE; i = 0;
        } 
        if (bDecryp){
            tabM[0] = tabD[i++].valeur;
        }
        convEnNombres2Hexa(tabM); memcpy((byte*)rech, tabM, DIM_NB_2HEXA); 
        rech += DIM_NB_2HEXA;
    }
}

typedef struct
{
    char fctName[DIM_8]; uint8 nbParams;
} MathsOper;

MathsOper gTabMathsOper[] =
{   // Template
    {"acos",1}, {"asin",1}, {"atan",1}, {"cos",1}, {"cosh", 1}, {"rint",1},
    {"exp",1}, {"fabs",1}, {"fmod",2}, {"log",1}, {"log10",1}, {"pow",2},
    {"sin",1}, {"sinh",1}, {"sqrt",1}, {"tan",1}, {"tanh",1}, {"acosh",1},
    {"asinh",1}, {"atanh",1}, {"ceil",1}, {"cbrt",1}, {"erf",1}, {"erfc",1},
    {"exp2",1}, {"expm1",1}, {"fdim",2}, {"floor",1}, {"atan2",2}, {"lgamma",1},
    {"nxta",2}, {"round",1}, {"hypot",2}, {"fma",3}, {"fmax",2}, {"fmin",2},
    {"floor",1}, {"nearbn",1}, {"log1p",1}, {"log2",1}, {"logb",1}, {"tgamma",1}
};

char getLetterOper(uint8 n)
{
    static char LTR_A = 'A', LTR_B = 'B', LTR_C = 'C';
    if (n == 1){ return LTR_A; }
    else if (n == 2){ return LTR_B; }
    else { return LTR_C; }
}

NTSTATUS g�n�rerAlgorithmesCl�s(char** txt, ULONG* dimF)
{
    const uint16 NMO = sizeof(gTabMathsOper), N = NMO / sizeof(MathsOper);
    const char *rech, NB_OP_REF[] = "50"; char tab[DIM_256] = {0};
    const uint16 NOR = sizeof(NB_OP_REF); char *txtA = *txt;
    ULONG dimA = *dimF; txtA[dimA - 1] = EOL; uint nop = 0, nt = 0;
    const uint8 NB_RF_DEB = 6; rech = strstr(txtA, NB_OP_REF); if (rech)
    {
        char motN[DIM_8] = {0}, *txtB = (char*)rech;
        sprintf(motN, "%d", N + DIM_8); uint8 j = uint8(strlen(motN));
        for (uint8 i = 0; i < j; i++){ txtB[i] = motN[i]; }
    }

    const char INIT_TAB_OPS[] = 
        "void iniTabOps()\n" \
        "{   \n" \
        "    uint8 i = 0;\n" \
        "    gTabOps[i++].opB = plus;\n"  \
        "    gTabOps[i++].opB = moins;\n" \
        "    gTabOps[i++].opB = fois;\n"  \
        "    gTabOps[i++].opB = diva;\n"  \
        "    gTabOps[i++].opB = divb;\n"  \
        "    gTabOps[i++].opB = divc;\n";
    const char G_TAB_OP_ASSIGN[] = 
        "    gTabOps[i++].op%c = %s;\n";
    
    dimA += sizeof(INIT_TAB_OPS) + NMO + (N * sizeof(G_TAB_OP_ASSIGN)) + N + 50;
    txtA = (char*)NDAllouer0(dimA); *dimF = dimA;
    memcpy(txtA, *txt, dimA); NDFree(*txt); *txt = txtA;
    strcat(txtA, INIT_TAB_OPS); for (uint i = 0; i < N; i++)
    {
        sprintf(tab, G_TAB_OP_ASSIGN, getLetterOper(gTabMathsOper[i]
            .nbParams), gTabMathsOper[i].fctName); strcat(txtA, tab);
    }
    strcat(txtA, "}\n\n"); *dimF = ULONG(STRLEN(txtA));
 
    const char RAND_FCT[] =
        "void prf%02d(byte tabCad[], const uint i)\n" \
        "{\n" \
        "    uint8 tab[] = { ";
    const char CALC_PRF[] =
        "    calcPrf(tabCad, i, tab, sizeof(tab));\n" \
        "}\n\n";

    dimA += NB_PRF * (sizeof(RAND_FCT) + sizeof(CALC_PRF) + 30);
    char* txtB = (char*)NDAllouer0(dimA); *dimF = dimA; uint8 j = 1;
    memcpy(txtB, txtA, dimA); NDFree(txtA); *txt = txtB;
    const uint8 M = NB_RF_DEB + N; for (uint8 i = 0; i < NB_PRF; i++)
    {
        sprintf(tab, RAND_FCT, i); strcat(txtB, tab);
        nt = getNombreAl�atoire(NB_RF_DEB);
        while ((nop = getNombreAl�atoire(M)) <= NB_RF_DEB){ ; }
        sprintf(tab, "%d, ", nop); strcat(txtB, tab); j++;
        nop = getNombreAl�atoire(NB_RF_DEB);
        sprintf(tab, "%d, ", nop); strcat(txtB, tab); j++;
        while ((nop = getNombreAl�atoire(M)) <= NB_RF_DEB){ ; }
        sprintf(tab, "%d };\n", nop); strcat(txtB, tab); j++;
        strcat(txtB, CALC_PRF); // TODO: ajouter selon 'nt'.
    }
    *dimF = ULONG(STRLEN(txtB));

    const char ADD_RFA[] =
        "void assignPrfs()\n" \
        "{\n" \
        "   RandomKeyFunction rkf = {0}; if ( ! bIniTabPrfs){ iniTabOps(); }\n" \
        "   bIniTabPrfs = TRUE; uint8 i = 0;\n";
    const char ADD_RFB[] =
        "   gTabRfs[i++].setRandKey = prf%02d;\n";
    
    dimA += sizeof(ADD_RFA) + (NB_PRF * sizeof(ADD_RFB)) + DIM_8;
    txtA = (char*)NDAllouer0(dimA); *dimF = dimA;
    memcpy(txtA, txtB, dimA); NDFree(txtB); *txt = txtA;
    strcat(txtA, ADD_RFA); for (uint8 i = 0; i < NB_PRF; i++)
    {
        sprintf(tab, ADD_RFB, i); strcat(txtA, tab);
    }
    strcat(txtA, "}\n\n"); *dimF = ULONG(STRLEN(txtA));

    const char FCT_PRF[] =
        "void prf(byte tabCad[], const uint i)\n" \
        "{\n" \
        "   RandomKeyFunction* prf = NULL; byte* tab = (tabCad + i);\n" \
        "   uint16 j = 0; ";
    const char SET_RKF[] =
        "   j = tab[%d] %% DIM_16;\n" \
        "   prf = getRkf(j); if (prf){ prf->setRandKey(tabCad, i + (j %% 13));" \
        " }\n";
    dimA += sizeof(FCT_PRF) + sizeof(SET_RKF) + DIM_8;
    txtB = (char*)NDAllouer0(dimA); *dimF = dimA;
    memcpy(txtB, txtA, dimA); NDFree(txtA); *txt = txtB;
    strcat(txtB, FCT_PRF); const uint8 S = DIM_16 - 3;
    uint8 u = getNombreAl�atoire(S), v = 0; 
    for (uint8 i = 0; i < 3; i++)
    {
        sprintf(tab, SET_RKF, u); strcat(txtB, tab);
        while ((v = getNombreAl�atoire(S)) == u){ ; } u = v; 
    }
    strcat(txtB, "}\n"); *dimF = ULONG(STRLEN(txtB));
    return EXIT_SUCCESS;
}

NTSTATUS modifierDRef(const char nomH[], const char nomM[], const char nomP[])
{   // PRE: n'utiliser qu'avec la solution NetDisq (� cause des dossiers).
    NTSTATUS r = ERR_SUCCESS; char* chem = gChemDev; int EFW = ERR_FILE_WRITE;
    const char FORMAT_TXT[DIM_16] = "%s%s%s%s%s"; ConstanteRem tabR[NDH] = {0};
    char ccnfS[MAX_PATH] = {0}, ccnfD[MAX_PATH] = {0}; char* txt = NULL;
    HANDLE hf = NULL; ULONG dimF, nbBytes; LARGE_INTEGER d = {0}; int i = 0;
    byte tabM[DIM_16] = {0}, tabB[DIM_8HEXA] = {0}; const char* rech;
    
    sprintf(ccnfS, FORMAT_TXT, chem, S�PAR_DIR, NOM_CORE_XREF, S�PAR_DIR, nomH);
    sprintf(ccnfD, FORMAT_TXT, chem, S�PAR_DIR, nomP, S�PAR_DIR, nomH);
    if (existe(ccnfD)){ supprimerFichier0(ccnfD); } copierFichier(ccnfS, ccnfD);
    sprintf(ccnfS, FORMAT_TXT, chem, S�PAR_DIR, NOM_CORE_XREF, S�PAR_DIR, nomM);
    sprintf(ccnfD, FORMAT_TXT, chem, S�PAR_DIR, nomP, S�PAR_DIR, nomM);
    if (existe(ccnfD)){ supprimerFichier0(ccnfD); } copierFichier(ccnfS, ccnfD);
    hf = CreateFileA(ccnfD, ACC�S_LECTURE_�CRITURE, MODE_PARTAG�,
        NULL, OPEN_EXISTING, 0, NULL); dimF = GetFileSize(hf, NULL);
    ND_ASSERT_CS((hf != INVALID_HANDLE_VALUE), ERR_FILE_OPEN);
    txt = ND_CC(NDAllouer0(dimF)); if ( ! ReadFile(hf, txt, dimF,
        &nbBytes, NULL)){ ND_ASSERT_S(ERR_FILE_READ); }
    if ( ! SetFilePointerEx(hf, d, NULL, FILE_BEGIN)){
        ND_ASSERT_S(ERR_OBJECT_INIT);
    }
    while (rech = chercherTexte(txt, dimF, TXT_10CHIFFR, NTXT_10))
    {
        if ( ! genConstanteRef(tabM, NTXT_10)){ ND_ERREUR(); }
        convEnChiffresD�cimaux(tabM);
        memcpy((byte*)rech, tabM, NTXT_10 - 1); rech += NTXT_10;
    }
    while (rech = chercherTexte(txt, dimF, TXT_8HEXA, DIM_8HEXA))
    {
        if ( ! genConstanteRef(tabB, DIM_8HEXA)){ ND_ERREUR(); }
        convEnChiffresHexad�cimaux(tabB);
        for (uint8 i = 0; i < DIM_8HEXA; i++){
            if (tabB[i] == EOL){ tabB[i] = '\x0'+(i+1); }
        }
        memcpy((byte*)rech, tabB, DIM_8HEXA - 1); rech += DIM_8HEXA;
    }
    while (rech = chercherTexte(txt, dimF, TXT_NB_16HEXA, DIM_16))
    {
        if ( ! genConstanteRef(tabM, DIM_16)){ ND_ERREUR(); }
        convEnNombresHexa(tabM, DIM_16); memcpy((byte*)rech, tabM, DIM_16); 
        rech += DIM_16;
    }
    while (rech = chercherTexte(txt, dimF, TXT_NB_8HEXA, DIM_NB_8HEXA))
    {
        if ( ! genConstanteRef(tabM, DIM_NB_8HEXA)){ ND_ERREUR(); }
        convEnNombresHexa(tabM, DIM_NB_8HEXA);
        memcpy((byte*)rech, tabM, DIM_NB_8HEXA); rech += DIM_NB_8HEXA;
    }
    if (FALSE){ // (strcmp(nomH, NOM_ENT�TE_AES_X64) == 0){
        modifierAES(tabM, txt, i, dimF);
    }
    if (strcmp(nomM, NOM_MODULE_GENKEY) == 0){
        g�n�rerAlgorithmesCl�s(&txt, &dimF);
    }
    if ( ! WriteFile(hf, txt, dimF, &nbBytes, NULL)){ ND_ASSERT_S(EFW); }
    ND_FIN(); ERR:ND_JOURNALISER_ERREUR(NOM_CORE_XREF);
    traiterErreurDict(gNDR�sultat); r = abs(gNDR�sultat);
FIN:NDFree(txt); fermerFichier(&hf); return r;
}

NTSTATUS testerAlgorithmesCl�s()
{
    const uint8 N = sizeof(gTabMathsOper) / DIM_8;
    byte tab16[20] = {"3161421941823562"}; assignPrfs();
    // Arguments: /k /g $(Configuration)
    prf(tab16, 0); journaliser("tab=%s.", tab16);
    return EXIT_SUCCESS;
}

char* getCheminDaa()
{
    static char gCheminDoa[MAX_PATH] = {0}; char nomProj[] = MOT_DAA;
    sprintf(gCheminDoa, "%s%s%s%s%s%s%s%s", gChemDev, S�PAR_DIR,
        nomProj, S�PAR_DIR, MOT_PLATEFORM_X64, S�PAR_DIR, gConfig, S�PAR_DIR);
    return gCheminDoa;
}

char* getCheminCyptur()
{
    static char gCheminCyptur[MAX_PATH] = {0}; char nomProj[] = MOT_CYPTUR;
    sprintf(gCheminCyptur, "%s%s%s%s%s%s%s%s", gChemDev, S�PAR_DIR,
        nomProj, S�PAR_DIR, MOT_PLATEFORM_X64, S�PAR_DIR,
        gConfig, S�PAR_DIR);
    return gCheminCyptur;
}

NTSTATUS copierDLL(char cheminSrc[], char cheminDest[], const char nom[])
{
    int i = 0; char ccnfA[MAX_PATH] = {0}, ccnfB[MAX_PATH] = {0},
        nfDll[MAX_PATH] = {0}; BOOL bEstProjetClient = FALSE;
    sprintf(nfDll, "%s%s", nom, SUFX_DLL); sprintf(ccnfA, "%s%s", cheminSrc,
        nfDll); ND_ASSERT_CS(existe(ccnfA), ERR_KEYFILE_NOT_FOUND);
    strcpy(ccnfB, cheminDest); if ( ! seTerminePar(ccnfB, nfDll)){
        sprintf(ccnfB, "%s%s", ccnfB, nfDll); }
    if ( ! copierFichier(ccnfA, ccnfB)){ ND_ASSERT_S(ERR_FILE_WRITE); }
ND_FIN(); ERR:ND_JOURNALISER_ERREUR(NOM_CORE_XREF); FIN: return gNDR�sultat;
}

NTSTATUS supprimerSousDossierCl�()
{   
    NTSTATUS r = STATUS_SUCCESS; char chemDest[MAX_PATH] = {0},
        cnfDll[MAX_PATH] = {0}; sprintf(chemDest, FMT_DOSSIER_TMP, 
            gChemProgram, S�PAR_DIR, gi, S�PAR_DIR);
    sprintf(cnfDll, "%s%s%s%s", chemDest, S�PAR_DIR, MOT_DAA, SUFX_DLL);
    if ( ! supprimerFichier0(cnfDll)){ ND_ASSERT_S(ERR_FILE_WRITE); }
    sprintf(cnfDll, "%s%s%s%s", chemDest, S�PAR_DIR, MOT_CYPTUR, SUFX_DLL);
    if ( ! supprimerFichier0(cnfDll)){ ND_ASSERT_S(ERR_FILE_WRITE); }
    if ( ! RemoveDirectoryA(chemDest)){ ND_ASSERT_S(ERR_FILE_WRITE); }
ND_FIN(); ERR:ND_JOURNALISER_ERREUR(NOM_CORE_XREF); FIN: return gNDR�sultat;
}

NTSTATUS copierCl�DansSousDossierND()
{   // Copier gam et cyptur.dll dans un dossier ./1, .2/, ...
    gi = getDernierDossierRef(gChemProgram) + 1; char chemDest[MAX_PATH];
    sprintf(chemDest, FMT_DOSSIER_TMP, gChemProgram, S�PAR_DIR, gi, S�PAR_DIR);
    if ( ! existe(chemDest)){ cr�erDossiers(chemDest, FALSE); }
    NTSTATUS r = copierDLL(getCheminDaa(), chemDest, MOT_DAA); ND_ASSERT_S(r);
    r = copierDLL(getCheminCyptur(), chemDest, MOT_CYPTUR); ND_ASSERT_S(r);
    ND_FIN(); ERR:ND_JOURNALISER_ERREUR(NOM_CORE_XREF); r = gNDR�sultat; 
    if (gi > 0){ supprimerSousDossierCl�(); } FIN:return r;
}

NTSTATUS supprimerMRef(const char nom[])
{
    NTSTATUS r�sultat = STATUS_SUCCESS; char ccnf[MAX_PATH] = {0}; 
    sprintf(ccnf, "%s%s%s%s%s", gChemDev, S�PAR_DIR, NOM_CORE_ALGO, S�PAR_DIR, 
        nom); if ( ! supprimerFichier0(ccnf)){ ND_ASSERT_S(ERR_FILE_WRITE); } 
    ND_FIN(); ERR:ND_JOURNALISER_ERREUR(NOM_CORE_XREF); r�sultat = gNDR�sultat;
FIN:return r�sultat;
}

NTSTATUS ex�cuterTestAlgorithmes()
{
    typedef BOOL (WINAPI* Ex�cuterDoaAutoTest)();
    NTSTATUS r�sultat = ERR_SUCCESS; Ex�cuterDoaAutoTest fcExecAutoTest = NULL;
    char cnfDll[MAX_PATH] = {0}; HMODULE hmDoaDll = NULL; BOOL bV�rif = FALSE;
    int i = 0; ND_ASSERT_S(r�sultat); i = getDernierDossierRef(gChemProgram);
    ND_ASSERT_CS(i > 0, ERR_KEYFILE_NOT_FOUND); gi = i; sprintf(cnfDll,
        "%s%s.%d%s%s", gChemProgram, S�PAR_DIR, i, S�PAR_DIR, NOM_DAA_DLL);
    hmDoaDll = LoadLibraryA(cnfDll); ND_ASSERT_CS(hmDoaDll, ERR_OBJECT_INIT); 
    fcExecAutoTest = (Ex�cuterDoaAutoTest)GetProcAddress(hmDoaDll, 
        NOM_FCT_EX�CUTER_TEST); ND_ASSERT_CS(fcExecAutoTest, ERR_INVALID_INIT);
    bV�rif = fcExecAutoTest(); ND_ASSERT_CS(bV�rif, ERR_CHIFFREMENT_INVALIDE);
    ND_FIN(); ERR: ND_JOURNALISER_ERREUR(NOM_CORE_XREF); r�sultat = gNDR�sultat;
    supprimerSousDossierCl�(); FIN: if (hmDoaDll){ FreeLibrary(hmDoaDll);
    hmDoaDll = NULL; } return r�sultat;
}

int main(int n, char* argv[])
{
    int r�sultat = STATUS_SUCCESS; const uint8 PARAM_FIN = 4;
    if ( ! LoadLanguageFile()){ ND_ASSERT_S(ERR_INVALID_INIT); }    
    gChemDev = getCheminDev(getCheminProgramme()); 
    ND_ASSERT_CS(strlen(gChemDev) > 0, ERR_ARGUMENT_INVALIDE); if (n > 1)
    {   
        if ((n >= PARAM_FIN) && (_stricmp(argv[2], "/g") == 0))
        {
            strcpy(gConfig, argv[3]); setConfiguration(gConfig);
        }
        strcpy(gChemProgram, getCheminService());
        if (_stricmp(argv[1], "/c") == 0)
        {
            r�sultat = copierCl�DansSousDossierND(); ND_ASSERT_S(r�sultat);
        } else if (_stricmp(argv[1], "/t") == 0){
            r�sultat = ex�cuterTestAlgorithmes(); ND_ASSERT_S(r�sultat);
        } else if (_stricmp(argv[1], "/d") == 0){
            gi = atoi(argv[PARAM_FIN]); supprimerSousDossierCl�();
        } else if (_stricmp(argv[1], "/k") == 0){
            r�sultat = testerAlgorithmesCl�s(); ND_ASSERT_S(r�sultat);
        } else if (_stricmp(argv[1], "/s") == 0){
            for (uint8 i = 0; i < NB_MODULES_ALGO; i++)
            {
                r�sultat = supprimerMRef(gTabModulesAlgo[i].nom); 
                ND_ASSERT_S(r�sultat);
            }
        }
    } else {

        for (uint8 i = 0; i < NB_MODULES_ALGO; i++)
        {
            r�sultat = modifierDRef(gTabModulesAlgo[i].ent�te,
                gTabModulesAlgo[i].nom, NOM_CORE_ALGO);
            ND_ASSERT_S(r�sultat);
        }
        r�sultat = modifierDRef(NOM_ENT�TE_GENKEY,
            NOM_MODULE_GENKEY, MOT_DAA);
        r�sultat = modifierDRef(NOM_ENT�TE_DOA, NOM_MODULE_DOA, MOT_DAA);
        ND_ASSERT_S(r�sultat);
    }
    ND_FIN();
ERR:ND_JOURNALISER_ERREUR(NOM_CORE_XREF); traiterErreurDict(gNDR�sultat);
    r�sultat = (r�sultat == ERR_CHIFFREMENT_INVALIDE ?
        getDernierDossierRef(gChemProgram) : abs(gNDR�sultat));
FIN:UnloadLanguageFile(); exit(r�sultat);
}