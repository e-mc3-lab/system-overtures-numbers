/*
 Legal Notice: Some portions of the source code contained in this file were
 derived from the source code of Encryption. Modifications and additions to
 the original source code (contained in this file), and all other portions
 of this file are Copyright(c) 2024-2026 'SCLE/CSES'. These are also
 governed by the SCLE License; the full text of which is contained in
 the file Licence 1.0.txt included in NetDisq packages. 
 */

#ifndef ND_HEADER_GAM
#define ND_HEADER_GAM

#include "Memoire.h"
#include "ModXyz.h"


#ifdef __cplusplus
extern "C"
{
#endif

#define NETDISQ_DLL_EXPORT          __declspec(dllexport)

#define MOT_GAM                     "Gam"
#define NOM_GAM_DLL                 MOT_GAM SUFX_DLL
#define NOM_SMARTKEY_ND             "SmartKey" SUFX_ND

#define NOM_FCT_NOUVEAU_GAM         "nouveau" MOT_GAM
#define NOM_FCT_AUTHENTIFIER        "authentifier"
#define NOM_FCT_FIN_GAM             "fin" MOT_GAM

#ifndef STATUS_FILE_NOT_ENCRYPTED
#define STATUS_FILE_NOT_ENCRYPTED   ((NTSTATUS)0xC0000291L)
#endif
#ifndef STATUS_FILE_ENCRYPTED
#define STATUS_FILE_ENCRYPTED       ((NTSTATUS)0xC0000293L)
#endif
#define STATUS_VOLUME_NON_CHIFFR�   STATUS_FILE_NOT_ENCRYPTED
#define STATUS_VOLUME_EST_CHIFFR�   STATUS_FILE_ENCRYPTED

#define NCARSUTIL                   DIM_16-2

#define NB_ITER_CHIFFRE             DIM_256/2
#define MAX_ESSAIS_NOUVG            6

typedef struct
{
    char code[NCARSUTIL]; int noInscrip; MOT_DE_PASSE_DRV mpassd; byte a16[4];

} UTILISATEUR;

typedef struct // BLOB ou ressource dans un .jar.
{
    UTILISATEUR util; DWORD idProcess, idThread; char chemKeyNd[MAX_PATH];

} CONTEXTE_NWMODULE;

typedef struct _CONTEXTE_VOLUME
{
    HANDLE hInst, poign�e; CONTEXTE_NWMODULE nwModule; MOT_DE_PASSE mpass;
    INFO_CRYPTO ci; uint8 cifr; D�RIVE_CHIFFRE* dc; int32 jm; byte r[8];
    byte eci[NDH], em16[NDH]; BOOL enUtilisation; int r�sultat;

} CONTEXTE_VOLUME;

#define DIM_CV sizeof(CONTEXTE_VOLUME)

#if defined(_DEBUG) || defined(DEBUG)

#define ND_JOURNALISER_GAM(format, ...){ \
   journaliser(format, __VA_ARGS__); }

#define ND_JOURNALISER_GAM_SANS0(fmt, txt, n){ \
    ND_JOURNALISER_SANS0(fmt, txt, n) \
}

#define ND_JOURNALISER_ERRGAM(nomModule){ \
    ND_JOURNALISER_ERREUR_A(nomModule, TRUE); \
}
#else 

#define ND_JOURNALISER_GAM(format, ...){ }
#define ND_JOURNALISER_GAM_SANS0(fmt, txt, n){ }
#define ND_JOURNALISER_ERRGAM(nomModule){ }

#endif

#define ND_ASSERT_G(argument) \
{ \
    if ( ! (argument) || ! NT_SUCCESS(gNDR�sultat)){ ND_ERREUR(); } \
}

    NETDISQ_DLL_EXPORT void nouveauGam(CONTEXTE_VOLUME* ctx); // TODO: effacer
    NETDISQ_DLL_EXPORT void authentifier(CONTEXTE_VOLUME* ctx);
    void fN(CONTEXTE_VOLUME* ctx); NTSTATUS ed(HANDLE hv, ulong d, ulong e);
    void bm(CONTEXTE_VOLUME* ctx); void tac(CONTEXTE_VOLUME* ctx);

    uint16 getNbGamEssais(); NETDISQ_DLL_EXPORT void finGam(CRYPTO_INFO* ci);

#if defined(__cplusplus)
}
#endif

#endif // [!] ND_HEADER_GAM 
