/*
 Legal Notice: Some portions of the source code contained in this file were
 derived from the source code of Encryption. Modifications and additions to
 the original source code (contained in this file), and all other portions
 of this file are Copyright(c) 2003-2013 'Fondation TrueCrypt'. These are
 also governed by the SCLE License; the full text of which is contained
 in the file Licence 1.0.txt included in NetDisq distribution packages.
 2024-2026. Le tableau (al�atoire) ci-apr�s est unique (un par utilisateur).
*/

#include <stdlib.h>
#include "Erreur.h"
#include "TexteCC.h"
#include "ByteOrder.h"
#include "Fichier.h"
#include "Crc.h"

static uint32 gTableC[] =
{                
    0x12345678, 0x12345678, 0x12345678, 0x12345678, 0x12345678, 0x12345678, 0x12345678, 0x12345678,
    0x12345678, 0x12345678, 0x12345678, 0x12345678, 0x12345678, 0x12345678, 0x12345678, 0x12345678,
    0x12345678, 0x12345678, 0x12345678, 0x12345678, 0x12345678, 0x12345678, 0x12345678, 0x12345678,
    0x12345678, 0x12345678, 0x12345678, 0x12345678, 0x12345678, 0x12345678, 0x12345678, 0x12345678,
    0x12345678, 0x12345678, 0x12345678, 0x12345678, 0x12345678, 0x12345678, 0x12345678, 0x12345678,
    0x12345678, 0x12345678, 0x12345678, 0x12345678, 0x12345678, 0x12345678, 0x12345678, 0x12345678,
    0x12345678, 0x12345678, 0x12345678, 0x12345678, 0x12345678, 0x12345678, 0x12345678, 0x12345678,
    0x12345678, 0x12345678, 0x12345678, 0x12345678, 0x12345678, 0x12345678, 0x12345678, 0x12345678,
    0x12345678, 0x12345678, 0x12345678, 0x12345678, 0x12345678, 0x12345678, 0x12345678, 0x12345678,
    0x12345678, 0x12345678, 0x12345678, 0x12345678, 0x12345678, 0x12345678, 0x12345678, 0x12345678,
    0x12345678, 0x12345678, 0x12345678, 0x12345678, 0x12345678, 0x12345678, 0x12345678, 0x12345678,
    0x12345678, 0x12345678, 0x12345678, 0x12345678, 0x12345678, 0x12345678, 0x12345678, 0x12345678,
    0x12345678, 0x12345678, 0x12345678, 0x12345678, 0x12345678, 0x12345678, 0x12345678, 0x12345678,
    0x12345678, 0x12345678, 0x12345678, 0x12345678, 0x12345678, 0x12345678, 0x12345678, 0x12345678,
    0x12345678, 0x12345678, 0x12345678, 0x12345678, 0x12345678, 0x12345678, 0x12345678, 0x12345678,
    0x12345678, 0x12345678, 0x12345678, 0x12345678, 0x12345678, 0x12345678, 0x12345678, 0x12345678,
    0x12345678, 0x12345678, 0x12345678, 0x12345678, 0x12345678, 0x12345678, 0x12345678, 0x12345678,
    0x12345678, 0x12345678, 0x12345678, 0x12345678, 0x12345678, 0x12345678, 0x12345678, 0x12345678,
    0x12345678, 0x12345678, 0x12345678, 0x12345678, 0x12345678, 0x12345678, 0x12345678, 0x12345678,
    0x12345678, 0x12345678, 0x12345678, 0x12345678, 0x12345678, 0x12345678, 0x12345678, 0x12345678,
    0x12345678, 0x12345678, 0x12345678, 0x12345678, 0x12345678, 0x12345678, 0x12345678, 0x12345678,
    0x12345678, 0x12345678, 0x12345678, 0x12345678, 0x12345678, 0x12345678, 0x12345678, 0x12345678,
    0x12345678, 0x12345678, 0x12345678, 0x12345678, 0x12345678, 0x12345678, 0x12345678, 0x12345678,
    0x12345678, 0x12345678, 0x12345678, 0x12345678, 0x12345678, 0x12345678, 0x12345678, 0x12345678,
    0x12345678, 0x12345678, 0x12345678, 0x12345678, 0x12345678, 0x12345678, 0x12345678, 0x12345678,
    0x12345678, 0x12345678, 0x12345678, 0x12345678, 0x12345678, 0x12345678, 0x12345678, 0x12345678,
    0x12345678, 0x12345678, 0x12345678, 0x12345678, 0x12345678, 0x12345678, 0x12345678, 0x12345678,
    0x12345678, 0x12345678, 0x12345678, 0x12345678, 0x12345678, 0x12345678, 0x12345678, 0x12345678,
    0x12345678, 0x12345678, 0x12345678, 0x12345678, 0x12345678, 0x12345678, 0x12345678, 0x12345678,
    0x12345678, 0x12345678, 0x12345678, 0x12345678, 0x12345678, 0x12345678, 0x12345678, 0x12345678,
    0x12345678, 0x12345678, 0x12345678, 0x12345678, 0x12345678, 0x12345678, 0x12345678, 0x12345678,
    0x12345678, 0x12345678, 0x12345678, 0x12345678, 0x12345678, 0x12345678, 0x12345678, 0x12345678
};  

#define NB_CRC_CTR    sizeof(gTableC) / sizeof(uint32)

uint32 getCrc32(const byte tab[], const int32 dimTab)
{
    uint32 CRC = MASQUE_CRC, lA = dimTab; byte* d = (byte*)tab;
    if (lA > 0) while (lA--) __try {
        CRC = (CRC >> 8) ^ gTableC[(CRC ^ *d++) & MASQUE_CTR];
    } __except(EXCEPTION_EXECUTE_HANDLER){ 
        ND_JOURNALISER_EXCEPTION0(__FILENAME__, GetExceptionCode());
    } return CRC ^ MASQUE_CRC;
}

uint16 getNbCrcCtr(){ return NB_CRC_CTR; }

long getNombre32(const byte tab[DIM_16], uint16 l, const uint16 n)
{
    int i; uint64 r = 0, n16 = 1; uint16 j=0; uint8 c;
    byte tabHexa[2*DIM_256+1]={0}; const uint16 L = UI16_STRLEN(tab);
    const uint64 MAXC_32 = 4293000000; __try
    {
        for (i=0; (uint16)i < L; i++, j++){ tabHexa[j] = tab[i]; }        
        for (i=12; i >=0; i--)
        {
            c = (int)(tabHexa[i]); if (c <= '9'){
                c -= '0';
            } else if (c <= 'Z'){
                c = (c - 'A') + 10;
            } else {
                c = (c - 'a') + 10;
            }
            if ((uint64)(n16 * DIM_16) < MAXC_32){
                r += c * n16; n16 *= DIM_16;
            } else { break; } // Arr�t.
        }
    } __except(EXCEPTION_EXECUTE_HANDLER){ 
        ND_JOURNALISER_EXCEPTION0(__FILENAME__, GetExceptionCode());
    }
    r += (uint64)(l+1)*52; while (r > MAXLONG){ r -= ((l+1)*29876321); } 
    return (long)r;
}

long getNombreDC(const byte t[], uint16 lA,
    const byte c1[][DIM_16], uint8 mb, uint16 x, uint16 lB)
{
    uint64 r = MASQUE_CRC, c; uint32 s=0, y = x % DIM_16; byte* tab = (byte*)t;
    uint32 dA[DIM_32] = {0}, dB[DIM_32] = {0}; uint16 i, j, xA=0;
    const uint16 NC = sizeof(gTableC)/sizeof(uint32); int32 n = ((uint8)lA/2)+1;
    for (i=0; i < mb; i++, j++)
    {
        s = getNombre32(c1[i], i, 1) + x; xA = (s % NC);
        for (j=0; j <= i; j++){
            if (dA[j] == xA){ xA++; j=0; } if (xA >= NC){ xA = 0; }
        }
        dA[i] = xA; dB[i] = gTableC[xA]; gTableC[xA] = s;
    }
    c = c1[3][y]*x; c = (c == 0 ? 29 : c); r -= c;
    while (n--){ r = (r / DIM_256) ^ gTableC[(r ^ *tab++) & MASQUE_CTR]; }
    for (i=0; i < DIM_32 && dB[i] != 0; i++){ gTableC[dA[i]] = dB[i]; }
    while (r > MAXLONG){ r -= ((c1[0][y]+c1[1][y]+x)*12389); }
    r = (r == 0 ? c1[3][y] % 85 : r); return (long)r;
}

uint32 getCrcPseudo(const uint32 data[])
{
    byte* d = (byte*) data; uint32 CRC = MASQUE_CRC;
    CRC = (CRC >> 8) ^ gTableC[ (CRC ^ *d++) & MASQUE_CTR ];
    CRC = (CRC >> 8) ^ gTableC[ (CRC ^ *d++) & MASQUE_CTR ];
    CRC = (CRC >> 8) ^ gTableC[ (CRC ^ *d++) & MASQUE_CTR ];
    CRC = (CRC >> 8) ^ gTableC[ (CRC ^ *d)   & MASQUE_CTR ];
    CRC ^= MASQUE_CRC; return CRC;
}

#define UPDC32(on, crc)\
\
  (uint32)((gTableC[(((uint32)(crc)) ^ ((uchar)(on))) & MASQUE_CTR] \
    ^ (((uint32)(crc)) >> 8)))

#if EST_STD_BYTE_ORDER
  #define CRC_SELFTEST  0xcae1a6a3
#else  
  define CRC_SELFTEST
#endif