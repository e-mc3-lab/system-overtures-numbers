::
:: Copyright (c) 2024-2026 SCLE-CSES
::
:: Governed by the licence 1.0
::
@echo off
chcp 28591 > nul
set CHEM_ND_PROGRAMME=%1
set CONFIG=%2
set CHEM_VS=%DC%\proj\vs
set NOM_CORALGO=Coralgo
set CHEM_CORALGO=%CHEM_VS%\%NOM_CORALGO%
set NO_ESSAI=1

:ESSAI
%CHEM_ND_PROGRAMME%CxRef.exe

:: Open "Native Tools for VS".
call %VSCMDIR%vcvars64

cd %CHEM_CORALGO%
del %CHEM_CORALGO%\x64\%CONFIG%\%NOM_CORALGO%.lib
msbuild -t:rebuild -property:Configuration=%CONFIG%
if NOT %ERRORLEVEL% == 0 (goto FIN)

set NOM_CYPTUR=Cyptur
set CHEM_CYPTUR=%CHEM_VS%\%NOM_CYPTUR%
cd %CHEM_CYPTUR%
msbuild -t:rebuild -property:Configuration=%CONFIG%
if NOT %ERRORLEVEL% == 0 (goto FIN)

set NOM_DAA=Daa
set CHEM_DAA=%CHEM_VS%\%NOM_DAA%
cd %CHEM_DAA%
msbuild -t:rebuild -property:Configuration=%CONFIG%
if %ERRORLEVEL% == 0 (%CHEM_ND_PROGRAMME%CxRef.exe /c /g %CONFIG%)

%CHEM_ND_PROGRAMME%CxRef.exe /a /g %CONFIG%
if NOT %ERRORLEVEL% == 0 (
    if %NO_ESSAI% GTR 3 (
	    echo �Erreur Auto-Test?
	) else (
        SET /a (NO_ESSAI += 1)
        %CHEM_ND_PROGRAMME%CxRef.exe /d /g %CONFIG% %ERRORLEVEL%
        goto ESSAI
	)
)

:FIN
 