/**
 * @auteur: SCLE|CSES.
 */

#include <math.h>
#include "GenKey.h"

typedef struct
{
    void(*setRandKey)(byte tabCad[], uint i);
    
} RandomKeyFunction;

#define DIM_RKF sizeof(RandomKeyFunction)

typedef struct
{
    double(*opA)(double a);
    double(*opB)(double a, double b);
    double(*opC)(double a, double b, double c);

} RandomKeyOperation;

#define NB_OP 50    

static RandomKeyOperation gTabOps[NB_OP] = {0};
static RandomKeyFunction gTabRfs[NB_PRF] = {0}; BOOL bIniTabPrfs = FALSE;

double plus(double x, double y){ return x + y; }
double moins(double x, double y){ return x - y; }
double fois(double x, double y){ return x * y; }
double diva(double x, double y){ return (y != 0 ? x / y : x); }
double divb(double x, double y){ return (y != 0 ? (x * y) / y : x); }
double divc(double x, double y){ return (y != 0 ? (x + (y * y )) / y : x); }
double nxta(double x, double y){ return nextafter(x, y); }
double nearbn(double x){ return nearbyint(x); }

double labsolu(double x)
{
    double r�sult = double(llabs(uint64(x)));
    return (r�sult > 0.0001 ? r�sult : 1.0);
}

double getRsA(RandomKeyOperation* op, double x){
    return labsolu(op->opA(x));
}

double getRsB(RandomKeyOperation* op, double x, double y){
    return op->opB(double(llabs(llong(x))), y);
}

double getRsC(RandomKeyOperation* op, double x, double y, double z){
    return labsolu(op->opC(x, y, z));
}

#ifndef exp10
  double exp10(uint8 x){ return pow(10, x); }
#endif

RandomKeyFunction* getRkf(uint16 i)
{
    if (i < NB_PRF){ return &gTabRfs[i]; } else { return NULL; }
}

void calcPrf(byte tabCad[], const uint i, const uint8 tab[], const uint8 N)
{
    double s = 0.0, r = 0, result = 1.0; RandomKeyOperation* op = NULL;
    byte* tabc = tabCad + i; for (uint8 j = 0; j < N; j++)
    {
        s = double(tabc[j]); op = &gTabOps[tab[j]];
        if (op->opA){ r = getRsA(op, s); }
        else if (op->opB){ r = getRsB(op, result, s); }
        else { r = getRsC(op, result, double(tab[0]), s); }
        if (r < 0.1)
        {
            char tabr[DIM_16] = {0}; double conv = 1;
            sprintf(tabr, "%12f", result);
            for (uint8 l = 0; l < 3; l++){ conv += tabr[j] * exp10(j); }
            result = conv;
        } else if (r < 100){ r *= 1000; } result += r;
        if (result < DIM_256){ result *= s; }
        result = double(llabs(uint64(result)) % DIM_256);
        if (result == 0){ result = 1; } tabc[j] = byte(result);
    }
}

