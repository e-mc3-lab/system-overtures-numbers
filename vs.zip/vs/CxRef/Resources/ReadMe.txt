
The function 'modifierDRef' copies encryption modules in CorAlgo. 
It executes itself via the command CxRef.exe which modifies the arrays
SALT and others. The resulting sources are not keeped. They are 
deleted (or simply replaced by a new) after the build.

The keyfiles are placed in the folders ./1, ./2, ./3, ... to construct 
them in advance. They are transfered after in the folders of NetDisq. 
Those should instead be saved (in format BLOB) in SQL database. In fact,
each one is free to implement the solutions according to his own needs.