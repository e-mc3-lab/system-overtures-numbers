#ifndef ND_CX_REF_H
#define ND_CX_REF_H

#include "Theo.h"
#include "Anthozoa.h"
#include "Crc.h"
#include "ModXyz.h"
#include "Ripemd.h"
#include "Sha.h"
#include "Whirlpool.h"
#include "Doa.h"
//#include "Aes_x64.h"

#ifdef __cplusplus
extern "C" {
#endif

#define NOM_CORE_XREF       "CxRef"

#define SUFX_H              ".h"
#define SUFX_CPP            ".cpp"
#define SUFX_ASM            ".asm"


#define NOM_ENT�TE_THEO     MOT_THEO SUFX_H
#define NOM_MODULE_THEO     MOT_THEO SUFX_CPP

#define NOM_ENT�TE_ANTHOA   MOT_ANTHOZOA SUFX_H
#define NOM_MODULE_ANTHOA   MOT_ANTHOZOA SUFX_CPP

#define NOM_ENT�TE_CRC      MOT_CRC SUFX_H
#define NOM_MODULE_CRC      MOT_CRC SUFX_CPP

#define NOM_ENT�TE_MODYZ    MOT_MOD_XYZ SUFX_H
#define NOM_MODULE_MODYZ    MOT_MOD_XYZ SUFX_CPP

#define NOM_ENT�TE_RIPEMD   MOT_RIPEMD SUFX_H
#define NOM_MODULE_RIPEMD   MOT_RIPEMD SUFX_CPP

#define NOM_ENT�TE_SHA      MOT_SHA SUFX_H
#define NOM_MODULE_SHA      MOT_SHA SUFX_CPP

#define NOM_ENT�TE_WHRPOOL  MOT_WHIRLPOOL SUFX_H
#define NOM_MODULE_WHRPOOL  MOT_WHIRLPOOL SUFX_CPP

#define NOM_ENT�TE_DOA      MOT_DOA SUFX_H
#define NOM_MODULE_DOA      MOT_DOA SUFX_CPP

#define NOM_ENT�TE_GENKEY   MOT_GENKEY SUFX_H
#define NOM_MODULE_GENKEY   MOT_GENKEY SUFX_CPP

// Non modifiable:
#define NOM_ENT�TE_AES_X64  MOT_AES_X64 SUFX_H
#define NOM_MODULE_AES_X64  MOT_AES_X64 SUFX_ASM

#ifdef __cplusplus
}
#endif

#endif // ND_CX_REF_H