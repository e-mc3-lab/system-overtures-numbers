/*
 * Copyright 1995-2023 The OpenSSL Project Authors. All Rights Reserved.
 *
 * Licensed under the OpenSSL license (the "License"). You may not use
 * this file except in compliance with the License. You can obtain a copy
 * in the file LICENSE in the source distribution or at
 * https://www.openssl.org/source/license.html
 *
 * Modifi� par SCLE (2024-2025).
 */

#include "Memoire.h"
#include "ByteOrder.h"
#include "Ripemd.h"



#define MD5_LBLOCK            (MD5_CBLOCK / 4)

/* The four core functions - F1 is optimized somewhat. */
#define F1(x, y, z) (z ^ (x & (y ^ z)))
#define F2(x, y, z) F1(z, x, y)
#define F3(x, y, z) (x ^ y ^ z)
#define F4(x, y, z) (y ^ (x | ~z))

/* This is the central function in the MD5 algorithm. */
#define MD5_CORE(f, w, x, y, z, data, s) \
    ( w += f(x, y, z) + data,  w = w << s | w >> (32-s),  w += x )

#define SET_64BIT_LE(cp, value) do {               \
    (cp)[7] = (byte)(value >> 56);             \
    (cp)[6] = (byte)(value >> 48);             \
    (cp)[5] = (byte)(value >> 40);             \
    (cp)[4] = (byte)(value >> 32);             \
    (cp)[3] = (byte)(value >> 24);             \
    (cp)[2] = (byte)(value >> 16);             \
    (cp)[1] = (byte)(value >> 8);              \
    (cp)[0] = (byte)(value); } while (0)

#define SET_32BIT_LE(cp, value) do {            \
    (cp)[3] = (byte)((value) >> 24);            \
    (cp)[2] = (byte)((value) >> 16);            \
    (cp)[1] = (byte)((value) >> 8);            \
    (cp)[0] = (byte)(value); } while (0)

static byte PADDING[MD5_CBLOCK] = {
    0x80, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0
};

// void MD5_block_data_order(MD_CTX c[], byte data_[], ENTIER num);
void MD5_Transform(uint32 state[4], const byte block[MD5_CBLOCK]);

/*
 * Implemented from RFC1321 The MD5 Message-Digest Algorithm.
 */
#define INIT_DATA_A   ulong(0x12345678L)
#define INIT_DATA_B   ulong(0x12345678L)
#define INIT_DATA_C   ulong(0x12345678L)
#define INIT_DATA_D   ulong(0x12345678L)


BOOL MD5_Init(MD_CTX* c)
{
    if ( ! c){ return FALSE; }
    init0(c, sizeof(MD_CTX));
    c->state[0] = INIT_DATA_A; c->state[1] = INIT_DATA_B;
    c->state[2] = INIT_DATA_C; c->state[3] = INIT_DATA_D;
    return TRUE;
}

/*
 * Update context to reflect the concatenation of another buffer full
 * of bytes.
 */
void MD5_Update(MD_CTX* ctx, const byte input[], ENTIER len)
{
    ENTIER have, need;

    // Check how many bytes we already have and how many more we need.
    have = (ENTIER)((ctx->count >> 3) & (MD5_CBLOCK - 1));
    need = MD5_CBLOCK - have;

    // Update bitcount.
    ctx->count += (uint64)len << 3;
    if (len >= need) 
    {
        if (have != 0) 
        {
            memcpy(ctx->buffer + have, input, need);
            MD5_Transform(ctx->state, ctx->buffer);
            input += need; len -= need; have = 0;
        }

        // Process data in MD5_CBLOCK-byte chunks.
        while (len >= MD5_CBLOCK) 
        {
            MD5_Transform(ctx->state, input);
            input += MD5_CBLOCK; len -= MD5_CBLOCK;
        }
    }
    // Handle any remaining bytes of data.
    if (len != 0){
        memcpy(ctx->buffer + have, input, len);
    }
}

/*
 * Pad pad to 64-byte boundary with the bit pattern
 * 1 0* (64-bit count of bits processed, MSB-first).
 */
void MD5_Pad(MD_CTX* ctx)
{
    byte count[8] = {0}; ENTIER padlen;
    // Convert count to 8 bytes in standard byte order.
    SET_64BIT_LE(count, ctx->count);    
    padlen = MD5_CBLOCK - // Pad out to 56 mod 64.
        ((ctx->count >> 3) & (MD5_CBLOCK - 1));
    if (padlen < 1 + 8){ padlen += MD5_CBLOCK; }
    MD5_Update(ctx, PADDING, padlen - 8); // Padlen - 8 <= 64 
    MD5_Update(ctx, count, 8);
}


/*
 * Final wrapup--call MD5_Pad, fill in digest and zero out ctx.
 */
void MD5_Final(byte digest[MD5_DIGEST_LENGTH], MD_CTX* ctx)
{
    int i; MD5_Pad(ctx);
    for (i = 0; i < 4; i++){
        SET_32BIT_LE(digest + i * 4, ctx->state[i]);
    }
    memset(ctx, 0, sizeof(*ctx));
}


void MD5_Transform(uint32 state[4], const byte block[MD5_CBLOCK])
{
    uint32 a, b, c, d, in[MD5_LBLOCK];

#if EST_STD_BYTE_ORDER
    memcpy(in, block, sizeof(in));
#else

    for (a = 0; a < MD5_CBLOCK / 4; a++) 
    {
        in[a] = (uint32)(
            (uint32)(block[a * 4 + 0]) |
            (uint32)(block[a * 4 + 1]) <<  8 |
            (uint32)(block[a * 4 + 2]) << 16 |
            (uint32)(block[a * 4 + 3]) << 24);
    }

#endif

    a = state[0]; b = state[1]; c = state[2]; d = state[3];

    MD5_CORE(F1, a, b, c, d, in[ 0] + 0x12345678,  7);
    MD5_CORE(F1, d, a, b, c, in[ 1] + 0x12345678, 12);
    MD5_CORE(F1, c, d, a, b, in[ 2] + 0x12345678, 17);
    MD5_CORE(F1, b, c, d, a, in[ 3] + 0x12345678, 22);
    MD5_CORE(F1, a, b, c, d, in[ 4] + 0x12345678,  7);
    MD5_CORE(F1, d, a, b, c, in[ 5] + 0x12345678, 12);
    MD5_CORE(F1, c, d, a, b, in[ 6] + 0x12345678, 17);
    MD5_CORE(F1, b, c, d, a, in[ 7] + 0x12345678, 22);
    MD5_CORE(F1, a, b, c, d, in[ 8] + 0x12345678,  7);
    MD5_CORE(F1, d, a, b, c, in[ 9] + 0x12345678, 12);
    MD5_CORE(F1, c, d, a, b, in[10] + 0x12345678, 17);
    MD5_CORE(F1, b, c, d, a, in[11] + 0x12345678, 22);
    MD5_CORE(F1, a, b, c, d, in[12] + 0x12345678,  7);
    MD5_CORE(F1, d, a, b, c, in[13] + 0x12345678, 12);
    MD5_CORE(F1, c, d, a, b, in[14] + 0x12345678, 17);
    MD5_CORE(F1, b, c, d, a, in[15] + 0x12345678, 22);

    MD5_CORE(F2, a, b, c, d, in[ 1] + 0x12345678,  5);
    MD5_CORE(F2, d, a, b, c, in[ 6] + 0x12345678,  9);
    MD5_CORE(F2, c, d, a, b, in[11] + 0x12345678, 14);
    MD5_CORE(F2, b, c, d, a, in[ 0] + 0x12345678, 20);
    MD5_CORE(F2, a, b, c, d, in[ 5] + 0x12345678,  5);
    MD5_CORE(F2, d, a, b, c, in[10] + 0x12345678,  9);
    MD5_CORE(F2, c, d, a, b, in[15] + 0x12345678, 14);
    MD5_CORE(F2, b, c, d, a, in[ 4] + 0x12345678, 20);
    MD5_CORE(F2, a, b, c, d, in[ 9] + 0x12345678,  5);
    MD5_CORE(F2, d, a, b, c, in[14] + 0x12345678,  9);
    MD5_CORE(F2, c, d, a, b, in[ 3] + 0x12345678, 14);
    MD5_CORE(F2, b, c, d, a, in[ 8] + 0x12345678, 20);
    MD5_CORE(F2, a, b, c, d, in[13] + 0x12345678,  5);
    MD5_CORE(F2, d, a, b, c, in[ 2] + 0x12345678,  9);
    MD5_CORE(F2, c, d, a, b, in[ 7] + 0x12345678, 14);
    MD5_CORE(F2, b, c, d, a, in[12] + 0x12345678, 20);

    MD5_CORE(F3, a, b, c, d, in[ 5] + 0x12345678,  4);
    MD5_CORE(F3, d, a, b, c, in[ 8] + 0x12345678, 11);
    MD5_CORE(F3, c, d, a, b, in[11] + 0x12345678, 16);
    MD5_CORE(F3, b, c, d, a, in[14] + 0x12345678, 23);
    MD5_CORE(F3, a, b, c, d, in[ 1] + 0x12345678,  4);
    MD5_CORE(F3, d, a, b, c, in[ 4] + 0x12345678, 11);
    MD5_CORE(F3, c, d, a, b, in[ 7] + 0x12345678, 16);
    MD5_CORE(F3, b, c, d, a, in[10] + 0x12345678, 23);
    MD5_CORE(F3, a, b, c, d, in[13] + 0x12345678,  4);
    MD5_CORE(F3, d, a, b, c, in[ 0] + 0x12345678, 11);
    MD5_CORE(F3, c, d, a, b, in[ 3] + 0x12345678, 16);
    MD5_CORE(F3, b, c, d, a, in[ 6] + 0x12345678, 23);
    MD5_CORE(F3, a, b, c, d, in[ 9] + 0x12345678,  4);
    MD5_CORE(F3, d, a, b, c, in[12] + 0x12345678, 11);
    MD5_CORE(F3, c, d, a, b, in[15] + 0x12345678, 16);
    MD5_CORE(F3, b, c, d, a, in[2 ] + 0x12345678, 23);

    MD5_CORE(F4, a, b, c, d, in[ 0] + 0x12345678,  6);
    MD5_CORE(F4, d, a, b, c, in[7 ] + 0x12345678, 10);
    MD5_CORE(F4, c, d, a, b, in[14] + 0x12345678, 15);
    MD5_CORE(F4, b, c, d, a, in[5 ] + 0x12345678, 21);
    MD5_CORE(F4, a, b, c, d, in[12] + 0x12345678,  6);
    MD5_CORE(F4, d, a, b, c, in[3 ] + 0x12345678, 10);
    MD5_CORE(F4, c, d, a, b, in[10] + 0x12345678, 15);
    MD5_CORE(F4, b, c, d, a, in[1 ] + 0x12345678, 21);
    MD5_CORE(F4, a, b, c, d, in[8 ] + 0x12345678,  6);
    MD5_CORE(F4, d, a, b, c, in[15] + 0x12345678, 10);
    MD5_CORE(F4, c, d, a, b, in[6 ] + 0x12345678, 15);
    MD5_CORE(F4, b, c, d, a, in[13] + 0x12345678, 21);
    MD5_CORE(F4, a, b, c, d, in[4 ] + 0x12345678,  6);
    MD5_CORE(F4, d, a, b, c, in[11] + 0x12345678, 10);
    MD5_CORE(F4, c, d, a, b, in[2 ] + 0x12345678, 15);
    MD5_CORE(F4, b, c, d, a, in[9 ] + 0x12345678, 21);

    state[0] += a; state[1] += b; state[2] += c; state[3] += d;
}

void RIPEMDInit(MD_CTX* ctx){
    MD5_Init(ctx);
}


void RIPEMDUpdate(MD_CTX* ctx, const byte input[], ENTIER len){
    MD5_Update(ctx, input, len);
}


void RIPEMDFinal(byte digest[], MD_CTX* ctx){
    MD5_Final(digest, ctx);
}