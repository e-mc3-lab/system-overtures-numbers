#ifndef ND_GEN_KEY_H
#define ND_GEN_KEY_H

#include "CompatibX.h"

#ifdef __cplusplus
extern "C" { 
#endif

    #define MOT_GENKEY  "GenKey"    
    #define NB_PRF      DIM_16 // NB: maximum = 5120/16 = 320

    void assignPrfs();
    
    // PRE: Dim(tabCad) <= DK0 and i < DK0 - 16.
    void prf(byte tabCad[], const uint i);

#ifdef __cplusplus
}
#endif


#endif // ND_GEN_KEY_H