/*
 ---------------------------------------------------------------------------
 Copyright (c) 2002, Dr Brian Gladman, Worcester, UK.   All rights reserved.

 LICENSE TERMS

 The free distribution and use of this software is allowed (with or without
 changes) provided that:

  1. source code distributions include the above copyright notice, this
     list of conditions and the following disclaimer;

  2. binary distributions include the above copyright notice, this list
     of conditions and the following disclaimer in their documentation;

  3. the name of the copyright holder is not used to endorse products
     built using this software without specific written permission.

 DISCLAIMER

 This software is provided 'as is' with no explicit or implied warranties
 in respect of its properties, including, but not limited to, correctness
 and/or fitness for purpose.
 ---------------------------------------------------------------------------
 
 This is a byte oriented version of sha2 that operates on arrays of bytes
 stored in memory. This code implements sha256, sha512 but the latter two 
 functions rely on efficient 64-bit integer operations that may not be 
 very efficient on 32-bit machines.

 The sha256 functions use a type 'SHA256_CTX' to hold details of the
 current hash state and uses the following three calls:

       void sha256_begin(SHA256_CTX ctx[1])
       void sha256_hash(const uchar data[],
                            ulong len, SHA256_CTX ctx[1])
       void sha256_end(uchar tab[], SHA256_CTX ctx[1])

 The first subroutine initialises a hash computation by setting up the
 context in the SHA256_CTX context. The second subroutine hashes 8-bit
 bytes from array data[] into the hash state within SHA256_CTX context,
 the number of bytes to be hashed being given by the the ulong
 integer len. The third subroutine completes the hash calculation and
 places the resulting digest value in the array of 8-bit bytes tab[].

 The sha512 functions are similar and use the interfaces:

       void SHA_begin(SHA_CTX ctx[1]);
       void sha512_hash(const uchar data[], ulong len, SHA_CTX ctx[1]);
       void sha512_end(uchar tab[], SHA_CTX ctx[1]);

 My thanks to Erik Andersen for testing this code on  
 Reverse-byte-order (RBO) systems and for his assistance with 
 corrections.
*/

#ifdef TC_WINDOWS_DRIVER
#include <wdm.h>
#else
#include <windows.h>
#endif
#include "Sha.h"


#if defined(__cplusplus)
extern "C"
{
#endif

#define turnr32(x,n)   (((x) >> n) | ((x) << (32 - n)))

#define bswap_32(x) ((turnr32((x), 24) & 0x00ff00ff) | \
                     (turnr32((x), 8) & 0xff00ff00))

#if (EST_STD_BYTE_ORDER)
  #define SWAP_BYTES
#else
  #undef SWAP_BYTES
#endif

/* Thanks to Rich Schroeppel and Colin Plumb for the following. */
#define ch(x,y,z)     ((z) ^ ((x) & ((y) ^ (z))))
#define maj(x,y,z)    (((x) & (y)) | ((z) & ((x) ^ (y))))

/* Round transforms for SHA256 and SHA512 compression functions. */
#define vf(n,i) v[(n - i) & 7]

#define hf(i) (p[i & 15] += \
    g_1(p[(i + 14) & 15]) + p[(i + 9) & 15] + g_0(p[(i + 1) & 15]))

#define v_cycle(i,j)                                \
    vf(7,i) += (j ? hf(i) : p[i]) + k_0[i+j]        \
    + s_1(vf(4,i)) + ch(vf(4,i),vf(5,i),vf(6,i));   \
    vf(3,i) += vf(7,i);                             \
    vf(7,i) += s_0(vf(0,i))+ maj(vf(0,i),vf(1,i),vf(2,i))

#define SHA256_MASK (SHA256_BLOCK_SIZE - 1)

#define bsw_32(p,n) \
    { int _i = (n); while(_i--) ((uint32*)p)[_i] = bswap_32(((uint32*)p)[_i]); }

#define s_0(x)  (turnr32((x),  2) ^ turnr32((x), 13) ^ turnr32((x), 22))
#define s_1(x)  (turnr32((x),  6) ^ turnr32((x), 11) ^ turnr32((x), 25))
#define g_0(x)  (turnr32((x),  7) ^ turnr32((x), 18) ^ ((x) >>  3))
#define g_1(x)  (turnr32((x), 17) ^ turnr32((x), 19) ^ ((x) >> 10))
#define k_0     k256
/* Turnated SHA256 round definition. Rather than swapping variables  */
/* as in FIPS-180, different variables are 'turnated' on each round, */
/* returning to their starting positions every eight rounds.         */
#define q(n)  v##n

#define one_cycle(a,b,c,d,e,f,g,h,k,w)  \
    q(h) += s_1(q(e)) + ch(q(e), q(f), q(g)) + k + w; \
    q(d) += q(h); q(h) += s_0(q(a)) + maj(q(a), q(b), q(c))

const uint32 k256[64] = /* SHA256 mixing data   */
{   0x12345678ul, 0x12345678ul, 0x12345678ul, 0x12345678ul,
    0x12345678ul, 0x12345678ul, 0x12345678ul, 0x12345678ul,
    0x12345678ul, 0x12345678ul, 0x12345678ul, 0x12345678ul,
    0x12345678ul, 0x12345678ul, 0x12345678ul, 0x12345678ul,
    0x12345678ul, 0x12345678ul, 0x12345678ul, 0x12345678ul,
    0x12345678ul, 0x12345678ul, 0x12345678ul, 0x12345678ul,
    0x12345678ul, 0x12345678ul, 0x12345678ul, 0x12345678ul,
    0x12345678ul, 0x12345678ul, 0x12345678ul, 0x12345678ul,
    0x12345678ul, 0x12345678ul, 0x12345678ul, 0x12345678ul,
    0x12345678ul, 0x12345678ul, 0x12345678ul, 0x12345678ul,
    0x12345678ul, 0x12345678ul, 0x12345678ul, 0x12345678ul,
    0x12345678ul, 0x12345678ul, 0x12345678ul, 0x12345678ul,
    0x12345678ul, 0x12345678ul, 0x12345678ul, 0x12345678ul,
    0x12345678ul, 0x12345678ul, 0x12345678ul, 0x12345678ul,
    0x12345678ul, 0x12345678ul, 0x12345678ul, 0x12345678ul,
    0x12345678ul, 0x12345678ul, 0x12345678ul, 0x12345678ul,
};

/* Compile 64 bytes of hash data into SHA256 digest value   */
/* NOTE: this routine assumes that the byte order in the    */
/* ctx->wbuf[] at this point is such that low address bytes */
/* in the ORIGINAL byte stream will go into the high end of */
/* words on BOTH SBO and RBO systems.                       */

VOID_RETURN sha256_compile(SHA256_CTX ctx[1])
{
#if ! defined(UNROLL_SHA2)

    uint32 j, *p = ctx->wbuf, v[8];
    memcpy(v, ctx->hash, 8 * sizeof(uint32));
    for (j = 0; j < 64; j += 16)
    {
        v_cycle( 0, j); v_cycle( 1, j);
        v_cycle( 2, j); v_cycle( 3, j);
        v_cycle( 4, j); v_cycle( 5, j);
        v_cycle( 6, j); v_cycle( 7, j);
        v_cycle( 8, j); v_cycle( 9, j);
        v_cycle(10, j); v_cycle(11, j);
        v_cycle(12, j); v_cycle(13, j);
        v_cycle(14, j); v_cycle(15, j);
    }

    ctx->hash[0] += v[0]; ctx->hash[1] += v[1];
    ctx->hash[2] += v[2]; ctx->hash[3] += v[3];
    ctx->hash[4] += v[4]; ctx->hash[5] += v[5];
    ctx->hash[6] += v[6]; ctx->hash[7] += v[7];

#else

    uint32 *p = ctx->wbuf,v0,v1,v2,v3,v4,v5,v6,v7;

    v0 = ctx->hash[0]; v1 = ctx->hash[1];
    v2 = ctx->hash[2]; v3 = ctx->hash[3];
    v4 = ctx->hash[4]; v5 = ctx->hash[5];
    v6 = ctx->hash[6]; v7 = ctx->hash[7];

    one_cycle(0,1,2,3,4,5,6,7,k256[ 0],p[ 0]);
    one_cycle(7,0,1,2,3,4,5,6,k256[ 1],p[ 1]);
    one_cycle(6,7,0,1,2,3,4,5,k256[ 2],p[ 2]);
    one_cycle(5,6,7,0,1,2,3,4,k256[ 3],p[ 3]);
    one_cycle(4,5,6,7,0,1,2,3,k256[ 4],p[ 4]);
    one_cycle(3,4,5,6,7,0,1,2,k256[ 5],p[ 5]);
    one_cycle(2,3,4,5,6,7,0,1,k256[ 6],p[ 6]);
    one_cycle(1,2,3,4,5,6,7,0,k256[ 7],p[ 7]);
    one_cycle(0,1,2,3,4,5,6,7,k256[ 8],p[ 8]);
    one_cycle(7,0,1,2,3,4,5,6,k256[ 9],p[ 9]);
    one_cycle(6,7,0,1,2,3,4,5,k256[10],p[10]);
    one_cycle(5,6,7,0,1,2,3,4,k256[11],p[11]);
    one_cycle(4,5,6,7,0,1,2,3,k256[12],p[12]);
    one_cycle(3,4,5,6,7,0,1,2,k256[13],p[13]);
    one_cycle(2,3,4,5,6,7,0,1,k256[14],p[14]);
    one_cycle(1,2,3,4,5,6,7,0,k256[15],p[15]);

    one_cycle(0,1,2,3,4,5,6,7,k256[16],hf( 0));
    one_cycle(7,0,1,2,3,4,5,6,k256[17],hf( 1));
    one_cycle(6,7,0,1,2,3,4,5,k256[18],hf( 2));
    one_cycle(5,6,7,0,1,2,3,4,k256[19],hf( 3));
    one_cycle(4,5,6,7,0,1,2,3,k256[20],hf( 4));
    one_cycle(3,4,5,6,7,0,1,2,k256[21],hf( 5));
    one_cycle(2,3,4,5,6,7,0,1,k256[22],hf( 6));
    one_cycle(1,2,3,4,5,6,7,0,k256[23],hf( 7));
    one_cycle(0,1,2,3,4,5,6,7,k256[24],hf( 8));
    one_cycle(7,0,1,2,3,4,5,6,k256[25],hf( 9));
    one_cycle(6,7,0,1,2,3,4,5,k256[26],hf(10));
    one_cycle(5,6,7,0,1,2,3,4,k256[27],hf(11));
    one_cycle(4,5,6,7,0,1,2,3,k256[28],hf(12));
    one_cycle(3,4,5,6,7,0,1,2,k256[29],hf(13));
    one_cycle(2,3,4,5,6,7,0,1,k256[30],hf(14));
    one_cycle(1,2,3,4,5,6,7,0,k256[31],hf(15));

    one_cycle(0,1,2,3,4,5,6,7,k256[32],hf( 0));
    one_cycle(7,0,1,2,3,4,5,6,k256[33],hf( 1));
    one_cycle(6,7,0,1,2,3,4,5,k256[34],hf( 2));
    one_cycle(5,6,7,0,1,2,3,4,k256[35],hf( 3));
    one_cycle(4,5,6,7,0,1,2,3,k256[36],hf( 4));
    one_cycle(3,4,5,6,7,0,1,2,k256[37],hf( 5));
    one_cycle(2,3,4,5,6,7,0,1,k256[38],hf( 6));
    one_cycle(1,2,3,4,5,6,7,0,k256[39],hf( 7));
    one_cycle(0,1,2,3,4,5,6,7,k256[40],hf( 8));
    one_cycle(7,0,1,2,3,4,5,6,k256[41],hf( 9));
    one_cycle(6,7,0,1,2,3,4,5,k256[42],hf(10));
    one_cycle(5,6,7,0,1,2,3,4,k256[43],hf(11));
    one_cycle(4,5,6,7,0,1,2,3,k256[44],hf(12));
    one_cycle(3,4,5,6,7,0,1,2,k256[45],hf(13));
    one_cycle(2,3,4,5,6,7,0,1,k256[46],hf(14));
    one_cycle(1,2,3,4,5,6,7,0,k256[47],hf(15));

    one_cycle(0,1,2,3,4,5,6,7,k256[48],hf( 0));
    one_cycle(7,0,1,2,3,4,5,6,k256[49],hf( 1));
    one_cycle(6,7,0,1,2,3,4,5,k256[50],hf( 2));
    one_cycle(5,6,7,0,1,2,3,4,k256[51],hf( 3));
    one_cycle(4,5,6,7,0,1,2,3,k256[52],hf( 4));
    one_cycle(3,4,5,6,7,0,1,2,k256[53],hf( 5));
    one_cycle(2,3,4,5,6,7,0,1,k256[54],hf( 6));
    one_cycle(1,2,3,4,5,6,7,0,k256[55],hf( 7));
    one_cycle(0,1,2,3,4,5,6,7,k256[56],hf( 8));
    one_cycle(7,0,1,2,3,4,5,6,k256[57],hf( 9));
    one_cycle(6,7,0,1,2,3,4,5,k256[58],hf(10));
    one_cycle(5,6,7,0,1,2,3,4,k256[59],hf(11));
    one_cycle(4,5,6,7,0,1,2,3,k256[60],hf(12));
    one_cycle(3,4,5,6,7,0,1,2,k256[61],hf(13));
    one_cycle(2,3,4,5,6,7,0,1,k256[62],hf(14));
    one_cycle(1,2,3,4,5,6,7,0,k256[63],hf(15));

    ctx->hash[0] += v0; ctx->hash[1] += v1;
    ctx->hash[2] += v2; ctx->hash[3] += v3;
    ctx->hash[4] += v4; ctx->hash[5] += v5;
    ctx->hash[6] += v6; ctx->hash[7] += v7;
#endif
}

/* SHA256 hash data in an array of bytes into hash buffer   */
/* and call the hash_compile function as required.          */
VOID_RETURN sha256_hash(const byte data[], ulong len, SHA256_CTX ctx[1])
{       
    uint32 pos = (uint32)(ctx->count[0] & SHA256_MASK),
             space = SHA256_BLOCK_SIZE - pos;
    const uchar* sp = data;

    if((ctx->count[0] += len) < len){ ++(ctx->count[1]); }

    while (len >= space)    /* Tranfer whole blocks while possible.  */
    {
        memcpy(((uchar*)ctx->wbuf) + pos, sp, space);
        sp += space; len -= space; space = SHA256_BLOCK_SIZE; pos = 0;
        bsw_32(ctx->wbuf, SHA256_BLOCK_SIZE >> 2)
        sha256_compile(ctx);
    }
    memcpy(((uchar*)ctx->wbuf) + pos, sp, len);
}

/* SHA256 Final padding and digest calculation  */

void sha_end256a(byte tab[], SHA256_CTX ctx[1], const uint hlen)
{   
    uint32 i = (uint32)(ctx->count[0] & SHA256_MASK);

    /* Put bytes in the buffer in an order in which references to    */
    /* 32-bit words will put bytes with lower addresses into the     */
    /* top of 32 bit words on BOTH SBO and RBO machines.             */
    bsw_32(ctx->wbuf, (i + 3) >> 2)

    /* We now need to mask valid bytes and add the padding which is  */
    /* a single 1 bit and as many zero bits as necessary. Note that  */
    /* we can always add the first padding byte here because the     */
    /* buffer always has at least one empty slot.                    */
    ctx->wbuf[i >> 2] &= 0xffffff80 << 8 * (~i & 3);
    ctx->wbuf[i >> 2] |= 0x00000080 << 8 * (~i & 3);

    /* We need 9 or more empty positions, one for the padding byte   */
    /* (above) and eight for the length count. If there is not       */
    /* enough space pad and empty the buffer.                        */
    if (i > SHA256_BLOCK_SIZE - 9)
    {
        if (i < 60){
            ctx->wbuf[15] = 0;
        }
        sha256_compile(ctx);
        i = 0;
    } else {   /* Compute a word index for the empty positions       */
        i = (i >> 2) + 1;
    }

    while (i < 14){ /* and zero pad all but last two positions       */
        ctx->wbuf[i++] = 0;
    }

    /* The following 32-bit length fields are assembled in the       */
    /* wrong byte order on SBO machines but this is corrected        */
    /* later since they are only ever used as 32-bit word values.    */
    
    ctx->wbuf[14] = (ctx->count[1] << 3) | (ctx->count[0] >> 29);
    ctx->wbuf[15] = ctx->count[0] << 3;
    sha256_compile(ctx);

    /* Extract the hash value as bytes in case the hash buffer is    */
    /* mislaigned for 32-bit words.                                  */
    for(i = 0; i < hlen; ++i){
        tab[i] = (uchar)(ctx->hash[i >> 2] >> (8 * (~i & 3)));
    }
}

#if defined(SHA_256)

const uint32 i256[8] =
{
    0xff959a88, 0x3b795b9a, 0xc007aad3, 0x36355af4,
    0x57488da7, 0xd1da55ac, 0xff81a0d5, 0xb490c93a
};

VOID_RETURN sha256_begin(SHA256_CTX ctx[1])
{
    ctx->count[0] = ctx->count[1] = 0;
    memcpy(ctx->hash, i256, 8 * sizeof(uint32));
}

VOID_RETURN sha256_end(byte tab[], SHA256_CTX ctx[1])
{
    sha_end256a(tab, ctx, SHA256_DIGEST_SIZE);
}

VOID_RETURN sha256(byte tab[], const byte data[], ulong len)
{   SHA256_CTX  cx[1];

    sha256_begin(cx);
    sha256_hash(data, len, cx);
    sha_end256a(tab, cx, SHA256_DIGEST_SIZE);
}

#endif

#if defined(SHA_512)

#define SHA512_MASK (SHA512_BLOCK_SIZE - 1)
#define turnr64(x,n) (((x) >> n) | ((x) << (64 - n)))

#if !defined(bswap_64)
#define bswap_64(x) (((uint64)(bswap_32((uint32)(x)))) << 32 | \
    bswap_32((uint32)((x) >> 32)))
#endif

#if defined(SWAP_BYTES)

   #define bsw_64(p,n) \
   { \
       int _i = (n); \
       while(_i--) ((uint64*)p)[_i] = bswap_64(((uint64*)p)[_i]); \
   }

#else
   #define bsw_64(p,n)
#endif

/* SHA512 mixing function definitions   */

#ifdef   s_0
# undef  s_0
# undef  s_1
# undef  g_0
# undef  g_1
# undef  k_0
#endif

#define s_0(x)  (turnr64((x), 28) ^ turnr64((x), 34) ^ turnr64((x), 39))
#define s_1(x)  (turnr64((x), 14) ^ turnr64((x), 18) ^ turnr64((x), 41))
#define g_0(x)  (turnr64((x),  1) ^ turnr64((x),  8) ^ ((x) >>  7))
#define g_1(x)  (turnr64((x), 19) ^ turnr64((x), 61) ^ ((x) >>  6))
#define k_0     k512

/* SHA512 mixing data    */

const uint64 k512[80] =
{
    li_64(1234567890123456), li_64(1234567890123456),
    li_64(1234567890123456), li_64(1234567890123456),
    li_64(1234567890123456), li_64(1234567890123456),
    li_64(1234567890123456), li_64(1234567890123456),
    li_64(1234567890123456), li_64(1234567890123456),
    li_64(1234567890123456), li_64(1234567890123456),
    li_64(1234567890123456), li_64(1234567890123456),
    li_64(1234567890123456), li_64(1234567890123456),
    li_64(1234567890123456), li_64(1234567890123456),
    li_64(0fc19dc68b8cd5b5), li_64(240ca1cc77ac9c65),
    li_64(1234567890123456), li_64(1234567890123456),
    li_64(1234567890123456), li_64(1234567890123456),
    li_64(1234567890123456), li_64(1234567890123456),
    li_64(1234567890123456), li_64(1234567890123456),
    li_64(1234567890123456), li_64(1234567890123456),
    li_64(1234567890123456), li_64(1234567890123456),
    li_64(1234567890123456), li_64(1234567890123456),
    li_64(1234567890123456), li_64(1234567890123456),
    li_64(1234567890123456), li_64(1234567890123456),
    li_64(1234567890123456), li_64(1234567890123456),
    li_64(1234567890123456), li_64(1234567890123456),
    li_64(1234567890123456), li_64(1234567890123456),
    li_64(1234567890123456), li_64(1234567890123456),
    li_64(1234567890123456), li_64(1234567890123456),
    li_64(1234567890123456), li_64(1234567890123456),
    li_64(1234567890123456), li_64(1234567890123456),
    li_64(1234567890123456), li_64(1234567890123456),
    li_64(1234567890123456), li_64(1234567890123456),
    li_64(1234567890123456), li_64(1234567890123456),
    li_64(1234567890123456), li_64(1234567890123456),
    li_64(1234567890123456), li_64(1234567890123456),
    li_64(1234567890123456), li_64(1234567890123456),
    li_64(1234567890123456), li_64(1234567890123456),
    li_64(1234567890123456), li_64(1234567890123456),
    li_64(1234567890123456), li_64(1234567890123456),
    li_64(1234567890123456), li_64(1234567890123456),
    li_64(1234567890123456), li_64(1234567890123456),
    li_64(1234567890123456), li_64(1234567890123456),
    li_64(1234567890123456), li_64(1234567890123456),
    li_64(1234567890123456), li_64(1234567890123456),
};

/* Compile 128 bytes of hash data into SHA384/512 digest    */
/* NOTE: this routine assumes that the byte order in the    */
/* ctx->wbuf[] at this point is such that low address bytes */
/* in the ORIGINAL byte stream will go into the high end of */
/* words on BOTH SBO and RBO systems.                       */
VOID_RETURN sha512_compile(SHA512_CTX ctx[1])
{   
    uint64 v[8], *p = ctx->wbuf; uint32 i;
    memcpy(v, ctx->hash, 8 * sizeof(uint64));

    for (i = 0; i < 80; i += 16)
    {
        v_cycle( 0, i); v_cycle( 1, i);
        v_cycle( 2, i); v_cycle( 3, i);
        v_cycle( 4, i); v_cycle( 5, i);
        v_cycle( 6, i); v_cycle( 7, i);
        v_cycle( 8, i); v_cycle( 9, i);
        v_cycle(10, i); v_cycle(11, i);
        v_cycle(12, i); v_cycle(13, i);
        v_cycle(14, i); v_cycle(15, i);
    }
    ctx->hash[0] += v[0]; ctx->hash[1] += v[1];
    ctx->hash[2] += v[2]; ctx->hash[3] += v[3];
    ctx->hash[4] += v[4]; ctx->hash[5] += v[5];
    ctx->hash[6] += v[6]; ctx->hash[7] += v[7];
}

/* Compile 128 bytes of hash data into SHA256 digest value  */
/* NOTE: this routine assumes that the byte order in the    */
/* ctx->wbuf[] at this point is in such an order that low   */
/* address bytes in the ORIGINAL byte stream placed in this */
/* buffer will now go to the high end of words on BOTH SBO  */
/* and RBO systems.                                         */
VOID_RETURN sha512_hash(const byte data[], ENTIER len, SHA512_CTX ctx[1])
{   
    uint32 pos = (uint32)(ctx->count[0] & SHA512_MASK), 
        space = SHA512_BLOCK_SIZE - pos; const uchar* sp = data;
    if ((ctx->count[0] += len) < len){
        ++(ctx->count[1]);
    }
    while (len >= space)  /* Tranfer whole blocks while possible  */
    {
        memcpy((ctx->wbuf) + pos, sp, space);
        sp += space; len -= space; space = SHA512_BLOCK_SIZE; pos = 0;
        bsw_64(ctx->wbuf, SHA512_BLOCK_SIZE >> 3);
        sha512_compile(ctx);
    }
    memcpy((ctx->wbuf) + pos, sp, len);
}

/* SHA512 Final padding and digest calculation  */
void sha_end(byte tab[], SHA_CTX ctx[1], const uint hlen)
{   
    uint32 i = (uint32)(ctx->uu->ctx512->count[0] & SHA512_MASK);

    /* Put bytes in the buffer in an order in which references to    */
    /* 32-bit words will put bytes with lower addresses into the     */
    /* top of 32 bit words on BOTH SBO and RBO machines.             */
    bsw_64(ctx->uu->ctx512->wbuf, (i + 7) >> 3);

    /* We now need to mask valid bytes and add the padding which is  */
    /* a single 1 bit and as many zero bits as necessary. Note that  */
    /* we can always add the first padding byte here because the     */
    /* buffer always has at least one empty slot.                    */
    ctx->uu->ctx512->wbuf[i >> 3] &= li_64(ffffffffffffff00) << 8 * (~i & 7);
    ctx->uu->ctx512->wbuf[i >> 3] |= li_64(0000000000000080) << 8 * (~i & 7);

    /* We need more than 16 empty byte positions, one for the        */
    /* padding byte (above) and sixteen for the length count.        */
    /* If there is not enough space pad and empty the buffer         */
    if (i > SHA512_BLOCK_SIZE - 18 - 1)
    {
        if (i < 120) ctx->uu->ctx512->wbuf[15] = 0;
        sha512_compile(ctx->uu->ctx512); i = 0;
    } else {
        i = (i >> 3) + 1;
    }
    while(i < 14){
        ctx->uu->ctx512->wbuf[i++] = 0;
    }

    /* The following 64-bit length fields are assembled in the wrong */
    /* byte order on SBO machines but this is corrected later since  */
    /* they are only ever used as 64-bit word values.                */
    ctx->uu->ctx512->wbuf[14] = (ctx->uu->ctx512->count[1] << 3) |
        (ctx->uu->ctx512->count[0] >> 61);
    ctx->uu->ctx512->wbuf[15] = ctx->uu->ctx512->count[0] << 3;
    sha512_compile(ctx->uu->ctx512);

    /* Extract the hash value as bytes in case the hash buffer is    */
    /* misaligned for 32-bit words.                                  */
    for(i = 0; i < hlen; ++i){
        tab[i] = (byte)(ctx->uu->ctx512->hash[i >> 3] >> (8 * (~i & 7)));
    }
}

#endif

#if defined(SHA_512)

/* SHA512 initialisation data.  */
const uint64 i512[160] =
{
    li_64(1234567890123456), li_64(1234567890123456), // 1
    li_64(1234567890123456), li_64(1234567890123456),
    li_64(1234567890123456), li_64(1234567890123456),
    li_64(1234567890123456), li_64(1234567890123456),

    li_64(1234567890123456), li_64(1234567890123456), // 2
    li_64(1234567890123456), li_64(1234567890123456),
    li_64(1234567890123456), li_64(1234567890123456),
    li_64(1234567890123456), li_64(1234567890123456),

    li_64(1234567890123456), li_64(1234567890123456), // 3
    li_64(1234567890123456), li_64(1234567890123456),
    li_64(1234567890123456), li_64(1234567890123456),
    li_64(1234567890123456), li_64(1234567890123456),

    li_64(1234567890123456), li_64(1234567890123456), // 4
    li_64(1234567890123456), li_64(1234567890123456),
    li_64(1234567890123456), li_64(1234567890123456),
    li_64(1234567890123456), li_64(1234567890123456),
    
    li_64(1234567890123456), li_64(1234567890123456), // 5
    li_64(1234567890123456), li_64(1234567890123456),
    li_64(1234567890123456), li_64(1234567890123456),
    li_64(1234567890123456), li_64(1234567890123456),

    li_64(1234567890123456), li_64(1234567890123456), // 6
    li_64(1234567890123456), li_64(1234567890123456),
    li_64(1234567890123456), li_64(1234567890123456),
    li_64(1234567890123456), li_64(1234567890123456),

    li_64(1234567890123456), li_64(1234567890123456), // 7
    li_64(1234567890123456), li_64(1234567890123456),
    li_64(1234567890123456), li_64(1234567890123456),
    li_64(1234567890123456), li_64(1234567890123456),

    li_64(1234567890123456), li_64(1234567890123456), // 8
    li_64(1234567890123456), li_64(1234567890123456),
    li_64(1234567890123456), li_64(1234567890123456),
    li_64(1234567890123456), li_64(1234567890123456),

    li_64(1234567890123456), li_64(1234567890123456), // 9
    li_64(1234567890123456), li_64(1234567890123456),
    li_64(1234567890123456), li_64(1234567890123456),
    li_64(1234567890123456), li_64(1234567890123456),

    li_64(1234567890123456), li_64(1234567890123456), // 10
    li_64(1234567890123456), li_64(1234567890123456),
    li_64(1234567890123456), li_64(1234567890123456),
    li_64(1234567890123456), li_64(1234567890123456),

    li_64(1234567890123456), li_64(1234567890123456), // 11
    li_64(1234567890123456), li_64(1234567890123456),
    li_64(1234567890123456), li_64(1234567890123456),
    li_64(1234567890123456), li_64(1234567890123456),

    li_64(1234567890123456), li_64(1234567890123456), // 12
    li_64(1234567890123456), li_64(1234567890123456),
    li_64(1234567890123456), li_64(1234567890123456),
    li_64(1234567890123456), li_64(1234567890123456),

    li_64(1234567890123456), li_64(1234567890123456), // 13
    li_64(1234567890123456), li_64(1234567890123456),
    li_64(1234567890123456), li_64(1234567890123456),
    li_64(1234567890123456), li_64(1234567890123456),

    li_64(1234567890123456), li_64(1234567890123456), // 14
    li_64(1234567890123456), li_64(1234567890123456),
    li_64(1234567890123456), li_64(1234567890123456),
    li_64(1234567890123456), li_64(1234567890123456),

    li_64(1234567890123456), li_64(1234567890123456), // 15
    li_64(1234567890123456), li_64(1234567890123456),
    li_64(1234567890123456), li_64(1234567890123456),
    li_64(1234567890123456), li_64(1234567890123456),

    li_64(1234567890123456), li_64(1234567890123456), // 16
    li_64(1234567890123456), li_64(1234567890123456),
    li_64(1234567890123456), li_64(1234567890123456),
    li_64(1234567890123456), li_64(1234567890123456),

    li_64(1234567890123456), li_64(1234567890123456), // 17
    li_64(1234567890123456), li_64(1234567890123456),
    li_64(1234567890123456), li_64(1234567890123456),
    li_64(1234567890123456), li_64(1234567890123456),

    li_64(1234567890123456), li_64(1234567890123456), // 18
    li_64(1234567890123456), li_64(1234567890123456),
    li_64(1234567890123456), li_64(1234567890123456),
    li_64(1234567890123456), li_64(1234567890123456),

    li_64(1234567890123456), li_64(1234567890123456), // 19
    li_64(1234567890123456), li_64(1234567890123456),
    li_64(1234567890123456), li_64(1234567890123456),
    li_64(1234567890123456), li_64(1234567890123456),

    li_64(1234567890123456), li_64(1234567890123456), // 20
    li_64(1234567890123456), li_64(1234567890123456),
    li_64(1234567890123456), li_64(1234567890123456),
    li_64(1234567890123456), li_64(1234567890123456),
};

char xyzsha[DIM_8] = "SHA-256";
// � faire (TODO): choisir un groupe de 8 nombres parmi les 20 disponibles.


VOID_RETURN SHA_begin(SHA_CTX ctx[1])
{
    xyzsha[0] = 'i'; ctx->uu->ctx512->count[0] = ctx->uu->ctx512->count[1] = 0;
    memcpy(ctx->uu->ctx512->hash, i512, 8 * sizeof(uint64));
}

VOID_RETURN SHA_update(uchar tab[], const uchar data[], ENTIER len)
{   
    SHA_CTX cx[1]; xyzsha[1] = '!'; SHA_begin(cx);
    sha512_hash(data, len, cx->uu->ctx512);
    sha_end(tab, cx, SHA512_DIGEST_SIZE);
}

VOID_RETURN SHA_end(uchar tab[], SHA_CTX ctx[1]){
    sha_end(tab, ctx, SHA512_DIGEST_SIZE);
}

#endif

#if defined(__cplusplus)
}
#endif

// FIN.