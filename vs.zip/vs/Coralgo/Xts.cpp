/*
 Copyright(c) 2003-2015 'Fondation TrueCrypt'. See SCLE License; the 
 full text of which is contained in the file Licence 1.0.txt included 
 in NetDisq distribution packages. 2023-2026. NB: le parall�lisme offert 
 n'est pas impl�ment� mais est disponible dans le code TC. */

#ifdef TC_WINDOWS_DRIVER
   #include "DriverDll.h"
#endif
#include "CadentKey.h"
#include "Memoire.h"
#include "ByteOrder.h"
#include "Secret.h"
#include "Xts.h"

#define GF_LOWEST_BYTES            135 // 2^7 + 2^2 + 2^1 + 2^0.

// Nombre de blocs "texte vs chiffre" par unit� de donn�es XTS.
#define BLOCKS_PER_XTS_DATA_UNIT   (DIM_UNIT_DONN�ES / \
                                    BYTES_PER_XTS_BLOCK)

#define XTS_MESSAGE_MULTIPLE_16     "la longueur doit �tre multiple de " \
                                    "BYTES_PER_XTS_BLOCK (16)."

/**
 * Convert the 64-bit integer into a reverse byte-order 16-byte array. 
 * The last 8 bytes is filled with 0.
 */
void getTab16From64(byte* t, uint64 donn�e)
{
    *((uint64*) t) = LE64(donn�e); *((uint64*) t + 1) = EOL;
}

/**
  * length: number of bytes to encrypt; may be larger than one data unit and
  * must be divisible by the ea block size.
  * cl�0: the initialisation key
  * cled: the key schedule
  * idUnit: The sequential number of the data unit with which the tab starts.
  * startCipherBlockNo: The sequential number of the first plaintext block to
    encrypt inside the data
  * When encrypting the data unit from its first block, startCipherBlockNo is 0.
  * The startCipherBlockNo value applies only to the first data unit in the tab;
    each successive
  * data unit is encrypted from its first block. The start of the tab does not
    have to be aligned with the start of a data unit. If it is aligned,
    startCipherBlockNo must be 0; if it is not aligned, startCipherBlockNo must
    reflect the misalignment accordingly.
*/
NTSTATUS EncryptBufferXTS(uint8 ea, byte tab[], ENTIER length,
    const UINT64_STRUCT* noUnit, uint startCipherBlockNo)
{
    NTSTATUS r�sultat = STATUS_SUCCESS; byte whitening[BYTES_PER_XYZTS] = {0};
    uint8 finalCarry, byteBufUnitNo[BYTES_PER_XYZTS]; 
    uint64* whiteningValueA64 = (uint64*)whitening, * tabB = (uint64*)tab;
    uint startBlock = startCipherBlockNo, endBlock, j;
    ENTIER blockCount, dataUnitNo;
    /* The encrypted data unit number (i.e. the resultant ciphertext i) is
        to be multiplied in the finite field GF(2^128) by i-th power of n, where
        i is the sequential plaintext/ciphertext i number and n is 2, a
        primitive element of GF(2^128). This can be (and is) simplified and
        implemented as a left shift of the preceding whitening value by one bit
        (with carry propagating). In addition, if the shift of the highest byte
        results in a carry, 135 is XORed into the lowest byte. The value 135 is
        derived from the modulus of the Galois Field (x^128+[x^7+x^2+x+1]). */
        // Convert the 64-bit data unit number into a standard 16-byte array. 
        // Note that as we are converting a 64-bit number into a 16-byte array, 
        // we can always zero the last 8 bytes.
    dataUnitNo = noUnit->Value; getTab16From64(byteBufUnitNo, dataUnitNo);
    ND_ASSERT_CS(length % BLOCKS_PER_XTS_DATA_UNIT == 0,
        ERR_CHIFFREMENT_INVALIDE); blockCount = length / BYTES_PER_XYZTS;
    // Process all blocks in the tab.
    while (blockCount > 0)
    {
        if (blockCount < BLOCKS_PER_XTS_DATA_UNIT){
            endBlock = startBlock + (uint)blockCount;
        } else {
            endBlock = BLOCKS_PER_XTS_DATA_UNIT;
        }
        whiteningValueA64 = (uint64*)whitening;
        // Encrypt the data unit number using the initialisation key (in 
        // order to generate the first whitening value for this data unit).
        *whiteningValueA64 = *((uint64*)byteBufUnitNo);
        *(whiteningValueA64 + 1) = EOL;
        encryptBlock0(ea, whitening);
        // Generate (and apply) subsequent whitening values for blocks in 
        // this data unit and encrypt all relevant blocks in this data unit.
        for (j = 0; j < endBlock; j++)
        {
            if (j >= startBlock)
            {
                // Pre-whitening
                *tabB++ ^= *whiteningValueA64++;
                *tabB-- ^= *whiteningValueA64--;
                // Actual encryption.
                encryptBlock16(ea, j, (byte*)tabB);
                // Post-whitening
                *tabB++ ^= *whiteningValueA64++;
                *tabB++ ^= *whiteningValueA64;
            } else {
                whiteningValueA64++;
            }
            // Derive the next whitening value
#if EST_STD_BYTE_ORDER
            {
                finalCarry = (*whiteningValueA64 & 0x8000000000000000) ? GF_LOWEST_BYTES : 0;

                *whiteningValueA64-- <<= 1;
                if (*whiteningValueA64 & 0x8000000000000000) {
                    *(whiteningValueA64 + 1) |= 1;
                }
                *whiteningValueA64 <<= 1;
            }
#else             
            {
                finalCarry = (*whiteningValueA64 & 0x80) ? GF_LOWEST_BYTES : 0;
                *whiteningValueA64 = LE64(LE64(*whiteningValueA64) << 1);
                whiteningValueA64--;
                if (*whiteningValueA64 & 0x80)
                    *(whiteningValueA64 + 1) |= 0x0100000000000000;
                *whiteningValueA64 = LE64(LE64(*whiteningValueA64) << 1);
            }
#endif
            whitening[0] ^= finalCarry;
        } // for
        blockCount -= endBlock - startBlock; startBlock = 0; dataUnitNo++;
        getTab16From64(byteBufUnitNo, dataUnitNo);
    }
    ND_FIN(); ERR:journaliser("Erreur EncryptBufferXts"); r�sultat = gNDR�sultat;
FIN:init0(whitening, sizeof(whitening)); return r�sultat;
}

// For descriptions of the input parameters, see EncryptBufferXTS().
NTSTATUS DecryptBufferXTS(uint8 ea, byte tab[], ENTIER length,
    const UINT64_STRUCT* noUnit, uint startCipherBlockNo)
{
    NTSTATUS r�sultat = STATUS_SUCCESS; byte whitening[BYTES_PER_XYZTS] = {0};
    uint8 finalCarry, byteBufUnitNo[BYTES_PER_XYZTS]; 
    uint64* whiteningValueA64 = (uint64*)whitening, * tabB = (uint64*)tab;
    uint startBlock = startCipherBlockNo, endBlock, j;
    ENTIER blockCount, dataUnitNo;
    dataUnitNo = noUnit->Value; getTab16From64(byteBufUnitNo, dataUnitNo);
    ND_ASSERT_CS(length% BLOCKS_PER_XTS_DATA_UNIT == 0,
        ERR_CHIFFREMENT_INVALIDE); blockCount = length / BYTES_PER_XYZTS;
    // Process all blocks in the tab.
    while (blockCount > 0)
    {
        if (blockCount < BLOCKS_PER_XTS_DATA_UNIT){
            endBlock = startBlock + (uint)blockCount;
        } else {
            endBlock = BLOCKS_PER_XTS_DATA_UNIT;
        }
        whiteningValueA64 = (uint64*)whitening;
        // Encrypt the data unit number using the initialisation key (in 
        // order to generate the first whitening value for this data unit).
        *whiteningValueA64 = *((uint64*)byteBufUnitNo);
        *(whiteningValueA64 + 1) = EOL;
        encryptBlock0(ea, whitening);
        // Generate (and apply) subsequent whitening values for blocks in 
        // this data unit and encrypt all relevant blocks in this data unit.
        for (j = 0; j < endBlock; j++)
        {
            if (j >= startBlock)
            {
                // Pre-whitening
                *tabB++ ^= *whiteningValueA64++;
                *tabB-- ^= *whiteningValueA64--;
                // Actual encryption.
                decryptBlock16(ea, j, (byte*)tabB);
                // Post-whitening
                *tabB++ ^= *whiteningValueA64++;
                *tabB++ ^= *whiteningValueA64;
            } else {
                whiteningValueA64++;
            }
            // Derive the next whitening value
    #if EST_STD_BYTE_ORDER
            {
                finalCarry = (*whiteningValueA64 & 0x8000000000000000) ? GF_LOWEST_BYTES : 0;

                *whiteningValueA64-- <<= 1;
                if (*whiteningValueA64 & 0x8000000000000000){
                    *(whiteningValueA64 + 1) |= 1;
                }
                *whiteningValueA64 <<= 1;
            }
    #else             
            {
                finalCarry = (*whiteningValueA64 & 0x80) ? GF_LOWEST_BYTES : 0;
                *whiteningValueA64 = LE64(LE64(*whiteningValueA64) << 1);
                whiteningValueA64--;
                if (*whiteningValueA64 & 0x80)
                    *(whiteningValueA64 + 1) |= 0x0100000000000000;
                *whiteningValueA64 = LE64(LE64(*whiteningValueA64) << 1);
            }
    #endif
        whitening[0] ^= finalCarry;
    } // for
    blockCount -= endBlock - startBlock; startBlock = 0; dataUnitNo++;
    getTab16From64(byteBufUnitNo, dataUnitNo);
}
ND_FIN(); ERR:journaliser("Erreur DecryptBufferXts"); r�sultat = gNDR�sultat;
FIN:init0(whitening, sizeof(whitening)); return r�sultat;
}