#ifndef ND_HEADER_CORE_ALGO
#define ND_HEADER_CORE_ALGO

#define NOM_CORE_ALGO  "Coralgo"

#endif // ND_HEADER_CORE_ALGO