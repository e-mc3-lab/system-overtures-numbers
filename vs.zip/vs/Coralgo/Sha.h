/*
 ---------------------------------------------------------------------------
 Copyright (c) 2002, Dr Brian Gladman, Worcester, UK.   All rights reserved.

 LICENSE TERMS

 The free distribution and use of this software is allowed (with or without
 changes) provided that:

  1. source code distributions include the above copyright notice, this
     list of conditions and the following disclaimer;

  2. binary distributions include the above copyright notice, this list
     of conditions and the following disclaimer in their documentation;

  3. the name of the copyright holder is not used to endorse products
     built using this software without specific written permission.

 DISCLAIMER

 This software is provided 'as is' with no explicit or implied warranties
 in respect of its properties, including, but not limited to, correctness
 and/or fitness for purpose.
 ---------------------------------------------------------------------------
 */

#ifndef CRYPTO_SHA_H
#define CRYPTO_SHA_H

#include "CompatibX.h"
#include "ByteOrder.h"

#define MOT_SHA             "Sha"

#define SHA_64BIT

/* Define the hash functions that you need  */
/* for dynamic hash length  */
#define SHA_256
#define SHA_512
#define NEED_UINT_64T

#define SHA1_BLOCKSIZE      64    
#define SHA1_DIGESTSIZE     20

#define SHA512_BLOCKSIZE    128
#define SHA512_DIGESTSIZE   64


#ifndef EXIT_SUCCESS
   #define EXIT_SUCCESS     0
   #define EXIT_FAILURE     1
#endif

#define li_64(h) 0x##h##ull

#define VOID_RETURN   void
#define INT_RETURN    int

#if defined(__cplusplus)
extern "C"
{
#endif

/* Note that the following function prototypes are the same */
/* for both the bit and byte oriented implementations. But  */
/* the length fields are in bytes or bits as is appropriate */
/* for the version used. Bit sequences are arrays of bytes  */
/* in which bit sequence indexes increase from the most to  */
/* the least significant end of each byte.                  */

#define SHA256_DIGEST_SIZE  32
#define SHA256_BLOCK_SIZE   64

/* Type to hold the SHA256 context */
typedef struct
{   uint32 count[2]; uint32 hash[8]; uint32 wbuf[16];
} SHA256_CTX;


#ifndef SHA_64BIT

typedef struct
{   
    union
    { 
        SHA256_CTX ctx256[1];
    } uu[1];
    uint32 sha_len;
} SHA_CTX;

#define SHA2_MAX_DIGEST_SIZE   SHA256_DIGEST_SIZE

#else

#define SHA512_DIGEST_SIZE  64
#define SHA512_BLOCK_SIZE   128

typedef struct
{   
    uint64 count[2]; 
    uint64 hash[8];   
    uint64 wbuf[16];
} SHA512_CTX;


typedef struct
{   
    union
    { 
      SHA256_CTX ctx256[1]; 
      SHA512_CTX ctx512[1];
    } uu[1];
    uint32 sha_len;

} SHA_CTX;

VOID_RETURN sha512_hash(const byte data[], ENTIER len, SHA512_CTX ctx[1]);
VOID_RETURN SHA_begin(SHA_CTX ctx[1]);
VOID_RETURN SHA_update(byte tab[], const byte data[], ENTIER len);
VOID_RETURN SHA_end(byte tab[], SHA_CTX ctx[1]);

#endif

#if defined(__cplusplus)
}
#endif

#endif // CRYPTO_SHA_H
