/*
 Copyright(c) 2003-2013 'Fondation TrueCrypt'. See also the SCLE
 License; which is contained in Licence 1.0.txt included in
 NetDisq packages. 2024-2026. */

#ifndef CRYPTO_H
#define CRYPTO_H

#include "CadentKey.h"
#include "TextHexa.h"
#include "Secret.h"

#ifdef __cplusplus
extern "C"
{
#endif

#define PKCS_SALT_SIZE DIM_64

typedef struct
{
    uint8 cifr; BOOL nouvFx; uint8 mode; // XTS | YTS | ZTS
    byte cl�0[DK0]; // Cl� d'initialisation.
    byte salt[PKCS_SALT_SIZE]; BOOL inverse; int r�sultat;

} INFO_CRYPTO;

#define CRYPTO_INFO INFO_CRYPTO // Synonyme, abr�viation: CI
#define DIM_CI sizeof(CRYPTO_INFO)
#define DIM_NOMS_CIPHERS (NB_ALGORITHMES_R�UNIS+1) * DIM_NOM_CIPHER

typedef struct { uint8 ea; BOOL exclusCCL�; } ENCRYPT_ALGORITHM;

// Suite d'algorithmes de chiffrement.
typedef struct { ENCRYPT_ALGORITHM tabEAs[NB_ALGORITHMES_R�UNIS]; } CIPHER;

#define DIM_CIFR  sizeof(CIPHER)

NTSTATUS initialisec(INFO_CRYPTO* ci); NTSTATUS finEas();
NTSTATUS finalisec(INFO_CRYPTO* ci, BOOL yComprisLeTableau);

char* getNomCipher(uint8 c); uint8 getCipher(const uint8 c);
uint8 getEAD�but(uint8 c); uint8 getEAFin(uint8 c);
uint8 getEAPr�c�dent(uint8 c); uint8 getEASuivant(uint8 c);

NTSTATUS copierCI(INFO_CRYPTO* ciDst, INFO_CRYPTO* ciSrc);
void comparerCIs(INFO_CRYPTO* ciA, INFO_CRYPTO* ciB);

BOOL estExclusCr�ationCl�(uint8 c, uint8 ea);

#if defined(__cplusplus)
}
#endif

#endif // CRYPTO_H
