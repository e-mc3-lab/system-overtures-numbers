/*
 * This code implements the MD5 message-digest algorithm.
 * The algorithm is due to Ron Rivest, and was written by
 * Colin Plumb in 1993, no copyright is claimed.
 * This is in the public domain.
 *
 * Equivalent code is available from RSA Data Security Inc.
 * This code has been tested against that, and is equivalent,
 * except that you don't need to include two pages of legalese
 * with every copy.
 *
 * Modifi� par 2024-2025.
 */

#ifndef ND_HEADER_CRYPTO_RIPEMD
#define ND_HEADER_CRYPTO_RIPEMD

#include "CompatibX.h"

#if defined(__cplusplus)
extern "C"
{
#endif

#define MOT_RIPEMD          "Ripemd"

#define MD5_CBLOCK          64
#define MD5_DIGEST_LENGTH   16

#define RIPEMD_BLOCKSIZE    MD5_CBLOCK
#define RIPEMD_DIGESTSIZE   MD5_DIGEST_LENGTH

typedef struct MD5Context {
    uint32 state[4];         // State.
    uint64 count;            // Number of bits, mod 2^64.
    byte buffer[MD5_CBLOCK]; // Input buffer.
} MD_CTX;


void RIPEMDInit(MD_CTX* ctx);
void RIPEMDUpdate(MD_CTX* ctx, const byte input[], ENTIER len);
void RIPEMDFinal(byte digest[], MD_CTX *ctx);


#if defined(__cplusplus)
}
#endif

#endif // ND_HEADER_CRYPTO_RIPEMD
