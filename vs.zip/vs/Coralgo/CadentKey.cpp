/*
 Legal Notice: Some portions of the source code contained in this file were
 derived from the source code of Encryption. Modifications and additions to
 the original source code (contained in this file), and all other portions
 of this file are Copyright(c) 2003-2013 'TrueCrypt Foundation'. These are
 also governed by the SCLE License; the full text of which is contained
 in the file Licence 1.0.txt included in NetDisq packages. 2024-2026. */

#include "Memoire.h"
#include "CadentKey.h"

static byte* gKey0 = NULL; static uint16 gPosCc[NB_EAS][NB_CL�S_MAX] = {0};

byte* getKey0(){ return gKey0; }

void setKey0(byte cl�[]){ gKey0 = cl�; }

uint16 getIndexKey(uint64 i){ return (i >= NB_CL�S_MAX ? 0 : uint16(i)); }

byte* getKeyInit(uint8 ea, uint64 i)
{ 
    uint16 j = getIndexKey(i), d = gPosCc[ea - 1][j]; return (gKey0 + d);
}

BOOL setInfosKeySchedule(uint8 ea, uint16 dks)
{
    uint8 ia = ea - 1; uint16 i, j = 0, c = 0; const uint16 N = NB_CL�S_MAX;
    for (i = 0; i < N; i++)
    {
        c = uint16(gKey0[i]); j += c;
        if ((c == 0) || (j > DK0 - dks)){ j = i + 3; } gPosCc[ia][i] = j;
    }
    return NT_SUCCESS(gNDR�sultat);
}

byte* getKeySchedule(uint8 ea, const uint64 i)
{ 
    uint16 d, j = uint16(i); if (j >= NB_CL�S_MAX){ j = 0; }
    d = gPosCc[ea - 1][j]; return gKey0 + d;
}

void init0Keys(){ init0(gPosCc, sizeof(gPosCc)); }