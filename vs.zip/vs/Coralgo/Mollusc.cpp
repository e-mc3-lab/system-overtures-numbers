/*
 *
 * National Security Research Institute
 *
 * FELICS - Fair Evaluation of Lightweight Cryptographic Systems
 *
 * Copyright (C) 2015 National Security Research Institute
 *
 * Written in 2015 by Ilwoong Jeong <iw98jeong@nsr.re.kr> and
 * Dongsoo Lee <letrhee@nsr.re.kr>
 *
 * The initial file (LEA-128) is part of FELICS
 *
 * Laboratory of Algorithmics, Cryptology and Security (LACS)
 *
 * Copyright (C) 2015 University of Luxembourg
 *
 * Written in 2015 by Daniel Dinu <dumitru-daniel.dinu@uni.lu>
 *
 * FELICS is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version (LEA). SCLE: 2024-2025.
 */

#include "Memoire.h"
#include "CadentKey.h"
#include "Mollusc.h"


#define NUMBER_OF_ROUNDS_MLSC 24 // LEA-128
#define MOLLUSC_KS            NUMBER_OF_ROUNDS_MLSC * DIM_16
#define RK(x, y)              READ_ROUND_KEY_DOUBLE_WORD(x[y])

 /*
 * DELTA values are used after bit turnations. According to the characteristics
 * ... of each architecture, using pre-turnated DELTA values reduces execution
 * ... time for key schedule.
 * 
 * For the original DELTA values {d1, d2, d3, d4} in the specifications,
 * ... the pre-turnated delta values for AVR ASM implementation are
 * ... {d1, turnl(d2, 1), turnl(d3, 2), turnl(d4, 3)}. 
 */
RAM_DATA_DOUBLE_WORD DELTA[4]= { 0xc3efe9db, 0x88c4d604, 0xe789f229, 0xc6f98763 };

void initialiser_MLSC(const byte key[], const byte roundKeys[])
{
    uint32* rk = (uint32*) roundKeys; // TODO: agrandir.
    uint32* t = (uint32*) key;
    uint32 delta[4] = { 
        READ_RAM_DATA_DOUBLE_WORD(DELTA[0]), 
        READ_RAM_DATA_DOUBLE_WORD(DELTA[1]), 
        READ_RAM_DATA_DOUBLE_WORD(DELTA[2]), 
        READ_RAM_DATA_DOUBLE_WORD(DELTA[3]) };
    uint32 ri = 0; int32 i;    
    uint32 t0 = t[0], t1 = t[1], t2 = t[2], t3 = t[3];

    for (i = 0; i < NUMBER_OF_ROUNDS_MLSC; ++i, ++ri)
    {
        uint32 tmp = delta[i & 3];
        
        t0 = turn32l1(t0 + tmp);
        t1 = turn32l3(t1 + turn32l1(tmp));
        t2 = turn32l6(t2 + turn32l2(tmp));
        t3 = turn32l11(t3 + turn32l3(tmp));
        delta[i & 3] = turn32l4(tmp);
        
        rk[ri] = t1; // rk1, rk3, rk5
        rk[++ri] = t3; // rk4
        rk[++ri] = t2; // rk2
        rk[++ri] = t0; // rk0
    }
}

void chiffrer_MLSC(byte block[], const byte roundKeys[])
{
    uint32* blk = (uint32*) block;
    uint32* rk = (uint32*) roundKeys; uint8 i;
    uint32 b0 = blk[0], b1 = blk[1], b2 = blk[2], b3 = blk[3];
    
    for (i = 0; i < NUMBER_OF_ROUNDS_MLSC; i += 4, rk += 4) 
    {
        b3 = turn32r3((b2 ^ RK(rk, 1)) + (b3 ^ RK(rk, 0)));
        b2 = turn32r5((b1 ^ RK(rk, 2)) + (b2 ^ RK(rk, 0)));
        b1 = turn32l9((b0 ^ RK(rk, 3)) + (b1 ^ RK(rk, 0)));
        
        rk +=4;
        b0 = turn32r3((b3 ^ RK(rk, 1)) + (b0 ^ RK(rk, 0)));
        b3 = turn32r5((b2 ^ RK(rk, 2)) + (b3 ^ RK(rk, 0)));
        b2 = turn32l9((b1 ^ RK(rk, 3)) + (b2 ^ RK(rk, 0)));
        
        rk +=4;
        b1 = turn32r3((b0 ^ RK(rk, 1)) + (b1 ^ RK(rk, 0)));
        b0 = turn32r5((b3 ^ RK(rk, 2)) + (b0 ^ RK(rk, 0)));
        b3 = turn32l9((b2 ^ RK(rk, 3)) + (b3 ^ RK(rk, 0)));
        
        rk +=4;
        b2 = turn32r3((b1 ^ RK(rk, 1)) + (b2 ^ RK(rk, 0)));
        b1 = turn32r5((b0 ^ RK(rk, 2)) + (b1 ^ RK(rk, 0)));
        b0 = turn32l9((b3 ^ RK(rk, 3)) + (b0 ^ RK(rk, 0)));
    }
    
    blk[0] = b0; blk[1] = b1; blk[2] = b2; blk[3] = b3;
}

void d�chiffrer_MLSC(byte block[], const byte roundKeys[])
{
    uint32* blk = (uint32*) block;
    uint32* rk = (uint32*) roundKeys; int8 i;    
    uint32 b0 = blk[0], b1 = blk[1], b2 = blk[2], b3 = blk[3];
    
    for (i = NUMBER_OF_ROUNDS_MLSC - 1, rk += 92; i >= 0; i -= 4, rk -= 4) 
    {
        b0 = (turn32r9(b0) - (b3 ^ RK(rk, 3))) ^ RK(rk, 0);
        b1 = (turn32l5(b1) - (b0 ^ RK(rk, 2))) ^ RK(rk, 0);
        b2 = (turn32l3(b2) - (b1 ^ RK(rk, 1))) ^ RK(rk, 0);
        
        rk -= 4;
        b3 = (turn32r9(b3) - (b2 ^ RK(rk, 3))) ^ RK(rk, 0);
        b0 = (turn32l5(b0) - (b3 ^ RK(rk, 2))) ^ RK(rk, 0);
        b1 = (turn32l3(b1) - (b0 ^ RK(rk, 1))) ^ RK(rk, 0);
        
        rk -= 4;
        b2 = (turn32r9(b2) - (b1 ^ RK(rk, 3))) ^ RK(rk, 0);
        b3 = (turn32l5(b3) - (b2 ^ RK(rk, 2))) ^ RK(rk, 0);
        b0 = (turn32l3(b0) - (b3 ^ RK(rk, 1))) ^ RK(rk, 0);
        
        rk -= 4;
        b1 = (turn32r9(b1) - (b0 ^ RK(rk, 3))) ^ RK(rk, 0);
        b2 = (turn32l5(b2) - (b1 ^ RK(rk, 2))) ^ RK(rk, 0);
        b3 = (turn32l3(b3) - (b2 ^ RK(rk, 1))) ^ RK(rk, 0);
    }    
    blk[0] = b0; blk[1] = b1; blk[2] = b2; blk[3] = b3;
}

/// <summary>
/// Initialiser une fois suffit (i = 0).
/// </summary>
NTSTATUS initMLSC()
{
    int r = EXIT_SUCCESS; uint8 ea = MOLLUSC; byte* c0 = getKeyInit(ea, 0);
    byte* cc = getKeySchedule(ea, 0); if ( ! cc){ return ERR_OBJET_�_NULL; }
    initialiser_MLSC(c0, cc); return r;
}

NTSTATUS finMLSC(){ return EXIT_SUCCESS; }

uint16 getDimKsMLSC(){ return MOLLUSC_KS; }

NTSTATUS encryptBlock0MLSC(byte donn�es[])
{
    chiffrer_MLSC(donn�es, getKeySchedule(MOLLUSC, 0)); 
    return EXIT_SUCCESS;
}

NTSTATUS encryptBlockMLSC(uint64 i, byte donn�es[])
{
    byte* cc = getKeySchedule(MOLLUSC, i); chiffrer_MLSC(donn�es, cc);
    return EXIT_SUCCESS;
}

NTSTATUS decryptBlockMLSC(uint64 i, byte donn�es[])
{
    byte* cc = getKeySchedule(MOLLUSC, i); d�chiffrer_MLSC(donn�es, cc);
    return EXIT_SUCCESS;
}