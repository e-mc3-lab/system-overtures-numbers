/*
 Legal Notice: Some portions of the source code contained in this file were
 derived from the source code of Encryption. Modifications and additions to
 the original source code (contained in this file), and all other portions
 of this file are Copyright(c) 2003-2013 'Fondation TrueCrypt'. These are
 also governed by the SCLE License; the full text of which is contained
 in the file Licence 1.0.txt included in NetDisq distribution packages.
 2024-2025. PKCS: Public Key Cryptography Standards. */

#ifdef TC_WINDOWS_DRIVER
   #include "DriverDll.h"
   #include "SortieDrv.h"
#endif

#include "Journal.h"
#include "Memoire.h"
#include "Sha.h"
#include "Whirlpool.h"
#include "Ripemd.h"
#include "Prf.h"


#ifdef TC_WINDOWS_DRIVER 
    // TODO: feed via CxRef and use it.
    static const uint64 gTabChiffresPkcs[2*PKCS_SALT_SIZE] =
    {
    1234567890, 1234567890, 1234567890, 1234567890, // 1
    1234567890, 1234567890, 1234567890, 1234567890, // 2
    1234567890, 1234567890, 1234567890, 1234567890, // 3
    1234567890, 1234567890, 1234567890, 1234567890, // 4
    1234567890, 1234567890, 1234567890, 1234567890, // 5
    1234567890, 1234567890, 1234567890, 1234567890, // 6
    1234567890, 1234567890, 1234567890, 1234567890, // 7
    1234567890, 1234567890, 1234567890, 1234567890, // 8
    1234567890, 1234567890, 1234567890, 1234567890, // 9
    1234567890, 1234567890, 1234567890, 1234567890, // 10
    1234567890, 1234567890, 1234567890, 1234567890, // 11
    1234567890, 1234567890, 1234567890, 1234567890, // 12
    1234567890, 1234567890, 1234567890, 1234567890, // 13
    1234567890, 1234567890, 1234567890, 1234567890, // 14
    1234567890, 1234567890, 1234567890, 1234567890, // 15
    1234567890, 1234567890, 1234567890, 1234567890, // 16
    1234567890, 1234567890, 1234567890, 1234567890, // 17
    1234567890, 1234567890, 1234567890, 1234567890, // 18
    1234567890, 1234567890, 1234567890, 1234567890, // 19
    1234567890, 1234567890, 1234567890, 1234567890, // 20
    1234567890, 1234567890, 1234567890, 1234567890, // 21
    1234567890, 1234567890, 1234567890, 1234567890, // 22
    1234567890, 1234567890, 1234567890, 1234567890, // 23
    1234567890, 1234567890, 1234567890, 1234567890, // 24
    1234567890, 1234567890, 1234567890, 1234567890, // 25
    1234567890, 1234567890, 1234567890, 1234567890, // 26
    1234567890, 1234567890, 1234567890, 1234567890, // 27
    1234567890, 1234567890, 1234567890, 1234567890, // 28
    1234567890, 1234567890, 1234567890, 1234567890, // 29
    1234567890, 1234567890, 1234567890, 1234567890, // 30
    1234567890, 1234567890, 1234567890, 1234567890, // 31
    1234567890, 1234567890, 1234567890, 1234567890, // 32
    };
  
#endif

void hmac_truncate(const byte da[], byte dR[], int len)
{
    int i; for (i = 0; i < len; i++){ dR[i] = da[i]; }
}

void hmac_sha512( const byte cs[], /* Cl� Secr�te */
    ENTIER lk, const byte d[], /* Data */ int ld,
    byte out[], int t /* At least "t" bytes */)
{
    SHA_CTX octx = {0}, ictx = {0}; ENTIER i;
    byte shaInterne[SHA512_DIGESTSIZE] = {0}, 
        shaExterne[SHA512_DIGESTSIZE] = {0};
    byte cl�[SHA512_DIGESTSIZE] = {0};
    byte tab[SHA512_BLOCKSIZE] = {0};

    /* If the key is longer than the hash algorithm block size,
       let key = SHA_update(key), as per HMAC specifications. 
     */
    if (lk > SHA512_BLOCKSIZE)
    {
        SHA_CTX tctx = {0}; SHA_begin(&tctx);
        sha512_hash((uchar*) cs, lk, tctx.uu->ctx512);
        SHA_end((uchar*) cl�, &tctx);
        cs = cl�; lk = SHA512_DIGESTSIZE;
        init0(&tctx, sizeof(tctx)); // Prevent leaks.
    }
    /**** Inner Digest ****/
    SHA_begin(&ictx);
    
    /* Pad the key for inner digest. */
    for (i = 0; i < lk; ++i){ tab[i] = (char) (cs[i] ^ 0x36); }
    for (i = lk; i < SHA512_BLOCKSIZE; ++i){ tab[i] = 0x36; }

    sha512_hash(tab, SHA512_BLOCKSIZE, ictx.uu->ctx512);
    sha512_hash(d, ld, ictx.uu->ctx512);
    SHA_end(shaInterne, &ictx);    
    
    /**** Outer Digest ****/
    SHA_begin(&octx);
    for (i = 0; i < lk; ++i){ tab[i] = (char) (cs[i] ^ 0x5C); }
    for (i = lk; i < SHA512_BLOCKSIZE; ++i){ tab[i] = 0x5C; }
    sha512_hash(tab, SHA512_BLOCKSIZE, octx.uu->ctx512);
    sha512_hash(shaInterne, SHA512_DIGESTSIZE, octx.uu->ctx512);
    SHA_end(shaExterne, &octx);
    
    /* Truncate and print the results. */
    t = t > SHA512_DIGESTSIZE ? SHA512_DIGESTSIZE : t;
    hmac_truncate(shaExterne, out, t);
    
    /* Prevent leaks. */
    init0(&ictx, sizeof(ictx)); init0(&octx, sizeof(octx));
    init0(shaInterne, sizeof(shaInterne));
    init0(shaExterne, sizeof(shaExterne));
    init0(tab, sizeof(tab)); init0(cl�, sizeof(cl�));
}


void derive_u_sha512(const byte txt[], ENTIER txt_len, 
    const byte salt[], int salt_len, int iterations, byte u[], int b)
{
    byte j[SHA512_DIGESTSIZE] = {0}, cs[SHA512_DIGESTSIZE] = {0};
    byte init[128] = {0}; char counter[4] = {0}; ENTIER c, i;

    /* Iteration 1 */
    init0(counter, 4); counter[3] = (char) b;
    memcpy(init, salt, salt_len); // Salt.
    memcpy(&init[salt_len], counter, 4); // Block number in RBO.
    hmac_sha512(txt, txt_len, init, salt_len + 4, j, SHA512_DIGESTSIZE);
    memcpy(u, j, SHA512_DIGESTSIZE); /* Remaining iterations. */
    for (c = 1; c < iterations; c++)
    {
        hmac_sha512(txt, txt_len, j, SHA512_DIGESTSIZE, cs, SHA512_DIGESTSIZE);
        for (i = 0; i < SHA512_DIGESTSIZE; i++)
        {
            u[i] ^= cs[i]; j[i] = cs[i];
        }
    }
    init0(j, sizeof(j)); init0(cs, sizeof(cs));
}

void d�chiqueter_SHA(const byte txt[], ENTIER txt_len, 
    const byte salt[], int salt_len, int iterations, byte dk[], int dklen)
{
    byte u[SHA512_DIGESTSIZE] = {0}; int b, l, r;

    if (dklen % SHA512_DIGESTSIZE){
        l = 1 + dklen / SHA512_DIGESTSIZE;
    } else {
        l = dklen / SHA512_DIGESTSIZE;
    }
    r = dklen - (l - 1) * SHA512_DIGESTSIZE;

    /* First l - 1 blocks. */
    for (b = 1; b < l; b++)
    {
        derive_u_sha512(txt, txt_len, salt, salt_len, iterations, u, b);
        memcpy(dk, u, SHA512_DIGESTSIZE);
        dk += SHA512_DIGESTSIZE;
    }
    /* Last block. */
    derive_u_sha512(txt, txt_len, salt, salt_len, iterations, u, b);
    memcpy(dk, u, r); /* Prevent leaks. */ init0(u, sizeof(u));
}

void hmac_whirlpool(const byte cs[], /* Cl� Secr�te */
    ENTIER lk, const byte d[], /* Data */
    int ld,    byte out[],    int t /* At least "t" bytes */)
{
    WHIRLPOOL_CTX ictx = {0}, octx = {0}; ENTIER i;
    byte iwhi[WHIRLPOOL_DIGESTSIZE] = {0}, owhi[WHIRLPOOL_DIGESTSIZE] = {0};
    byte cl�[WHIRLPOOL_DIGESTSIZE] = {0}, tab[WHIRLPOOL_BLOCKSIZE] = {0};
    
    /* If the key is longer than the hash algorithm block size,
       let key = whirlpool(key), as per HMAC specifications. */
    if (lk > WHIRLPOOL_BLOCKSIZE)
    {
        WHIRLPOOL_CTX tctx = {0}; WHIRLPOOL_init(&tctx);
        WHIRLPOOL_add((uchar*) cs, lk * 8, &tctx);
        WHIRLPOOL_finalize(&tctx, (uchar*) cl�);
        cs = cl�; lk = WHIRLPOOL_DIGESTSIZE;
        NDInit0(tctx, sizeof(tctx)); // Prevent leaks.
    }

    /**** Inner Digest ****/
    WHIRLPOOL_init(&ictx);

    /* Pad the key for inner digest */
    for (i = 0; i < lk; ++i){ tab[i] = (byte) (cs[i] ^ 0x36); }
    for (i = lk; i < WHIRLPOOL_BLOCKSIZE; ++i){ tab[i] = 0x36; }
    WHIRLPOOL_add(tab, WHIRLPOOL_BLOCKSIZE * 8, &ictx);
    WHIRLPOOL_add(d, ld * 8, &ictx);
    WHIRLPOOL_finalize(&ictx, iwhi);    
    
    /**** Outer Digest ****/
    WHIRLPOOL_init(&octx);
    for (i = 0; i < lk; ++i){ tab[i] = (char) (cs[i] ^ 0x5C); }
    for (i = lk; i < WHIRLPOOL_BLOCKSIZE; ++i){ tab[i] = 0x5C; }
    WHIRLPOOL_add((uchar*) tab, WHIRLPOOL_BLOCKSIZE * 8, &octx);
    WHIRLPOOL_add((uchar*) iwhi, WHIRLPOOL_DIGESTSIZE * 8, &octx);
    WHIRLPOOL_finalize(&octx, (uchar*) owhi);

    /* Truncate and print the results */
    t = t > WHIRLPOOL_DIGESTSIZE ? WHIRLPOOL_DIGESTSIZE : t;
    hmac_truncate(owhi, out, t);

    /* Prevent possible leaks. */
    NDInit0(ictx, sizeof(ictx)); NDInit0(octx, sizeof(octx));
    init0(owhi, sizeof(owhi)); init0(iwhi, sizeof(iwhi));
    init0(tab, sizeof(tab)); init0(cl�, sizeof(cl�));
}

void derive_u_whirlpool(const byte txt[], ENTIER txt_len, 
    const byte salt[], int salt_len, int iterations, byte u[], int b)
{
    byte j[WHIRLPOOL_DIGESTSIZE] = {0}, cs[WHIRLPOOL_DIGESTSIZE] = {0};
    byte init[128] = {0}; byte counter[4] = {0}; int c, i;
    /* Iteration 1 */
    init0(counter, 4); counter[3] = (byte) b;
    memcpy(init, salt, salt_len); // Salt 
    memcpy(&init[salt_len], counter, 4); // Block number in RBO.
    hmac_whirlpool(txt, txt_len, init, salt_len + 4, j, WHIRLPOOL_DIGESTSIZE);
    memcpy(u, j, WHIRLPOOL_DIGESTSIZE);

    /* Remaining iterations */
    for (c = 1; c < iterations; c++)
    {
        hmac_whirlpool(txt, txt_len, j, WHIRLPOOL_DIGESTSIZE, cs, 
            WHIRLPOOL_DIGESTSIZE);
        for (i = 0; i < WHIRLPOOL_DIGESTSIZE; i++)
        {
            u[i] ^= cs[i]; j[i] = cs[i];
        }
    } // Prevent leaks.
    init0(j, sizeof(j)); init0(cs, sizeof(cs)); 
}


void d�chiqueter_WHIRLPOOL(const byte txt[], ENTIER txt_len, 
    const byte salt[], int salt_len, int iterations, byte dk[], int dklen)
{
    byte u[WHIRLPOOL_DIGESTSIZE]; int b, l, r;

    if (dklen % WHIRLPOOL_DIGESTSIZE){
        l = 1 + dklen / WHIRLPOOL_DIGESTSIZE;
    } else {
        l = dklen / WHIRLPOOL_DIGESTSIZE;
    }

    r = dklen - (l - 1) * WHIRLPOOL_DIGESTSIZE;
    /* First l - 1 blocks */
    for (b = 1; b < l; b++)
    {
        derive_u_whirlpool(txt, txt_len, salt, salt_len, iterations, u, b);
        memcpy(dk, u, WHIRLPOOL_DIGESTSIZE);
        dk += WHIRLPOOL_DIGESTSIZE;
    }
    /* Last block */
    derive_u_whirlpool(txt, txt_len, salt, salt_len, iterations, u, b);
    memcpy(dk, u, r); init0(u, sizeof(u)); 
}

void hmac_RIPEMD(const byte txt[], ENTIER keylen, const byte input[], 
                 int len, byte digest[])
{
    MD_CTX context = {0}; int i;
    byte k_ipad[65];  /* Inner padding - cl� XORd with ipad. */
    byte k_opad[65];  /* Outer padding - cl� XORd with opad. */
    byte tk[RIPEMD_DIGESTSIZE] = {0}; 

    /* If the txt is longer than the hash algorithm block size,
       let txt = ripemd(txt), as per HMAC specifications. */
    if (keylen > RIPEMD_BLOCKSIZE) 
    {
        MD_CTX tctx = {0}; RIPEMDInit(&tctx);
        RIPEMDUpdate(&tctx, txt, keylen);
        RIPEMDFinal(tk, &tctx);
        txt = tk; keylen = RIPEMD_DIGESTSIZE;
        init0(&tctx, sizeof(tctx));    // Prevent leaks.
    }

    /*

    RIPEMD(K XOR opad, RIPEMD(K XOR ipad, text))

    where K is an n byte cl�
    ipad is the byte 0x36 repeated RIPEMD_BLOCKSIZE times
    opad is the byte 0x5c repeated RIPEMD_BLOCKSIZE times
    and text is the data being pdcalected */

    /* Start out by storing key in pads. */
    memset(k_ipad, 0x36, sizeof(k_ipad));
    memset(k_opad, 0x5c, sizeof(k_opad));

    /* XOR key with ipad and opad values. */
    for (i=0; i<keylen; i++) 
    {
        k_ipad[i] ^= txt[i]; k_opad[i] ^= txt[i];
    }

    /* Perform inner RIPEMD. */

    RIPEMDInit(&context); // Init context for 1st pass. 
    RIPEMDUpdate(&context, k_ipad, RIPEMD_BLOCKSIZE); // Start with inner pad, 
    RIPEMDUpdate(&context, input, len); // then text of datagram. 
    RIPEMDFinal(digest, &context); // Finish up 1st pass. 
    /* Perform outer RIPEMD. */
    RIPEMDInit(&context); // Init context for 2nd pass. 
    RIPEMDUpdate(&context, k_opad, RIPEMD_BLOCKSIZE); // Start with outer pad. 
    /* Results of 1st hash */
    RIPEMDUpdate(&context, digest, RIPEMD_DIGESTSIZE);
    RIPEMDFinal(digest, &context); // Finish up 2nd pass.

    /* Prevent possible leaks. */
    init0(k_ipad, sizeof(k_ipad)); 
    init0(k_opad, sizeof(k_opad));
    init0(tk, sizeof(tk)); 
    init0(&context, sizeof(context));
}


void derive_u_RIPEMD(const byte txt[], ENTIER txt_len, 
    const byte salt[], int salt_len, int iterations, byte u[], int b)
{
    byte j[RIPEMD_DIGESTSIZE], cs[RIPEMD_DIGESTSIZE];
    byte init[2 * DIM_64 + 3] = {0}, counter[4]; int c, i;    
    /* Iteration 1 */
    init0(counter, 4); counter[3] = (byte) b;
    if (salt_len > sizeof(init)){
        journaliser("Erreur derive_u_RIPEMD.");
    }
    
    memcpy(init, salt, min(salt_len, sizeof(init))); /* Salt */
    memcpy(&init[salt_len], counter, 4); /* RBO block. */
    hmac_RIPEMD(txt, txt_len, init, salt_len + 4, j);
    memcpy(u, j, RIPEMD_DIGESTSIZE);
    /* Remaining iterations */
    for (c = 1; c < iterations; c++)
    {
        hmac_RIPEMD(txt, txt_len, j, RIPEMD_DIGESTSIZE, cs);
        for (i = 0; i < RIPEMD_DIGESTSIZE; i++)
        {
            u[i] ^= cs[i]; j[i] = cs[i];
        }
    } // Prevent leaks.
    init0(j, sizeof(j)); init0(cs, sizeof(cs)); 
}

void d�chiqueter_RIPEMD(const byte txt[], ENTIER txt_len, 
    const byte salt[], int salt_len, int iterations, byte dk[], int dklen)
{
    byte u[RIPEMD_DIGESTSIZE]; int b, l, r;

    if (dklen % RIPEMD_DIGESTSIZE){
        l = 1 + dklen / RIPEMD_DIGESTSIZE;
    } else {
        l = dklen / RIPEMD_DIGESTSIZE;
    }
    r = dklen - (l - 1) * RIPEMD_DIGESTSIZE;
    /* First l - 1 blocks. */
    for (b = 1; b < l; b++)
    {
        derive_u_RIPEMD(txt, txt_len, salt, salt_len, iterations, u, b);
        memcpy(dk, u, RIPEMD_DIGESTSIZE);
        dk += RIPEMD_DIGESTSIZE;
    }
    /* Last block. */
    derive_u_RIPEMD(txt, txt_len, salt, salt_len, iterations, u, b);
    memcpy(dk, u, r); init0(u, sizeof(u)); // Prevent leaks.
}