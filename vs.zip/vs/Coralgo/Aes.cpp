/*
 ---------------------------------------------------------------------------
 Copyright (c) 1998-2007, Brian Gladman, Worcester, UK. All rights reserved.

 LICENSE TERMS

 The free distribution and use of this software is allowed (with or without
 changes) provided that:

  1. source code distributions include the above copyright notice, this
     list of conditions and the following disclaimer;

  2. binary distributions include the above copyright notice, this list
     of conditions and the following disclaimer in their documentation;

  3. the name of the copyright holder is not used to endorse products
     built using this software without specific written permission.

 DISCLAIMER

 This software is provided 'as is' with no explicit or implied warranties
 in respect of its properties, including, but not limited to, correctness
 and/or fitness for purpose.
 ---------------------------------------------------------------------------
*/

#include "CompatibX.h"
#include "Aesoption.h"
#include "Aestab.h"

/* Initialise the key schedule from the user supplied key. The key
   length can be specified in bytes, with legal values of 16, 24
   and 32, or in bits, with legal values of 128, 192 and 256. These
   values correspond with Nk values of 4, 6 and 8 respectively.

   The following macros implement a single cycle in the key
   schedule generation process. The number of cycles needed
   for each cx->n_col and nk value is:

    nk =             4  5  6  7  8
    ------------------------------
    cx->n_col = 4   10  9  8  7  7
    cx->n_col = 5   14 11 10  9  9
    cx->n_col = 6   19 15 12 11 11
    cx->n_col = 7   21 19 16 13 14
    cx->n_col = 8   29 23 19 17 14
*/

#if (FUNCS_IN_C & ENC_KEYING_IN_C)

#if defined(AES_256)

#define kef8(k, i) \
{   \
    k[8*(i)+ 8] = ss[0] ^= ls_box(ss[7],3) ^ t_use(r,c)[i]; \
    k[8*(i)+ 9] = ss[1] ^= ss[0]; \
    k[8*(i)+10] = ss[2] ^= ss[1]; \
    k[8*(i)+11] = ss[3] ^= ss[2]; \
}

#define ke8(k, i) \
{   \
    kef8(k,i); \
    k[8*(i)+12] = ss[4] ^= ls_box(ss[3],0); \
    k[8*(i)+13] = ss[5] ^= ss[4]; \
    k[8*(i)+14] = ss[6] ^= ss[5]; \
    k[8*(i)+15] = ss[7] ^= ss[6]; \
}

AES_RETURN aes_encrypt_key256(const uchar key[], AES_CRYPTO_CTX cx[1])
{   
    AES_RETURN r�sultat = EXIT_SUCCESS; uint32 ss[8];

    cx->key[0] = ss[0] = word_in(key, 0);
    cx->key[1] = ss[1] = word_in(key, 1);
    cx->key[2] = ss[2] = word_in(key, 2);
    cx->key[3] = ss[3] = word_in(key, 3);
    cx->key[4] = ss[4] = word_in(key, 4);
    cx->key[5] = ss[5] = word_in(key, 5);
    cx->key[6] = ss[6] = word_in(key, 6);
    cx->key[7] = ss[7] = word_in(key, 7);

    ke8(cx->key, 0); ke8(cx->key, 1);
    ke8(cx->key, 2); ke8(cx->key, 3);
    ke8(cx->key, 4); ke8(cx->key, 5);
    kef8(cx->key, 6); cx->inf.l = 0; 
    cx->inf.b[0] = AES_INF_B0;

#if defined( AES_ERR_V�RIF )
    return r�sultat;
#endif
}

#endif // AES_256

#endif // FUNCS_IN_C & ENC_KEYING_IN_C

#if (FUNCS_IN_C & DEC_KEYING_IN_C)

/* This is used to store the decryption round keys  */
/* in forward or reverse order                      */
#ifdef AES_REV_DKS
   #define v(n,i)  ((n) - (i) + 2 * ((i) & 3))
#endif

#define ff(x) inv_mcol(x)

#if defined(AES_256)

#define k8ef(k,i) \
{    \
    k[v(56,(8*(i))+ 8)] = ss[0] ^= ls_box(ss[7],3) ^ t_use(r,c)[i]; \
    k[v(56,(8*(i))+ 9)] = ss[1] ^= ss[0]; \
    k[v(56,(8*(i))+10)] = ss[2] ^= ss[1]; \
    k[v(56,(8*(i))+11)] = ss[3] ^= ss[2]; \
}

#define k8e(k,i) \
{   \
    k8ef(k,i); k[v(56,(8*(i))+12)] = ss[4] ^= ls_box(ss[3],0); \
    k[v(56,(8*(i))+13)] = ss[5] ^= ss[4]; \
    k[v(56,(8*(i))+14)] = ss[6] ^= ss[5]; \
    k[v(56,(8*(i))+15)] = ss[7] ^= ss[6]; \
}

#define kdf8(k,i) \
{   \
    ss[0] ^= ls_box(ss[7],3) ^ t_use(r,c)[i]; k[v(56,(8*(i))+ 8)] = ff(ss[0]); \
    ss[1] ^= ss[0]; k[v(56,(8*(i))+ 9)] = ff(ss[1]); \
    ss[2] ^= ss[1]; k[v(56,(8*(i))+10)] = ff(ss[2]); \
    ss[3] ^= ss[2]; k[v(56,(8*(i))+11)] = ff(ss[3]); \
    ss[4] ^= ls_box(ss[3],0); k[v(56,(8*(i))+12)] = ff(ss[4]); \
    ss[5] ^= ss[4]; k[v(56,(8*(i))+13)] = ff(ss[5]); \
    ss[6] ^= ss[5]; k[v(56,(8*(i))+14)] = ff(ss[6]); \
    ss[7] ^= ss[6]; k[v(56,(8*(i))+15)] = ff(ss[7]); \
}

#define kd8(k,i) \
{   \
    ss[8] = ls_box(ss[7],3) ^ t_use(r,c)[i]; \
    ss[0] ^= ss[8]; ss[8] = ff(ss[8]); \
    k[v(56,(8*(i))+ 8)] = ss[8] ^= k[v(56,(8*(i)))]; \
    ss[1] ^= ss[0]; k[v(56,(8*(i))+ 9)] = ss[8] ^= k[v(56,(8*(i))+ 1)]; \
    ss[2] ^= ss[1]; k[v(56,(8*(i))+10)] = ss[8] ^= k[v(56,(8*(i))+ 2)]; \
    ss[3] ^= ss[2]; k[v(56,(8*(i))+11)] = ss[8] ^= k[v(56,(8*(i))+ 3)]; \
    ss[8] = ls_box(ss[3],0); ss[4] ^= ss[8]; ss[8] = ff(ss[8]); \
    k[v(56,(8*(i))+12)] = ss[8] ^= k[v(56,(8*(i))+ 4)]; \
    ss[5] ^= ss[4]; k[v(56,(8*(i))+13)] = ss[8] ^= k[v(56,(8*(i))+ 5)]; \
    ss[6] ^= ss[5]; k[v(56,(8*(i))+14)] = ss[8] ^= k[v(56,(8*(i))+ 6)]; \
    ss[7] ^= ss[6]; k[v(56,(8*(i))+15)] = ss[8] ^= k[v(56,(8*(i))+ 7)]; \
}

#define kdl8(k,i) \
{   \
    ss[0] ^= ls_box(ss[7],3) ^ t_use(r,c)[i]; k[v(56,(8*(i))+ 8)] = ss[0]; \
    ss[1] ^= ss[0]; k[v(56,(8*(i))+ 9)] = ss[1]; \
    ss[2] ^= ss[1]; k[v(56,(8*(i))+10)] = ss[2]; \
    ss[3] ^= ss[2]; k[v(56,(8*(i))+11)] = ss[3]; \
}

AES_RETURN aes_decrypt_key256(const uchar key[], AES_CRYPTO_CTX cx[1])
{   
    uint32 ss[9]; cx->key[v(56,(0))] = ss[0] = word_in(key, 0);
    cx->key[v(56,(1))] = ss[1] = word_in(key, 1);
    cx->key[v(56,(2))] = ss[2] = word_in(key, 2);
    cx->key[v(56,(3))] = ss[3] = word_in(key, 3);
    cx->key[v(56,(4))] = ff(ss[4] = word_in(key, 4));
    cx->key[v(56,(5))] = ff(ss[5] = word_in(key, 5));
    cx->key[v(56,(6))] = ff(ss[6] = word_in(key, 6));
    cx->key[v(56,(7))] = ff(ss[7] = word_in(key, 7));
    kdf8(cx->key, 0); kd8(cx->key, 1);
    kd8(cx->key, 2);  kd8(cx->key, 3);
    kd8(cx->key, 4);  kd8(cx->key, 5);
    kdl8(cx->key, 6); cx->inf.l = 0; cx->inf.b[0] = AES_INF_B0;
    return EXIT_SUCCESS;
}

#endif // AES_256

#endif // FUNCS_IN_C & DEC_KEYING_IN_C