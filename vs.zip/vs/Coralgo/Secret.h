/*
 Copyright(c) 2003-2015 'Fondation TrueCrypt'. See the SCLE License. 2024-2025. 
*/

#ifndef SECRET_H
#define SECRET_H

#include "Theo.h"
#include "Rem.h"
#include "Anthozoa.h"
#include "Mollusc.h"
#include "Apod.h"
#include "Fish.h"


#ifdef __cplusplus
extern "C"
{
#endif

#define DIM_NOM_CIPHER        12
#define NB_ALGORITHMES_R�UNIS 3

typedef NTSTATUS EDOperation(uint8 c, uint8 ea, uint8 mode,
    byte tab[], ENTIER length, const UINT64_STRUCT* noUnit,
    uint startCipherBlockNo); // TODO: utiliser une structure.

NTSTATUS initEA(uint8 ea); int finEA(uint8 ea);
char* getNomEA(uint8 ea); uint16 getDimKs(uint8 ea);
NTSTATUS encryptBlock0(uint8 ea, byte donn�es[]);
NTSTATUS encryptBlock16(const uint8 ea, uint64 i, byte donn�es[]);
NTSTATUS decryptBlock16(const uint8 ea, uint64 i, byte donn�es[]);

#if defined(__cplusplus)
}
#endif

#endif // SECRET_H