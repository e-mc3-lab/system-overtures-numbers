/*
 Legal Notice: Some portions of the source code contained in this file were 
 derived from the source code of Encryption. Modifications and additions to 
 the original source code (contained in this file), and all other portions 
 of this file are Copyright(c) 2003-2013 'Fondation TrueCrypt'. These are
 also governed by the SCLE License; the full text of which is contained 
 in the file Licence 1.0.txt included in NetDisq packages. 2024-2026. */
 
#ifndef TC_HEADER_CRC
#define TC_HEADER_CRC

#include "CompatibX.h"

#if defined(__cplusplus)
extern "C"
{
#endif

  #define MOT_CRC   "Crc"

  uint32 getCrc32(const byte tab[], const int32 dimTab);

  uint16 getNbCrcCtr();

  LONG getNombreDC(const byte t[], uint16 lA,
     const byte c1[][DIM_16], uint8 mb, uint16 x, uint16 lB);

  uint32 getCrcPseudo(const uint32 data[]);

#if defined(__cplusplus)
}
#endif

#endif // TC_HEADER_CRC