/*
 * Copyright 2006-2018 The OpenSSL Project Authors. All Rights Reserved.
 *
 * Licensed under the OpenSSL license (the "License"). You may not use
 * this file except in compliance with the License. You can obtain a 
 * copy in the file LICENSE in the source distribution or at
 * https://www.openssl.org/source/license.html Camellia.
 */

#ifndef HEADER_ANTHOZOA_H
#define HEADER_ANTHOZOA_H

#include "CompatibX.h"

#ifdef  __cplusplus
extern "C" {
#endif

#define MOT_ANTHOZOA            "Anthozoa"
#define ANTHOZR_TABLE_BYTE_LEN  272
#define ANTHOZR_TABLE_WORD_LEN  (ANTHOZR_TABLE_BYTE_LEN / 4)

typedef uint KEY_TABLE_TYPE[ANTHOZR_TABLE_WORD_LEN]; // + 6

typedef struct 
{
    union {
        double ALIGN_ADDRESS(64) d; KEY_TABLE_TYPE rd_key;
    } u; 
    int grand_rounds; byte a[6];

} CAMELLIA_KEY; 

NTSTATUS initAZR(); NTSTATUS finAZR(); uint8 getNbCl�sAZR(); 
uint16 getDimKsAZR(); NTSTATUS encryptBlock0AZR(byte donn�es[]);
NTSTATUS encryptBlockAZR(uint64 i, byte donn�es[]);
NTSTATUS decryptBlockAZR(uint64 i, byte donn�es[]);

#ifdef  __cplusplus
}
#endif

#endif // HEADER_ANTHOZOA_H 