/*
 * SCLE/CSES: 2024-2025.
 */

#ifndef THEO_H
#define THEO_H

#include "CompatibX.h"

#ifdef __cplusplus
extern "C" {
#endif

#define MOT_THEO    "Theo"

NTSTATUS initTHEO(); NTSTATUS finTHEO();

uint16 getDimKsTHEO(); uint16 getMemTHEO();
NTSTATUS encryptBlock0THEO(byte donn�es[]);
NTSTATUS encryptBlockTHEO(uint64 i, byte donn�es[]);
NTSTATUS decryptBlockTHEO(uint64 i, byte donn�es[]);

#if defined(__cplusplus)
}
#endif

#endif // THEO_H