/*
 * Copyright(c) 2024-2026 SCLE-CSES. Governed by the SCLE License 1.0; the
 * full text of which is contained in Licence.txt and NetDisq packages.

 * Ce module devrait �tre une classe m�tier que l'on instancie trois fois,
 * mais il faut consid�rer qu'un 'driver' est g�n�ralement �crit en langage C.
 */

#ifndef ND_HEADER_CK
#define ND_HEADER_CK

#include "TexteCc.h"

#if defined(__cplusplus)
extern "C"
{
#endif

// Doit �tre multiple de la taille unitaire du mode d'op�ration:
#define DIM_UNIT_DONN�ES (2UL * DIM_256)
#define UDM              DIM_UNIT_DONN�ES
#define DK0              (10 * DIM_UNIT_DONN�ES) + 1
#define NB_EAS           6
#define NB_CIPHERS       20
#define NB_CL�S_MAX      30

enum { THEO = ENUM_1, REM, ANTHOZA, MOLLUSC, APOD, FISH };

// FELICS RAM data types : THEO & MOLLUSC.
#define RAM_DATA_DOUBLE_WORD ALIGN_ADDRESS(64) uint32
#define READ_RAM_DATA_BYTE(x) x
#define READ_RAM_DATA_DOUBLE_WORD(x) x
#define READ_ROUND_KEY_BYTE(x) READ_RAM_DATA_BYTE(x)
#define READ_ROUND_KEY_DOUBLE_WORD(x) READ_RAM_DATA_DOUBLE_WORD(x)

void init0Keys(); void setKey0(byte cl�[]);
uint16 getIndexKey(uint64 i); byte* getKeyInit(uint8 ea, const uint64 i);
BOOL setInfosKeySchedule(uint8 ea, uint16 dks);
byte* getKeySchedule(uint8 ea, const uint64 i);

#if defined(__cplusplus)
}
#endif


#endif // ND_HEADER_CK