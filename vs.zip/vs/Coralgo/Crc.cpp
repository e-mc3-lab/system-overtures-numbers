/*
 Legal Notice: Some portions of the source code contained in this file were
 derived from the source code of Encryption. Modifications and additions to
 the original source code (contained in this file), and all other portions
 of this file are Copyright(c) 2003-2013 'Fondation TrueCrypt'. These are
 also governed by the SCLE License; the full text of which is contained
 in the file Licence 1.0.txt included in NetDisq distribution packages.
 2024-2026. Le tableau (al�atoire) ci-apr�s est unique (un par utilisateur).
*/

#include <stdlib.h>
#include "Erreur.h"
#include "TexteCC.h"
#include "ByteOrder.h"
#include "Fichier.h"
#include "Crc.h"

static uint32 gTableC[] =
{                
    0xf37c9724, 0x2b643676, 0x43717987, 0x2f9343ea, 0x0414e0be, 0xaee73296, 0xe4d61a35, 0xf506b2cb,
    0xad328239, 0x9e295a33, 0xc272e8b0, 0x1678572f, 0x25acb95f, 0xa7f41259, 0x945c68fe, 0x2b031c60,
    0xcf74b6ac, 0x2d07c458, 0x95995c09, 0x4e8ff3e2, 0x4c0e28bf, 0x936451d7, 0xaae41836, 0x86478c9b,
    0x669f1d06, 0x8b731a70, 0xf2849a6a, 0x90b94880, 0xa0240487, 0xf37885a7, 0xb090b739, 0xf6f0abb6,
    0xee3d8caf, 0x0d6151cc, 0xa05050be, 0x82b98132, 0x7e7a07e4, 0xb5b84eaa, 0x7c12bacc, 0x76f696fa,
    0x9763bc24, 0x029fc09a, 0x442a076b, 0x180e86b6, 0xe565f5e1, 0xc10ee6af, 0xa1b992ba, 0x6dd7bbce,
    0x12c5bec5, 0xf08611c3, 0x06b02dba, 0x02c62f55, 0x94bf92e6, 0x68eb3266, 0x4a0c7e82, 0x4eb7ae23,
    0x4c82424f, 0xfd6925d7, 0xd304e232, 0xfdc76372, 0x1cf346ad, 0x8cd4986c, 0xdbbe1960, 0x10d89aaf,
    0x09fcfea7, 0xa5fd8ac4, 0x624f1226, 0x43795347, 0x76faa1e2, 0xb1a41ff5, 0x6a0f1841, 0xa3d1586d,
    0xbd1f4110, 0xc0f7c52d, 0x8814398b, 0xd34b545f, 0x7fa6fa27, 0xf365eb97, 0x788ef61a, 0x97a2b66f,
    0xdebdec8e, 0xd3aca094, 0xfd38414a, 0x3dbdfbc1, 0x9dfb8aef, 0x62873d77, 0x4d88b9d6, 0x561b7972,
    0x31760276, 0xf3190513, 0x7bd793b8, 0xebd9ab47, 0x3627c64b, 0xf5c89f1b, 0xe99e49b3, 0xdccd613c,
    0xc3cd8040, 0x8c1fabd3, 0x6efd7584, 0x8d3d51bd, 0x28c1842b, 0x4aedd705, 0x6f5dc935, 0xef9bca96,
    0x2c48c50a, 0x867bd74d, 0x96c9b369, 0x563864c4, 0xccc0c0d9, 0xe2250678, 0x2cecc0da, 0x7f0269d8,
    0xdbc73b91, 0x165341c3, 0xfa0ccf91, 0x82a8ef16, 0x73cc1bc2, 0xd754e57b, 0xa7ad014a, 0x80012f85,
    0x8239e0bc, 0x5a6f9aef, 0xa60e70a2, 0x2bb3c366, 0xc034b797, 0xf9a70f32, 0x2167b88c, 0xa3c9bd9c,
    0xd544d131, 0x151352e3, 0xfd25b7b5, 0x069346f2, 0x14776d8c, 0x28cfde83, 0x83031705, 0x7b3f91e3,
    0x8c97446b, 0xe133a868, 0x93869727, 0x555dbb52, 0x790dc73d, 0x5381a8e2, 0xfb5b6336, 0x29e5f2f9,
    0x7cb51f3c, 0xa74d11ec, 0xaecac191, 0xd53f61d7, 0x8e7e9e2f, 0x631331ac, 0x1aaa1a6b, 0x6f3d0dae,
    0x130a1f85, 0x8023af0b, 0x22a9c701, 0x8e93eec3, 0x95608994, 0xb7618de6, 0x83952cc9, 0x9cda67c1,
    0x68b1bc13, 0xf477d671, 0xede7c159, 0xf99c487d, 0x0f5e0a09, 0x26a52bc9, 0xa6f5f31f, 0x9f63ac14,
    0x07364e9f, 0x140c52f5, 0xedcc063c, 0xd378cc60, 0x89f73e81, 0xb589ac80, 0x923fb306, 0xc93cb73b,
    0x687a7ef7, 0x815a66cc, 0x3a529a44, 0xea912f10, 0xcedf6b28, 0xe2f5abd1, 0xbf7b9499, 0xf97bfa4d,
    0x34fa1a13, 0x82fc667e, 0x81cfdfd7, 0xf1cf5c04, 0x65769dbb, 0x310dc1c3, 0x31f1ef1d, 0xf6271910,
    0x37b4e97f, 0xc5a331dd, 0xfd04ceaf, 0x3f1ffc97, 0xa20da493, 0x1447175f, 0x6d7e6f83, 0x2723606b,
    0xfe79cda7, 0x9d397f7a, 0xdb248999, 0xdf39fd59, 0xd55a2725, 0xaf6debff, 0xbb77f521, 0x2b72b081,
    0x4637cbb9, 0x2536deee, 0x53e00983, 0x563c8e0e, 0xb26f0f3f, 0xc177eeba, 0x3ec84b19, 0xd86a6fca,
    0x4f2bcc47, 0x195f8695, 0x6c9c6697, 0x805de944, 0x55702bc9, 0x3c935f19, 0x99b7088a, 0xe563a4dd,
    0x9c3fa45b, 0x1f495903, 0xe27f0d18, 0x832c0bc2, 0x73502ee9, 0x09f39a39, 0xa5279b8f, 0xebcd9bee,
    0xb967e438, 0xcdaf697c, 0x8fa6ab10, 0xf804252b, 0x7f8c1525, 0xe3719a47, 0x934a6dd4, 0x2fad704e,
    0x71f98586, 0x38c7ea06, 0xdfe6869d, 0xb085bad3, 0xd5f13651, 0x89e79bcf, 0x39e3cd5f, 0x18763496,
    0xae80b6d8, 0x02af0d23, 0x04441563, 0x6ec569ba, 0xa8355579, 0xe70d9519, 0x05cc8adb, 0x67bd13b0
};  

#define NB_CRC_CTR    sizeof(gTableC) / sizeof(uint32)

uint32 getCrc32(const byte tab[], const int32 dimTab)
{
    uint32 CRC = MASQUE_CRC, lA = dimTab; byte* d = (byte*)tab;
    if (lA > 0) while (lA--) __try {
        CRC = (CRC >> 8) ^ gTableC[(CRC ^ *d++) & MASQUE_CTR];
    } __except(EXCEPTION_EXECUTE_HANDLER){ 
        ND_JOURNALISER_EXCEPTION0(__FILENAME__, GetExceptionCode());
    } return CRC ^ MASQUE_CRC;
}

uint16 getNbCrcCtr(){ return NB_CRC_CTR; }

long getNombre32(const byte tab[DIM_16], uint16 l, const uint16 n)
{
    int i; uint64 r = 0, n16 = 1; uint16 j=0; uint8 c;
    byte tabHexa[2*DIM_256+1]={0}; const uint16 L = UI16_STRLEN(tab);
    const uint64 MAXC_32 = 4293000000; __try
    {
        for (i=0; (uint16)i < L; i++, j++){ tabHexa[j] = tab[i]; }        
        for (i=12; i >=0; i--)
        {
            c = (int)(tabHexa[i]); if (c <= '9'){
                c -= '0';
            } else if (c <= 'Z'){
                c = (c - 'A') + 10;
            } else {
                c = (c - 'a') + 10;
            }
            if ((uint64)(n16 * DIM_16) < MAXC_32){
                r += c * n16; n16 *= DIM_16;
            } else { break; } // Arr�t.
        }
    } __except(EXCEPTION_EXECUTE_HANDLER){ 
        ND_JOURNALISER_EXCEPTION0(__FILENAME__, GetExceptionCode());
    }
    r += (uint64)(l+1)*52; while (r > MAXLONG){ r -= ((l+1)*29876321); } 
    return (long)r;
}

long getNombreDC(const byte t[], uint16 lA,
    const byte c1[][DIM_16], uint8 mb, uint16 x, uint16 lB)
{
    uint64 r = MASQUE_CRC, c; uint32 s=0, y = x % DIM_16; byte* tab = (byte*)t;
    uint32 dA[DIM_32] = {0}, dB[DIM_32] = {0}; uint16 i, j, xA=0;
    const uint16 NC = sizeof(gTableC)/sizeof(uint32); int32 n = ((uint8)lA/2)+1;
    for (i=0; i < mb; i++, j++)
    {
        s = getNombre32(c1[i], i, 1) + x; xA = (s % NC);
        for (j=0; j <= i; j++){
            if (dA[j] == xA){ xA++; j=0; } if (xA >= NC){ xA = 0; }
        }
        dA[i] = xA; dB[i] = gTableC[xA]; gTableC[xA] = s;
    }
    c = c1[3][y]*x; c = (c == 0 ? 29 : c); r -= c;
    while (n--){ r = (r / DIM_256) ^ gTableC[(r ^ *tab++) & MASQUE_CTR]; }
    for (i=0; i < DIM_32 && dB[i] != 0; i++){ gTableC[dA[i]] = dB[i]; }
    while (r > MAXLONG){ r -= ((c1[0][y]+c1[1][y]+x)*12389); }
    r = (r == 0 ? c1[3][y] % 85 : r); return (long)r;
}

uint32 getCrcPseudo(const uint32 data[])
{
    byte* d = (byte*) data; uint32 CRC = MASQUE_CRC;
    CRC = (CRC >> 8) ^ gTableC[ (CRC ^ *d++) & MASQUE_CTR ];
    CRC = (CRC >> 8) ^ gTableC[ (CRC ^ *d++) & MASQUE_CTR ];
    CRC = (CRC >> 8) ^ gTableC[ (CRC ^ *d++) & MASQUE_CTR ];
    CRC = (CRC >> 8) ^ gTableC[ (CRC ^ *d)   & MASQUE_CTR ];
    CRC ^= MASQUE_CRC; return CRC;
}

#define UPDC32(on, crc)\
\
  (uint32)((gTableC[(((uint32)(crc)) ^ ((uchar)(on))) & MASQUE_CTR] \
    ^ (((uint32)(crc)) >> 8)))

#if EST_STD_BYTE_ORDER
  #define CRC_SELFTEST  0xcae1a6a3
#else  
  define CRC_SELFTEST
#endif