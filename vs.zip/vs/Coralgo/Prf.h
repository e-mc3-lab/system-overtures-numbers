/*
 Legal Notice: Some portions of the source code contained in this file were
 derived from the source code of Encryption. Modifications and additions to
 the original source code (contained in this file), and all other portions
 of this file are Copyright(c) 2003-2013 'Fondation TrueCrypt'. These are
 also governed by the SCLE License; the full text of which is contained
 in the file Licence 1.0.txt included in NetDisq packages. 2024-2025. */

#ifndef TC_HEADER_PRF
#define TC_HEADER_PRF

#include "CompatibX.h"

#if defined(__cplusplus)
extern "C"
{
#endif

enum 
{
    SHA = ENUM_1, WHIRLPOOL, RIPEMD, FIN_ENUM_HACHAGE
};

void d�chiqueter_SHA(const byte txt[], ENTIER txt_len, 
    const byte salt[], int salt_len, int iterations, byte dk[], int dklen);

void d�chiqueter_WHIRLPOOL(const byte txt[], ENTIER txt_len,
    const byte salt[], int salt_len, int iterations, byte dk[], int dklen);

void d�chiqueter_RIPEMD(const byte txt[], ENTIER txt_len, 
    const byte salt[], int salt_len, int iterations, byte dk[], int dklen);

#if defined(__cplusplus)
}
#endif

#endif // TC_HEADER_PRF