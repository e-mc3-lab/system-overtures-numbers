/*
 * National Security Research Institute
 *
 * FELICS - Fair Evaluation of Lightweight Cryptographic Systems
 *
 * Copyright (C) 2015 National Security Research Institute
 *
 * Written in 2015 by Ilwoong Jeong <iw98jeong@nsr.re.kr> and
 * Dongsoo Lee <letrhee@nsr.re.kr>
 *
 * This file is part of FELICS.
 *
 * Laboratory of Algorithmics, Cryptology and Security (LACS)
 *
 * Copyright (C) 2015 University of Luxembourg
 *
 * Written in 2015 by Daniel Dinu <dumitru-daniel.dinu@uni.lu>
 *
 * FELICS is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version. SCLE: 2024-2025. TODO: passer � 64.
 */

#ifndef MOLLUSC_H
#define MOLLUSC_H

#include "CompatibX.h"

#ifndef PC
#define PC
#endif

// Turn (l)eft from a number x of bits.
static inline uint32 turn32l1(uint32 x){
    return (x << 1) | (x >> 31);
}
 
static inline uint32 turn32l2(uint32 x){
    return (x << 2) | (x >> 30);
}

static inline uint32 turn32l3(uint32 x){
    return (x << 3) | (x >> 29);
}

static inline uint32 turn32l4(uint32 x){
   return (x << 4) | (x >> 28);
}

static inline uint32 turn32l5(uint32 x){
    return (x << 5) | (x >> 27);
}

static inline uint32 turn32l6(uint32 x){
    return (x << 6) | (x >> 26);
}

static inline uint32 turn32l9(uint32 x){
    return (x << 9) | (x >> 23);
}

static inline uint32 turn32l10(uint32 x){
    return (x << 10) | (x >> 23);
}

static inline uint32 turn32l11(uint32 x){
    return (x << 11) | (x >> 21);
}

/* (r)ight turn.
 */
static inline uint32 turn32r3(uint32 x){
    return (x >> 3) | (x << 29);
}

static inline uint32 turn32r5(uint32 x){
    return (x >> 5) | (x << 27);
}

static inline uint32 turn32r9(uint32 x){
    return (x >> 9) | (x << 23);
}

NTSTATUS initMLSC(); NTSTATUS finMLSC(); uint16 getDimKsMLSC();
NTSTATUS encryptBlock0MLSC(byte donn�es[]);
NTSTATUS encryptBlockMLSC(uint64 i, byte donn�es[]);
NTSTATUS decryptBlockMLSC(uint64 i, byte donn�es[]);

#endif // MOLLUSC_H