/*
 Legal Notice: Some portions of the source code contained in this file were
 derived from the source code of Encryption. Modifications to the original
 source code (contained in this file), and all other portions of this file
 are Copyright(c) 2003-2013 'TrueCrypt Foundation'. These are also governed
 by the SCLE License; of which the text is contained in the file
 Licence 1.0.txt included in NetDisq packages. 2024-2025.

 Written and placed in the public domain by Wei Dai.
 */
#include "ByteOrder.h"
#include "CadentKey.h"
#include "Memoire.h"
#include "Apod.h"

#define APOD_KS   35 * DIM_16 // = 560


#if defined(_DEBUG)
#include <stdlib.h>
#define turnlFixed(x,n)   (((x) << (n)) | ((x) >> (32 - (n))))
#define turnrFixed(x,n)   (((x) >> (n)) | ((x) << (32 - (n))))
#else
#define turnlFixed _rotl
#define turnrFixed _rotr
#endif

// Linear Transformation
#define LT(i,a,b,c,d,e)    {\
    a = turnlFixed(a, 13);    \
    c = turnlFixed(c, 3);     \
    d = turnlFixed(d ^ c ^ (a << 3), 7);     \
    b = turnlFixed(b ^ a ^ c, 1);     \
    a = turnlFixed(a ^ b ^ d, 5);         \
    c = turnlFixed(c ^ d ^ (b << 7), 22);}

// Inverse Linear Transformation
#define ILT(i,a,b,c,d,e)    {\
    c = turnrFixed(c, 22);    \
    a = turnrFixed(a, 5);     \
    c ^= d ^ (b << 7);    \
    a ^= b ^ d;         \
    b = turnrFixed(b, 1);     \
    d = turnrFixed(d, 7) ^ c ^ (a << 3);    \
    b ^= a ^ c;         \
    c = turnrFixed(c, 3);     \
    a = turnrFixed(a, 13);}

// Order of output from S-box functions
#define beforeS0(f) f(0,a,b,c,d,e)
#define afterS0(f) f(1,b,e,c,a,d)
#define afterS1(f) f(2,c,b,a,e,d)
#define afterS2(f) f(3,a,e,b,d,c)
#define afterS3(f) f(4,e,b,d,c,a)
#define afterS4(f) f(5,b,a,e,c,d)
#define afterS5(f) f(6,a,c,b,e,d)
#define afterS6(f) f(7,a,c,d,b,e)
#define afterS7(f) f(8,d,e,b,a,c)

// Order of output from inverse S-box functions
#define beforeI7(f) f(8,a,b,c,d,e)
#define afterI7(f) f(7,d,a,b,e,c)
#define afterI6(f) f(6,a,b,c,e,d)
#define afterI5(f) f(5,b,d,e,c,a)
#define afterI4(f) f(4,b,c,e,a,d)
#define afterI3(f) f(3,a,b,e,c,d)
#define afterI2(f) f(2,b,d,e,c,a)
#define afterI1(f) f(1,a,b,c,e,d)
#define afterI0(f) f(0,a,d,b,e,c)

// The instruction sequences for the S-box functions 
// come from Dag Arne Osvik's paper "Speeding up Serpent".

#define S0(i, r0, r1, r2, r3, r4) \
       {        \
    r3 ^= r0;   \
    r4 = r1;    \
    r1 &= r3;   \
    r4 ^= r2;   \
    r1 ^= r0;   \
    r0 |= r3;   \
    r0 ^= r4;   \
    r4 ^= r3;   \
    r3 ^= r2;   \
    r2 |= r1;   \
    r2 ^= r4;   \
    r4 = ~r4;   \
    r4 |= r1;   \
    r1 ^= r3;   \
    r1 ^= r4;   \
    r3 |= r0;   \
    r1 ^= r3;   \
    r4 ^= r3;   \
            }

#define I0(i, r0, r1, r2, r3, r4) \
       {           \
    r2 = ~r2;      \
    r4 = r1;   \
    r1 |= r0;   \
    r4 = ~r4;      \
    r1 ^= r2;   \
    r2 |= r4;   \
    r1 ^= r3;   \
    r0 ^= r4;   \
    r2 ^= r0;   \
    r0 &= r3;   \
    r4 ^= r0;   \
    r0 |= r1;   \
    r0 ^= r2;   \
    r3 ^= r4;   \
    r2 ^= r1;   \
    r3 ^= r0;   \
    r3 ^= r1;   \
    r2 &= r3;   \
    r4 ^= r2;   \
            }

#define S1(i, r0, r1, r2, r3, r4) \
       {           \
    r0 = ~r0;      \
    r2 = ~r2;      \
    r4 = r0;   \
    r0 &= r1;   \
    r2 ^= r0;   \
    r0 |= r3;   \
    r3 ^= r2;   \
    r1 ^= r0;   \
    r0 ^= r4;   \
    r4 |= r1;   \
    r1 ^= r3;   \
    r2 |= r0;   \
    r2 &= r4;   \
    r0 ^= r1;   \
    r1 &= r2;   \
    r1 ^= r0;   \
    r0 &= r2;   \
    r0 ^= r4;   \
            }

#define I1(i, r0, r1, r2, r3, r4) \
       {           \
    r4 = r1;   \
    r1 ^= r3;   \
    r3 &= r1;   \
    r4 ^= r2;   \
    r3 ^= r0;   \
    r0 |= r1;   \
    r2 ^= r3;   \
    r0 ^= r4;   \
    r0 |= r2;   \
    r1 ^= r3;   \
    r0 ^= r1;   \
    r1 |= r3;   \
    r1 ^= r0;   \
    r4 = ~r4;   \
    r4 ^= r1;   \
    r1 |= r0;   \
    r1 ^= r0;   \
    r1 |= r4;   \
    r3 ^= r1;   \
            }

#define S2(i, r0, r1, r2, r3, r4) \
       {           \
    r4 = r0;   \
    r0 &= r2;   \
    r0 ^= r3;   \
    r2 ^= r1;   \
    r2 ^= r0;   \
    r3 |= r4;   \
    r3 ^= r1;   \
    r4 ^= r2;   \
    r1 = r3;   \
    r3 |= r4;   \
    r3 ^= r0;   \
    r0 &= r1;   \
    r4 ^= r0;   \
    r1 ^= r3;   \
    r1 ^= r4;   \
    r4 = ~r4;   \
            }

#define I2(i, r0, r1, r2, r3, r4) \
       {           \
    r2 ^= r3;   \
    r3 ^= r0;   \
    r4 = r3;   \
    r3 &= r2;   \
    r3 ^= r1;   \
    r1 |= r2;   \
    r1 ^= r4;   \
    r4 &= r3;   \
    r2 ^= r3;   \
    r4 &= r0;   \
    r4 ^= r2;   \
    r2 &= r1;   \
    r2 |= r0;   \
    r3 = ~r3;      \
    r2 ^= r3;   \
    r0 ^= r3;   \
    r0 &= r1;   \
    r3 ^= r4;   \
    r3 ^= r0;   \
            }

#define S3(i, r0, r1, r2, r3, r4) \
       {           \
    r4 = r0;   \
    r0 |= r3;   \
    r3 ^= r1;   \
    r1 &= r4;   \
    r4 ^= r2;   \
    r2 ^= r3;   \
    r3 &= r0;   \
    r4 |= r1;   \
    r3 ^= r4;   \
    r0 ^= r1;   \
    r4 &= r0;   \
    r1 ^= r3;   \
    r4 ^= r2;   \
    r1 |= r0;   \
    r1 ^= r2;   \
    r0 ^= r3;   \
    r2 = r1;   \
    r1 |= r3;   \
    r1 ^= r0;   \
            }

#define I3(i, r0, r1, r2, r3, r4) \
       {           \
    r4 = r2;   \
    r2 ^= r1;   \
    r1 &= r2;   \
    r1 ^= r0;   \
    r0 &= r4;   \
    r4 ^= r3;   \
    r3 |= r1;   \
    r3 ^= r2;   \
    r0 ^= r4;   \
    r2 ^= r0;   \
    r0 |= r3;   \
    r0 ^= r1;   \
    r4 ^= r2;   \
    r2 &= r3;   \
    r1 |= r3;   \
    r1 ^= r2;   \
    r4 ^= r0;   \
    r2 ^= r4;   \
            }

#define S4(i, r0, r1, r2, r3, r4) \
       {           \
    r1 ^= r3;   \
    r3 = ~r3;      \
    r2 ^= r3;   \
    r3 ^= r0;   \
    r4 = r1;   \
    r1 &= r3;   \
    r1 ^= r2;   \
    r4 ^= r3;   \
    r0 ^= r4;   \
    r2 &= r4;   \
    r2 ^= r0;   \
    r0 &= r1;   \
    r3 ^= r0;   \
    r4 |= r1;   \
    r4 ^= r0;   \
    r0 |= r3;   \
    r0 ^= r2;   \
    r2 &= r3;   \
    r0 = ~r0;      \
    r4 ^= r2;   \
            }

#define I4(i, r0, r1, r2, r3, r4) \
       {           \
    r4 = r2;   \
    r2 &= r3;   \
    r2 ^= r1;   \
    r1 |= r3;   \
    r1 &= r0;   \
    r4 ^= r2;   \
    r4 ^= r1;   \
    r1 &= r2;   \
    r0 = ~r0;   \
    r3 ^= r4;   \
    r1 ^= r3;   \
    r3 &= r0;   \
    r3 ^= r2;   \
    r0 ^= r1;   \
    r2 &= r0;   \
    r3 ^= r0;   \
    r2 ^= r4;   \
    r2 |= r3;   \
    r3 ^= r0;   \
    r2 ^= r1;   \
            }

#define S5(i, r0, r1, r2, r3, r4) \
       {           \
    r0 ^= r1;   \
    r1 ^= r3;   \
    r3 = ~r3;   \
    r4 = r1;   \
    r1 &= r0;   \
    r2 ^= r3;   \
    r1 ^= r2;   \
    r2 |= r4;   \
    r4 ^= r3;   \
    r3 &= r1;   \
    r3 ^= r0;   \
    r4 ^= r1;   \
    r4 ^= r2;   \
    r2 ^= r0;   \
    r0 &= r3;   \
    r2 = ~r2;   \
    r0 ^= r4;   \
    r4 |= r3;   \
    r2 ^= r4;   \
            }

#define I5(i, r0, r1, r2, r3, r4) \
       {           \
    r1 = ~r1;      \
    r4 = r3;   \
    r2 ^= r1;   \
    r3 |= r0;   \
    r3 ^= r2;   \
    r2 |= r1;   \
    r2 &= r0;   \
    r4 ^= r3;   \
    r2 ^= r4;   \
    r4 |= r0;   \
    r4 ^= r1;   \
    r1 &= r2;   \
    r1 ^= r3;   \
    r4 ^= r2;   \
    r3 &= r4;   \
    r4 ^= r1;   \
    r3 ^= r0;   \
    r3 ^= r4;   \
    r4 = ~r4;      \
            }

#define S6(i, r0, r1, r2, r3, r4) \
       {           \
    r2 = ~r2;      \
    r4 = r3;   \
    r3 &= r0;   \
    r0 ^= r4;   \
    r3 ^= r2;   \
    r2 |= r4;   \
    r1 ^= r3;   \
    r2 ^= r0;   \
    r0 |= r1;   \
    r2 ^= r1;   \
    r4 ^= r0;   \
    r0 |= r3;   \
    r0 ^= r2;   \
    r4 ^= r3;   \
    r4 ^= r0;   \
    r3 = ~r3;   \
    r2 &= r4;   \
    r2 ^= r3;   \
            }

#define I6(i, r0, r1, r2, r3, r4) \
       {           \
    r0 ^= r2;   \
    r4 = r2;   \
    r2 &= r0;   \
    r4 ^= r3;   \
    r2 = ~r2;   \
    r3 ^= r1;   \
    r2 ^= r3;   \
    r4 |= r0;   \
    r0 ^= r2;   \
    r3 ^= r4;   \
    r4 ^= r1;   \
    r1 &= r3;   \
    r1 ^= r0;   \
    r0 ^= r3;   \
    r0 |= r2;   \
    r3 ^= r1;   \
    r4 ^= r0;   \
            }

#define S7(i, r0, r1, r2, r3, r4) \
       {           \
    r4 = r2;   \
    r2 &= r1;   \
    r2 ^= r3;   \
    r3 &= r1;   \
    r4 ^= r2;   \
    r2 ^= r1;   \
    r1 ^= r0;   \
    r0 |= r4;   \
    r0 ^= r2;   \
    r3 ^= r1;   \
    r2 ^= r3;   \
    r3 &= r0;   \
    r3 ^= r4;   \
    r4 ^= r2;   \
    r2 &= r0;   \
    r4 = ~r4;   \
    r2 ^= r4;   \
    r4 &= r0;   \
    r1 ^= r3;   \
    r4 ^= r1;   \
            }

#define I7(i, r0, r1, r2, r3, r4) \
       {           \
    r4 = r2;   \
    r2 ^= r0;   \
    r0 &= r3;   \
    r2 = ~r2;   \
    r4 |= r3;   \
    r3 ^= r1;   \
    r1 |= r0;   \
    r0 ^= r2;   \
    r2 &= r4;   \
    r1 ^= r2;   \
    r2 ^= r0;   \
    r0 |= r2;   \
    r3 &= r4;   \
    r0 ^= r3;   \
    r4 ^= r1;   \
    r3 ^= r4;   \
    r4 |= r0;   \
    r3 ^= r2;   \
    r4 ^= r2;   \
            }

// Key xor
#define KX(r, a, b, c, d, e){\
    a ^= k[4 * r + 0]; \
    b ^= k[4 * r + 1]; \
    c ^= k[4 * r + 2]; \
    d ^= k[4 * r + 3]; }

#ifndef TC_MINIMIZE_CODE_SIZE

void initialiser_SERPENT(const byte userKey[], int keylen, const byte cc[])
{
    uint32 a,b,c,d,e, *k = (uint32*)cc, t; int i;
    for (i = 0; i < keylen / (int)sizeof(int32); i++){
        k[i] = LE32(((uint32*)userKey)[i]);
    }
    if (keylen < 32){
        k[keylen/4] |= (uint32)1 << ((keylen%4)*8);
    }
    k += 8; t = k[-1]; for (i = 0; i < 132; ++i){
        k[i] = t = turnlFixed(k[i-8] ^ k[i-5] ^ k[i-3] ^ t ^ 0x9e3779b9 ^ i, 11);
    }
    k -= 20;

#define LK(r, a, b, c, d, e)    {\
    a = k[(8-r)*4 + 0];        \
    b = k[(8-r)*4 + 1];        \
    c = k[(8-r)*4 + 2];        \
    d = k[(8-r)*4 + 3];}

#define SK(r, a, b, c, d, e)    {\
    k[(8-r)*4 + 4] = a;        \
    k[(8-r)*4 + 5] = b;        \
    k[(8-r)*4 + 6] = c;        \
    k[(8-r)*4 + 7] = d;}    \

    for (i=0; i < 4; i++)
    {
        afterS2(LK); afterS2(S3); afterS3(SK);
        afterS1(LK); afterS1(S2); afterS2(SK);
        afterS0(LK); afterS0(S1); afterS1(SK);
        beforeS0(LK); beforeS0(S0); afterS0(SK);
        k += 32;
        afterS6(LK); afterS6(S7); afterS7(SK);
        afterS5(LK); afterS5(S6); afterS6(SK);
        afterS4(LK); afterS4(S5); afterS5(SK);
        afterS3(LK); afterS3(S4); afterS4(SK);
    }
    afterS2(LK); afterS2(S3); afterS3(SK);
}

#endif // TC_MINIMIZE_CODE_SIZE

#ifndef TC_MINIMIZE_CODE_SIZE

void chiffrer_SERPENT(const byte inBlock[], byte outBlock[], const byte cc[])
{
    uint32 a, b, c, d, e; uint i=1;
    const uint32* k = (uint32*)cc + 8;
    uint32* in = (uint32*) inBlock;
    uint32* out = (uint32*) outBlock;

    a = LE32(in[0]); b = LE32(in[1]); c = LE32(in[2]); d = LE32(in[3]);
    do
    {
        beforeS0(KX); beforeS0(S0); afterS0(LT);
        afterS0(KX); afterS0(S1); afterS1(LT);
        afterS1(KX); afterS1(S2); afterS2(LT);
        afterS2(KX); afterS2(S3); afterS3(LT);
        afterS3(KX); afterS3(S4); afterS4(LT);
        afterS4(KX); afterS4(S5); afterS5(LT);
        afterS5(KX); afterS5(S6); afterS6(LT);
        afterS6(KX); afterS6(S7);

        if (i == 4){ break; }
        ++i;
        c = b;
        b = e;
        e = d;
        d = a;
        a = e;
        k += 32;
        beforeS0(LT);
    }
    while (1);

    afterS7(KX);    
    out[0] = LE32(d);
    out[1] = LE32(e);
    out[2] = LE32(b);
    out[3] = LE32(a);
}

#endif // TC_MINIMIZE_CODE_SIZE

#if ! defined (TC_MINIMIZE_CODE_SIZE)

void d�chiffrer_SERPENT(const byte inBlock[], byte outBlock[], const byte cc[])
{
    uint32 a, b, c, d, e;
    const uint32* k = (uint32*)cc + 104;
    uint i=4;
    uint32* in = (uint32*) inBlock;
    uint32* out = (uint32*) outBlock;

    a = LE32(in[0]);
    b = LE32(in[1]);
    c = LE32(in[2]);
    d = LE32(in[3]);

    beforeI7(KX); goto start;
    do
    {
        c = b;  b = d;  d = e;  k -= 32; beforeI7(ILT);
start:
        beforeI7(I7); afterI7(KX); 
        afterI7(ILT); afterI7(I6); afterI6(KX); 
        afterI6(ILT); afterI6(I5); afterI5(KX); 
        afterI5(ILT); afterI5(I4); afterI4(KX); 
        afterI4(ILT); afterI4(I3); afterI3(KX); 
        afterI3(ILT); afterI3(I2); afterI2(KX); 
        afterI2(ILT); afterI2(I1); afterI1(KX); 
        afterI1(ILT); afterI1(I0); afterI0(KX);
    }
    while (--i != 0);
    
    out[0] = LE32(a); out[1] = LE32(d);
    out[2] = LE32(b); out[3] = LE32(e);
}

#endif // TC_MINIMIZE_CODE_SIZE 



/// <summary>
/// Initialiser une seule fois suffit.
/// </summary>
NTSTATUS initAPOD()
{
    int r = EXIT_SUCCESS; uint8 ea = APOD, i = 0; byte* c0 = getKeyInit(ea, i);
    byte cl�0[APOD_KS] = {0}; memcpy(cl�0, c0, APOD_KS);
    byte* cc = getKeySchedule(ea, i); if ( ! cc){ return ERR_OBJET_�_NULL; }
    initialiser_SERPENT(cl�0, APOD_KS, cc); return r;
}

NTSTATUS finAPOD(){ return EXIT_SUCCESS; }

uint16 getDimKsAPOD(){ return APOD_KS; }

NTSTATUS encryptBlock0APOD(byte donn�es[])
{
    byte* cc = getKeySchedule(APOD, 0);
    chiffrer_SERPENT(donn�es, donn�es, cc); return EXIT_SUCCESS; }

NTSTATUS encryptBlockAPOD(uint64 i, byte donn�es[])
{
    byte* cc = getKeySchedule(APOD, i);
    chiffrer_SERPENT(donn�es, donn�es, cc); return EXIT_SUCCESS; }

NTSTATUS decryptBlockAPOD(uint64 i, byte donn�es[])
{
    byte* cc = getKeySchedule(APOD, i);
    d�chiffrer_SERPENT(donn�es, donn�es, cc); return EXIT_SUCCESS;
}
