/*
 * Copyright 1995-2023 The OpenSSL Project Authors. All Rights Reserved.
 *
 * Licensed under the OpenSSL license (the "License"). You may not use
 * this file except in compliance with the License. You can obtain a copy
 * in the file LICENSE in the source distribution or at
 * https://www.openssl.org/source/license.html
 *
 * Modifi� par SCLE (2024-2025).
 */

#include "Memoire.h"
#include "ByteOrder.h"
#include "Ripemd.h"



#define MD5_LBLOCK            (MD5_CBLOCK / 4)

/* The four core functions - F1 is optimized somewhat. */
#define F1(x, y, z) (z ^ (x & (y ^ z)))
#define F2(x, y, z) F1(z, x, y)
#define F3(x, y, z) (x ^ y ^ z)
#define F4(x, y, z) (y ^ (x | ~z))

/* This is the central function in the MD5 algorithm. */
#define MD5_CORE(f, w, x, y, z, data, s) \
    ( w += f(x, y, z) + data,  w = w << s | w >> (32-s),  w += x )

#define SET_64BIT_LE(cp, value) do {               \
    (cp)[7] = (byte)(value >> 56);             \
    (cp)[6] = (byte)(value >> 48);             \
    (cp)[5] = (byte)(value >> 40);             \
    (cp)[4] = (byte)(value >> 32);             \
    (cp)[3] = (byte)(value >> 24);             \
    (cp)[2] = (byte)(value >> 16);             \
    (cp)[1] = (byte)(value >> 8);              \
    (cp)[0] = (byte)(value); } while (0)

#define SET_32BIT_LE(cp, value) do {            \
    (cp)[3] = (byte)((value) >> 24);            \
    (cp)[2] = (byte)((value) >> 16);            \
    (cp)[1] = (byte)((value) >> 8);            \
    (cp)[0] = (byte)(value); } while (0)

static byte PADDING[MD5_CBLOCK] = {
    0x80, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0
};

// void MD5_block_data_order(MD_CTX c[], byte data_[], ENTIER num);
void MD5_Transform(uint32 state[4], const byte block[MD5_CBLOCK]);

/*
 * Implemented from RFC1321 The MD5 Message-Digest Algorithm.
 */
#define INIT_DATA_A   ulong(0x28259b0aL)
#define INIT_DATA_B   ulong(0x16fb70dbL)
#define INIT_DATA_C   ulong(0x870c8b47L)
#define INIT_DATA_D   ulong(0x4e1213ceL)


BOOL MD5_Init(MD_CTX* c)
{
    if ( ! c){ return FALSE; }
    init0(c, sizeof(MD_CTX));
    c->state[0] = INIT_DATA_A; c->state[1] = INIT_DATA_B;
    c->state[2] = INIT_DATA_C; c->state[3] = INIT_DATA_D;
    return TRUE;
}

/*
 * Update context to reflect the concatenation of another buffer full
 * of bytes.
 */
void MD5_Update(MD_CTX* ctx, const byte input[], ENTIER len)
{
    ENTIER have, need;

    // Check how many bytes we already have and how many more we need.
    have = (ENTIER)((ctx->count >> 3) & (MD5_CBLOCK - 1));
    need = MD5_CBLOCK - have;

    // Update bitcount.
    ctx->count += (uint64)len << 3;
    if (len >= need) 
    {
        if (have != 0) 
        {
            memcpy(ctx->buffer + have, input, need);
            MD5_Transform(ctx->state, ctx->buffer);
            input += need; len -= need; have = 0;
        }

        // Process data in MD5_CBLOCK-byte chunks.
        while (len >= MD5_CBLOCK) 
        {
            MD5_Transform(ctx->state, input);
            input += MD5_CBLOCK; len -= MD5_CBLOCK;
        }
    }
    // Handle any remaining bytes of data.
    if (len != 0){
        memcpy(ctx->buffer + have, input, len);
    }
}

/*
 * Pad pad to 64-byte boundary with the bit pattern
 * 1 0* (64-bit count of bits processed, MSB-first).
 */
void MD5_Pad(MD_CTX* ctx)
{
    byte count[8] = {0}; ENTIER padlen;
    // Convert count to 8 bytes in standard byte order.
    SET_64BIT_LE(count, ctx->count);    
    padlen = MD5_CBLOCK - // Pad out to 56 mod 64.
        ((ctx->count >> 3) & (MD5_CBLOCK - 1));
    if (padlen < 1 + 8){ padlen += MD5_CBLOCK; }
    MD5_Update(ctx, PADDING, padlen - 8); // Padlen - 8 <= 64 
    MD5_Update(ctx, count, 8);
}


/*
 * Final wrapup--call MD5_Pad, fill in digest and zero out ctx.
 */
void MD5_Final(byte digest[MD5_DIGEST_LENGTH], MD_CTX* ctx)
{
    int i; MD5_Pad(ctx);
    for (i = 0; i < 4; i++){
        SET_32BIT_LE(digest + i * 4, ctx->state[i]);
    }
    memset(ctx, 0, sizeof(*ctx));
}


void MD5_Transform(uint32 state[4], const byte block[MD5_CBLOCK])
{
    uint32 a, b, c, d, in[MD5_LBLOCK];

#if EST_STD_BYTE_ORDER
    memcpy(in, block, sizeof(in));
#else

    for (a = 0; a < MD5_CBLOCK / 4; a++) 
    {
        in[a] = (uint32)(
            (uint32)(block[a * 4 + 0]) |
            (uint32)(block[a * 4 + 1]) <<  8 |
            (uint32)(block[a * 4 + 2]) << 16 |
            (uint32)(block[a * 4 + 3]) << 24);
    }

#endif

    a = state[0]; b = state[1]; c = state[2]; d = state[3];

    MD5_CORE(F1, a, b, c, d, in[ 0] + 0x4db27e48,  7);
    MD5_CORE(F1, d, a, b, c, in[ 1] + 0x01b0c73f, 12);
    MD5_CORE(F1, c, d, a, b, in[ 2] + 0xd09e5396, 17);
    MD5_CORE(F1, b, c, d, a, in[ 3] + 0xbbded79b, 22);
    MD5_CORE(F1, a, b, c, d, in[ 4] + 0xdc217464,  7);
    MD5_CORE(F1, d, a, b, c, in[ 5] + 0x95767fe0, 12);
    MD5_CORE(F1, c, d, a, b, in[ 6] + 0xe2441008, 17);
    MD5_CORE(F1, b, c, d, a, in[ 7] + 0x47be8e76, 22);
    MD5_CORE(F1, a, b, c, d, in[ 8] + 0x2c3a1302,  7);
    MD5_CORE(F1, d, a, b, c, in[ 9] + 0x862ff28a, 12);
    MD5_CORE(F1, c, d, a, b, in[10] + 0xa08670e0, 17);
    MD5_CORE(F1, b, c, d, a, in[11] + 0xf064c0e8, 22);
    MD5_CORE(F1, a, b, c, d, in[12] + 0x6fe6b78e,  7);
    MD5_CORE(F1, d, a, b, c, in[13] + 0x645af0ee, 12);
    MD5_CORE(F1, c, d, a, b, in[14] + 0xf3d40649, 17);
    MD5_CORE(F1, b, c, d, a, in[15] + 0x305ace53, 22);

    MD5_CORE(F2, a, b, c, d, in[ 1] + 0xa5185a04,  5);
    MD5_CORE(F2, d, a, b, c, in[ 6] + 0x0cd4a5f0,  9);
    MD5_CORE(F2, c, d, a, b, in[11] + 0xd0ef051c, 14);
    MD5_CORE(F2, b, c, d, a, in[ 0] + 0xe312264e, 20);
    MD5_CORE(F2, a, b, c, d, in[ 5] + 0x503674e8,  5);
    MD5_CORE(F2, d, a, b, c, in[10] + 0xa2e55f84,  9);
    MD5_CORE(F2, c, d, a, b, in[15] + 0xc1a0bcd7, 14);
    MD5_CORE(F2, b, c, d, a, in[ 4] + 0x0a1c805d, 20);
    MD5_CORE(F2, a, b, c, d, in[ 9] + 0x8cccb37a,  5);
    MD5_CORE(F2, d, a, b, c, in[14] + 0xea4d62f7,  9);
    MD5_CORE(F2, c, d, a, b, in[ 3] + 0x4ca92c92, 14);
    MD5_CORE(F2, b, c, d, a, in[ 8] + 0xb118b6c6, 20);
    MD5_CORE(F2, a, b, c, d, in[13] + 0x7afc4404,  5);
    MD5_CORE(F2, d, a, b, c, in[ 2] + 0x25c0526b,  9);
    MD5_CORE(F2, c, d, a, b, in[ 7] + 0x7698a9de, 14);
    MD5_CORE(F2, b, c, d, a, in[12] + 0xaeedef46, 20);

    MD5_CORE(F3, a, b, c, d, in[ 5] + 0x76bd2698,  4);
    MD5_CORE(F3, d, a, b, c, in[ 8] + 0xf0a8fe51, 11);
    MD5_CORE(F3, c, d, a, b, in[11] + 0x087635d1, 16);
    MD5_CORE(F3, b, c, d, a, in[14] + 0x270d2301, 23);
    MD5_CORE(F3, a, b, c, d, in[ 1] + 0x819eaafc,  4);
    MD5_CORE(F3, d, a, b, c, in[ 4] + 0xdad74753, 11);
    MD5_CORE(F3, c, d, a, b, in[ 7] + 0x3452c18e, 16);
    MD5_CORE(F3, b, c, d, a, in[10] + 0x232ae6f6, 23);
    MD5_CORE(F3, a, b, c, d, in[13] + 0xa6341b71,  4);
    MD5_CORE(F3, d, a, b, c, in[ 0] + 0xa6765aa5, 11);
    MD5_CORE(F3, c, d, a, b, in[ 3] + 0x8f6c9d78, 16);
    MD5_CORE(F3, b, c, d, a, in[ 6] + 0x05922c0a, 23);
    MD5_CORE(F3, a, b, c, d, in[ 9] + 0x44f0d933,  4);
    MD5_CORE(F3, d, a, b, c, in[12] + 0x7135ff25, 11);
    MD5_CORE(F3, c, d, a, b, in[15] + 0x58a47215, 16);
    MD5_CORE(F3, b, c, d, a, in[2 ] + 0x84543270, 23);

    MD5_CORE(F4, a, b, c, d, in[ 0] + 0x751246df,  6);
    MD5_CORE(F4, d, a, b, c, in[7 ] + 0x40d47452, 10);
    MD5_CORE(F4, c, d, a, b, in[14] + 0xdc350d18, 15);
    MD5_CORE(F4, b, c, d, a, in[5 ] + 0x1d4826e4, 21);
    MD5_CORE(F4, a, b, c, d, in[12] + 0x52e1560a,  6);
    MD5_CORE(F4, d, a, b, c, in[3 ] + 0x8bd1cc92, 10);
    MD5_CORE(F4, c, d, a, b, in[10] + 0x44ac7b71, 15);
    MD5_CORE(F4, b, c, d, a, in[1 ] + 0x77deb6ec, 21);
    MD5_CORE(F4, a, b, c, d, in[8 ] + 0xe08183ad,  6);
    MD5_CORE(F4, d, a, b, c, in[15] + 0xd09ce276, 10);
    MD5_CORE(F4, c, d, a, b, in[6 ] + 0x2c7e44c6, 15);
    MD5_CORE(F4, b, c, d, a, in[13] + 0xae64b7c0, 21);
    MD5_CORE(F4, a, b, c, d, in[4 ] + 0x186845ce,  6);
    MD5_CORE(F4, d, a, b, c, in[11] + 0x0a978348, 10);
    MD5_CORE(F4, c, d, a, b, in[2 ] + 0x10152256, 15);
    MD5_CORE(F4, b, c, d, a, in[9 ] + 0x70cac126, 21);

    state[0] += a; state[1] += b; state[2] += c; state[3] += d;
}

void RIPEMDInit(MD_CTX* ctx){
    MD5_Init(ctx);
}


void RIPEMDUpdate(MD_CTX* ctx, const byte input[], ENTIER len){
    MD5_Update(ctx, input, len);
}


void RIPEMDFinal(byte digest[], MD_CTX* ctx){
    MD5_Final(digest, ctx);
}