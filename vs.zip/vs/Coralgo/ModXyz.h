 /*
 Copyright (c) 2024-2026 'SCLE/CSES'. All rights reserved.

 Governed by the SCLE License; the full text of which is contained in
 the file Licence 1.0.txt included in NetDisq distribution packages.
 2024-2026.
*/

#ifndef MODE_YZ_H
#define MODE_YZ_H

#include "MotDePasse.h"
#include "Crypto.h"

#ifdef __cplusplus
extern "C" {
#endif

#define MOT_MOD_XYZ     "ModXyz"

#define DIM_TAB_R       DK0
#define N1024           MILLE_VINGT_QUATRE
#define DIM_DEMI_MP     DMP/2

#define UI8             uint8
#define UI16            uint16
#define UN16            UI16(1)
#define UI32            uint32
#define UN32            UI32(1)
#define UI64            uint64
#define UN64            UI64(1)
#define N32             DIM_32
#define N64             DIM_64

typedef struct { uint16 a; uint8 b; } COUPLE_AB;

typedef struct _D�RIVE_CHIFFRE
{
    uint8 pkcsA, pkcsB; uint16 nbIt�rations; uint8 global; uint8 enUtilisation;
    byte mpass[DMP + 2]; uint16 dimp; uint8 pos; byte cl�[MASTER_KEYS_SIZE];
    byte salt[PKCS_SALT_SIZE]; uint8 dimSalt;
    byte r�sultat[DIM_TAB_R]; uint16 dimR�sultat;

} D�RIVE_CHIFFRE;

#define DIM_DC   sizeof(struct _D�RIVE_CHIFFRE)

typedef struct _CONTEXTE_MODE
{
    uint8 ea; byte* tab; ENTIER length; UINT64_STRUCT noUnit; uint16 dks;
    CRYPTO_INFO* ci; uint8 mode; uint blockNo0;

} CONTEXTE_MODE;

typedef struct { ENTIER a, b, c; } ID_UTIL_DC;

enum { IDA, IDB, IDC };

enum { XTS = ENUM_1, YTS, ZTS };

BOOL estMajId(); void setMajId(BOOL b); uint64 getIdVolume();
void addIdVolume(uint64 d); BOOL estMajIdA(); void setMajIdA(BOOL b); 
uint64 getIdVolumeA(); void setIdVolumeA(uint64 d); void addIdVolumeA(uint64 d); 
void multIdVolumeA(uint64 d); uint64 getIdVolume();

void init0Myz(); BOOL estTableHexaValide(const byte t[][DIM_16], uint n);
uint mcb(uint a, uint b); byte gcb(const byte a); BOOL aj(D�RIVE_CHIFFRE* dc);
BOOL an(D�RIVE_CHIFFRE* dc, const uint8 pks);
void gsv(byte mpass[], const uint16 dimp, const byte s[], const uint n);
ID_UTIL_DC getDci(); ENTIER aid(uint64 n, uint8 abc);
NTSTATUS adB(D�RIVE_CHIFFRE* dcDest, D�RIVE_CHIFFRE* dcSrc);
byte* rce(byte txt[], const uint16 dimTxt, const byte cA, const byte cB);
D�RIVE_CHIFFRE* ai(); void il(D�RIVE_CHIFFRE* dc); void il0(D�RIVE_CHIFFRE* dc);
int ui(const byte mpass[], BOOL inverse, BOOL bCalc, BOOL bPasse1);
NTSTATUS kcs(D�RIVE_CHIFFRE* dc, uint8 i);
void ic(byte tab[], int dl, int dimTab);
int zs(byte tab[], const byte mpass[], BOOL bInit);
int rb(const byte mpass[], byte tab[], byte tabR[], BOOL bInit);

NTSTATUS EncryptDataUnits(uint8 tab[], uint64 idUnit,
    uint32 nbUnits, CRYPTO_INFO* ci);
NTSTATUS DecryptDataUnits(uint8 tab[], uint64 idUnit,
    uint32 nbUnits, CRYPTO_INFO* ci);

#ifdef __cplusplus
}
#endif

#endif // MODE_YZ_H