/*
 Legal Notice: Some portions of the source code contained in this file were
 derived from the source code of Encryption. Modifications and additions to
 the original source code (contained in this file), and all other portions
 of this file are Copyright(c) 2003-2013 'Fondation TrueCrypt'. These are
 also governed by the SCLE License; the full text of which is contained
 in the file Licence 1.0.txt included in NetDisq packages.
 2024-2026. */

#include "CadentKey.h"
#include "Aesdefs.h"
#include "Erreur.h"
#include "Secret.h"


typedef struct
{
    uint8 noEA; char nom[DIM_NOM_CIPHER];
    NTSTATUS(*initEA)(); NTSTATUS(*finEA)(); uint16(*getDimKS)();
    NTSTATUS(*encryptBlock0)(byte donn�es[]); // Whitening.
    NTSTATUS(*encryptBlock)(uint64 i, byte donn�es[]);
    NTSTATUS(*decryptBlock)(uint64 i, byte donn�es[]);

} AlgorithmChiffre; 

static AlgorithmChiffre gTabEAs[] = { // Cf. IEDAlgorithm.h.
    { THEO,     "Theo",     initTHEO,   finTHEO,  getDimKsTHEO,  
        encryptBlock0THEO,  encryptBlockTHEO,   decryptBlockTHEO },
    { REM,      "Rem",      initREM,    finREM,   getDimKsREM,   
        encryptBlock0REM,   encryptBlockREM,    decryptBlockREM },
    { ANTHOZA,  "Anthozoa", initAZR,    finAZR,   getDimKsAZR,   
        encryptBlock0AZR,   encryptBlockAZR,    decryptBlockAZR  },
    { MOLLUSC,  "Mollusc",  initMLSC,   finMLSC,  getDimKsMLSC,  
        encryptBlock0MLSC,  encryptBlockMLSC,   decryptBlockMLSC },
    { APOD,     "Apod",     initAPOD,   finAPOD,  getDimKsAPOD,  
        encryptBlock0APOD,  encryptBlockAPOD,   decryptBlockAPOD },
    { FISH,     "Poisson",  initFISH,   finFISH,  getDimKsFISH,  
        encryptBlock0FISH,  encryptBlockFISH,   decryptBlockFISH }
}; 

AlgorithmChiffre* getEA(const uint8 ea) 
{
    for (uint8 i = 0; gTabEAs[i].noEA != 0; i++)
    {
        if (gTabEAs[i].noEA == ea){ return &gTabEAs[i]; }
    } 
    return &gTabEAs[0];
}

// PRE: la cl� 0 doit �tre initialis�e (avec setKey0 [Crypto]).
NTSTATUS initEA(uint8 ea)
{ 
    AlgorithmChiffre* algo = getEA(ea); const uint16 DKS = algo->getDimKS();
    if ( ! setInfosKeySchedule(ea, DKS)){ return ERR_INVALID_INIT; } 
    NTSTATUS result = algo->initEA();
    if (NT_SUCCESS(result))
    {
        const uint16 I0 = 0; byte* cc = getKeySchedule(ea, I0);
        if (estVide0(cc, DKS, DIM_8)){ return ERR_CIPHER_INIT_WEAK_KEY; }
    } return result;
}

int finEA(uint8 ea){ return getEA(ea)->finEA(); }

char* getNomEA(uint8 ea){ return getEA(ea)->nom; }

uint16 getDimKs(uint8 ea)
{
    AlgorithmChiffre* algo = getEA(ea); return algo->getDimKS();
}

NTSTATUS encryptBlock0(uint8 ea, byte donn�es[]){
    return getEA(ea)->encryptBlock0(donn�es);
}

NTSTATUS encryptBlock16(const uint8 ea, uint64 i, byte donn�es[])
{   // PRE: la dimension (longueur) de 'donn�es' est 512 (UDM).
    NTSTATUS r = getEA(ea)->encryptBlock(i, donn�es); ND_ASSERT_S(r); 
    ND_FIN(); ERR: journaliser("Erreur encryptBlock %d.", gNDR�sultat); 
    r = gNDR�sultat; FIN: return r; 
}

NTSTATUS decryptBlock16(const uint8 ea, uint64 i, byte donn�es[])
{
    NTSTATUS r = getEA(ea)->decryptBlock(i, donn�es); ND_ASSERT_S(r); ND_FIN();
ERR:journaliser("Erreur decryptBlock %d.", gNDR�sultat); r = gNDR�sultat;
FIN:return r; 
}
