/*
 --------------------------------------------------------------------------
 Copyright (c) 1999, Dr Brian Gladman, Worcester, UK.  All rights reserved.

 LICENSE TERMS

 The free distribution and use of this software is allowed (with or without
 changes) provided that:

  1. source code distributions include the above copyright notice, this
     list of conditions and the following disclaimer;

  2. binary distributions include the above copyright notice, this list
     of conditions and the following disclaimer in their documentation;

  3. the name of the copyright holder is not used to endorse products
     built using this software without specific written permission.

 DISCLAIMER - SCLE/CSES

 This module works very well and has been tested intensively. The
 "no warranty" applies only to the maintainability, which can be
 difficult to satisfy. Ie. the data tables are not really modifiable.
 TODO: this should be replaced by 3-Fish algorithm.
 ---------------------------------------------------------------------------

 My thanks to Doug Whiting and Niels Ferguson for comments that led
 to improvements in this implementation.
*/
#include "ByteOrder.h"
#include "CadentKey.h"
#include "Memoire.h"
#include "Fish.h"

#define FISH_KL   DIM_32 * DIM_8
#define FISH_KS   sizeof(FISH_INSTANCE)

#define Q_TABLES
#define M_TABLE

#if ! defined (TC_MINIMIZE_CODE_SIZE)
  #define MK_TABLE
  #define ONE_STEP
#endif

// Finite field arithmetic for GF(2**8) with the modular 
// polynomial x^8 + x^6 + x^5 + x^3 + 1 (0x169).

#define G_M 0x0169

static uchar tab_5b[4] = { 0, G_M >> 2, G_M >> 1, (G_M >> 1) ^ (G_M >> 2) };
static uchar tab_ef[4] = { 0, (G_M >> 1) ^ (G_M >> 2), G_M >> 1, G_M >> 2 };

#define ffm_01(x)    (x)
#define ffm_5b(x)   ((x) ^ ((x) >> 2) ^ tab_5b[(x) & 3])
#define ffm_ef(x)   ((x) ^ ((x) >> 1) ^ ((x) >> 2) ^ tab_ef[(x) & 3])

static uchar ror4[16] = { 0, 8, 1, 9, 2, 10, 3, 11, 4, 12, 5, 13, 6, 14, 7, 15 };
static uchar ashx[16] = { 0, 9, 2, 11, 4, 13, 6, 15, 8, 1, 10, 3, 12, 5, 14, 7 };

static uchar qt0[2][16] =
{   { 8, 1, 7, 13, 6, 15, 3, 2, 0, 11, 5, 9, 14, 12, 10, 4 },
    { 2, 8, 11, 13, 15, 7, 6, 14, 3, 1, 9, 4, 0, 10, 12, 5 }
};

static uchar qt1[2][16] =
{   { 14, 12, 11, 8, 1, 2, 3, 5, 15, 4, 10, 6, 7, 0, 9, 13 }, 
    { 1, 14, 2, 11, 4, 12, 3, 7, 6, 13, 10, 5, 15, 9, 0, 8 }
};

static uchar qt2[2][16] =
{   { 11, 10, 5, 14, 6, 13, 9, 0, 12, 8, 15, 3, 2, 4, 7, 1 },
    { 4, 12, 7, 5, 1, 6, 9, 10, 0, 14, 13, 8, 2, 11, 3, 15 }
};

static uchar qt3[2][16] =
{   { 13, 7, 15, 4, 1, 2, 6, 14, 9, 11, 3, 0, 8, 5, 12, 10 },
    { 11, 9, 5, 1, 12, 3, 13, 14, 6, 4, 7, 15, 2, 0, 8, 10 }
};
 
static uchar qp(const uint32 n, const uchar x)
{   uchar a0, a1, a2, a3, a4, b0, b1, b2, b3, b4;

    a0 = x >> 4; b0 = x & 15;
    a1 = a0 ^ b0; b1 = ror4[b0] ^ ashx[a0];
    a2 = qt0[n][a1]; b2 = qt1[n][b1];
    a3 = a2 ^ b2; b3 = ror4[b2] ^ ashx[a2];
    a4 = qt2[n][a3]; b4 = qt3[n][b3];
    return (b4 << 4) | a4;
};

#ifdef  Q_TABLES

static uint32 qt_gen = 0;
static uchar q_tab[2][256];

#define q(n,x)  q_tab[n][x]

static void gen_qtab(void)
{   
    uint32  i;

    for(i = 0; i < 256; ++i)
    {       
        q(0,i) = qp(0, (uchar)i); q(1,i) = qp(1, (uchar)i);
    }
};

#else

#define q(n,x)  qp(n, x)

#endif

#ifdef  M_TABLE

static uint32 mt_gen = 0, m_tab[4][256];

static void gen_mtab(void)
{   
    uint32  i, f01, f5b, fef;
    
    for(i = 0; i < 256; ++i)
    {
        f01 = q(1,i); f5b = ffm_5b(f01); fef = ffm_ef(f01);
        m_tab[0][i] = f01 + (f5b << 8) + (fef << 16) + (fef << 24);
        m_tab[2][i] = f5b + (fef << 8) + (f01 << 16) + (fef << 24);

        f01 = q(0,i); f5b = ffm_5b(f01); fef = ffm_ef(f01);
        m_tab[1][i] = fef + (fef << 8) + (f5b << 16) + (f01 << 24);
        m_tab[3][i] = f5b + (f01 << 8) + (fef << 16) + (f5b << 24);
    }
};

#define mds(n,x)    m_tab[n][x]

#endif // M_TABLE

static uint32 h_fun(FISH_INSTANCE *instance, const uint32 x, const uint32 ks[])
{   
    uint32  b0, b1, b2, b3;

    b0 = extract_byte(x, 0); b1 = extract_byte(x, 1); 
    b2 = extract_byte(x, 2); b3 = extract_byte(x, 3);

    switch(instance->k_len)
    {
    case 4: b0 = q(1, (uchar) b0) ^ extract_byte(ks[3],0);
            b1 = q(0, (uchar) b1) ^ extract_byte(ks[3],1);
            b2 = q(0, (uchar) b2) ^ extract_byte(ks[3],2);
            b3 = q(1, (uchar) b3) ^ extract_byte(ks[3],3);

    case 3: b0 = q(1, (uchar) b0) ^ extract_byte(ks[2],0);
            b1 = q(1, (uchar) b1) ^ extract_byte(ks[2],1);
            b2 = q(0, (uchar) b2) ^ extract_byte(ks[2],2);
            b3 = q(0, (uchar) b3) ^ extract_byte(ks[2],3);

    case 2: b0 = q(0, (uchar) (q(0, (uchar) b0) ^ extract_byte(ks[1],0))) ^ extract_byte(ks[0],0);
            b1 = q(0, (uchar) (q(1, (uchar) b1) ^ extract_byte(ks[1],1))) ^ extract_byte(ks[0],1);
            b2 = q(1, (uchar) (q(0, (uchar) b2) ^ extract_byte(ks[1],2))) ^ extract_byte(ks[0],2);
            b3 = q(1, (uchar) (q(1, (uchar) b3) ^ extract_byte(ks[1],3))) ^ extract_byte(ks[0],3);
    }
#ifdef M_TABLE

    return  mds(0, b0) ^ mds(1, b1) ^ mds(2, b2) ^ mds(3, b3);

#endif // M_TABLE
};

#ifdef MK_TABLE

#define q20(x)  q(0,q(0,x) ^ extract_byte(ks[1],0)) ^ extract_byte(ks[0],0)
#define q21(x)  q(0,q(1,x) ^ extract_byte(ks[1],1)) ^ extract_byte(ks[0],1)
#define q22(x)  q(1,q(0,x) ^ extract_byte(ks[1],2)) ^ extract_byte(ks[0],2)
#define q23(x)  q(1,q(1,x) ^ extract_byte(ks[1],3)) ^ extract_byte(ks[0],3)

#define q30(x)  q(0,q(0,q(1, x) ^ extract_byte(ks[2],0)) ^ extract_byte(ks[1],0)) ^ extract_byte(ks[0],0)
#define q31(x)  q(0,q(1,q(1, x) ^ extract_byte(ks[2],1)) ^ extract_byte(ks[1],1)) ^ extract_byte(ks[0],1)
#define q32(x)  q(1,q(0,q(0, x) ^ extract_byte(ks[2],2)) ^ extract_byte(ks[1],2)) ^ extract_byte(ks[0],2)
#define q33(x)  q(1,q(1,q(0, x) ^ extract_byte(ks[2],3)) ^ extract_byte(ks[1],3)) ^ extract_byte(ks[0],3)

#define q40(x)  q(0,q(0,q(1, q(1, x) ^ extract_byte(ks[3],0)) ^ extract_byte(ks[2],0)) ^ extract_byte(ks[1],0)) ^ extract_byte(ks[0],0)
#define q41(x)  q(0,q(1,q(1, q(0, x) ^ extract_byte(ks[3],1)) ^ extract_byte(ks[2],1)) ^ extract_byte(ks[1],1)) ^ extract_byte(ks[0],1)
#define q42(x)  q(1,q(0,q(0, q(0, x) ^ extract_byte(ks[3],2)) ^ extract_byte(ks[2],2)) ^ extract_byte(ks[1],2)) ^ extract_byte(ks[0],2)
#define q43(x)  q(1,q(1,q(0, q(1, x) ^ extract_byte(ks[3],3)) ^ extract_byte(ks[2],3)) ^ extract_byte(ks[1],3)) ^ extract_byte(ks[0],3)

static void gen_mk_tab(FISH_INSTANCE *instance, uint32 ks[])
{   
    uint32 i, *mk_tab = instance->mk_tab; uchar  by;

    switch(instance->k_len)
    {
        case 2: for (i = 0; i < 256; ++i)
        {
            by = (uchar)i;
            mk_tab[0 + 4*i] = mds(0, q20(by)); mk_tab[1 + 4*i] = mds(1, q21(by));
            mk_tab[2 + 4*i] = mds(2, q22(by)); mk_tab[3 + 4*i] = mds(3, q23(by));
        }
        break;
    
        case 3: for (i = 0; i < 256; ++i)
        {
            by = (uchar)i;
            mk_tab[0 + 4*i] = mds(0, q30(by)); mk_tab[1 + 4*i] = mds(1, q31(by));
            mk_tab[2 + 4*i] = mds(2, q32(by)); mk_tab[3 + 4*i] = mds(3, q33(by));
        }
        break;
    
        case 4: for(i = 0; i < 256; ++i)
        {
            by = (uchar)i;
            mk_tab[0 + 4*i] = mds(0, q40(by)); mk_tab[1 + 4*i] = mds(1, q41(by));
            mk_tab[2 + 4*i] = mds(2, q42(by)); mk_tab[3 + 4*i] = mds(3, q43(by));
        }
    }

};

#define g0_fun(x) ( mk_tab[0 + 4*extract_byte(x,0)] ^ mk_tab[1 + 4*extract_byte(x,1)] \
                   ^ mk_tab[2 + 4*extract_byte(x,2)] ^ mk_tab[3 + 4*extract_byte(x,3)] )
#define g1_fun(x) ( mk_tab[0 + 4*extract_byte(x,3)] ^ mk_tab[1 + 4*extract_byte(x,0)] \
                   ^ mk_tab[2 + 4*extract_byte(x,1)] ^ mk_tab[3 + 4*extract_byte(x,2)] )

#endif // MK_TABLE

/* 
  The (12,8) Reed Soloman code has the generator polynomial

  g(x) = x^4 + (a + 1/a) * x^3 + a * x^2 + (a + 1/a) * x + 1

where the coefficients are in the finite field GF(2^8) with a
modular polynomial a^8 + a^6 + a^3 + a^2 + 1. To generate the
remainder we have to start with a 12th order polynomial with our
eight input bytes as the coefficients of the 4th to 11th terms. 
That is:

  m[7] * x^11 + m[6] * x^10 ... + m[0] * x^4 + 0 * x^3 +... + 0
  
We then multiply the generator polynomial by m[7] * x^7 and subtract
it - xor in GF(2^8) - from the above to eliminate the x^7 term (the 
artihmetic on the coefficients is done in GF(2^8). We then multiply 
the generator polynomial by x^6 * coeff(x^10) and use this to remove
the x^10 term. We carry on in this way until the x^4 term is removed
so that we are left with:

  r[3] * x^3 + r[2] * x^2 + r[1] 8 x^1 + r[0]

which give the resulting 4 bytes of the remainder. This is equivalent 
to the matrix multiplication in the Poisson description but much faster 
to implement.

*/

#define G_MOD   0x0000014d

static uint32 mds_rem(uint32 pa, uint32 pb)
{   
    uint32  i, c, u;

    for (i = 0; i < 8; ++i)
    {
        c = pb >> 24;   // get most significant coefficient
        
        pb = (pb << 8) | (pa >> 24); pa <<= 8;  // shift others up
            
        // multiply c by a (the primitive element - i.e. left shift)
        u = (c << 1);         
        if (c & 0x80){           // subtract modular polynomial on overflow        
            u ^= G_MOD; 
        }

        pb ^= c ^ (u << 16);    // remove c * (a * x^2 + 1)  

        u ^= (c >> 1);          // form u = a * c + c / a = c * (a + 1 / a); 
        
        if (c & 0x01){            // add the modular polynomial on underflow        
            u ^= G_MOD >> 1;
        }
        pb ^= (u << 24) | (u << 8); // remove c * (a + 1/a) * (x^3 + x)
    }

    return pb;
};

/* Initialise the key schedule (ks) from the user supplied key. */
uint32* initialiser_TWOFISH(FISH_INSTANCE *instance, const uint32 in_key[], 
                        const uint32 key_len)
{   
    uint32  i, a, b, me_key[4], mo_key[4], *l_key, *s_key;

    l_key = instance->l_key; s_key = instance->s_key;

#ifdef Q_TABLES
    if ( ! qt_gen)
    {
        gen_qtab(); qt_gen = 1;
    }
#endif

#ifdef M_TABLE
    if ( ! mt_gen)
    {
        gen_mtab(); mt_gen = 1;
    }
#endif

    instance->k_len = key_len / 64;   /* 2, 3 or 4 */

    for (i = 0; i < instance->k_len; ++i)
    {
        a = LE32(in_key[i + i]); me_key[i] = a;
        b = LE32(in_key[i + i + 1]); mo_key[i] = b;
        s_key[instance->k_len - i - 1] = mds_rem(a, b);
    }

    for(i = 0; i < 40; i += 2)
    {
        a = 0x01010101 * i; b = a + 0x01010101;
        a = h_fun(instance, a, me_key);
        b = turnl(h_fun(instance, b, mo_key), 8);
        l_key[i] = a + b; l_key[i + 1] = turnl(a + 2 * b, 9);
    }

#ifdef MK_TABLE
    gen_mk_tab(instance, s_key);
#endif
    return l_key;
};

/* Encrypt a block of text  */
#define f_rnd(i)                                                     \
    t1 = g1_fun(blk[1]); t0 = g0_fun(blk[0]);                        \
    blk[2] = turnr(blk[2] ^ (t0 + t1 + l_key[4 * (i) + 8]), 1);      \
    blk[3] = turnl(blk[3], 1) ^ (t0 + 2 * t1 + l_key[4 * (i) + 9]);  \
    t1 = g1_fun(blk[3]); t0 = g0_fun(blk[2]);                        \
    blk[0] = turnr(blk[0] ^ (t0 + t1 + l_key[4 * (i) + 10]), 1);     \
    blk[1] = turnl(blk[1], 1) ^ (t0 + 2 * t1 + l_key[4 * (i) + 11])

void chiffrer_TWOFISH(const FISH_INSTANCE* instance, 
    const uint32 in_blk[4], uint32 out_blk[])
{   
    uint32  t0, t1, blk[4];
    uint32* l_key = (uint32*)instance->l_key;
    uint32* mk_tab = (uint32*)instance->mk_tab;

    blk[0] = LE32(in_blk[0]) ^ l_key[0];
    blk[1] = LE32(in_blk[1]) ^ l_key[1];
    blk[2] = LE32(in_blk[2]) ^ l_key[2];
    blk[3] = LE32(in_blk[3]) ^ l_key[3];

    f_rnd(0); f_rnd(1); f_rnd(2); f_rnd(3);
    f_rnd(4); f_rnd(5); f_rnd(6); f_rnd(7);

    out_blk[0] = LE32(blk[2] ^ l_key[4]);
    out_blk[1] = LE32(blk[3] ^ l_key[5]);
    out_blk[2] = LE32(blk[0] ^ l_key[6]);
    out_blk[3] = LE32(blk[1] ^ l_key[7]); 
};

/* Decrypt a block of text  */

#define i_rnd(i)                                                    \
    t1 = g1_fun(blk[1]); t0 = g0_fun(blk[0]);                       \
    blk[2] = turnl(blk[2], 1) ^ (t0 + t1 + l_key[4 * (i) + 10]);     \
    blk[3] = turnr(blk[3] ^ (t0 + 2 * t1 + l_key[4 * (i) + 11]), 1); \
    t1 = g1_fun(blk[3]); t0 = g0_fun(blk[2]);                       \
    blk[0] = turnl(blk[0], 1) ^ (t0 + t1 + l_key[4 * (i) +  8]);     \
    blk[1] = turnr(blk[1] ^ (t0 + 2 * t1 + l_key[4 * (i) +  9]), 1)

void d�chiffrer_TWOFISH(const FISH_INSTANCE *instance,
    const uint32 in_blk[4], uint32 out_blk[4])
{   
    uint32  t0, t1, blk[4];
    uint32* l_key = (uint32*)instance->l_key;
    uint32* mk_tab = (uint32*)instance->mk_tab;
    blk[0] = LE32(in_blk[0]) ^ l_key[4];
    blk[1] = LE32(in_blk[1]) ^ l_key[5];
    blk[2] = LE32(in_blk[2]) ^ l_key[6];
    blk[3] = LE32(in_blk[3]) ^ l_key[7];
    i_rnd(7); i_rnd(6); i_rnd(5); i_rnd(4);
    i_rnd(3); i_rnd(2); i_rnd(1); i_rnd(0);
    out_blk[0] = LE32(blk[2] ^ l_key[0]);
    out_blk[1] = LE32(blk[3] ^ l_key[1]);
    out_blk[2] = LE32(blk[0] ^ l_key[2]);
    out_blk[3] = LE32(blk[1] ^ l_key[3]); 
};

#define NB_CL�S_FISH    1 // TODO: prend ~trop de m�moire (4276) ?

static FISH_INSTANCE gTabFISH[NB_CL�S_FISH] = {0};

NTSTATUS initFISH()
{ 
    uint8 ea = FISH; byte *c0 = NULL, cl�0[FISH_KS] = {0};
    FISH_INSTANCE* cl� = NULL; const uint8 N = NB_CL�S_FISH;
    for (uint8 j = 0; j < N; j++)
    {
        c0 = getKeyInit(ea, j); memcpy(cl�0, c0, FISH_KS);
        cl� = (FISH_INSTANCE*)&gTabFISH[j];
        memcpy(cl�, getKeySchedule(ea, j), FISH_KS);
        if ( ! initialiser_TWOFISH((FISH_INSTANCE*)cl�,
            (const uint32*)cl�0, FISH_KL)){ return NULL; }
    }
    return EXIT_SUCCESS; 
}

NTSTATUS finFISH(){ 
    return EXIT_SUCCESS; 
}

byte* getKeyFISH(uint64 i)
{
    uint64 j = (i % NB_CL�S_FISH); return (byte*)&gTabFISH[j];
}

uint16 getDimKsFISH(){ return FISH_KS; }

NTSTATUS encryptBlock0FISH(byte donn�es[])
{
    byte* cc = getKeyFISH(0);
    chiffrer_TWOFISH((FISH_INSTANCE*)cc, (const uint32*)donn�es,
        (uint32*)donn�es); return EXIT_SUCCESS;
}

NTSTATUS encryptBlockFISH(uint64 i, byte donn�es[])
{   
    byte* cc = getKeyFISH(i);
    chiffrer_TWOFISH((FISH_INSTANCE*)cc, (const uint32*)donn�es,
        (uint32*)donn�es); return EXIT_SUCCESS;
}

NTSTATUS decryptBlockFISH(uint64 i, byte donn�es[])
{
    byte* cc = getKeyFISH(i); d�chiffrer_TWOFISH((FISH_INSTANCE*)cc,
        (const uint32*) donn�es, (uint32*) donn�es); return EXIT_SUCCESS;
}