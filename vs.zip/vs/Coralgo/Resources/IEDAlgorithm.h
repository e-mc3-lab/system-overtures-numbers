/*
 Legal Notice: Some portions of the source code contained in this file were
 derived from the source code of Encryption. Modifications and additions to
 the original source code (contained in this file), and all other portions
 of this file are Copyright(c) 2003-2013 'Fondation TrueCrypt'. These are
 also governed by the SCLE License; the full text of which is contained
 in the file Licence 1.0.txt included in NetDisq distribution packages.
 2024-2026. */

#ifndef I_ED_ALGO_H
#define I_ED_ALGO_H

#include "CompatibX.h"

#define DIM_NOM_CIPHER 12

/*
 * NB: on a essay� 6 classes impl�mentant cette interface, mais il faut 
 * reconna�tre qu'il y a aussi une redondance de mots (ex: 'const') [+]
 * oblige d'utiliser un 'switch'. On ne voit pas un avantage significatif.
 * Conclusion: le langage C++ devrait-il s'am�liorer encore pour mieux 
 * ressembler � Java, et ainsi �tre plus conforme � UML ? 
 */
interface /* __STRUCT__ */ IChiffrAlgorithm
{
public:
    IChiffrAlgorithm(){ };  virtual ~IChiffrAlgorithm(){ }
    virtual NTSTATUS initialize(uint64 i) const=0;  
    virtual NTSTATUS finalize() const = 0;
    
    virtual char* getName() const = 0; virtual uint16 getDimKs() const = 0;
    virtual NTSTATUS encryptBlock(uint64 i, byte data[]) const = 0;
    virtual NTSTATUS decryptBlock(uint64 i, byte data[]) const = 0;
};

#endif // I_ED_ALGO_H