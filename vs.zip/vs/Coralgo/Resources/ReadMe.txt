The hierarchy of modules is as follows:
                   __________________________________________ 
                  /                                          \
                 /    Cyptur|Doa  AutoTest  ModXyz  Random    \
                *______________________________________________*
                |                                              |
                |       Crypto (Cipher)     Secret (EA)        |
                |______________________________________________|
                |                                              |
                |   Theo  Rem  Anthozoa  Mollusc  Apod  Fish   |
                |______________________________________________|
                |                                              |
                | Ripemd|Sha|Whirlpool  ProcesSpace  CadentKey |
                |______________________________________________|
                                            
################################################################################

* EA: is an unitary encryption algorithm (individual). While Cipher is a random
      suite of 3 algorithms (EAs) to form a new one.

To know how to modify the arrays SALT in Doa.cpp, see the project CxRef.

--------------------------------------------------------------------------------
AutoTest (module)
--------------------------------------------------------------------------------

Serves to verify if there were changes to the encryption 
algorithms; and that they stay valid.

-------------------------------------------------
New algorithm (or change. of OS environment)
-------------------------------------------------

This part is not used anymore, because some arrays of algorithms are 
modified according to each user version. Then the CRC values become
unknown, being actually variable.

-------------------------------------------------------------------------------
Pilot (driver)
--------------------------------------------------------------------------------
See the comment in LisezMoi.txt (using an automatic translator if necessary).