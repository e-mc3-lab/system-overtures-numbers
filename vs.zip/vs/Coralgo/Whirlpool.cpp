/**
 * The Whirlpool hashing function.
 *
 * <P>
 * <b>References</b>
 *
 * <P>
 * The Whirlpool algorithm was developed by
 * Paulo S. L. M. Barreto and
 * Vincent Rijmen
 *
 * See  P.S.L.M. Barreto, V. Rijmen,
 *      ``The Whirlpool hashing function,''
 *      NESSIE submission, 2000 (tweaked version, 2001),
 *      <https://www.cosic.esat.kuleuven.ac.be/nessie/workshop/submissions/whirlpool.zip>
 * 
 * @author  Paulo S.L.M. Barreto
 * @author  Vincent Rijmen.
 * Adapted for TrueCrypt.
 *
 * @version 3.0
 *
 * =============================================================================
 *
 * Differences from version 2.1:
 *
 * - Suboptimal diffusion matrix replaced by cir(1, 1, 4, 1, 8, 5, 2, 9).
 *
 * =============================================================================
 *
 * Differences from version 2.0:
 *
 * - Generation of ISO/IEC 10118-3 test vectors.
 *
 * Differences from version 1.0:
 *
 * - Original S-box replaced by the tweaked, hardware-efficient version.
 *
 * =============================================================================
 *
 * The code contained in this file (Whirlpool.cpp) is in the public domain.
 * 
 * SCLE: les tableaux C1 � C8 sont actualis�s. Il y a une version unique de 
 * ce module pour chaque utilisateur.
 */ 
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include "CompatibX.h"
#include "Memoire.h"
#include "Whirlpool.h"

/* #define TRACE_INTERMEDIATE_VALUES */
/*
 * The number of rounds of the internal dedicated block algorithm.
 */
#define R 10

/* Since Whirlpool is byte-order-neutral, the encryption tables are listed
 * in Reverse-byte-order format (LL), which is adopted over this 
 * implementation (but standard-byte-order notation would be 
 * equally suitable if consistently employed). */
static const u64 C1[DIM_256] = 
{
    LL(0x9836b3e87e4176d9), LL(0x62c8fc96fa608856), LL(0x01ace53094cc32d7), LL(0x424bfeb1aa887bdc),
    LL(0x3e7d1f106d088653), LL(0x8632c5e4db7bdff8), LL(0x01f818ee78f15672), LL(0x68de38fc589a149a),
    LL(0x68ae8f37dba53814), LL(0x0dcd72b4aa35eaba), LL(0x1c28ccdbfd9adb7f), LL(0x8fa4a00e78bcc298),
    LL(0xf1799116087f94d5), LL(0x762aebdf9e542b51), LL(0x3e3dc74a18e8e5f1), LL(0x64a9884e0e5a06a2),
    LL(0xa28eb7467e553cc0), LL(0xc4afe605e6cc16a3), LL(0xad38b63b67342403), LL(0xcc562c99bc11e20e),
    LL(0x1140d6f7bb582b30), LL(0xd71e485802f474f8), LL(0xeedd371e6be480d2), LL(0xd07a10b8ca37e252),
    LL(0xd21ec2db3790a3d0), LL(0x8a95ebceef87fdfb), LL(0x2f32e9ec3c4426b2), LL(0x4f23f71d516d0e78),
    LL(0x467e8b14242b1367), LL(0x0d3a98031461f699), LL(0x52ee840fc1b43378), LL(0x3b9cea93b5540c12),
    LL(0x358ea18b1078cc5a), LL(0x2d3c4e0ab00a4a24), LL(0x8ed24f2e64908a34), LL(0x2417753395d9b629),
    LL(0xe78d05c5298fbf4a), LL(0x8e1af144ab2eca52), LL(0xc26c6a54d3ce9ec4), LL(0x1ccb2ff880589cda),
    LL(0xa6b316e07af43523), LL(0xb027249a096602d9), LL(0xc1d87b5e52e3b6e4), LL(0x1bc2653097bccd1a),
    LL(0xa6a2d0576c246b5e), LL(0x4ab39eeddf1cdc4d), LL(0xe6605a71c0ddaf4d), LL(0xdefaf534142aa6c6),
    LL(0xe447be8e76a59416), LL(0xa11c764646c05c19), LL(0xd0db159ac483b18d), LL(0xe0fc374049b944c9),
    LL(0x72b2542b4b420414), LL(0xa55e0490deb54b9d), LL(0xb2a6c54eb25c8dfe), LL(0xded0ef051c0e50a4),
    LL(0x7090651c42e9807e), LL(0x21777994c9900388), LL(0x7bf4c79e1a5dcba9), LL(0x4a8c73b2ce9089bc),
    LL(0x15a041cf7b7e86dd), LL(0x922d60b168629eda), LL(0x0125c0526b4fb40d), LL(0x39e017a637352ca2),
    LL(0x6af01f96f4e097e3), LL(0x362b47c40952cc55), LL(0xf89609a572b93cfc), LL(0x7c58224f43edab28),
    LL(0x5239a2a71b881270), LL(0xf4a6341b710c789b), LL(0x98f76caa7077214d), LL(0x8606026f9bab86c2),
    LL(0x9d81a7ee1564c862), LL(0x0c7d16ce3b62f7a2), LL(0xc826ad415aa5a288), LL(0x6e02f91814135356),
    LL(0xdc1d4826e4ddcdd0), LL(0x01dc26931f38f693), LL(0x1b426617ee445c5f), LL(0xa00266b78b41e22d),
    LL(0x2e2b9304f08ac89e), LL(0x1b6b995004cfe094), LL(0x2a8e7a4cc06f7da2), LL(0xe510152256db02f4),
    LL(0x93f8489e4e94bd56), LL(0xff1b7cfc49d48918), LL(0xfce032a7675c9e65), LL(0xf05cbb04b1d76be5),
    LL(0xbeac9be59b96546e), LL(0x015b4a98d65648e9), LL(0x56cf3fc482c464f0), LL(0xb6da1ec6f20ce53d),
    LL(0xe68128c1a2a406a0), LL(0xcf8d7d9d2ed00aae), LL(0xda751e8d10019f24), LL(0xc9c718e0566ae9fd),
    LL(0x1ab9ed7cea571210), LL(0x98983b4e19e3c003), LL(0xb30e2a47056cf712), LL(0xd52835544c5a2342),
    LL(0x629bd966c0f31fb7), LL(0x73242490e01695d4), LL(0xeb73dca7da308c4f), LL(0xe296286a9258c44f),
    LL(0x1ce4091a251204ec), LL(0x765284497172a4c2), LL(0x09f33260cbcd6bb6), LL(0x82eccb053be3238b),
    LL(0xcbefbff2ee092101), LL(0xf76c445fe1f5c468), LL(0xd7a117581785cb3a), LL(0x02d34e6d46806632),
    LL(0x168c47631f2605bd), LL(0xe5933ff2afcc4865), LL(0xcce1f4aad0b4ddf4), LL(0xf5343c82eae71b06),
    LL(0x13b3f97a18edcf70), LL(0xb0d10a9fda43a1c1), LL(0x1ef460a8580ba938), LL(0x8128a8f257ee7c5c),
    LL(0x251f4e2b53b4fe41), LL(0x9836b3e87e4176d9), LL(0x62c8fc96fa608856), LL(0x01ace53094cc32d7),
    LL(0x424bfeb1aa887bdc), LL(0x3e7d1f106d088653), LL(0x8632c5e4db7bdff8), LL(0x01f818ee78f15672),
    LL(0x68de38fc589a149a), LL(0x68ae8f37dba53814), LL(0x0dcd72b4aa35eaba), LL(0x1c28ccdbfd9adb7f),
    LL(0x8fa4a00e78bcc298), LL(0xf1799116087f94d5), LL(0x762aebdf9e542b51), LL(0x3e3dc74a18e8e5f1),
    LL(0x64a9884e0e5a06a2), LL(0xa28eb7467e553cc0), LL(0xc4afe605e6cc16a3), LL(0xad38b63b67342403),
    LL(0xcc562c99bc11e20e), LL(0x1140d6f7bb582b30), LL(0xd71e485802f474f8), LL(0xeedd371e6be480d2),
    LL(0xd07a10b8ca37e252), LL(0xd21ec2db3790a3d0), LL(0x8a95ebceef87fdfb), LL(0x2f32e9ec3c4426b2),
    LL(0x4f23f71d516d0e78), LL(0x467e8b14242b1367), LL(0x0d3a98031461f699), LL(0x52ee840fc1b43378),
    LL(0x3b9cea93b5540c12), LL(0x358ea18b1078cc5a), LL(0x2d3c4e0ab00a4a24), LL(0x8ed24f2e64908a34),
    LL(0x2417753395d9b629), LL(0xe78d05c5298fbf4a), LL(0x8e1af144ab2eca52), LL(0xc26c6a54d3ce9ec4),
    LL(0x1ccb2ff880589cda), LL(0xa6b316e07af43523), LL(0xb027249a096602d9), LL(0xc1d87b5e52e3b6e4),
    LL(0x1bc2653097bccd1a), LL(0xa6a2d0576c246b5e), LL(0x4ab39eeddf1cdc4d), LL(0xe6605a71c0ddaf4d),
    LL(0xdefaf534142aa6c6), LL(0xe447be8e76a59416), LL(0xa11c764646c05c19), LL(0xd0db159ac483b18d),
    LL(0xe0fc374049b944c9), LL(0x72b2542b4b420414), LL(0xa55e0490deb54b9d), LL(0xb2a6c54eb25c8dfe),
    LL(0xded0ef051c0e50a4), LL(0x7090651c42e9807e), LL(0x21777994c9900388), LL(0x7bf4c79e1a5dcba9),
    LL(0x4a8c73b2ce9089bc), LL(0x15a041cf7b7e86dd), LL(0x922d60b168629eda), LL(0x0125c0526b4fb40d),
    LL(0x39e017a637352ca2), LL(0x6af01f96f4e097e3), LL(0x362b47c40952cc55), LL(0xf89609a572b93cfc),
    LL(0x7c58224f43edab28), LL(0x5239a2a71b881270), LL(0xf4a6341b710c789b), LL(0x98f76caa7077214d),
    LL(0x8606026f9bab86c2), LL(0x9d81a7ee1564c862), LL(0x0c7d16ce3b62f7a2), LL(0xc826ad415aa5a288),
    LL(0x6e02f91814135356), LL(0xdc1d4826e4ddcdd0), LL(0x01dc26931f38f693), LL(0x1b426617ee445c5f),
    LL(0xa00266b78b41e22d), LL(0x2e2b9304f08ac89e), LL(0x1b6b995004cfe094), LL(0x2a8e7a4cc06f7da2),
    LL(0xe510152256db02f4), LL(0x93f8489e4e94bd56), LL(0xff1b7cfc49d48918), LL(0xfce032a7675c9e65),
    LL(0xf05cbb04b1d76be5), LL(0xbeac9be59b96546e), LL(0x015b4a98d65648e9), LL(0x56cf3fc482c464f0),
    LL(0xb6da1ec6f20ce53d), LL(0xe68128c1a2a406a0), LL(0xcf8d7d9d2ed00aae), LL(0xda751e8d10019f24),
    LL(0xc9c718e0566ae9fd), LL(0x1ab9ed7cea571210), LL(0x98983b4e19e3c003), LL(0xb30e2a47056cf712),
    LL(0xd52835544c5a2342), LL(0x629bd966c0f31fb7), LL(0x73242490e01695d4), LL(0xeb73dca7da308c4f),
    LL(0xe296286a9258c44f), LL(0x1ce4091a251204ec), LL(0x765284497172a4c2), LL(0x09f33260cbcd6bb6),
    LL(0x82eccb053be3238b), LL(0xcbefbff2ee092101), LL(0xf76c445fe1f5c468), LL(0xd7a117581785cb3a),
    LL(0x02d34e6d46806632), LL(0x168c47631f2605bd), LL(0xe5933ff2afcc4865), LL(0xcce1f4aad0b4ddf4),
    LL(0xf5343c82eae71b06), LL(0x13b3f97a18edcf70), LL(0xb0d10a9fda43a1c1), LL(0x1ef460a8580ba938),
    LL(0x8128a8f257ee7c5c), LL(0x251f4e2b53b4fe41), LL(0x9836b3e87e4176d9), LL(0x62c8fc96fa608856),
    LL(0x01ace53094cc32d7), LL(0x424bfeb1aa887bdc), LL(0x3e7d1f106d088653), LL(0x8632c5e4db7bdff8),
    LL(0x01f818ee78f15672), LL(0x68de38fc589a149a), LL(0x68ae8f37dba53814), LL(0x0dcd72b4aa35eaba),
    LL(0x1c28ccdbfd9adb7f), LL(0x8fa4a00e78bcc298), LL(0xf1799116087f94d5), LL(0x762aebdf9e542b51),
};

static const u64 C2[DIM_256] = 
{
    LL(0x3e3dc74a18e8e5f1), LL(0x64a9884e0e5a06a2), LL(0xa28eb7467e553cc0), LL(0xc4afe605e6cc16a3),
    LL(0xad38b63b67342403), LL(0xcc562c99bc11e20e), LL(0x1140d6f7bb582b30), LL(0xd71e485802f474f8),
    LL(0xeedd371e6be480d2), LL(0xd07a10b8ca37e252), LL(0xd21ec2db3790a3d0), LL(0x8a95ebceef87fdfb),
    LL(0x2f32e9ec3c4426b2), LL(0x4f23f71d516d0e78), LL(0x467e8b14242b1367), LL(0x0d3a98031461f699),
    LL(0x52ee840fc1b43378), LL(0x3b9cea93b5540c12), LL(0x358ea18b1078cc5a), LL(0x2d3c4e0ab00a4a24),
    LL(0x8ed24f2e64908a34), LL(0x2417753395d9b629), LL(0xe78d05c5298fbf4a), LL(0x8e1af144ab2eca52),
    LL(0xc26c6a54d3ce9ec4), LL(0x1ccb2ff880589cda), LL(0xa6b316e07af43523), LL(0xb027249a096602d9),
    LL(0xc1d87b5e52e3b6e4), LL(0x1bc2653097bccd1a), LL(0xa6a2d0576c246b5e), LL(0x4ab39eeddf1cdc4d),
    LL(0xe6605a71c0ddaf4d), LL(0xdefaf534142aa6c6), LL(0xe447be8e76a59416), LL(0xa11c764646c05c19),
    LL(0xd0db159ac483b18d), LL(0xe0fc374049b944c9), LL(0x72b2542b4b420414), LL(0xa55e0490deb54b9d),
    LL(0xb2a6c54eb25c8dfe), LL(0xded0ef051c0e50a4), LL(0x7090651c42e9807e), LL(0x21777994c9900388),
    LL(0x7bf4c79e1a5dcba9), LL(0x4a8c73b2ce9089bc), LL(0x15a041cf7b7e86dd), LL(0x922d60b168629eda),
    LL(0x0125c0526b4fb40d), LL(0x39e017a637352ca2), LL(0x6af01f96f4e097e3), LL(0x362b47c40952cc55),
    LL(0xf89609a572b93cfc), LL(0x7c58224f43edab28), LL(0x5239a2a71b881270), LL(0xf4a6341b710c789b),
    LL(0x98f76caa7077214d), LL(0x8606026f9bab86c2), LL(0x9d81a7ee1564c862), LL(0x0c7d16ce3b62f7a2),
    LL(0xc826ad415aa5a288), LL(0x6e02f91814135356), LL(0xdc1d4826e4ddcdd0), LL(0x01dc26931f38f693),
    LL(0x1b426617ee445c5f), LL(0xa00266b78b41e22d), LL(0x2e2b9304f08ac89e), LL(0x1b6b995004cfe094),
    LL(0x2a8e7a4cc06f7da2), LL(0xe510152256db02f4), LL(0x93f8489e4e94bd56), LL(0xff1b7cfc49d48918),
    LL(0xfce032a7675c9e65), LL(0xf05cbb04b1d76be5), LL(0xbeac9be59b96546e), LL(0x015b4a98d65648e9),
    LL(0x56cf3fc482c464f0), LL(0xb6da1ec6f20ce53d), LL(0xe68128c1a2a406a0), LL(0xcf8d7d9d2ed00aae),
    LL(0xda751e8d10019f24), LL(0xc9c718e0566ae9fd), LL(0x1ab9ed7cea571210), LL(0x98983b4e19e3c003),
    LL(0xb30e2a47056cf712), LL(0xd52835544c5a2342), LL(0x629bd966c0f31fb7), LL(0x73242490e01695d4),
    LL(0xeb73dca7da308c4f), LL(0xe296286a9258c44f), LL(0x1ce4091a251204ec), LL(0x765284497172a4c2),
    LL(0x09f33260cbcd6bb6), LL(0x82eccb053be3238b), LL(0xcbefbff2ee092101), LL(0xf76c445fe1f5c468),
    LL(0xd7a117581785cb3a), LL(0x02d34e6d46806632), LL(0x168c47631f2605bd), LL(0xe5933ff2afcc4865),
    LL(0xcce1f4aad0b4ddf4), LL(0xf5343c82eae71b06), LL(0x13b3f97a18edcf70), LL(0xb0d10a9fda43a1c1),
    LL(0x1ef460a8580ba938), LL(0x8128a8f257ee7c5c), LL(0x251f4e2b53b4fe41), LL(0x9836b3e87e4176d9),
    LL(0x62c8fc96fa608856), LL(0x01ace53094cc32d7), LL(0x424bfeb1aa887bdc), LL(0x3e7d1f106d088653),
    LL(0x8632c5e4db7bdff8), LL(0x01f818ee78f15672), LL(0x68de38fc589a149a), LL(0x68ae8f37dba53814),
    LL(0x0dcd72b4aa35eaba), LL(0x1c28ccdbfd9adb7f), LL(0x8fa4a00e78bcc298), LL(0xf1799116087f94d5),
    LL(0x762aebdf9e542b51), LL(0x3e3dc74a18e8e5f1), LL(0x64a9884e0e5a06a2), LL(0xa28eb7467e553cc0),
    LL(0xc4afe605e6cc16a3), LL(0xad38b63b67342403), LL(0xcc562c99bc11e20e), LL(0x1140d6f7bb582b30),
    LL(0xd71e485802f474f8), LL(0xeedd371e6be480d2), LL(0xd07a10b8ca37e252), LL(0xd21ec2db3790a3d0),
    LL(0x8a95ebceef87fdfb), LL(0x2f32e9ec3c4426b2), LL(0x4f23f71d516d0e78), LL(0x467e8b14242b1367),
    LL(0x0d3a98031461f699), LL(0x52ee840fc1b43378), LL(0x3b9cea93b5540c12), LL(0x358ea18b1078cc5a),
    LL(0x2d3c4e0ab00a4a24), LL(0x8ed24f2e64908a34), LL(0x2417753395d9b629), LL(0xe78d05c5298fbf4a),
    LL(0x8e1af144ab2eca52), LL(0xc26c6a54d3ce9ec4), LL(0x1ccb2ff880589cda), LL(0xa6b316e07af43523),
    LL(0xb027249a096602d9), LL(0xc1d87b5e52e3b6e4), LL(0x1bc2653097bccd1a), LL(0xa6a2d0576c246b5e),
    LL(0x4ab39eeddf1cdc4d), LL(0xe6605a71c0ddaf4d), LL(0xdefaf534142aa6c6), LL(0xe447be8e76a59416),
    LL(0xa11c764646c05c19), LL(0xd0db159ac483b18d), LL(0xe0fc374049b944c9), LL(0x72b2542b4b420414),
    LL(0xa55e0490deb54b9d), LL(0xb2a6c54eb25c8dfe), LL(0xded0ef051c0e50a4), LL(0x7090651c42e9807e),
    LL(0x21777994c9900388), LL(0x7bf4c79e1a5dcba9), LL(0x4a8c73b2ce9089bc), LL(0x15a041cf7b7e86dd),
    LL(0x922d60b168629eda), LL(0x0125c0526b4fb40d), LL(0x39e017a637352ca2), LL(0x6af01f96f4e097e3),
    LL(0x362b47c40952cc55), LL(0xf89609a572b93cfc), LL(0x7c58224f43edab28), LL(0x5239a2a71b881270),
    LL(0xf4a6341b710c789b), LL(0x98f76caa7077214d), LL(0x8606026f9bab86c2), LL(0x9d81a7ee1564c862),
    LL(0x0c7d16ce3b62f7a2), LL(0xc826ad415aa5a288), LL(0x6e02f91814135356), LL(0xdc1d4826e4ddcdd0),
    LL(0x01dc26931f38f693), LL(0x1b426617ee445c5f), LL(0xa00266b78b41e22d), LL(0x2e2b9304f08ac89e),
    LL(0x1b6b995004cfe094), LL(0x2a8e7a4cc06f7da2), LL(0xe510152256db02f4), LL(0x93f8489e4e94bd56),
    LL(0xff1b7cfc49d48918), LL(0xfce032a7675c9e65), LL(0xf05cbb04b1d76be5), LL(0xbeac9be59b96546e),
    LL(0x015b4a98d65648e9), LL(0x56cf3fc482c464f0), LL(0xb6da1ec6f20ce53d), LL(0xe68128c1a2a406a0),
    LL(0xcf8d7d9d2ed00aae), LL(0xda751e8d10019f24), LL(0xc9c718e0566ae9fd), LL(0x1ab9ed7cea571210),
    LL(0x98983b4e19e3c003), LL(0xb30e2a47056cf712), LL(0xd52835544c5a2342), LL(0x629bd966c0f31fb7),
    LL(0x73242490e01695d4), LL(0xeb73dca7da308c4f), LL(0xe296286a9258c44f), LL(0x1ce4091a251204ec),
    LL(0x765284497172a4c2), LL(0x09f33260cbcd6bb6), LL(0x82eccb053be3238b), LL(0xcbefbff2ee092101),
    LL(0xf76c445fe1f5c468), LL(0xd7a117581785cb3a), LL(0x02d34e6d46806632), LL(0x168c47631f2605bd),
    LL(0xe5933ff2afcc4865), LL(0xcce1f4aad0b4ddf4), LL(0xf5343c82eae71b06), LL(0x13b3f97a18edcf70),
    LL(0xb0d10a9fda43a1c1), LL(0x1ef460a8580ba938), LL(0x8128a8f257ee7c5c), LL(0x251f4e2b53b4fe41),
    LL(0x9836b3e87e4176d9), LL(0x62c8fc96fa608856), LL(0x01ace53094cc32d7), LL(0x424bfeb1aa887bdc),
    LL(0x3e7d1f106d088653), LL(0x8632c5e4db7bdff8), LL(0x01f818ee78f15672), LL(0x68de38fc589a149a),
    LL(0x33ae149a0ff1baa1), LL(0xf00b7310c66049a7), LL(0xc6e366f4b0425650), LL(0x689267bb24923ff4), 
    LL(0x68ae8f37dba53814), LL(0x0dcd72b4aa35eaba), LL(0x1c28ccdbfd9adb7f), LL(0x8fa4a00e78bcc298),
    LL(0xf1799116087f94d5), LL(0x762aebdf9e542b51), LL(0x3e3dc74a18e8e5f1), LL(0x64a9884e0e5a06a2),
    LL(0xa28eb7467e553cc0), LL(0xc4afe605e6cc16a3), LL(0xad38b63b67342403), LL(0xcc562c99bc11e20e),
    LL(0x1140d6f7bb582b30), LL(0xd71e485802f474f8), LL(0xeedd371e6be480d2), LL(0xd07a10b8ca37e252),
};

static const u64 C3[DIM_256] = 
{
    LL(0xd21ec2db3790a3d0), LL(0x8a95ebceef87fdfb), LL(0x2f32e9ec3c4426b2), LL(0x4f23f71d516d0e78),
    LL(0x467e8b14242b1367), LL(0x0d3a98031461f699), LL(0x52ee840fc1b43378), LL(0x3b9cea93b5540c12),
    LL(0x358ea18b1078cc5a), LL(0x2d3c4e0ab00a4a24), LL(0x8ed24f2e64908a34), LL(0x2417753395d9b629),
    LL(0xe78d05c5298fbf4a), LL(0x8e1af144ab2eca52), LL(0xc26c6a54d3ce9ec4), LL(0x1ccb2ff880589cda),
    LL(0xa6b316e07af43523), LL(0xb027249a096602d9), LL(0xc1d87b5e52e3b6e4), LL(0x1bc2653097bccd1a),
    LL(0xa6a2d0576c246b5e), LL(0x4ab39eeddf1cdc4d), LL(0xe6605a71c0ddaf4d), LL(0xdefaf534142aa6c6),
    LL(0xe447be8e76a59416), LL(0xa11c764646c05c19), LL(0xd0db159ac483b18d), LL(0xe0fc374049b944c9),
    LL(0x72b2542b4b420414), LL(0xa55e0490deb54b9d), LL(0xb2a6c54eb25c8dfe), LL(0xded0ef051c0e50a4),
    LL(0x7090651c42e9807e), LL(0x21777994c9900388), LL(0x7bf4c79e1a5dcba9), LL(0x4a8c73b2ce9089bc),
    LL(0x15a041cf7b7e86dd), LL(0x922d60b168629eda), LL(0x0125c0526b4fb40d), LL(0x39e017a637352ca2),
    LL(0x6af01f96f4e097e3), LL(0x362b47c40952cc55), LL(0xf89609a572b93cfc), LL(0x7c58224f43edab28),
    LL(0x5239a2a71b881270), LL(0xf4a6341b710c789b), LL(0x98f76caa7077214d), LL(0x8606026f9bab86c2),
    LL(0x9d81a7ee1564c862), LL(0x0c7d16ce3b62f7a2), LL(0xc826ad415aa5a288), LL(0x6e02f91814135356),
    LL(0xdc1d4826e4ddcdd0), LL(0x01dc26931f38f693), LL(0x1b426617ee445c5f), LL(0xa00266b78b41e22d),
    LL(0x2e2b9304f08ac89e), LL(0x1b6b995004cfe094), LL(0x2a8e7a4cc06f7da2), LL(0xe510152256db02f4),
    LL(0x93f8489e4e94bd56), LL(0xff1b7cfc49d48918), LL(0xfce032a7675c9e65), LL(0xf05cbb04b1d76be5),
    LL(0xbeac9be59b96546e), LL(0x015b4a98d65648e9), LL(0x56cf3fc482c464f0), LL(0xb6da1ec6f20ce53d),
    LL(0xe68128c1a2a406a0), LL(0xcf8d7d9d2ed00aae), LL(0xda751e8d10019f24), LL(0xc9c718e0566ae9fd),
    LL(0x1ab9ed7cea571210), LL(0x98983b4e19e3c003), LL(0xb30e2a47056cf712), LL(0xd52835544c5a2342),
    LL(0x629bd966c0f31fb7), LL(0x73242490e01695d4), LL(0xeb73dca7da308c4f), LL(0xe296286a9258c44f),
    LL(0x1ce4091a251204ec), LL(0x765284497172a4c2), LL(0x09f33260cbcd6bb6), LL(0x82eccb053be3238b),
    LL(0xcbefbff2ee092101), LL(0xf76c445fe1f5c468), LL(0xd7a117581785cb3a), LL(0x02d34e6d46806632),
    LL(0x168c47631f2605bd), LL(0xe5933ff2afcc4865), LL(0xcce1f4aad0b4ddf4), LL(0xf5343c82eae71b06),
    LL(0x13b3f97a18edcf70), LL(0xb0d10a9fda43a1c1), LL(0x1ef460a8580ba938), LL(0x8128a8f257ee7c5c),
    LL(0x251f4e2b53b4fe41), LL(0x9836b3e87e4176d9), LL(0x62c8fc96fa608856), LL(0x01ace53094cc32d7),
    LL(0x424bfeb1aa887bdc), LL(0x3e7d1f106d088653), LL(0x8632c5e4db7bdff8), LL(0x01f818ee78f15672),
    LL(0x68de38fc589a149a), LL(0x68ae8f37dba53814), LL(0x0dcd72b4aa35eaba), LL(0x1c28ccdbfd9adb7f),
    LL(0x8fa4a00e78bcc298), LL(0xf1799116087f94d5), LL(0x762aebdf9e542b51), LL(0x3e3dc74a18e8e5f1),
    LL(0x64a9884e0e5a06a2), LL(0xa28eb7467e553cc0), LL(0xc4afe605e6cc16a3), LL(0xad38b63b67342403),
    LL(0xcc562c99bc11e20e), LL(0x1140d6f7bb582b30), LL(0xd71e485802f474f8), LL(0xeedd371e6be480d2),
    LL(0xd07a10b8ca37e252), LL(0xd21ec2db3790a3d0), LL(0x8a95ebceef87fdfb), LL(0x2f32e9ec3c4426b2),
    LL(0x4f23f71d516d0e78), LL(0x467e8b14242b1367), LL(0x0d3a98031461f699), LL(0x52ee840fc1b43378),
    LL(0x3b9cea93b5540c12), LL(0x358ea18b1078cc5a), LL(0x2d3c4e0ab00a4a24), LL(0x8ed24f2e64908a34),
    LL(0x2417753395d9b629), LL(0xe78d05c5298fbf4a), LL(0x8e1af144ab2eca52), LL(0xc26c6a54d3ce9ec4),
    LL(0x1ccb2ff880589cda), LL(0xa6b316e07af43523), LL(0xb027249a096602d9), LL(0xc1d87b5e52e3b6e4),
    LL(0x1bc2653097bccd1a), LL(0xa6a2d0576c246b5e), LL(0x4ab39eeddf1cdc4d), LL(0xe6605a71c0ddaf4d),
    LL(0xdefaf534142aa6c6), LL(0xe447be8e76a59416), LL(0xa11c764646c05c19), LL(0xd0db159ac483b18d),
    LL(0xe0fc374049b944c9), LL(0x72b2542b4b420414), LL(0xa55e0490deb54b9d), LL(0xb2a6c54eb25c8dfe),
    LL(0xded0ef051c0e50a4), LL(0x7090651c42e9807e), LL(0x21777994c9900388), LL(0x7bf4c79e1a5dcba9),
    LL(0x4a8c73b2ce9089bc), LL(0x15a041cf7b7e86dd), LL(0x922d60b168629eda), LL(0x0125c0526b4fb40d),
    LL(0x39e017a637352ca2), LL(0x6af01f96f4e097e3), LL(0x362b47c40952cc55), LL(0xf89609a572b93cfc),
    LL(0x7c58224f43edab28), LL(0x5239a2a71b881270), LL(0xf4a6341b710c789b), LL(0x98f76caa7077214d),
    LL(0x8606026f9bab86c2), LL(0x9d81a7ee1564c862), LL(0x0c7d16ce3b62f7a2), LL(0xc826ad415aa5a288),
    LL(0x6e02f91814135356), LL(0xdc1d4826e4ddcdd0), LL(0x01dc26931f38f693), LL(0x1b426617ee445c5f),
    LL(0xa00266b78b41e22d), LL(0x2e2b9304f08ac89e), LL(0x1b6b995004cfe094), LL(0x2a8e7a4cc06f7da2),
    LL(0xe510152256db02f4), LL(0x93f8489e4e94bd56), LL(0xff1b7cfc49d48918), LL(0xfce032a7675c9e65),
    LL(0xf05cbb04b1d76be5), LL(0xbeac9be59b96546e), LL(0x015b4a98d65648e9), LL(0x56cf3fc482c464f0),
    LL(0xb6da1ec6f20ce53d), LL(0xe68128c1a2a406a0), LL(0xcf8d7d9d2ed00aae), LL(0xda751e8d10019f24),
    LL(0xc9c718e0566ae9fd), LL(0x1ab9ed7cea571210), LL(0x98983b4e19e3c003), LL(0xb30e2a47056cf712),
    LL(0xd52835544c5a2342), LL(0x629bd966c0f31fb7), LL(0x73242490e01695d4), LL(0xeb73dca7da308c4f),
    LL(0xe296286a9258c44f), LL(0x1ce4091a251204ec), LL(0x765284497172a4c2), LL(0x09f33260cbcd6bb6),
    LL(0x82eccb053be3238b), LL(0xcbefbff2ee092101), LL(0xf76c445fe1f5c468), LL(0xd7a117581785cb3a),
    LL(0x02d34e6d46806632), LL(0x168c47631f2605bd), LL(0xe5933ff2afcc4865), LL(0xcce1f4aad0b4ddf4),
    LL(0xf5343c82eae71b06), LL(0x13b3f97a18edcf70), LL(0xb0d10a9fda43a1c1), LL(0x1ef460a8580ba938),
    LL(0x8128a8f257ee7c5c), LL(0x251f4e2b53b4fe41), LL(0x9836b3e87e4176d9), LL(0x62c8fc96fa608856),
    LL(0x01ace53094cc32d7), LL(0x424bfeb1aa887bdc), LL(0x3e7d1f106d088653), LL(0x8632c5e4db7bdff8),
    LL(0x01f818ee78f15672), LL(0x68de38fc589a149a), LL(0x68ae8f37dba53814), LL(0x0dcd72b4aa35eaba),
    LL(0x1c28ccdbfd9adb7f), LL(0x8fa4a00e78bcc298), LL(0xf1799116087f94d5), LL(0x762aebdf9e542b51),
    LL(0x3e3dc74a18e8e5f1), LL(0x64a9884e0e5a06a2), LL(0xa28eb7467e553cc0), LL(0xc4afe605e6cc16a3),
    LL(0xad38b63b67342403), LL(0xcc562c99bc11e20e), LL(0x1140d6f7bb582b30), LL(0xd71e485802f474f8),
    LL(0xeedd371e6be480d2), LL(0xd07a10b8ca37e252), LL(0xd21ec2db3790a3d0), LL(0x8a95ebceef87fdfb),
    LL(0x2f32e9ec3c4426b2), LL(0x4f23f71d516d0e78), LL(0x467e8b14242b1367), LL(0x0d3a98031461f699),
    LL(0x52ee840fc1b43378), LL(0x3b9cea93b5540c12), LL(0x358ea18b1078cc5a), LL(0x2d3c4e0ab00a4a24),
    LL(0x8ed24f2e64908a34), LL(0x2417753395d9b629), LL(0xe78d05c5298fbf4a), LL(0x8e1af144ab2eca52),
};

static const u64 C4[DIM_256] = 
{
    LL(0xc26c6a54d3ce9ec4), LL(0x1ccb2ff880589cda), LL(0xa6b316e07af43523), LL(0xb027249a096602d9),
    LL(0xc1d87b5e52e3b6e4), LL(0x1bc2653097bccd1a), LL(0xa6a2d0576c246b5e), LL(0x4ab39eeddf1cdc4d),
    LL(0xe6605a71c0ddaf4d), LL(0xdefaf534142aa6c6), LL(0xe447be8e76a59416), LL(0xa11c764646c05c19),
    LL(0xd0db159ac483b18d), LL(0xe0fc374049b944c9), LL(0x72b2542b4b420414), LL(0xa55e0490deb54b9d),
    LL(0xb2a6c54eb25c8dfe), LL(0xded0ef051c0e50a4), LL(0x7090651c42e9807e), LL(0x21777994c9900388),
    LL(0x7bf4c79e1a5dcba9), LL(0x4a8c73b2ce9089bc), LL(0x15a041cf7b7e86dd), LL(0x922d60b168629eda),
    LL(0x0125c0526b4fb40d), LL(0x39e017a637352ca2), LL(0x6af01f96f4e097e3), LL(0x362b47c40952cc55),
    LL(0xf89609a572b93cfc), LL(0x7c58224f43edab28), LL(0x5239a2a71b881270), LL(0xf4a6341b710c789b),
    LL(0x98f76caa7077214d), LL(0x8606026f9bab86c2), LL(0x9d81a7ee1564c862), LL(0x0c7d16ce3b62f7a2),
    LL(0xc826ad415aa5a288), LL(0x6e02f91814135356), LL(0xdc1d4826e4ddcdd0), LL(0x01dc26931f38f693),
    LL(0x1b426617ee445c5f), LL(0xa00266b78b41e22d), LL(0x2e2b9304f08ac89e), LL(0x1b6b995004cfe094),
    LL(0x2a8e7a4cc06f7da2), LL(0xe510152256db02f4), LL(0x93f8489e4e94bd56), LL(0xff1b7cfc49d48918),
    LL(0xfce032a7675c9e65), LL(0xf05cbb04b1d76be5), LL(0xbeac9be59b96546e), LL(0x015b4a98d65648e9),
    LL(0x56cf3fc482c464f0), LL(0xb6da1ec6f20ce53d), LL(0xe68128c1a2a406a0), LL(0xcf8d7d9d2ed00aae),
    LL(0xda751e8d10019f24), LL(0xc9c718e0566ae9fd), LL(0x1ab9ed7cea571210), LL(0x98983b4e19e3c003),
    LL(0xb30e2a47056cf712), LL(0xd52835544c5a2342), LL(0x629bd966c0f31fb7), LL(0x73242490e01695d4),
    LL(0xeb73dca7da308c4f), LL(0xe296286a9258c44f), LL(0x1ce4091a251204ec), LL(0x765284497172a4c2),
    LL(0x09f33260cbcd6bb6), LL(0x82eccb053be3238b), LL(0xcbefbff2ee092101), LL(0xf76c445fe1f5c468),
    LL(0xd7a117581785cb3a), LL(0x02d34e6d46806632), LL(0x168c47631f2605bd), LL(0xe5933ff2afcc4865),
    LL(0xcce1f4aad0b4ddf4), LL(0xf5343c82eae71b06), LL(0x13b3f97a18edcf70), LL(0xb0d10a9fda43a1c1),
    LL(0x1ef460a8580ba938), LL(0x8128a8f257ee7c5c), LL(0x251f4e2b53b4fe41), LL(0x9836b3e87e4176d9),
    LL(0x62c8fc96fa608856), LL(0x01ace53094cc32d7), LL(0x424bfeb1aa887bdc), LL(0x3e7d1f106d088653),
    LL(0x8632c5e4db7bdff8), LL(0x01f818ee78f15672), LL(0x68de38fc589a149a), LL(0x68ae8f37dba53814),
    LL(0x0dcd72b4aa35eaba), LL(0x1c28ccdbfd9adb7f), LL(0x8fa4a00e78bcc298), LL(0xf1799116087f94d5),
    LL(0x762aebdf9e542b51), LL(0x3e3dc74a18e8e5f1), LL(0x64a9884e0e5a06a2), LL(0xa28eb7467e553cc0),
    LL(0xc4afe605e6cc16a3), LL(0xad38b63b67342403), LL(0xcc562c99bc11e20e), LL(0x1140d6f7bb582b30),
    LL(0xd71e485802f474f8), LL(0xeedd371e6be480d2), LL(0xd07a10b8ca37e252), LL(0xd21ec2db3790a3d0),
    LL(0x8a95ebceef87fdfb), LL(0x2f32e9ec3c4426b2), LL(0x4f23f71d516d0e78), LL(0x467e8b14242b1367),
    LL(0x0d3a98031461f699), LL(0x52ee840fc1b43378), LL(0x3b9cea93b5540c12), LL(0x358ea18b1078cc5a),
    LL(0x2d3c4e0ab00a4a24), LL(0x8ed24f2e64908a34), LL(0x2417753395d9b629), LL(0xe78d05c5298fbf4a),
    LL(0x8e1af144ab2eca52), LL(0xc26c6a54d3ce9ec4), LL(0x1ccb2ff880589cda), LL(0xa6b316e07af43523),
    LL(0xb027249a096602d9), LL(0xc1d87b5e52e3b6e4), LL(0x1bc2653097bccd1a), LL(0xa6a2d0576c246b5e),
    LL(0x4ab39eeddf1cdc4d), LL(0xe6605a71c0ddaf4d), LL(0xdefaf534142aa6c6), LL(0xe447be8e76a59416),
    LL(0xa11c764646c05c19), LL(0xd0db159ac483b18d), LL(0xe0fc374049b944c9), LL(0x72b2542b4b420414),
    LL(0xa55e0490deb54b9d), LL(0xb2a6c54eb25c8dfe), LL(0xded0ef051c0e50a4), LL(0x7090651c42e9807e),
    LL(0xbf815bcd4a276b4b), LL(0x379fe9a0f4a0713c), LL(0x29a97f7c285b0a17), LL(0xa46e8be1dffaae85), 
    LL(0x5200acb2e03719f0), LL(0x65eebe43f12c08fe), LL(0xd2b0cf2a36fe2db7), LL(0x864f15a2b0afda61), 
    LL(0x21777994c9900388), LL(0x7bf4c79e1a5dcba9), LL(0x4a8c73b2ce9089bc), LL(0x15a041cf7b7e86dd),
    LL(0x922d60b168629eda), LL(0x0125c0526b4fb40d), LL(0x39e017a637352ca2), LL(0x6af01f96f4e097e3),
    LL(0x362b47c40952cc55), LL(0xf89609a572b93cfc), LL(0x7c58224f43edab28), LL(0x5239a2a71b881270),
    LL(0xf4a6341b710c789b), LL(0x98f76caa7077214d), LL(0x8606026f9bab86c2), LL(0x9d81a7ee1564c862),
    LL(0x0c7d16ce3b62f7a2), LL(0xc826ad415aa5a288), LL(0x6e02f91814135356), LL(0xdc1d4826e4ddcdd0),
    LL(0x01dc26931f38f693), LL(0x1b426617ee445c5f), LL(0xa00266b78b41e22d), LL(0x2e2b9304f08ac89e),
    LL(0x1b6b995004cfe094), LL(0x2a8e7a4cc06f7da2), LL(0xe510152256db02f4), LL(0x93f8489e4e94bd56),
    LL(0xff1b7cfc49d48918), LL(0xfce032a7675c9e65), LL(0xf05cbb04b1d76be5), LL(0xbeac9be59b96546e),
    LL(0x015b4a98d65648e9), LL(0x56cf3fc482c464f0), LL(0xb6da1ec6f20ce53d), LL(0xe68128c1a2a406a0),
    LL(0xcf8d7d9d2ed00aae), LL(0xda751e8d10019f24), LL(0xc9c718e0566ae9fd), LL(0x1ab9ed7cea571210),
    LL(0x98983b4e19e3c003), LL(0xb30e2a47056cf712), LL(0xd52835544c5a2342), LL(0x629bd966c0f31fb7),
    LL(0x73242490e01695d4), LL(0xeb73dca7da308c4f), LL(0xe296286a9258c44f), LL(0x1ce4091a251204ec),
    LL(0x765284497172a4c2), LL(0x09f33260cbcd6bb6), LL(0x82eccb053be3238b), LL(0xcbefbff2ee092101),
    LL(0xf76c445fe1f5c468), LL(0xd7a117581785cb3a), LL(0x02d34e6d46806632), LL(0x168c47631f2605bd),
    LL(0xe5933ff2afcc4865), LL(0xcce1f4aad0b4ddf4), LL(0xf5343c82eae71b06), LL(0x13b3f97a18edcf70),
    LL(0xb0d10a9fda43a1c1), LL(0x1ef460a8580ba938), LL(0x8128a8f257ee7c5c), LL(0x251f4e2b53b4fe41),
    LL(0x9836b3e87e4176d9), LL(0x62c8fc96fa608856), LL(0x01ace53094cc32d7), LL(0x424bfeb1aa887bdc),
    LL(0x3e7d1f106d088653), LL(0x8632c5e4db7bdff8), LL(0x01f818ee78f15672), LL(0x68de38fc589a149a),
    LL(0x68ae8f37dba53814), LL(0x0dcd72b4aa35eaba), LL(0x1c28ccdbfd9adb7f), LL(0x8fa4a00e78bcc298),
    LL(0xf1799116087f94d5), LL(0x762aebdf9e542b51), LL(0x3e3dc74a18e8e5f1), LL(0x64a9884e0e5a06a2),
    LL(0xa28eb7467e553cc0), LL(0xc4afe605e6cc16a3), LL(0xad38b63b67342403), LL(0xcc562c99bc11e20e),
    LL(0x1140d6f7bb582b30), LL(0xd71e485802f474f8), LL(0xeedd371e6be480d2), LL(0xd07a10b8ca37e252),
    LL(0xd21ec2db3790a3d0), LL(0x8a95ebceef87fdfb), LL(0x2f32e9ec3c4426b2), LL(0x4f23f71d516d0e78),
    LL(0x467e8b14242b1367), LL(0x0d3a98031461f699), LL(0x52ee840fc1b43378), LL(0x3b9cea93b5540c12),
    LL(0x358ea18b1078cc5a), LL(0x2d3c4e0ab00a4a24), LL(0x8ed24f2e64908a34), LL(0x2417753395d9b629),
    LL(0xe78d05c5298fbf4a), LL(0x8e1af144ab2eca52), LL(0xc26c6a54d3ce9ec4), LL(0x1ccb2ff880589cda),
    LL(0xa6b316e07af43523), LL(0xb027249a096602d9), LL(0xc1d87b5e52e3b6e4), LL(0x1bc2653097bccd1a),
};

static const u64 C5[DIM_256] = 
{
    LL(0xa6a2d0576c246b5e), LL(0x4ab39eeddf1cdc4d), LL(0xe6605a71c0ddaf4d), LL(0xdefaf534142aa6c6),
    LL(0xe447be8e76a59416), LL(0xa11c764646c05c19), LL(0xd0db159ac483b18d), LL(0xe0fc374049b944c9),
    LL(0x72b2542b4b420414), LL(0xa55e0490deb54b9d), LL(0xb2a6c54eb25c8dfe), LL(0xded0ef051c0e50a4),
    LL(0x7090651c42e9807e), LL(0x21777994c9900388), LL(0x7bf4c79e1a5dcba9), LL(0x4a8c73b2ce9089bc),
    LL(0x15a041cf7b7e86dd), LL(0x922d60b168629eda), LL(0x0125c0526b4fb40d), LL(0x39e017a637352ca2),
    LL(0x6af01f96f4e097e3), LL(0x362b47c40952cc55), LL(0xf89609a572b93cfc), LL(0x7c58224f43edab28),
    LL(0x5239a2a71b881270), LL(0xf4a6341b710c789b), LL(0x98f76caa7077214d), LL(0x8606026f9bab86c2),
    LL(0x9d81a7ee1564c862), LL(0x0c7d16ce3b62f7a2), LL(0xc826ad415aa5a288), LL(0x6e02f91814135356),
    LL(0xdc1d4826e4ddcdd0), LL(0x01dc26931f38f693), LL(0x1b426617ee445c5f), LL(0xa00266b78b41e22d),
    LL(0x2e2b9304f08ac89e), LL(0x1b6b995004cfe094), LL(0x2a8e7a4cc06f7da2), LL(0xe510152256db02f4),
    LL(0x93f8489e4e94bd56), LL(0xff1b7cfc49d48918), LL(0xfce032a7675c9e65), LL(0xf05cbb04b1d76be5),
    LL(0xbeac9be59b96546e), LL(0x015b4a98d65648e9), LL(0x56cf3fc482c464f0), LL(0xb6da1ec6f20ce53d),
    LL(0xe68128c1a2a406a0), LL(0xcf8d7d9d2ed00aae), LL(0xda751e8d10019f24), LL(0xc9c718e0566ae9fd),
    LL(0x1ab9ed7cea571210), LL(0x98983b4e19e3c003), LL(0xb30e2a47056cf712), LL(0xd52835544c5a2342),
    LL(0x629bd966c0f31fb7), LL(0x73242490e01695d4), LL(0xeb73dca7da308c4f), LL(0xe296286a9258c44f),
    LL(0x1ce4091a251204ec), LL(0x765284497172a4c2), LL(0x09f33260cbcd6bb6), LL(0x82eccb053be3238b),
    LL(0xcbefbff2ee092101), LL(0xf76c445fe1f5c468), LL(0xd7a117581785cb3a), LL(0x02d34e6d46806632),
    LL(0x168c47631f2605bd), LL(0xe5933ff2afcc4865), LL(0xcce1f4aad0b4ddf4), LL(0xf5343c82eae71b06),
    LL(0x13b3f97a18edcf70), LL(0xb0d10a9fda43a1c1), LL(0x1ef460a8580ba938), LL(0x8128a8f257ee7c5c),
    LL(0x251f4e2b53b4fe41), LL(0x9836b3e87e4176d9), LL(0x62c8fc96fa608856), LL(0x01ace53094cc32d7),
    LL(0x424bfeb1aa887bdc), LL(0x3e7d1f106d088653), LL(0x8632c5e4db7bdff8), LL(0x01f818ee78f15672),
    LL(0x68de38fc589a149a), LL(0x68ae8f37dba53814), LL(0x0dcd72b4aa35eaba), LL(0x1c28ccdbfd9adb7f),
    LL(0x8fa4a00e78bcc298), LL(0xf1799116087f94d5), LL(0x762aebdf9e542b51), LL(0x3e3dc74a18e8e5f1),
    LL(0x64a9884e0e5a06a2), LL(0xa28eb7467e553cc0), LL(0xc4afe605e6cc16a3), LL(0xad38b63b67342403),
    LL(0xcc562c99bc11e20e), LL(0x1140d6f7bb582b30), LL(0xd71e485802f474f8), LL(0xeedd371e6be480d2),
    LL(0xd07a10b8ca37e252), LL(0xd21ec2db3790a3d0), LL(0x8a95ebceef87fdfb), LL(0x2f32e9ec3c4426b2),
    LL(0x4f23f71d516d0e78), LL(0x467e8b14242b1367), LL(0x0d3a98031461f699), LL(0x52ee840fc1b43378),
    LL(0x3b9cea93b5540c12), LL(0x358ea18b1078cc5a), LL(0x2d3c4e0ab00a4a24), LL(0x8ed24f2e64908a34),
    LL(0x2417753395d9b629), LL(0xe78d05c5298fbf4a), LL(0x8e1af144ab2eca52), LL(0xc26c6a54d3ce9ec4),
    LL(0x1ccb2ff880589cda), LL(0xa6b316e07af43523), LL(0xb027249a096602d9), LL(0xc1d87b5e52e3b6e4),
    LL(0x1bc2653097bccd1a), LL(0xa6a2d0576c246b5e), LL(0x4ab39eeddf1cdc4d), LL(0xe6605a71c0ddaf4d),
    LL(0xdefaf534142aa6c6), LL(0xe447be8e76a59416), LL(0xa11c764646c05c19), LL(0xd0db159ac483b18d),
    LL(0xe0fc374049b944c9), LL(0x72b2542b4b420414), LL(0xa55e0490deb54b9d), LL(0xb2a6c54eb25c8dfe),
    LL(0xded0ef051c0e50a4), LL(0x7090651c42e9807e), LL(0x21777994c9900388), LL(0x7bf4c79e1a5dcba9),
    LL(0x4a8c73b2ce9089bc), LL(0x15a041cf7b7e86dd), LL(0x922d60b168629eda), LL(0x0125c0526b4fb40d),
    LL(0xbf815bcd4a276b4b), LL(0x379fe9a0f4a0713c), LL(0x29a97f7c285b0a17), LL(0xa46e8be1dffaae85),
    LL(0x5200acb2e03719f0), LL(0x65eebe43f12c08fe), LL(0xd2b0cf2a36fe2db7), LL(0x864f15a2b0afda61),
    LL(0x39e017a637352ca2), LL(0x6af01f96f4e097e3), LL(0x362b47c40952cc55), LL(0xf89609a572b93cfc),
    LL(0x7c58224f43edab28), LL(0x5239a2a71b881270), LL(0xf4a6341b710c789b), LL(0x98f76caa7077214d),
    LL(0x8606026f9bab86c2), LL(0x9d81a7ee1564c862), LL(0x0c7d16ce3b62f7a2), LL(0xc826ad415aa5a288),
    LL(0x6e02f91814135356), LL(0xdc1d4826e4ddcdd0), LL(0x01dc26931f38f693), LL(0x1b426617ee445c5f),
    LL(0xa00266b78b41e22d), LL(0x2e2b9304f08ac89e), LL(0x1b6b995004cfe094), LL(0x2a8e7a4cc06f7da2),
    LL(0xe510152256db02f4), LL(0x93f8489e4e94bd56), LL(0xff1b7cfc49d48918), LL(0xfce032a7675c9e65),
    LL(0xf05cbb04b1d76be5), LL(0xbeac9be59b96546e), LL(0x015b4a98d65648e9), LL(0x56cf3fc482c464f0),
    LL(0xb6da1ec6f20ce53d), LL(0xe68128c1a2a406a0), LL(0xcf8d7d9d2ed00aae), LL(0xda751e8d10019f24),
    LL(0xc9c718e0566ae9fd), LL(0x1ab9ed7cea571210), LL(0x98983b4e19e3c003), LL(0xb30e2a47056cf712),
    LL(0xd52835544c5a2342), LL(0x629bd966c0f31fb7), LL(0x73242490e01695d4), LL(0xeb73dca7da308c4f),
    LL(0xe296286a9258c44f), LL(0x1ce4091a251204ec), LL(0x765284497172a4c2), LL(0x09f33260cbcd6bb6),
    LL(0x82eccb053be3238b), LL(0xcbefbff2ee092101), LL(0xf76c445fe1f5c468), LL(0xd7a117581785cb3a),
    LL(0x02d34e6d46806632), LL(0x168c47631f2605bd), LL(0xe5933ff2afcc4865), LL(0xcce1f4aad0b4ddf4),
    LL(0xf5343c82eae71b06), LL(0x13b3f97a18edcf70), LL(0xb0d10a9fda43a1c1), LL(0x1ef460a8580ba938),
    LL(0x8128a8f257ee7c5c), LL(0x251f4e2b53b4fe41), LL(0x9836b3e87e4176d9), LL(0x62c8fc96fa608856),
    LL(0x01ace53094cc32d7), LL(0x424bfeb1aa887bdc), LL(0x3e7d1f106d088653), LL(0x8632c5e4db7bdff8),
    LL(0x01f818ee78f15672), LL(0x68de38fc589a149a), LL(0x68ae8f37dba53814), LL(0x0dcd72b4aa35eaba),
    LL(0x1c28ccdbfd9adb7f), LL(0x8fa4a00e78bcc298), LL(0xf1799116087f94d5), LL(0x762aebdf9e542b51),
    LL(0x3e3dc74a18e8e5f1), LL(0x64a9884e0e5a06a2), LL(0xa28eb7467e553cc0), LL(0xc4afe605e6cc16a3),
    LL(0xad38b63b67342403), LL(0xcc562c99bc11e20e), LL(0x1140d6f7bb582b30), LL(0xd71e485802f474f8),
    LL(0xeedd371e6be480d2), LL(0xd07a10b8ca37e252), LL(0xd21ec2db3790a3d0), LL(0x8a95ebceef87fdfb),
    LL(0x2f32e9ec3c4426b2), LL(0x4f23f71d516d0e78), LL(0x467e8b14242b1367), LL(0x0d3a98031461f699),
    LL(0x52ee840fc1b43378), LL(0x3b9cea93b5540c12), LL(0x358ea18b1078cc5a), LL(0x2d3c4e0ab00a4a24),
    LL(0x8ed24f2e64908a34), LL(0x2417753395d9b629), LL(0xe78d05c5298fbf4a), LL(0x8e1af144ab2eca52),
    LL(0xc26c6a54d3ce9ec4), LL(0x1ccb2ff880589cda), LL(0xa6b316e07af43523), LL(0xb027249a096602d9),
    LL(0xc1d87b5e52e3b6e4), LL(0x1bc2653097bccd1a), LL(0xa6a2d0576c246b5e), LL(0x4ab39eeddf1cdc4d),
    LL(0xe6605a71c0ddaf4d), LL(0xdefaf534142aa6c6), LL(0xe447be8e76a59416), LL(0xa11c764646c05c19),
};

static const u64 C6[DIM_256] = 
{
    LL(0xd0db159ac483b18d), LL(0xe0fc374049b944c9), LL(0x72b2542b4b420414), LL(0xa55e0490deb54b9d),
    LL(0xb2a6c54eb25c8dfe), LL(0xded0ef051c0e50a4), LL(0x7090651c42e9807e), LL(0x21777994c9900388),
    LL(0x7bf4c79e1a5dcba9), LL(0x4a8c73b2ce9089bc), LL(0x15a041cf7b7e86dd), LL(0x922d60b168629eda),
    LL(0x0125c0526b4fb40d), LL(0x39e017a637352ca2), LL(0x6af01f96f4e097e3), LL(0x362b47c40952cc55),
    LL(0xf89609a572b93cfc), LL(0x7c58224f43edab28), LL(0x5239a2a71b881270), LL(0xf4a6341b710c789b),
    LL(0x98f76caa7077214d), LL(0x8606026f9bab86c2), LL(0x9d81a7ee1564c862), LL(0x0c7d16ce3b62f7a2),
    LL(0xc826ad415aa5a288), LL(0x6e02f91814135356), LL(0xdc1d4826e4ddcdd0), LL(0x01dc26931f38f693),
    LL(0x1b426617ee445c5f), LL(0xa00266b78b41e22d), LL(0x2e2b9304f08ac89e), LL(0x1b6b995004cfe094),
    LL(0x2a8e7a4cc06f7da2), LL(0xe510152256db02f4), LL(0x93f8489e4e94bd56), LL(0xff1b7cfc49d48918),
    LL(0xfce032a7675c9e65), LL(0xf05cbb04b1d76be5), LL(0xbeac9be59b96546e), LL(0x015b4a98d65648e9),
    LL(0x56cf3fc482c464f0), LL(0xb6da1ec6f20ce53d), LL(0xe68128c1a2a406a0), LL(0xcf8d7d9d2ed00aae),
    LL(0xda751e8d10019f24), LL(0xc9c718e0566ae9fd), LL(0x1ab9ed7cea571210), LL(0x98983b4e19e3c003),
    LL(0xb30e2a47056cf712), LL(0xd52835544c5a2342), LL(0x629bd966c0f31fb7), LL(0x73242490e01695d4),
    LL(0xeb73dca7da308c4f), LL(0xe296286a9258c44f), LL(0x1ce4091a251204ec), LL(0x765284497172a4c2),
    LL(0x09f33260cbcd6bb6), LL(0x82eccb053be3238b), LL(0xcbefbff2ee092101), LL(0xf76c445fe1f5c468),
    LL(0xd7a117581785cb3a), LL(0x02d34e6d46806632), LL(0x168c47631f2605bd), LL(0xe5933ff2afcc4865),
    LL(0xcce1f4aad0b4ddf4), LL(0xf5343c82eae71b06), LL(0x13b3f97a18edcf70), LL(0xb0d10a9fda43a1c1),
    LL(0x1ef460a8580ba938), LL(0x8128a8f257ee7c5c), LL(0x251f4e2b53b4fe41), LL(0x9836b3e87e4176d9),
    LL(0x62c8fc96fa608856), LL(0x01ace53094cc32d7), LL(0x424bfeb1aa887bdc), LL(0x3e7d1f106d088653),
    LL(0x8632c5e4db7bdff8), LL(0x01f818ee78f15672), LL(0x68de38fc589a149a), LL(0x68ae8f37dba53814),
    LL(0x0dcd72b4aa35eaba), LL(0x1c28ccdbfd9adb7f), LL(0x8fa4a00e78bcc298), LL(0xf1799116087f94d5),
    LL(0x762aebdf9e542b51), LL(0x3e3dc74a18e8e5f1), LL(0x64a9884e0e5a06a2), LL(0xa28eb7467e553cc0),
    LL(0xc4afe605e6cc16a3), LL(0xad38b63b67342403), LL(0xcc562c99bc11e20e), LL(0x1140d6f7bb582b30),
    LL(0xd71e485802f474f8), LL(0xeedd371e6be480d2), LL(0xd07a10b8ca37e252), LL(0xd21ec2db3790a3d0),
    LL(0x8a95ebceef87fdfb), LL(0x2f32e9ec3c4426b2), LL(0x4f23f71d516d0e78), LL(0x467e8b14242b1367),
    LL(0x0d3a98031461f699), LL(0x52ee840fc1b43378), LL(0x3b9cea93b5540c12), LL(0x358ea18b1078cc5a),
    LL(0x2d3c4e0ab00a4a24), LL(0x8ed24f2e64908a34), LL(0x2417753395d9b629), LL(0xe78d05c5298fbf4a),
    LL(0x8e1af144ab2eca52), LL(0xc26c6a54d3ce9ec4), LL(0x1ccb2ff880589cda), LL(0xa6b316e07af43523),
    LL(0xb027249a096602d9), LL(0xc1d87b5e52e3b6e4), LL(0x1bc2653097bccd1a), LL(0xa6a2d0576c246b5e),
    LL(0x4ab39eeddf1cdc4d), LL(0xe6605a71c0ddaf4d), LL(0xdefaf534142aa6c6), LL(0xe447be8e76a59416),
    LL(0xa11c764646c05c19), LL(0xd0db159ac483b18d), LL(0xe0fc374049b944c9), LL(0x72b2542b4b420414),
    LL(0xa55e0490deb54b9d), LL(0xb2a6c54eb25c8dfe), LL(0xded0ef051c0e50a4), LL(0x7090651c42e9807e),
    LL(0x21777994c9900388), LL(0x7bf4c79e1a5dcba9), LL(0x4a8c73b2ce9089bc), LL(0x15a041cf7b7e86dd),
    LL(0x922d60b168629eda), LL(0x0125c0526b4fb40d), LL(0x39e017a637352ca2), LL(0x6af01f96f4e097e3),
    LL(0x362b47c40952cc55), LL(0xf89609a572b93cfc), LL(0x7c58224f43edab28), LL(0x5239a2a71b881270),
    LL(0xbf815bcd4a276b4b), LL(0x379fe9a0f4a0713c), LL(0x29a97f7c285b0a17), LL(0xa46e8be1dffaae85),
    LL(0x5200acb2e03719f0), LL(0x65eebe43f12c08fe), LL(0xd2b0cf2a36fe2db7), LL(0x864f15a2b0afda61),
    LL(0xf4a6341b710c789b), LL(0x98f76caa7077214d), LL(0x8606026f9bab86c2), LL(0x9d81a7ee1564c862),
    LL(0x0c7d16ce3b62f7a2), LL(0xc826ad415aa5a288), LL(0x6e02f91814135356), LL(0xdc1d4826e4ddcdd0),
    LL(0x01dc26931f38f693), LL(0x1b426617ee445c5f), LL(0xa00266b78b41e22d), LL(0x2e2b9304f08ac89e),
    LL(0x1b6b995004cfe094), LL(0x2a8e7a4cc06f7da2), LL(0xe510152256db02f4), LL(0x93f8489e4e94bd56),
    LL(0xff1b7cfc49d48918), LL(0xfce032a7675c9e65), LL(0xf05cbb04b1d76be5), LL(0xbeac9be59b96546e),
    LL(0x015b4a98d65648e9), LL(0x56cf3fc482c464f0), LL(0xb6da1ec6f20ce53d), LL(0xe68128c1a2a406a0),
    LL(0xcf8d7d9d2ed00aae), LL(0xda751e8d10019f24), LL(0xc9c718e0566ae9fd), LL(0x1ab9ed7cea571210),
    LL(0x98983b4e19e3c003), LL(0xb30e2a47056cf712), LL(0xd52835544c5a2342), LL(0x629bd966c0f31fb7),
    LL(0x73242490e01695d4), LL(0xeb73dca7da308c4f), LL(0xe296286a9258c44f), LL(0x1ce4091a251204ec),
    LL(0x765284497172a4c2), LL(0x09f33260cbcd6bb6), LL(0x82eccb053be3238b), LL(0xcbefbff2ee092101),
    LL(0xf76c445fe1f5c468), LL(0xd7a117581785cb3a), LL(0x02d34e6d46806632), LL(0x168c47631f2605bd),
    LL(0xe5933ff2afcc4865), LL(0xcce1f4aad0b4ddf4), LL(0xf5343c82eae71b06), LL(0x13b3f97a18edcf70),
    LL(0xb0d10a9fda43a1c1), LL(0x1ef460a8580ba938), LL(0x8128a8f257ee7c5c), LL(0x251f4e2b53b4fe41),
    LL(0x9836b3e87e4176d9), LL(0x62c8fc96fa608856), LL(0x01ace53094cc32d7), LL(0x424bfeb1aa887bdc),
    LL(0x3e7d1f106d088653), LL(0x8632c5e4db7bdff8), LL(0x01f818ee78f15672), LL(0x68de38fc589a149a),
    LL(0x68ae8f37dba53814), LL(0x0dcd72b4aa35eaba), LL(0x1c28ccdbfd9adb7f), LL(0x8fa4a00e78bcc298),
    LL(0xf1799116087f94d5), LL(0x762aebdf9e542b51), LL(0x3e3dc74a18e8e5f1), LL(0x64a9884e0e5a06a2),
    LL(0xa28eb7467e553cc0), LL(0xc4afe605e6cc16a3), LL(0xad38b63b67342403), LL(0xcc562c99bc11e20e),
    LL(0x1140d6f7bb582b30), LL(0xd71e485802f474f8), LL(0xeedd371e6be480d2), LL(0xd07a10b8ca37e252),
    LL(0xd21ec2db3790a3d0), LL(0x8a95ebceef87fdfb), LL(0x2f32e9ec3c4426b2), LL(0x4f23f71d516d0e78),
    LL(0x467e8b14242b1367), LL(0x0d3a98031461f699), LL(0x52ee840fc1b43378), LL(0x3b9cea93b5540c12),
    LL(0x358ea18b1078cc5a), LL(0x2d3c4e0ab00a4a24), LL(0x8ed24f2e64908a34), LL(0x2417753395d9b629),
    LL(0xe78d05c5298fbf4a), LL(0x8e1af144ab2eca52), LL(0xc26c6a54d3ce9ec4), LL(0x1ccb2ff880589cda),
    LL(0xa6b316e07af43523), LL(0xb027249a096602d9), LL(0xc1d87b5e52e3b6e4), LL(0x1bc2653097bccd1a),
    LL(0xa6a2d0576c246b5e), LL(0x4ab39eeddf1cdc4d), LL(0xe6605a71c0ddaf4d), LL(0xdefaf534142aa6c6),
    LL(0xe447be8e76a59416), LL(0xa11c764646c05c19), LL(0xd0db159ac483b18d), LL(0xe0fc374049b944c9),
    LL(0x72b2542b4b420414), LL(0xa55e0490deb54b9d), LL(0xb2a6c54eb25c8dfe), LL(0xded0ef051c0e50a4),
};

static const u64 C7[DIM_256] = 
{
    LL(0x7090651c42e9807e), LL(0x21777994c9900388), LL(0x7bf4c79e1a5dcba9), LL(0x4a8c73b2ce9089bc),
    LL(0x15a041cf7b7e86dd), LL(0x922d60b168629eda), LL(0x0125c0526b4fb40d), LL(0x39e017a637352ca2),
    LL(0x6af01f96f4e097e3), LL(0x362b47c40952cc55), LL(0xf89609a572b93cfc), LL(0x7c58224f43edab28),
    LL(0x5239a2a71b881270), LL(0xf4a6341b710c789b), LL(0x98f76caa7077214d), LL(0x8606026f9bab86c2),
    LL(0x9d81a7ee1564c862), LL(0x0c7d16ce3b62f7a2), LL(0xc826ad415aa5a288), LL(0x6e02f91814135356),
    LL(0xdc1d4826e4ddcdd0), LL(0x01dc26931f38f693), LL(0x1b426617ee445c5f), LL(0xa00266b78b41e22d),
    LL(0x2e2b9304f08ac89e), LL(0x1b6b995004cfe094), LL(0x2a8e7a4cc06f7da2), LL(0xe510152256db02f4),
    LL(0x93f8489e4e94bd56), LL(0xff1b7cfc49d48918), LL(0xfce032a7675c9e65), LL(0xf05cbb04b1d76be5),
    LL(0xbeac9be59b96546e), LL(0x015b4a98d65648e9), LL(0x56cf3fc482c464f0), LL(0xb6da1ec6f20ce53d),
    LL(0xe68128c1a2a406a0), LL(0xcf8d7d9d2ed00aae), LL(0xda751e8d10019f24), LL(0xc9c718e0566ae9fd),
    LL(0x1ab9ed7cea571210), LL(0x98983b4e19e3c003), LL(0xb30e2a47056cf712), LL(0xd52835544c5a2342),
    LL(0x629bd966c0f31fb7), LL(0x73242490e01695d4), LL(0xeb73dca7da308c4f), LL(0xe296286a9258c44f),
    LL(0x1ce4091a251204ec), LL(0x765284497172a4c2), LL(0x08f2315fcacc6ab5), LL(0x81ebca043ae2228a),
    LL(0xcaeebef1ed080c0e), LL(0xf66b435ee0f4c367), LL(0xd6a016571684ca39), LL(0x01d24d6c457f6531),
    LL(0x158b46621e2504bc), LL(0xe4923ef1aecb4764), LL(0xcbe0f3a9cfb3dcf3), LL(0xf4333b81e9e61a05),
    LL(0x12b2f87917ecce6f), LL(0xafd0099ed942a0c0), LL(0x1df35fa7570aa837), LL(0x8027a7f156ed7b5b),
    LL(0x241e4d2a52b3fd40), LL(0x9735b2e77d4075d8), LL(0x61c7fb95f95f8755), LL(0x01abe42f93cb31d6),
    LL(0x414afdb0a9877adb), LL(0x3d7c1e0f6c078552), LL(0x8531c4e3da7adef7), LL(0x01f717ed77f05571),
    LL(0x67dd37fb57991399), LL(0x67ad8e36daa43713), LL(0x0ccc71b3a934e9b9), LL(0x1b27cbdafc99da7e),
    LL(0x8ea39f0d77bbc197), LL(0xf0789015077e93d4), LL(0x7529eade9d532a50), LL(0x3d3cc64917e7e4f0),
    LL(0x62a7864c0c5804a0), LL(0xa08cb5447c533abe), LL(0xc2ade403e4ca14a1), LL(0xab36b43965322201),
    LL(0xca542a97ba0fe0fe), LL(0x0f3ed4f5b956292e), LL(0xd51c465608f272f6), LL(0xecdb351c69e27ed0),
    LL(0xce780eb6c835e050), LL(0xd01cc0d9358ea1ce), LL(0x8893e9cced85fbf9), LL(0x2d30e7ea3a4224b0),
    LL(0x4d21f51b4f6b0c76), LL(0x447c891222291165), LL(0x0b389601125ff497), LL(0x50ec820dbfb23176),
    LL(0x399ae891b3520a10), LL(0x338c9f890e76ca58), LL(0x2b3a4c08ae084822), LL(0x8cd04d2c628e8832),
    LL(0x2215733193d7b427), LL(0xe58b03c3278dbd48), LL(0x8c18ef42a92cc850), LL(0xc06a6852d1cc9cc2),
    LL(0x1ac92df67e569ad8), LL(0xa4b114de78f23321), LL(0xae25229807640cd7), LL(0xbfd6795c50e1b4e2),
    LL(0x56072c7174d986d1), LL(0x053f9d5aa37df8f7), LL(0x63f17b337441a5b8), LL(0x6fa093de5599ed8b),
    LL(0xaf6877a57f8b6fb7), LL(0xf1fc63214366b3b7), LL(0x6cfdc5e1c66b533e), LL(0x3dbe2245cf732cb4),
    LL(0xd3a164bde00f0d80), LL(0x4a1fade4829f278c), LL(0xff16113103ccc4cb), LL(0x7107708133b435eb),
    LL(0x6b91076d38e3ddad), LL(0xa9e50fedeb32537d), LL(0xe66da3654bbf181d), LL(0xa4b9f246758b50a2),
    LL(0xff4de683ebf5b625), LL(0xc03f07a0c1770966), LL(0xcb5053b565839583), LL(0xc79a2b89edc6598a),
    LL(0xbd15dc3335db0d39), LL(0xa1c1dcf7c5912430), LL(0x198772c5fc9799ba), LL(0xbd4fdbab07960181),
    LL(0xcbc807fc0b4db34f), LL(0x7b0227e9fb0da8d7), LL(0xe91bdd2436499750), LL(0xfb1469b1319df6ab),
    LL(0xdb2f13920ed706ad), LL(0x4abb56cd5f39f1ae), LL(0x79e7e3b1db0d796b), LL(0x87d9824f3f5ed5c2),
    LL(0xbf815bcd4a276b4b), LL(0x379fe9a0f4a0713c), LL(0x29a97f7c285b0a17), LL(0xa46e8be1dffaae85),
    LL(0x5200acb2e03719f0), LL(0x65eebe43f12c08fe), LL(0xd2b0cf2a36fe2db7), LL(0x864f15a2b0afda61),
    LL(0x95bdbb4a5458046b), LL(0x0bc0bdc9fd8a106d), LL(0x99395bc35e31bbc2), LL(0x345337f88729a9bc),
    LL(0x53e485a5b86fefb8), LL(0xdbafa865222d27cf), LL(0xd0262c85944139e9), LL(0x4b3803dd795f2499),
    LL(0xd3fdd0b7b7718f65), LL(0xf0553b53df5901d3), LL(0x039fbfa91ee9ba35), LL(0xc3330fcb1c95834b),
    LL(0x715bf371ae140369), LL(0xcb75f2732fd5cd01), LL(0xc7812b2bfb9fb512), LL(0x1f0d83bde9f95543),
    LL(0x53bfffe737298ff5), LL(0xbbb72b422fc5079f), LL(0x0289ad545c15cff9), LL(0xc3ee2bfdcb4199d9),
    LL(0x9efcabc51be00c16), LL(0x070ef419a724ef85), LL(0x296538573648b130), LL(0x54839f12dc253ccf),
    LL(0xdac532b94d3fe613), LL(0xcf848c1b3d30ca14), LL(0x66219d7555f3b6b9), LL(0xc46c49747771a934),
    LL(0x57cb55e1bfdd35cc), LL(0xb531384f643bedc9), LL(0xf3db01ecf2f70dcf), LL(0x5ea0af5dce969c7f),
    LL(0x4b7dfe38e01e0e24), LL(0xc6faba4b3b90fe86), LL(0x52618192609c1da5), LL(0x26d05af1ba74c2e3),
    LL(0xc302fbaca36d279f), LL(0x57bbbc6e481b689e), LL(0xf0720a7358c9d592), LL(0xc14e35cf4591eaa9),
    LL(0xc2eb91275704748d), LL(0x0146fa1f9d9c8605), LL(0x3102e5fa27de12ac), LL(0x0d1327d76fd63c07),
    LL(0xd8ffeff1e6bd8f8b), LL(0x34e26de672738df8), LL(0x873d5a4755ec9588), LL(0xa1db7b7d859fcfbd),
    LL(0x54ab8ce34b03a112), LL(0xf1f6fd24098fd65b), LL(0x392c6e7b644f054e), LL(0x05dd64db7e361e77),
    LL(0x9c1f4f3517309559), LL(0xc79d8fcb8ff9c7cd), LL(0xc71d7a169298d703), LL(0x2cd01993a5b4a9c9),
    LL(0x2ba73b1650a1c62a), LL(0x2e5f4f651bd30177), LL(0x14ac78e5135633cc), LL(0x25996e5abd738a9c),
    LL(0x1d6c72511fef78c4), LL(0xeb641f25ad2505c9), LL(0xe1ddb265ed784bbf), LL(0x235e5d70e57be9a2),
    LL(0xd01f35c6b2933b46), LL(0xb325fb0c7b50c1bf), LL(0x84973d3e76bf96df), LL(0x237afc1c6e546008),
    LL(0xde1921ba7d24bebe), LL(0xbcc610fceaef323c), LL(0x367ae2f5a54863ec), LL(0x9a47572a81a9bbff),
    LL(0x9f427b98a4f6ac26), LL(0x058b43352d4dba58), LL(0x72c633ded0e5c3b7), LL(0x833078fb62d132a1),
    LL(0x92c2f87df1548fc8), LL(0xe5e20a79ed8c5662), LL(0xad9e01b7262a3c1a), LL(0x1d447e4e2c6a5a84),
    LL(0xc6920152fa509a3c), LL(0xca495b2dc1f3debf), LL(0x47199f07699befa6), LL(0x7640b194f5c6ca42),
    LL(0x01bcea5039662e14), LL(0xd0351750f6f05656), LL(0x76b126783ec013a1), LL(0xd0d9d09641222e41),
    LL(0x817c1b48b269a00e), LL(0x8f7221c8d77c3576), LL(0xf262b07bc84ccb06), LL(0xf239dea36f0ca4e1),
    LL(0x2ef2c211505735d3), LL(0xd6a013eca8826e7e), LL(0x4497ae12563d60ee), LL(0x757462fa58d43809),
    LL(0x703f75ae1835a589), LL(0x913db8411a82a59a), LL(0x4b33350c1c4335ed), LL(0x8e37a1b11f862c26),
    LL(0xc3c736ffd335e67f), LL(0x5ff1c85e15cfd105), LL(0x5151cebda34a318f), LL(0x6240e235f221c449),
    LL(0xdc3538f70be60c8a), LL(0x0bad2453cfd10a1d), LL(0x86b18a70c45fb73e), LL(0x735e11ea69836f3b),
};

static const u64 C8[DIM_256] = 
{
    LL(0x4ae63123940af50e), LL(0x72a15827407e4d73), LL(0x3b9104b795811864), LL(0x6724b8e5ba934d96),
    LL(0x3977b2ee33ba7d3d), LL(0x0df163d09c060479), LL(0xb39ae3d034c9dbc1), LL(0xb567957cb20d895c),
    LL(0xc9f86dfb91c0e256), LL(0x4767a3a04c249f33), LL(0x1e6a38ff7e2529db), LL(0x8de697ff54d30c03),
    LL(0xd9d76eca9b865371), LL(0xbf0122c12d54f417), LL(0x6d4e0957c55efed1), LL(0x01dde72c30193724),
    LL(0xfce30738cf85dd60), LL(0x515977400cca639e), LL(0xaf64542599bbd93f), LL(0xdc5c4a119d78c155),
    LL(0x4bf7dbeda108ce73), LL(0x6e9106e377a48395), LL(0x94f9f95fefd5f657), LL(0x3854ad7d0a952a19),
    LL(0xad95d55752f3996b), LL(0x9f7547d7b49a17b5), LL(0x71737c231b6fabe3), LL(0xa721190d919d1bd0),
    LL(0x1d9d4f9b132fe3a5), LL(0x99d5ed550d6f5749), LL(0x31f76d70d53335b9), LL(0x2485b19e4ceba50b),
    LL(0x01ccd1813de5810f), LL(0x14328ddbf1a06a34), LL(0xc502a76f8dd2e5a7), LL(0x49133e934c22810e),
    LL(0x3c2541b7b77906b5), LL(0x041b381365d9e753), LL(0xcd30455d03d65fca), LL(0xbf27518f77695ed3),
    LL(0x28e0c7a24d293f4e), LL(0x794d330c1d474512), LL(0xf91f1fd11307193f), LL(0xb9d7475d4ae1f99d),
    LL(0x703e7563efb20c1b), LL(0x671d77315a3b4368), LL(0xc3bfb76fa90374f0), LL(0x7f43278baf9f414b),
    LL(0x1db79b352bbbadef), LL(0xbbe9995b592b1f1d), LL(0x8f22de33147db9a6), LL(0xb5f1afcb644f63f0),
    LL(0xa34c6d09e787b86b), LL(0xf0b6a3a1d51a180e), LL(0x3e6f129907c35137), LL(0x8967d2a7152ba2e1),
    LL(0x354f496f1dff4337), LL(0x36fd3175262df623), LL(0xe8458d33d20b61ba), LL(0xe35b3097af0d3574),
    LL(0xd9daa3c34e971d23), LL(0x037322da4d65dd7f), LL(0xdd5785abd92d5b03), LL(0x7698d2ec16dd2dcb),
    LL(0xadfea44d49c316df), LL(0x1195718397e84d5f), LL(0x57b5898fb1c97e64), LL(0x17194b0614bf971f),
    LL(0x8c23ef03e2dc817d), LL(0xdf4fb7c33f3f974b), LL(0xae2cbb5f661d39e7), LL(0xbf83fe69bcf073fe),
    LL(0x911521375d131af5), LL(0x8d38936f7d8d5753), LL(0x293189bf6d1ecdbf), LL(0x1901efc5e9a3ff87),
    LL(0x334a2fa16d6778aa), LL(0x3b255d4fcb23c5c9), LL(0x7969ffd3d348f117), LL(0x0b11a38c436507cb),
    LL(0x1c0b91c9176b49a7), LL(0x4dfa072b1f0b22a7), LL(0x253f97e9a10a3122), LL(0xd30b192351e38a9d),
    LL(0xb959803b63e3df0c), LL(0x43767452b4bf87d4), LL(0xd81b8d7d5f097414), LL(0x6c0663638ac2078b),
    LL(0x3623347331755441), LL(0x3ee0261c75f0819c), LL(0x1a9de64405241bb6), LL(0x6552fd31e9f3e006),
    LL(0x01648204ee668e0e), LL(0xdefecab8fd3c4e5c), LL(0xf552a62abbc04ec2), LL(0x4303ac3815c5f318),
    LL(0xc6ab9d683a4e56a6), LL(0x1790b6d2c46ea2e8), LL(0x9eca67b8a978b398), LL(0x0a38da80b4cacae8),
    LL(0xaca20a985984a8d1), LL(0x6d22371daec475d2), LL(0x3db603d003684568), LL(0xbcceece13abc4736),
    LL(0xa2140af66370a45f), LL(0x6eeb52ad449410ae), LL(0x4e4beac4266a6ed6), LL(0x406b92e892c56a96),
    LL(0x93dc3c481112ea6d), LL(0x0cc571ecf67e130b), LL(0x1ad033ccf7120c17), LL(0x75eeeca3192e2e37),
    LL(0x86292eee288571da), LL(0x3a443112b007a860), LL(0x018eda6073e892fa), LL(0xd6eab68a78ff24c6),
    LL(0x4bcc4a02e2e89da2), LL(0x311eb3b9169a354f), LL(0xc44af706409aab32), LL(0x81c8863d4024bab3),
    LL(0xf84164807a400e10), LL(0x46df6c82843f7e9f), LL(0x88da41e8641a4af2), LL(0x9a5e713462eed965),
    LL(0x8a4233420dfcce5f), LL(0x227c92aa8c6b6666), LL(0x348bacf1be70e6a8), LL(0x08cf0c061ef247b0),
    LL(0x2e606a719bde0c15), LL(0x6c697eca2edcfb9a), LL(0xe0bc30831fb269ee), LL(0x3f027fd6463e7ec9),
    LL(0xee0e18227ece1038), LL(0x506a871ee48b6609), LL(0xee52d2c137bd61f0), LL(0x34b102baea7f41c2),
    LL(0x460e040627de0ceb), LL(0x2170d43574cede91), LL(0xe42f0e34ad7ea439), LL(0xd07a2da2991e302c),
    LL(0xbf815bcd4a276b4b), LL(0x379fe9a0f4a0713c), LL(0x29a97f7c285b0a17), LL(0xa46e8be1dffaae85),
    LL(0x5200acb2e03719f0), LL(0x65eebe43f12c08fe), LL(0xd2b0cf2a36fe2db7), LL(0x864f15a2b0afda61),
    LL(0xea02069f0efbd303), LL(0xe5f29d7713d97ef3), LL(0x0d17aad151aba9ff), LL(0x0a6f156d7973fbed),
    LL(0xfd9999c33803544f), LL(0x1d0d29c5362f9d85), LL(0x0bb56d8bc82e7d63), LL(0xe50f4cad292f67db),
    LL(0x01bbc5051539cfac), LL(0xb9477d574313ef1d), LL(0x6dd999815143496f), LL(0xd5f105dc495fa1f9),
    LL(0xdc8327ae962fe9d3), LL(0x5d884577a5bb53f3), LL(0xb81685df351a7ab0), LL(0x29fc2963e1d699e3),
    LL(0xb917522bc0ae1132), LL(0x5c617da529a13209), LL(0x700f4c9fa5e57d83), LL(0xb1682b5997aaedfe),
    LL(0x653bb99bb31dfedf), LL(0xb0c8aba64129b35a), LL(0xb5c9575e413355a6), LL(0xc1a3594dfdff51f3),
    LL(0x4defdb930acdb161), LL(0x4ce20977458a5cf3), LL(0x3f8ddd97a6f99130), LL(0xc16db5772d0528dc),
    LL(0xbcecc098e40462e4), LL(0xb28c88d658107270), LL(0x8cbe5210b264f056), LL(0x60f7871095266637),
    LL(0x92660c1ce5685ca9), LL(0x4c853e5290e0b194), LL(0x69fb8cea0ef339a5), LL(0x77bc63e2909896a0),
    LL(0xda3c0fe48ee813fe), LL(0xde48dad8deac680e), LL(0xb7fe428e2ff69b8c), LL(0x5df262b0a7a0d61f),
    LL(0x98a035ecd42a0aa9), LL(0x6e67b848ab2ce2a8), LL(0x10882727b2ca92fc), LL(0x12749a782e729818),
    LL(0x73cdc789fba242c8), LL(0xc21b79323640abf4), LL(0xce9ad6486c7de2e4), LL(0xac4aae84161ecbb1),
    LL(0x6ccee85b798c6cd4), LL(0x6150f458dff116f2), LL(0xedc9bd90ba130c04), LL(0x90d951f7a5e5a359),
    LL(0x9ed6aa27ade8959e), LL(0x271bb8541fd56cb6), LL(0xff6e4cc39161622e), LL(0x5dde31b70f3f277b),
    LL(0x831facc76f020de1), LL(0x05602fca077d53c4), LL(0x5a515760cc754d10), LL(0xe5673db61df2a361),
    LL(0x2e296f30f0f1f0e1), LL(0xd03791c13bd5ad39), LL(0xefb60cb71085bd0b), LL(0x097331212b48a327),
    LL(0x7b372310d4a14469), LL(0xcb7a24e7944c3ae4), LL(0x30738ea5ad29737b), LL(0xfc94f0ee6a4ec759),
    LL(0xffaf7ca9dda09428), LL(0x3a6779947162cf4a), LL(0xf3774dac42154c39), LL(0x90694ba0c665a1d3),
    LL(0xc6cf82447d5dcdfb), LL(0x2eedcf7309eb8b05), LL(0x9f733457d131cbe5), LL(0xb1fc82284e0ea796),
    LL(0xc8063acaca084063), LL(0xffa7920540ffeb53), LL(0x3f2d8bade09fdf85), LL(0x1e0f8da628c6d0b4),
    LL(0x3c736c4eacbe9563), LL(0x36c38ef4570aecb7), LL(0x27aa812298bb7a9e), LL(0x5df8ff9e7d22ab94),
    LL(0xf00896a9e642b1fc), LL(0xe88b8455b512daef), LL(0x649c387796518725), LL(0x6c321502b6d8a494),
    LL(0x2a5db4063c135e44), LL(0x03caa04802e2560f), LL(0xd6ed5bbca61f73e7), LL(0x12f2bd6683414243),
    LL(0x5eb87209c5289640), LL(0xf50a0ebed4efa955), LL(0xbc54e706a0481904), LL(0x243e5b1150649622),
    LL(0x4ee655aa08e77208), LL(0x573f6922e97ad95e), LL(0x392ae92a9c158107), LL(0x60faa54034060ffa),
    LL(0x376aa95de3dcd85b), LL(0xa182655d93497ff9), LL(0x5b188df329b0f7b8), LL(0x65133ac199af53e3),
    LL(0x0ba78a3dabb7b23e), LL(0xcbbf54cb0ef5a7d8), LL(0x1b25f7bf45045f5f), LL(0x4538254a0b5d3359),
};

static const u64 rc[R + 1] = 
{
    LL(0xf13805a50beb1c61),
    LL(0x679953da94f7f14e),
    LL(0xad0297fbb771b44f),
    LL(0x99a579c408efd60f),
    LL(0x98c710a7cbf76786),
    LL(0x4713f1636befb5a1),
    LL(0xa16b40135d3467ce),
    LL(0x9f6b77a6a4b62aa9),
    LL(0xc5f23bfb13d8025b),
    LL(0xefa759b37887197c),
    LL(0x4ab91d3e9d47b72a),
};

/**
 * The core Whirlpool transform.
 */
static void processBuffer(struct NESSIEstruct* structpointer) 
{
    int i, r; u64 K[DIM_8]; /* The round key */
    u64 block[DIM_8];       /* mu(buffer) */
    u64 state[DIM_8];       /* The algorithm state */
    u64 L[DIM_8]; byte *buffer = structpointer->buffer;

    // Map the buffer to a block:
    for (i = 0; i < 8; i++, buffer += 8)
	{
        block[i] =
            (((u64)buffer[0]        ) << 56) ^
            (((u64)buffer[1] & MASQUE_CTR) << 48) ^
            (((u64)buffer[2] & MASQUE_CTR) << 40) ^
            (((u64)buffer[3] & MASQUE_CTR) << 32) ^
            (((u64)buffer[4] & MASQUE_CTR) << 24) ^
            (((u64)buffer[5] & MASQUE_CTR) << 16) ^
            (((u64)buffer[6] & MASQUE_CTR) <<  8) ^
            (((u64)buffer[7] & MASQUE_CTR)      );
    }
    /*
     * Compute and apply K^0 to the algorithm state:
     */
    state[0] = block[0] ^ (K[0] = structpointer->hash[0]);
    state[1] = block[1] ^ (K[1] = structpointer->hash[1]);
    state[2] = block[2] ^ (K[2] = structpointer->hash[2]);
    state[3] = block[3] ^ (K[3] = structpointer->hash[3]);
    state[4] = block[4] ^ (K[4] = structpointer->hash[4]);
    state[5] = block[5] ^ (K[5] = structpointer->hash[5]);
    state[6] = block[6] ^ (K[6] = structpointer->hash[6]);
    state[7] = block[7] ^ (K[7] = structpointer->hash[7]);
    /*
     * Iterate over all rounds:
     */
    for (r = 1; r <= R; r++) 
	{
        /*
         * Compute K^r from K^{r-1}:
         */
        L[0] =
            C1[(int)(K[0] >> 56)       ] ^
            C2[(int)(K[7] >> 48) & MASQUE_CTR] ^
            C3[(int)(K[6] >> 40) & MASQUE_CTR] ^
            C4[(int)(K[5] >> 32) & MASQUE_CTR] ^
            C6[(int)(K[4] >> 24) & MASQUE_CTR] ^
            C6[(int)(K[3] >> 16) & MASQUE_CTR] ^
            C7[(int)(K[2] >>  8) & MASQUE_CTR] ^
            C8[(int)(K[1]      ) & MASQUE_CTR] ^
            rc[r];
        L[1] =
            C1[(int)(K[1] >> 56)       ] ^
            C2[(int)(K[0] >> 48) & MASQUE_CTR] ^
            C3[(int)(K[7] >> 40) & MASQUE_CTR] ^
            C4[(int)(K[6] >> 32) & MASQUE_CTR] ^
            C5[(int)(K[5] >> 24) & MASQUE_CTR] ^
            C6[(int)(K[4] >> 16) & MASQUE_CTR] ^
            C7[(int)(K[3] >>  8) & MASQUE_CTR] ^
            C8[(int)(K[2]      ) & MASQUE_CTR];
        L[2] =
            C1[(int)(K[2] >> 56)       ] ^
            C2[(int)(K[1] >> 48) & MASQUE_CTR] ^
            C3[(int)(K[0] >> 40) & MASQUE_CTR] ^
            C4[(int)(K[7] >> 32) & MASQUE_CTR] ^
            C5[(int)(K[6] >> 24) & MASQUE_CTR] ^
            C6[(int)(K[5] >> 16) & MASQUE_CTR] ^
            C7[(int)(K[4] >>  8) & MASQUE_CTR] ^
            C8[(int)(K[3]      ) & MASQUE_CTR];
        L[3] =
            C1[(int)(K[3] >> 56)       ] ^
            C2[(int)(K[2] >> 48) & MASQUE_CTR] ^
            C3[(int)(K[1] >> 40) & MASQUE_CTR] ^
            C4[(int)(K[0] >> 32) & MASQUE_CTR] ^
            C5[(int)(K[7] >> 24) & MASQUE_CTR] ^
            C6[(int)(K[6] >> 16) & MASQUE_CTR] ^
            C7[(int)(K[5] >>  8) & MASQUE_CTR] ^
            C8[(int)(K[4]      ) & MASQUE_CTR];
        L[4] =
            C1[(int)(K[4] >> 56)       ] ^
            C2[(int)(K[3] >> 48) & MASQUE_CTR] ^
            C3[(int)(K[2] >> 40) & MASQUE_CTR] ^
            C4[(int)(K[1] >> 32) & MASQUE_CTR] ^
            C5[(int)(K[0] >> 24) & MASQUE_CTR] ^
            C6[(int)(K[7] >> 16) & MASQUE_CTR] ^
            C7[(int)(K[6] >>  8) & MASQUE_CTR] ^
            C8[(int)(K[5]      ) & MASQUE_CTR];
        L[5] =
            C1[(int)(K[5] >> 56)       ] ^
            C2[(int)(K[4] >> 48) & MASQUE_CTR] ^
            C3[(int)(K[3] >> 40) & MASQUE_CTR] ^
            C4[(int)(K[2] >> 32) & MASQUE_CTR] ^
            C5[(int)(K[1] >> 24) & MASQUE_CTR] ^
            C6[(int)(K[0] >> 16) & MASQUE_CTR] ^
            C7[(int)(K[7] >>  8) & MASQUE_CTR] ^
            C8[(int)(K[6]      ) & MASQUE_CTR];
        L[6] =
            C1[(int)(K[6] >> 56)       ] ^
            C2[(int)(K[5] >> 48) & MASQUE_CTR] ^
            C3[(int)(K[4] >> 40) & MASQUE_CTR] ^
            C4[(int)(K[3] >> 32) & MASQUE_CTR] ^
            C5[(int)(K[2] >> 24) & MASQUE_CTR] ^
            C6[(int)(K[1] >> 16) & MASQUE_CTR] ^
            C7[(int)(K[0] >>  8) & MASQUE_CTR] ^
            C8[(int)(K[7]      ) & MASQUE_CTR];
        L[7] =
            C1[(int)(K[7] >> 56)       ] ^
            C2[(int)(K[6] >> 48) & MASQUE_CTR] ^
            C3[(int)(K[5] >> 40) & MASQUE_CTR] ^
            C4[(int)(K[4] >> 32) & MASQUE_CTR] ^
            C5[(int)(K[3] >> 24) & MASQUE_CTR] ^
            C6[(int)(K[2] >> 16) & MASQUE_CTR] ^
            C7[(int)(K[1] >>  8) & MASQUE_CTR] ^
            C8[(int)(K[0]      ) & MASQUE_CTR];
        K[0] = L[0];
        K[1] = L[1];
        K[2] = L[2];
        K[3] = L[3];
        K[4] = L[4];
        K[5] = L[5];
        K[6] = L[6];
        K[7] = L[7];
        /*
         * apply the r-th round transformation:
         */
        L[0] =
            C1[(int)(state[0] >> 56)       ] ^
            C2[(int)(state[7] >> 48) & MASQUE_CTR] ^
            C3[(int)(state[6] >> 40) & MASQUE_CTR] ^
            C4[(int)(state[5] >> 32) & MASQUE_CTR] ^
            C5[(int)(state[4] >> 24) & MASQUE_CTR] ^
            C6[(int)(state[3] >> 16) & MASQUE_CTR] ^
            C7[(int)(state[2] >>  8) & MASQUE_CTR] ^
            C8[(int)(state[1]      ) & MASQUE_CTR] ^
            K[0];
        L[1] =
            C1[(int)(state[1] >> 56)       ] ^
            C2[(int)(state[0] >> 48) & MASQUE_CTR] ^
            C3[(int)(state[7] >> 40) & MASQUE_CTR] ^
            C4[(int)(state[6] >> 32) & MASQUE_CTR] ^
            C5[(int)(state[5] >> 24) & MASQUE_CTR] ^
            C6[(int)(state[4] >> 16) & MASQUE_CTR] ^
            C7[(int)(state[3] >>  8) & MASQUE_CTR] ^
            C8[(int)(state[2]      ) & MASQUE_CTR] ^
            K[1];
        L[2] =
            C1[(int)(state[2] >> 56)       ] ^
            C2[(int)(state[1] >> 48) & MASQUE_CTR] ^
            C3[(int)(state[0] >> 40) & MASQUE_CTR] ^
            C4[(int)(state[7] >> 32) & MASQUE_CTR] ^
            C5[(int)(state[6] >> 24) & MASQUE_CTR] ^
            C6[(int)(state[5] >> 16) & MASQUE_CTR] ^
            C7[(int)(state[4] >>  8) & MASQUE_CTR] ^
            C8[(int)(state[3]      ) & MASQUE_CTR] ^
            K[2];
        L[3] =
            C1[(int)(state[3] >> 56)       ] ^
            C2[(int)(state[2] >> 48) & MASQUE_CTR] ^
            C3[(int)(state[1] >> 40) & MASQUE_CTR] ^
            C4[(int)(state[0] >> 32) & MASQUE_CTR] ^
            C5[(int)(state[7] >> 24) & MASQUE_CTR] ^
            C6[(int)(state[6] >> 16) & MASQUE_CTR] ^
            C7[(int)(state[5] >>  8) & MASQUE_CTR] ^
            C8[(int)(state[4]      ) & MASQUE_CTR] ^
            K[3];
        L[4] =
            C1[(int)(state[4] >> 56)       ] ^
            C2[(int)(state[3] >> 48) & MASQUE_CTR] ^
            C3[(int)(state[2] >> 40) & MASQUE_CTR] ^
            C4[(int)(state[1] >> 32) & MASQUE_CTR] ^
            C5[(int)(state[0] >> 24) & MASQUE_CTR] ^
            C6[(int)(state[7] >> 16) & MASQUE_CTR] ^
            C7[(int)(state[6] >>  8) & MASQUE_CTR] ^
            C8[(int)(state[5]      ) & MASQUE_CTR] ^
            K[4];
        L[5] =
            C1[(int)(state[5] >> 56)       ] ^
            C2[(int)(state[4] >> 48) & MASQUE_CTR] ^
            C3[(int)(state[3] >> 40) & MASQUE_CTR] ^
            C4[(int)(state[2] >> 32) & MASQUE_CTR] ^
            C5[(int)(state[1] >> 24) & MASQUE_CTR] ^
            C6[(int)(state[0] >> 16) & MASQUE_CTR] ^
            C7[(int)(state[7] >>  8) & MASQUE_CTR] ^
            C8[(int)(state[6]      ) & MASQUE_CTR] ^
            K[5];
        L[6] =
            C1[(int)(state[6] >> 56)       ] ^
            C2[(int)(state[5] >> 48) & MASQUE_CTR] ^
            C3[(int)(state[4] >> 40) & MASQUE_CTR] ^
            C4[(int)(state[3] >> 32) & MASQUE_CTR] ^
            C5[(int)(state[2] >> 24) & MASQUE_CTR] ^
            C6[(int)(state[1] >> 16) & MASQUE_CTR] ^
            C7[(int)(state[0] >>  8) & MASQUE_CTR] ^
            C8[(int)(state[7]      ) & MASQUE_CTR] ^
            K[6];
        L[7] =
            C1[(int)(state[7] >> 56)       ] ^
            C2[(int)(state[6] >> 48) & MASQUE_CTR] ^
            C3[(int)(state[5] >> 40) & MASQUE_CTR] ^
            C4[(int)(state[4] >> 32) & MASQUE_CTR] ^
            C5[(int)(state[3] >> 24) & MASQUE_CTR] ^
            C6[(int)(state[2] >> 16) & MASQUE_CTR] ^
            C7[(int)(state[1] >>  8) & MASQUE_CTR] ^
            C8[(int)(state[0]      ) & MASQUE_CTR] ^
            K[7];
        state[0] = L[0];
        state[1] = L[1];
        state[2] = L[2];
        state[3] = L[3];
        state[4] = L[4];
        state[5] = L[5];
        state[6] = L[6];
        state[7] = L[7];
    }
    /*
     * apply the Miyaguchi-Preneel compression function:
     */
    structpointer->hash[0] ^= state[0] ^ block[0];
    structpointer->hash[1] ^= state[1] ^ block[1];
    structpointer->hash[2] ^= state[2] ^ block[2];
    structpointer->hash[3] ^= state[3] ^ block[3];
    structpointer->hash[4] ^= state[4] ^ block[4];
    structpointer->hash[5] ^= state[5] ^ block[5];
    structpointer->hash[6] ^= state[6] ^ block[6];
    structpointer->hash[7] ^= state[7] ^ block[7];
}

/**
 * Initialize the hashing state.
 */
void WHIRLPOOL_init(struct NESSIEstruct* structpointer) 
{
    int i;
	init0(structpointer->bitLength, DIM_32);
    structpointer->bufferBits = structpointer->bufferPos = 0;
    structpointer->buffer[0] = 0; /* it's only necessary to cleanup buffer[bufferPos] */
    for (i = 0; i < DIM_8; i++) {
        structpointer->hash[i] = 0L; /* initial value */
    }
}

/**
 * Delivers input data to the hashing algorithm.
 *
 * @param    source        text data to hash.
 * @param    sourceBits    how many bits of text to process.
 *
 * This method maintains the invariant: bufferBits < DIGESTBITS
 */
void WHIRLPOOL_add(const byte source[],
               ENTIER sourceBits,
               struct NESSIEstruct* structpointer) {
    /*
                       sourcePos
                       |
                       +-------+-------+-------
                          ||||||||||||||||||||| source
                       +-------+-------+-------
    +-------+-------+-------+-------+-------+-------
    ||||||||||||||||||||||                           buffer
    +-------+-------+-------+-------+-------+-------
                    |
                    bufferPos
    */
    int sourcePos    = 0; /* index of leftmost source byte containing data (1 to 8 bits). */
    int sourceGap    = (DIM_8 - ((int)sourceBits & 7)) & 7; /* space on source[sourcePos]. */
    int bufferRem    = structpointer->bufferBits & 7; /* occupied bits on buffer[bufferPos]. */
    int64 i;
    u32 b, carry;
    byte *buffer = structpointer->buffer;
    byte *bitLength = structpointer->bitLength;
    ENTIER bufferBits = structpointer->bufferBits;
    ENTIER bufferPos = structpointer->bufferPos;
    /*
     * Tally the length of the added data:
     */
    u64 value = sourceBits;
    for (i = DIM_32-1, carry = 0; i >= 0 && (carry != 0 || value != LL(0)); i--)
	{
        carry += bitLength[i] + ((u32)value & MASQUE_CTR);
        bitLength[i] = (byte)carry;
        carry >>= DIM_8;
        value >>= DIM_8;
    }
    /*
     * Process data in chunks of 8 bits (a more efficient approach would be to take whole-word chunks):
     */
    while (sourceBits > DIM_8)
	{
        /* N.B. at least source[sourcePos] and source[sourcePos+1] contain data. 
         *
         * Take a byte from the source:
         */
        b = ((source[sourcePos] << sourceGap) & MASQUE_CTR) |
            ((source[sourcePos + 1] & MASQUE_CTR) >> (DIM_8 - sourceGap));
        /*
         * process this byte:
         */
        buffer[bufferPos++] |= (byte)(b >> bufferRem);
        bufferBits += DIM_8 - bufferRem; // bufferBits = 8*bufferPos; 
        if (bufferBits == DIGESTBITS) 
		{
            /*
             * Process data block:
             */
            processBuffer(structpointer);
            /*
             * Reset buffer:
             */
            bufferBits = bufferPos = 0;
        }
        buffer[bufferPos] = (byte) (b << (DIM_8 - bufferRem));
        bufferBits += bufferRem;
        /*
         * proceed to remaining data:
         */
        sourceBits -= DIM_8;
        sourcePos++;
    }
    /* now 0 <= sourceBits <= 8;
     * furthermore, all data (if any is left) is in source[sourcePos].
     */
    if (sourceBits > 0) {
        b = (source[sourcePos] << sourceGap) & MASQUE_CTR; /* bits are left-justified on b. */
        /*
         * process the remaining bits:
         */
        buffer[bufferPos] |= b >> bufferRem;
    } else {
        b = 0;
    }
    if (bufferRem + sourceBits < DIM_8) {
        /*
         * all remaining data fits on buffer[bufferPos],
         * and there still remains some space.
         */
        bufferBits += sourceBits;
    } else {
        /*
         * buffer[bufferPos] is full:
         */
        bufferPos++;
        bufferBits += DIM_8 - bufferRem; // bufferBits = 8*bufferPos;
        sourceBits -= DIM_8 - bufferRem;
        /* now 0 <= sourceBits < 8;
         * furthermore, all data (if any is left) is in source[sourcePos].
         */
        if (bufferBits == DIGESTBITS)
		{
            /*
             * process data block:
             */
            processBuffer(structpointer);
            /*
             * reset buffer:
             */
            bufferBits = bufferPos = 0;
        }
        buffer[bufferPos] = (byte) (b << (DIM_8 - bufferRem));
        bufferBits += (int)sourceBits;
    }
    structpointer->bufferBits = bufferBits;
    structpointer->bufferPos = bufferPos;
}

/**
 * Get the hash value from the hashing state.
 * 
 * This method uses the invariant: bufferBits < DIGESTBITS
 */
void WHIRLPOOL_finalize(struct NESSIEstruct* structpointer,
                    const byte result[])
{
    ENTIER i; byte* buffer = structpointer->buffer;
    byte* bitLength = structpointer->bitLength;
    ENTIER bufferBits = structpointer->bufferBits;
    ENTIER bufferPos = structpointer->bufferPos;
    byte* digest = (byte*)result;

    /*
     * Append a '1'-bit:
     */
    buffer[bufferPos] |= 0x80U >> (bufferBits & 7);
    bufferPos++; /* all remaining bits on the current byte are set to zero. */
    /*
     * Pad with zero bits to complete (N*WBLOCKBITS - LENGTHBITS) bits:
     */
    if (bufferPos > WBLOCKBYTES - LENGTHBYTES)
	{
        if (bufferPos < WBLOCKBYTES) {
            memset((buffer + bufferPos), 0, WBLOCKBYTES - bufferPos);
        }
        /*
         * Process data block:
         */
        processBuffer(structpointer);
        /*
         * Reset buffer:
         */
        bufferPos = 0;
    }

    if (bufferPos < WBLOCKBYTES - LENGTHBYTES) {
        memset((buffer + bufferPos), 0, (WBLOCKBYTES - LENGTHBYTES) - bufferPos);
    }

    bufferPos = WBLOCKBYTES - LENGTHBYTES;
    /*
     * Append bit length of hashed data:
     */
    memcpy(&buffer[WBLOCKBYTES - LENGTHBYTES], bitLength, LENGTHBYTES);
    
	/*
     * Process data block:
     */
    processBuffer(structpointer);
    
	/*
     * Return the completed message digest:
     */
    for (i = 0; i < DIGESTBYTES/DIM_8; i++) 
	{
        digest[0] = (byte)(structpointer->hash[i] >> 56);
        digest[1] = (byte)(structpointer->hash[i] >> 48);
        digest[2] = (byte)(structpointer->hash[i] >> 40);
        digest[3] = (byte)(structpointer->hash[i] >> 32);
        digest[4] = (byte)(structpointer->hash[i] >> 24);
        digest[5] = (byte)(structpointer->hash[i] >> DIM_16);
        digest[6] = (byte)(structpointer->hash[i] >> DIM_8);
        digest[7] = (byte)(structpointer->hash[i]      );
        digest += DIM_8;
    }
    structpointer->bufferBits = bufferBits;
    structpointer->bufferPos = bufferPos;
}