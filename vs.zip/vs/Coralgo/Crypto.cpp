/*
 Legal Notice: Some portions of the source code contained in this file were
 derived from the source code of Encryption. Modifications and additions to
 the original source code (contained in this file), and all other portions
 of this file are Copyright(c) 2003-2013 'Fondation TrueCrypt'. These are
 also governed by the SCLE License; the full text of which is contained
 in the file Licence 1.0.txt included in NetDisq packages.
 2024-2026. */
 
#include "Memoire.h"
#include "Crypto.h"

void adjustMemKs(CRYPTO_INFO* ci);

static CIPHER* gChiffres[NB_CIPHERS + 1] = {0}; static byte* gMemExtra = NULL;
static char gNomCipher[DIM_NOMS_CIPHERS] = {0}; static uint8 iEa = 0;

void* allouerCh(ENTIER n, uint ligne)
{
    void* mem = NULL;
    #ifdef TC_WINDOWS_DRIVER
        mem = (void*)ExAllocatePoolWithTag(NonPagedPool, n, ND_TAG_CRYPTO);
    #else
        mem = NDAllouer0NM(n, __FILE__, ligne);
    #endif 
    return mem;
}

// @param n sup�rieur � 0 veut dire initialiser mem � 0 avant de lib�rer.
void lib�rerCh(void* mem, ENTIER n, uint ligne)
{
    if (mem != NULL) __try { ND_SYNCHRO_VR_INTRL(); NDFree0(mem, n); ERR_MEM:;
    } __except (EXCEPTION_EXECUTE_HANDLER){
        journaliser("Erreur lib�rerCh: mem %p (%x).", mem, GetExceptionCode());
    }
}

void initTableauChiffre()
{
    if (gChiffres[0]){ return; } // D�j� initialis�.
    uint8 c = 0, i, j; CIPHER* cifr = NULL; char* nom;
    for (i = REM; i <= FISH; i++)
    {
        for (j = REM; j <= FISH; j++)
        {
            if (i != j)
            {
                gChiffres[c] = (CIPHER*)allouerCh(DIM_CIFR, __LINE__);
                cifr = gChiffres[c]; cifr->tabEAs[0].ea = THEO;
                cifr->tabEAs[1].ea = i; cifr->tabEAs[2].ea = j;
                if (((i == MOLLUSC) && (j == APOD)) || 
                    ((i == APOD) && (j == MOLLUSC))){
                    cifr->tabEAs[2].exclusCCL� = TRUE;
                } else if ((i == MOLLUSC) || (i == APOD)){
                    cifr->tabEAs[1].exclusCCL� = TRUE;
                } else if ((j == MOLLUSC) || (j == APOD)){
                    cifr->tabEAs[2].exclusCCL� = TRUE;
                }
                nom = getNomCipher(c); c++;
            }
        } //j
    } // i
    if ( ! gChiffres[NB_CIPHERS]){
        gChiffres[NB_CIPHERS] = (CIPHER*)allouerCh(DIM_CIFR, __LINE__);
    }
}

void lib�rerTableauChiffre()
{
    for (uint8 i = 0; i <= NB_CIPHERS; i++)
    {
        lib�rerCh(gChiffres[i], DIM_CIFR, __LINE__); gChiffres[i] = NULL;
    }
}

NTSTATUS initialisec(INFO_CRYPTO* ci)
{   // PRE: gCi->cl�0 doit �tre non vide (initialis�e).
    int r = EXIT_SUCCESS; uint8 ea, c = ci->cifr;
    VirtualLock(ci, DIM_CI); setKey0(ci->cl�0);
    initTableauChiffre(); adjustMemKs(ci);
    for (ea = getEAD�but(c); ea >= ENUM_1; ea = getEASuivant(c))
    {
        switch (r = initEA(ea))
        {
            case ERR_CIPHER_INIT_FAILURE: return r;
            case ERR_CIPHER_INIT_WEAK_KEY: // Non-fatal error.
            r = ERR_CIPHER_INIT_WEAK_KEY; break;
        }
    } 
    return r;
}

NTSTATUS finalisec(INFO_CRYPTO* ci, BOOL yComprisLeTableau)
{
    if (ci != NULL)
    {
        VirtualUnlock(ci, DIM_CI); ci->cifr = 0;
        ci->mode = 0; init0(ci->cl�0, DK0);
        init0(ci->salt, sizeof(ci->salt));
    }
    int r = finEas(); ND_ASSERT_S(r); init0(ci, DIM_CI); ND_FIN();
ERR:journaliser("finalisec %d.", gNDR�sultat);
FIN:if (yComprisLeTableau){ lib�rerTableauChiffre(); } return r;
}

NTSTATUS finEas()
{
    for (uint8 ea = THEO; ea <= FISH; ea++)
    {
        int r = finEA(ea); ND_ASSERT_S(r);
    }
    init0Keys(); NDFree(gMemExtra); ND_FIN();
ERR:journaliser("finEas %d.", gNDR�sultat); FIN: return gNDR�sultat;
}

uint8 getCipher(const uint8 c)
{
    initTableauChiffre(); uint8 d = c; if (d >= NB_CIPHERS){ d = 0; } return d;
}

char* getNomCipher(uint8 c)
{   
    uint8 ea = getEAD�but(c), i = 0; strcpy(gNomCipher, getNomEA(ea));
    while ((ea = getEASuivant(c)) && (i++ < NB_ALGORITHMES_R�UNIS))
    {
        strcat(gNomCipher, "-"); strcat(gNomCipher, getNomEA(ea));
    }
    return gNomCipher;
}

uint8 getEAD�but(uint8 c)
{
    const uint8 N = NB_CIPHERS; if (c > N)
    {
        journaliser("Erreur getEAD�but cipher=%d.", c); return 0;
    }
    iEa = 0; return (gChiffres[c] ? gChiffres[c]->tabEAs[iEa].ea : N + 1);
}

uint8 getEAFin(uint8 c)
{
    const uint8 N = NB_CIPHERS, M = NB_ALGORITHMES_R�UNIS; if (c > N)
    {
        journaliser("Erreur getEAFin cipher=%d.", c); return N;
    } 
    iEa = M - 1; return (gChiffres[c] ? gChiffres[c]->tabEAs[iEa].ea : N - 1);
}

uint8 getEAPr�c�dent(uint8 c)
{
    uint8 ea = ENUM_1 - 1; if (c > NB_CIPHERS)
    {
        journaliser("Erreur getEAPr�c�dent cipher=%d.", c); return 0;
    }
    if (iEa > ea){ ea = gChiffres[c]->tabEAs[--iEa].ea; } return ea;
}

uint8 getEASuivant(uint8 c)
{
    uint8 ea = 0; const uint8 N = NB_ALGORITHMES_R�UNIS; if (c > NB_CIPHERS)
    {
        journaliser("Erreur getEASuivant cipher=%d.", c); return 0;
    }
    if (iEa < (N - 1))
    {
        iEa++; 
        ea = (gChiffres[c] != NULL ? gChiffres[c]->tabEAs[iEa].ea : N + 1);
    }
    return ea;
}

/* 
 * Do a maximum of memory for keys scheduled to insure that each cipher has
 * the same total. Then if we see the memory of a process, it will say nothing,
 * and not reveal what algorithms are related to it. At the same time, the
 * computer memory must be protected from detailed analysis (ex: sandbox or vm).
*/
void adjustMemKs(CRYPTO_INFO* ci)
{   
    const uint N0 = getNbCl�sREM() * getDimKs(REM); uint8 c = ci->cifr;
    const uint N1 = getNbCl�sAZR() * getDimKs(ANTHOZA); uint m = N0 + N1;
    for (uint8 ea = getEAD�but(c); ea >= ENUM_1; ea = getEASuivant(c))
    {
        // These are dynamic, while other are static (i.e. constant amount):
        if (ea == REM){ m -= N0; } else if (ea == ANTHOZA){ m -= N1; }
    }
    uint n = (GetCurrentProcessId() % GetCurrentThreadId() % 63) + 1;
    uint germe = (n % DIM_32); byte* rst = NULL; if (m > 0)
    {   // Maximum is around 10KB.
        rst = (byte*)NDAllouer(m); for (uint j = 0; j < n; j++){ srand(germe); }
        for (uint i = 0; i < m; i++){ rst[i] = byte(randx()); } gMemExtra = rst;
    }
}

NTSTATUS copierCI(INFO_CRYPTO* ciDst, INFO_CRYPTO* ciSrc)
{
    uint16 M = DK0; if ( ! ciSrc || ! ciDst){ return ERR_OBJET_�_NULL; }
    ciDst->cifr = ciSrc->cifr; ciDst->mode = ciSrc->mode;
    if (ciSrc->cl�0 && ciDst->cl�0){ memcpy(ciDst->cl�0, ciSrc->cl�0, M); }
    memcpy(ciDst->salt, ciSrc->salt, PKCS_SALT_SIZE); return STATUS_SUCCESS;
}

#if defined(_DEBUG) || defined(DEBUG)
void comparerCIs(INFO_CRYPTO* ciA, INFO_CRYPTO* ciB)
{
    const uint16 N = PKCS_SALT_SIZE; int i; if ( ! ciA || ! ciB){ return; }
    journaliser("Ci %d, %d.", ciA->cifr, ciB->cifr);
    journaliser("Mode %d, %d.", ciA->mode, ciB->mode); 
    ND_JOURNALISER_SANS0("Cl�0 %s.", ND_CC(ciB->cl�0), MAX_LONGUEUR_MSG - 80);
    journaliser("... = ? %d.", comparerMem(ciA->cl�0, ciB->cl�0, DK0, TRUE));
    ND_JOURNALISER_SANS0("Salt %s.", ND_CC(ciB->salt), N); 
    journaliser("... = ? %d.", i = comparerMem(ciA->salt, ciB->salt, N, TRUE));
}
#endif // debug

BOOL estExclusCr�ationCl�(uint8 c, uint8 ea)
{
    if (c < NB_CIPHERS){ return gChiffres[c]->tabEAs[iEa].exclusCCL�; }
    else { return FALSE; }
}