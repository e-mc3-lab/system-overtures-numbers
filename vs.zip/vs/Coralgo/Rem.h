/*
 ---------------------------------------------------------------------------
 Copyright (c) 1998-2007, Brian Gladman, Worcester, UK. All rights reserved.

 LICENSE TERMS

 The free distribution and use of this software is allowed (with or without
 changes) provided that:

  1. source code distributions include the above copyright notice, this
     list of conditions and the following disclaimer;

  2. binary distributions include the above copyright notice, this list
     of conditions and the following disclaimer in their documentation;

  3. the name of the copyright holder is not used to endorse products
     built using this software without specific written permission.

 DISCLAIMER

 This software is provided 'as is' with no explicit or implied warranties
 in respect of its properties, including, but not limited to, correctness
 and/or fitness for purpose. See also SCLE/SCES comments in Fish.c(pp).
 ---------------------------------------------------------------------------

 This file contains the definitions required to use AES in C. Read  
 aesoptions.h for optimisation details. & SCLE.
*/
#ifndef _REM_H
#define _REM_H

#include "CompatibX.h"

#define MOT_REM  "Rem"

// Activer si dispo. (ex. Intel AES-NI).
#define ND_DISABLE_HARDWARE_ENCRYPTION 0x8 

#ifdef __cplusplus
extern "C" {
#endif

// .asm
BOOL IsAESHwProcessSupported();
void EnableHwEncryption(BOOL enable);
BOOL IsHwEncryptionEnabled();

uint16 getBlockSizeREM(); uint8 getNbCl�sREM(); uint16 getDimKsREM();

NTSTATUS initREM(); NTSTATUS finREM();
NTSTATUS encryptBlock0REM(byte donn�es[]);
NTSTATUS encryptBlockREM(uint64 i, byte donn�es[]);
NTSTATUS decryptBlockREM(uint64 i, byte donn�es[]);

#if defined(__cplusplus)
}
#endif

#endif // _REM_H 