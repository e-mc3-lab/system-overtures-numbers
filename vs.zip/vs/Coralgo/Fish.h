#ifndef FISH_H
#define FISH_H

#include "CompatibX.h"

#if defined(__cplusplus)
extern "C"
{
#endif

#ifndef extract_byte
#define extract_byte(x,n)  ((UCHAR)((x) >> (8 * n)))
#endif

#ifdef _WIN32
   #include <stdlib.h>
   #define turnr(x,n) _lrotr(x,n)
   #define turnl(x,n) _lrotl(x,n)
#else
   #define turnr(x,n) (((x)>>(n))|((x)<<(32-(n))))
   #define turnl(x,n) (((x)<<(n))|((x)>>(32-(n))))
#endif

typedef struct
{
    uint32 l_key[40], s_key[4];
    uint32 mk_tab[4*DIM_256];
    uint32 k_len;
} FISH_INSTANCE;

NTSTATUS initFISH(); NTSTATUS finFISH(); uint16 getDimKsFISH();
NTSTATUS encryptBlock0FISH(byte donn�es[]);
NTSTATUS encryptBlockFISH(uint64 i, byte donn�es[]);
NTSTATUS decryptBlockFISH(uint64 i, byte donn�es[]);

#if defined(__cplusplus)
}
#endif

#endif // FISH_H  