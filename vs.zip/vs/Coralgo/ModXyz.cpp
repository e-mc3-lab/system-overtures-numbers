/*
 Legal Notice: Some portions of the source code contained in this file were
 derived from the source code of Encryption. Modifications to the original
 source code (in this file), and all other portions of this file are
 Copyright(c) 2024-2026 'SCLE-CSES'. See also the Licence 1.0.txt.
 */

#include "Memoire.h"
#include "Aesdefs.h"
#include "TextHexa.h"
#include "ProcesSpace.h"
#include "Crc.h"
#include "Fichier.h"
#include "Prf.h"
#include "Xts.h"
#include "Secret.h"
#include "ModXyz.h"

#define NB_CHANGEMENTS_CHIFFRE  DIM_32

D�RIVE_CHIFFRE gD�riveChiffres[NB_CHANGEMENTS_CHIFFRE] = {0};
static ID_UTIL_DC gDci = {0}; volatile TC_MUTEX gObjMyzMtx = NULL;
static volatile uint16 giN = 0L; static uint16 gINDHx0[NDH] = {0},
    gINDHx1[NDH] = {0}; BOOL bMajIdA = TRUE; static BOOL bMajId = TRUE;
static uint64 gIdVolume = 0, gIdVolumeA = 0;

BOOL estMajId(){ return bMajId; } void setMajId(BOOL b){ bMajId = b; }
uint64 getIdVolume(){ return gIdVolume; }
void addIdVolume(uint64 d){ gIdVolume += d; }

BOOL estMajIdA(){ return bMajIdA; } void setMajIdA(BOOL b){ bMajIdA = b; }

uint64 getIdVolumeA(){ return gIdVolumeA; }
void setIdVolumeA(uint64 d){ gIdVolumeA = d; }
void addIdVolumeA(uint64 d){ gIdVolumeA += d; }
void multIdVolumeA(uint64 d){ gIdVolumeA *= d; }

void init0Myz()
{
    init0(gD�riveChiffres, sizeof(gD�riveChiffres)); 
    NDInit0(gDci, sizeof(gDci));
}

ID_UTIL_DC getDci(){ return gDci; }

BOOL estTableHexaValide(const byte t[][DIM_16], uint n)
{
    uint i, j = 0, x = n / DIM_16, m = sizeof(ND_TEXTE_8HEXA);
    for (i=0; i < x; i++)
    {
        if (memcmp(t[i], ND_TEXTE_8HEXA, m) == 0){ j++; }
    }
    return (((float)j / (float)x) < 0.20);
}

uint mcb(uint a, uint b){
    return (a > 0 ? min(a, b) : b); 
}

BOOL af(const int i) // estObjetDCUtilis�
{
    return (gD�riveChiffres[i].global || gD�riveChiffres[i].enUtilisation);
}

uint8 ag() // setProchainObjetDC
{   
    uint8 i = 0; TC_ACQUIRE_MUTEX(&gObjMyzMtx);
    for (uint8 j = 0; af(i) && j < 2;){
        if (++i >= NB_CHANGEMENTS_CHIFFRE){ i = 0;  j++; }
    } 
    TC_RELEASE_MUTEX(&gObjMyzMtx); return i;
}

// getObjetDC
D�RIVE_CHIFFRE* ai()
{   
    D�RIVE_CHIFFRE* r�sultat = NULL; uint8 i = ag(); ND_SYNCHRO_VR_INTRL();
    if (af(i)){ gNDR�sultat = ERR_D�PASSEMENT_RESSOURCE; return NULL; }
    r�sultat = &gD�riveChiffres[i]; r�sultat->enUtilisation = TRUE; 
	r�sultat->pos = i; r�sultat->nbIt�rations = 1; return r�sultat;
}

byte gcb(const byte a){ return (a != EOL ? a : byte(DIM_32+1)); }

BOOL aj(D�RIVE_CHIFFRE* dc) // d�chiqueterDonn�es
{
    static const byte zt/*SALT*/[] = {
        "\x8e\x52\x17\x95\x2d\xe3\xad\x55" "\x40\x28\xe2\x0c\xf2\x13\x35\xc8"
        "\x4c\x23\x6b\xdf\xa5\xdb\x0f\xe5" "\x51\xef\x59\xf8\x0b\xf2\x99\xa9"
        "\x29\x5b\x36\x6b\xab\x53\x31\x43" "\x15\x07\x3b\x9e\x68\x65\x22\xfa"
        "\xee\x87\x77\xb9\x9a\x59\xb5\xf5" "\x43\xc6\x67\x17\x16\x47\x2f\x43"
    };
    uint8 dimSalt = mcb(dc->dimSalt, PKCS_SALT_SIZE); byte* tabR = dc->r�sultat;
    dc->dimp = mcb(UI16_STRLEN(dc->mpass), dc->dimp);
    const byte* mpass = dc->mpass; uint16 dimR = mcb(dc->dimR�sultat, DIM_TAB_R);
    dc->dimR�sultat = dimR; init0(tabR, DIM_TAB_R);     
    switch (dc->pkcsB)
    {
    case SHA:

    d�chiqueter_SHA(mpass, dc->dimp, dc->salt, dimSalt,
        dc->nbIt�rations, tabR, dimR); break;

    case WHIRLPOOL:

    d�chiqueter_WHIRLPOOL(mpass, dc->dimp, dc->salt, dimSalt,
        dc->nbIt�rations, tabR, dimR); break;

    case RIPEMD:

    d�chiqueter_RIPEMD(mpass, dc->dimp, dc->salt, dimSalt,
        dc->nbIt�rations, tabR, dimR); break;

    default:
    ND_JOURNALISER_ERREUR("d�chiqueterDonn�es");
    return FALSE; // Unknown/wrong ID.
    }
    if (bMajId)
    {
        uint8 n = sizeof(zt);
        for (uint8 i = 0; i < n; i++){ gIdVolume += zt[i]; }
    }
    for (int i = 0; i < (dimR - 3); i++){ tabR[i] = gcb(tabR[i]); } return TRUE;
}

BOOL an(D�RIVE_CHIFFRE* dc, const uint8 pks) // d�chiqueterDonn�es
{ 
    dc->pkcsB = pks; return aj(dc);
}

// Remplir un segment vide d'un mot de passe.
void gsv(byte mpass[], const uint16 d, const byte s[], const uint n)
{
    uint i, j=0; for (i=d; j < n && i < DMP; i++, j++){ mpass[i] = gcb(s[j]); }
}

void gb(D�RIVE_CHIFFRE* dc, uint8 n) // PRE: n ne doit pas d�passer 192.
{    
    if (dc->dimp + n < DIM_256)
    {
        gsv(dc->mpass, dc->dimp, dc->cl�+n, n); dc->dimp += n;
        if (dc->dimp > DMP){ dc->dimp -= n; }
    }
}

ENTIER aid(uint64 n, uint8 abc) // TODO: ne sert pas actuellement.
{
    ENTIER a = (abc == IDA ? gDci.a : (abc == IDB ? gDci.b : gDci.c));
    if ((a + n) < MAXENTIER){ a += n; } else { a++; } return a;
}

void aim(ID_UTIL_DC* iud, uint64 n, uint8 ab)
{
    ENTIER* a = (ab ? &iud->a : &iud->b); if (*a == 0){ *a = 1; }
    if ((*a * n) < MAXENTIER){ *a *= n; } else { (*a)++; }
}

// additionnerEntiers32vs64
ENTIER cm(ENTIER a, long b) 
{
    ID_UTIL_DC iud = {0}; iud.a = a; aim(&iud, b, TRUE); return iud.a;
}

NTSTATUS kcs(D�RIVE_CHIFFRE* dc, uint8 i)
{
    if (dc && i < FIN_ENUM_HACHAGE){ dc->pkcsA = i; return STATUS_SUCCESS; }
	else { return ERR_CHIFFREMENT_INVALIDE; }
}

NTSTATUS adB(D�RIVE_CHIFFRE* dcDest, D�RIVE_CHIFFRE* dcSrc)
{
    if (dcSrc && dcDest)
    {
        memcpy(dcDest->mpass, dcSrc->mpass, mcb(dcSrc->dimp, DMP));
        dcDest->dimp = dcSrc->dimp;
        memcpy(dcDest->cl�, dcSrc->cl�, MASTER_KEYS_SIZE);
        memcpy(dcDest->salt, dcSrc->salt, PKCS_SALT_SIZE);
        dcDest->dimSalt = dcSrc->dimSalt;
        memcpy(dcDest->r�sultat, dcSrc->r�sultat, DIM_TAB_R);
        dcDest->dimR�sultat = dcSrc->dimR�sultat;
        dcDest->nbIt�rations = dcSrc->nbIt�rations;
        kcs(dcDest, dcSrc->pkcsA); dcDest->pkcsB = dcSrc->pkcsB; 
		return STATUS_SUCCESS;
    } else { 
		return ERR_OBJET_�_NULL; }
} 

void ic(byte tab[], int dl, int dimTab) // init0FinChampDC
{
    int n = dimTab - dl; if (n >= 0){ init0(tab + dl, n); } 
    else { ND_JOURNALISER_EXCEPTION(__FILENAME__, ERR_ARGUMENT_INVALIDE,
            __LINE__); journaliser("%I64d %I64d.", dl, dimTab);
    }
}

NTSTATUS ad1(byte a[], const uint dl, const uint dimA, const byte b[], uint n)
{
    NTSTATUS r = STATUS_SUCCESS; if ((dl + n) <= dimA)
    {
        if ((n > 0) && (n <= dimA)){ memcpy(a+dl, b, n); } ic(a, dl+n, dimA);
    } else { r = ERR_INSUCC�S; } return r;
}

byte* rce(byte txt[], const uint16 dimTxt, const byte cA, const byte cB)
{   // remplacer
    const ENTIER n = dimTxt; int i; for (i = 0; i < n; i++){
        if (txt[i] == cA){ txt[i] = cB; } 
    } 
    return txt;
}

void il(D�RIVE_CHIFFRE* dc){ if (dc && ! dc->global){ init0(dc, DIM_DC); } }

void il0(D�RIVE_CHIFFRE* dc) // init0DC
{
    if (dc)
    {
        uint8 ps = dc->pos; ND_SYNCHRO_VR_INTRL(); init0(dc, DIM_DC);
        dc->pos = ps; dc->enUtilisation = TRUE; dc->nbIt�rations = 1;
    }
}

// d�calerDonn�es16
void r(uint16 tab[], int i, uint n) 
{
    int j; for (j=n-1; j >= i; j--){ tab[j] = tab[j-1]; }
}

// ajouterPositionDonn�eClassement
void se(uint16 tab[], const uint16 i, BOOL inverse)
{   // Le tri se fait � mesure des insertions dans la table.
    uint16 d, l = i, n = giN, *gINDHx = (inverse ? gINDHx1 : gINDHx0);
    for (d=0; d < n; d++)
    {
        if ((giN == 0) || (tab[d] > l))
        {
            r(tab, d, giN+1); tab[d] = l; gINDHx[giN++] = l; return;
        }
    }
    tab[d] = l; gINDHx[giN++] = l;
}

// v�riFinM�lange
BOOL sb(const int i, BOOL inverse){
    return (inverse ? (i >= 0 && giN < NDH) :
        (i < MILLE_VINGT_QUATRE && giN < NDH));
}

// getPositionManquante
// PRE: tab (de dimension NDH) est tri�(e) en ordre croissant.
uint16 rx(const uint16 tab[], uint16 r)
{
    uint16 r�sultat = r; int i; BOOL bExiste = FALSE;
    if (giN == 0){ return r�sultat; } for (i=giN-1; i >= 0; i--)
    {
        if (tab[i] == r){ r�sultat = tab[giN-1]+1; bExiste = TRUE; break; } 
        else if (tab[i] < r�sultat){ break; }
    }
    if (bExiste)
    {
        uint16 a = giN - 1; for (i = giN - 1; i > 0; i--)
        {
            if (tab[a-1]+1 < tab[a])
            {
                r�sultat = tab[a-1]+1; break;
            } a--;
        } // for
        if ((r�sultat == NDH) && (tab[0] > 0)){ r�sultat = tab[0]-1; }
    }
    return r�sultat;
}

// m�langerIndicesTab
int ui(const byte mpass[], BOOL inverse, BOOL bCalc, BOOL bPasse1)
{
    static const byte x3/*SALT*/[][DIM_16] = {
        "\xb1\x23\x86\x0e\xa3\x92\x79\x32", "\x4b\x74\xcf\x8a\x84\xe7\x53\x12",
        "\xcb\x09\x0f\xc2\x22\xf1\x4c\x05", "\x19\x13\x55\x17\xb5\x61\xaf\x1f",
        "\x3b\x5f\x08\xc0\x76\xf2\xef\x13", "\x11\x76\x46\x2b\x12\x53\xc0\x31",
        "\x12\x2d\xc9\x5f\x8e\xdd\x94\x3a", "\xd3\x50\xcf\x90\xf8\x26\xcd\x64",
        "\x13\x2f\xc1\xa5\xbf\x1d\x6e\x95", "\x42\x45\xd0\xac\x64\x6c\x3e\xee",
        "\xa4\xd2\x93\x08\x73\xdb\xf9\x4f", "\x27\x3c\x1c\x4c\x43\x74\x01\x68"
    };
    const uint16 m = sizeof(x3); const uint8 n0 = 4; // PRE: n0 < DIM_16.
    const uint16 D�BUT = (inverse ? N1024 - 1 : 0), X = sizeof(x3);
    const uint16 PASA = 4, PASB = 2, PASC = PASA * PASB;
    int PASD = (inverse ? -1 * (int)PASB : PASB); uint16 j = 3;
    int r = ERR_SUCCESS; uint32 y = 0; byte tab[50] = {0};
    D�RIVE_CHIFFRE* dcs0 = NULL, * dcs = NULL, * dcA = NULL;
    byte* espaceTravail = NULL; uint16 tabPosAssign�es[NDH] = {0};
    uint16 i, l = mcb(DIM_DEMI_MP, UI16_STRLEN(mpass));
    byte mpc[DIM_DEMI_MP + 25] = {0}; BOOL b;
    if ( ! estTableHexaValide(x3, X)){ return ERR_CHIFFREMENT_INVALIDE; }
    giN = 0; if (bMajIdA){ gIdVolumeA += getCrc32(x3[9], sizeof(x3[9]))
        + UI64(x3[0][0]); } y = getCrc32(mpass, l);
    ND_ASSERT(dcs0 = ai()); ND_ASSERT(dcA = ai()); ND_ASSERT(dcs = ai());
    dcA->dimp = N64; if (mpass){ memcpy(dcA->mpass, mpass, N64); }
    dcA->nbIt�rations = 9; dcA->dimSalt = UI8_STRLEN(x3[3]);
    memcpy(dcA->salt, x3[1], mcb(dcA->dimSalt, sizeof(dcA->salt)));
    an(dcA, RIPEMD); gb(dcA, N32); gb(dcA, N32 + 8);
    gb(dcA, N32 + 16); gb(dcA, N32 + 24); gb(dcA, N64); if (mpass){
        memcpy(mpc, mpass, mcb(l, DIM_DEMI_MP));
    } sprintf(ND_CC(tab), "%I32x", y);
    i = UI16_STRLEN(tab); strncat(ND_CC(mpc), ND_CC(tab), i); l += i;
    if (l != j + 3){ mpc[l] = mpc[j + 3]; l++; }
    if (l != j + 6){ mpc[10] = mpc[j + 6]; l++; } mpc[l++] = EOL;
    for (i = 0; i < n0; i++)
    {
        dcs->dimp = UI16_STRLEN(mpc);
        memcpy(dcs->mpass, mpc, mcb(dcs->dimp, DMP));
        dcs->dimSalt = UI8_STRLEN(x3[i + PASC]); memcpy(dcs->salt,
            x3[i + PASC], mcb(dcs->dimSalt, sizeof(dcs->salt))); if (bCalc)
        {
            long ndc = getNombreDC(dcs->mpass, dcs->dimp, x3, DIM_16,
                (i + 1), m); l = dcs->dimp; aid(cm(gDci.c, ndc), IDC);
        }
        dcs->nbIt�rations = i + 1; dcs->dimR�sultat = DIM_256;
        kcs(dcs, ((y * i) % (FIN_ENUM_HACHAGE - 1)) + 1);
        b = an(dcs, dcs->pkcsA); ND_ASSERT_CS(b, ERR_CHIFFREMENT_INVALIDE);
        if (i == 0){ adB(dcs0, dcs); } else { ad1(dcs0->r�sultat, 
            (i * DIM_256), DIM_TAB_R, dcs->r�sultat, DIM_256); }
        memcpy(mpc, dcs->r�sultat, DIM_256);
        rce(mpc, DIM_256, EOL, (byte)(((i + 1) * y) % DIM_256));
        mpc[DIM_256] = EOL; if (i > 0){ il0(dcs); }
    }
    if (bPasse1){ return r; } espaceTravail = dcs0->r�sultat;
    init0(tabPosAssign�es, sizeof(tabPosAssign�es));
    for (i = D�BUT; sb(i, inverse); i = UI16(i + PASD))
    {
        j = espaceTravail[i]; j = UI16(j) *
            UI16(espaceTravail[i + 1]) % 2 + 1 % NDH;
        if (giN % 2 == 0){ PASD = (inverse ? -1 : 1); }
        else { PASD = (inverse ? -1 * PASB : PASB); }
        j = rx(tabPosAssign�es, j); se(tabPosAssign�es, j, inverse);
    }
ERR:/*FIN*/ il(dcs0); il(dcs); il(dcA); return r;
}

// m�langerDonn�es. PRE: tab est de dimension NDH.
int u(byte tab[], const byte mpass[], BOOL inverse, BOOL bInit)
{
    int r = ERR_SUCCESS; byte tabM�lang�e[NDH] = {0}; uint i;
    uint16* gINDHx = gINDHx0; if (bInit)
    {
        init0(gINDHx, sizeof(gINDHx));
        if (r = ui(mpass, inverse, FALSE, FALSE) != ERR_SUCCESS){ return r; }
    }
    for (i=0; i < NDH; i++){ tabM�lang�e[i] = tab[gINDHx[i]]; }
    memcpy(tab, tabM�lang�e, NDH); return r;
}

// d�m�lerDonn�es. PRE: idem que u.
int dem(const byte mpass[], const byte tab[], byte tabR[], 
      BOOL inverse, BOOL bCalc, BOOL bPasse1, BOOL bInit)
{ 
    int r = ERR_SUCCESS; COUPLE_AB tab�Ordonner[NDH] = {0};
    int i, j; uint16 ta, *gINDHx = gINDHx1; uint8 tb; if (bInit)
    {
        init0(gINDHx, sizeof(gINDHx));
        r = ui(mpass, inverse, bCalc, bPasse1);
    }
    if (r != ERR_SUCCESS){ return r; } for (i=0; i < NDH; i++)
    {
        tab�Ordonner[i].a = gINDHx[i]; tab�Ordonner[i].b = tab[i];
    }
    for (i=0; i < NDH; i++)
    {   // Tri s�lection.
        for (j=i; j > 0 && (tab�Ordonner[j-1].a > tab�Ordonner[j].a); j--)
        { 
            ta = tab�Ordonner[j].a; tb = tab�Ordonner[j].b;
            tab�Ordonner[j].a = tab�Ordonner[j-1].a;
            tab�Ordonner[j].b = tab�Ordonner[j-1].b;
            tab�Ordonner[j-1].a = ta; tab�Ordonner[j-1].b = tb;
        }
    } 
    for (i=0; i < NDH; i++){ tabR[i] = tab�Ordonner[i].b; } return r;
}

// m�langerDonn�es (couplage). PRE: idem que dem.
int zs(byte tab[], const byte mpass[], BOOL bInit)
{
    int r = u(tab, mpass, FALSE, bInit); if (r != ERR_SUCCESS){ return r; }
    r = u(tab, mpass, TRUE, bInit); return r;
}

// d�m�lerDonn�es. PRE: idem que dem.
int rb(const byte mpass[], byte tab[], byte tabR[], BOOL bInit)
{
    int r = ERR_SUCCESS; byte tabB[NDH+1] = {0};
    r = dem(mpass, tab, tabB, TRUE, TRUE, FALSE, bInit);
    if (r != ERR_SUCCESS){ return r; }
    dem(mpass, tabB, tab, FALSE, FALSE, FALSE, bInit); 
    if (r == ERR_SUCCESS){ memcpy(tabR, tab, NDH); } 
    return r;
}

NTSTATUS myzEncryption(uint8 c, uint8 ea, uint8 mode, byte tab[],
    ENTIER length, const UINT64_STRUCT* noUnit, uint startCipherBlockNo)
{
    NTSTATUS r = STATUS_SUCCESS; if ((ea == THEO) || (mode == ZTS))
    {   
        const ENTIER C = getDimKsTHEO(), N = length / C;
        for (uint i = 0; i < N && NT_SUCCESS(r); i++){
            r = encryptBlockTHEO(i, tab + (i * C));
        }
    } else if (mode == XTS){
        r = EncryptBufferXTS(ea, tab, length, noUnit, startCipherBlockNo);
    } else if (mode == YTS){
        if (estExclusCr�ationCl�(c, ea)){ return EXIT_SUCCESS; }

        const ENTIER M = length / UDM; const uint8 S = UDM / DIM_16;
        for (uint i = 0; i < M && NT_SUCCESS(r); i++)
        {
            for (uint8 j = 0; j < S; j++){
                r = encryptBlock16(ea, i, tab + ((i * M) + (j * DIM_16)));
            }
        }
    } else { r = ERR_INVALID_MODE; } return r;
}

NTSTATUS myzDecryption(uint8 c, uint8 ea, uint8 mode, byte tab[],
    ENTIER length, const UINT64_STRUCT* noUnit, uint startCipherBlockNo)
{
    NTSTATUS r = STATUS_SUCCESS; if ((ea == THEO) || (mode == ZTS))
    {   
        const ENTIER C = getDimKsTHEO(), N = length / C;
        for (uint i = 0; i < N && NT_SUCCESS(r); i++){
            r = decryptBlockTHEO(i, tab + (i * C));
        }
    } else if (mode == XTS){
        r = DecryptBufferXTS(ea, tab, length, noUnit, startCipherBlockNo);
    } else if (mode == YTS){
        if (estExclusCr�ationCl�(c, ea)){ return EXIT_SUCCESS; }

        const ENTIER M = length / UDM; const uint8 S = UDM / DIM_16;
        for (uint i = 0; i < M && NT_SUCCESS(r); i++)
        {
            for (uint8 j = 0; j < S; j++){
                r = decryptBlock16(ea, i, tab + ((i * M) + (j * DIM_16)));
            }
        }
    } else { r = ERR_INVALID_MODE; } return r;
}


static CONTEXTE_MODE gCtxMode = {0}; volatile TC_MUTEX gObjMtxYZ = NULL;

void myzAcquireMutex(){ TC_ACQUIRE_MUTEX(&gObjMtxYZ); }

void myzReleaseMutex(){ TC_RELEASE_MUTEX(&gObjMtxYZ); }

NTSTATUS FxEdBlock(EDOperation edOp, CONTEXTE_MODE* cm)
{
    NTSTATUS result = STATUS_SUCCESS; myzAcquireMutex();
    ND_ASSERT_CS((cm->length % UDM == 0), ERR_ARGUMENT_INVALIDE);
    result = edOp(cm->ci->cifr, cm->ea, cm->mode, cm->tab, cm->length,
        &cm->noUnit, cm->blockNo0); ND_ASSERT_S(result); ND_FIN();
ERR:journaliser("Erreur FxEdBlock %d.", gNDR�sultat); result = gNDR�sultat;
FIN:myzReleaseMutex(); return result;
}

NTSTATUS FxEncryptBlock(void* ctx)
{   
    // TODO: rendre modifiables les tab. SALT.
    NTSTATUS r = STATUS_SUCCESS; CONTEXTE_MODE* cm = (CONTEXTE_MODE*)ctx;
    CRYPTO_INFO* ci = cm->ci; uint8 c = ci->cifr;
    for (uint8 ea = getEAD�but(c); ea >= ENUM_1; ea = getEASuivant(c))
    {
        cm->ea = ea; cm->dks = getDimKs(ea);
        gNDR�sultat = FxEdBlock(myzEncryption, cm); ND_ASSERT_S(gNDR�sultat);
    }
ERR:/*FIN*/ return gNDR�sultat;
}

FONCTION_FX gEncryptFx = { FxEncryptBlock, &gCtxMode };

NTSTATUS EncryptDataUnits(uint8 tab[], uint64 idUnit,
    uint32 nbUnits, CRYPTO_INFO* ci)
{
    gCtxMode = {0}; gCtxMode.ci = ci; gCtxMode.mode = ci->mode;
    gCtxMode.noUnit.Value = idUnit; gCtxMode.tab = tab;
    ci->inverse = FALSE; gCtxMode.length = uint64(nbUnits) * UDM;
    execFilEx(&gEncryptFx, TRUE); return gNDR�sultat;
}

NTSTATUS FxDecryptBlock(void* ctx)
{
    CONTEXTE_MODE* cm = (CONTEXTE_MODE*)ctx; CRYPTO_INFO* ci = cm->ci;
    NTSTATUS r = STATUS_SUCCESS; uint8 c = ci->cifr; ENTIER j = 0, s = 0;
    for (uint8 ea = getEAFin(c); ea >= ENUM_1; ea = getEAPr�c�dent(c))
    {
        cm->ea = ea; cm->dks = getDimKs(ea);
        gNDR�sultat = FxEdBlock(myzDecryption, cm); ND_ASSERT_S(gNDR�sultat);
    }
ERR:/*FIN*/ return gNDR�sultat;
}

FONCTION_FX gDecryptFx = { FxDecryptBlock, &gCtxMode };

NTSTATUS DecryptDataUnits(uint8 tab[], uint64 idUnit,
    uint32 nbUnits, CRYPTO_INFO* ci)
{
    gCtxMode = {0}; gCtxMode.ci = ci; gCtxMode.mode = ci->mode;
    gCtxMode.noUnit.Value = idUnit; gCtxMode.tab = tab;
    gCtxMode.length = uint64(nbUnits) * UDM; ci->inverse = TRUE;
    execFilEx(&gDecryptFx, TRUE); return gNDR�sultat;
}
