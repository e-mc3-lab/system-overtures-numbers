 /*
 Copyright (c) 2003-2015 'Fondation TrueCrypt'.

 Governed by the SCLE License; the full text of which is contained in
 the file Licence 1.0.txt included in NetDisq distribution packages.
 2023-2025.
*/

#ifndef XTS_H
#define XTS_H

#include "Aesdefs.h"

#ifdef __cplusplus
extern "C" {
#endif

#define BYTES_PER_XTS_BLOCK BYTES_PER_XYZTS

NTSTATUS EncryptBufferXTS(uint8 ea, byte tab[], ENTIER length,
    const UINT64_STRUCT* noUnit, uint startCipherBlockNo);

NTSTATUS DecryptBufferXTS(uint8 ea, byte tab[], ENTIER length,
    const UINT64_STRUCT* noUnit, uint startCipherBlockNo);

#ifdef __cplusplus
}
#endif

#endif  // [!] XTS_H