
#ifndef HEADER_APOD
#define HEADER_APOD

#include "CompatibX.h"

#ifdef __cplusplus
extern "C"
{
#endif

NTSTATUS initAPOD(); NTSTATUS finAPOD(); uint16 getDimKsAPOD();
NTSTATUS encryptBlock0APOD(byte donn�es[]);
NTSTATUS encryptBlockAPOD(uint64 i, byte donn�es[]);
NTSTATUS decryptBlockAPOD(uint64 i, byte donn�es[]);

#ifdef __cplusplus
}
#endif

#endif // HEADER_APOD  