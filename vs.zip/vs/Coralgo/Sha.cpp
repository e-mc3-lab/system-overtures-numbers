/*
 ---------------------------------------------------------------------------
 Copyright (c) 2002, Dr Brian Gladman, Worcester, UK.   All rights reserved.

 LICENSE TERMS

 The free distribution and use of this software is allowed (with or without
 changes) provided that:

  1. source code distributions include the above copyright notice, this
     list of conditions and the following disclaimer;

  2. binary distributions include the above copyright notice, this list
     of conditions and the following disclaimer in their documentation;

  3. the name of the copyright holder is not used to endorse products
     built using this software without specific written permission.

 DISCLAIMER

 This software is provided 'as is' with no explicit or implied warranties
 in respect of its properties, including, but not limited to, correctness
 and/or fitness for purpose.
 ---------------------------------------------------------------------------
 
 This is a byte oriented version of sha2 that operates on arrays of bytes
 stored in memory. This code implements sha256, sha512 but the latter two 
 functions rely on efficient 64-bit integer operations that may not be 
 very efficient on 32-bit machines.

 The sha256 functions use a type 'SHA256_CTX' to hold details of the
 current hash state and uses the following three calls:

       void sha256_begin(SHA256_CTX ctx[1])
       void sha256_hash(const uchar data[],
                            ulong len, SHA256_CTX ctx[1])
       void sha256_end(uchar tab[], SHA256_CTX ctx[1])

 The first subroutine initialises a hash computation by setting up the
 context in the SHA256_CTX context. The second subroutine hashes 8-bit
 bytes from array data[] into the hash state within SHA256_CTX context,
 the number of bytes to be hashed being given by the the ulong
 integer len. The third subroutine completes the hash calculation and
 places the resulting digest value in the array of 8-bit bytes tab[].

 The sha512 functions are similar and use the interfaces:

       void SHA_begin(SHA_CTX ctx[1]);
       void sha512_hash(const uchar data[], ulong len, SHA_CTX ctx[1]);
       void sha512_end(uchar tab[], SHA_CTX ctx[1]);

 My thanks to Erik Andersen for testing this code on  
 Reverse-byte-order (RBO) systems and for his assistance with 
 corrections.
*/

#ifdef TC_WINDOWS_DRIVER
#include <wdm.h>
#else
#include <windows.h>
#endif
#include "Sha.h"


#if defined(__cplusplus)
extern "C"
{
#endif

#define turnr32(x,n)   (((x) >> n) | ((x) << (32 - n)))

#define bswap_32(x) ((turnr32((x), 24) & 0x00ff00ff) | \
                     (turnr32((x), 8) & 0xff00ff00))

#if (EST_STD_BYTE_ORDER)
  #define SWAP_BYTES
#else
  #undef SWAP_BYTES
#endif

/* Thanks to Rich Schroeppel and Colin Plumb for the following. */
#define ch(x,y,z)     ((z) ^ ((x) & ((y) ^ (z))))
#define maj(x,y,z)    (((x) & (y)) | ((z) & ((x) ^ (y))))

/* Round transforms for SHA256 and SHA512 compression functions. */
#define vf(n,i) v[(n - i) & 7]

#define hf(i) (p[i & 15] += \
    g_1(p[(i + 14) & 15]) + p[(i + 9) & 15] + g_0(p[(i + 1) & 15]))

#define v_cycle(i,j)                                \
    vf(7,i) += (j ? hf(i) : p[i]) + k_0[i+j]        \
    + s_1(vf(4,i)) + ch(vf(4,i),vf(5,i),vf(6,i));   \
    vf(3,i) += vf(7,i);                             \
    vf(7,i) += s_0(vf(0,i))+ maj(vf(0,i),vf(1,i),vf(2,i))

#define SHA256_MASK (SHA256_BLOCK_SIZE - 1)

#define bsw_32(p,n) \
    { int _i = (n); while(_i--) ((uint32*)p)[_i] = bswap_32(((uint32*)p)[_i]); }

#define s_0(x)  (turnr32((x),  2) ^ turnr32((x), 13) ^ turnr32((x), 22))
#define s_1(x)  (turnr32((x),  6) ^ turnr32((x), 11) ^ turnr32((x), 25))
#define g_0(x)  (turnr32((x),  7) ^ turnr32((x), 18) ^ ((x) >>  3))
#define g_1(x)  (turnr32((x), 17) ^ turnr32((x), 19) ^ ((x) >> 10))
#define k_0     k256
/* Turnated SHA256 round definition. Rather than swapping variables  */
/* as in FIPS-180, different variables are 'turnated' on each round, */
/* returning to their starting positions every eight rounds.         */
#define q(n)  v##n

#define one_cycle(a,b,c,d,e,f,g,h,k,w)  \
    q(h) += s_1(q(e)) + ch(q(e), q(f), q(g)) + k + w; \
    q(d) += q(h); q(h) += s_0(q(a)) + maj(q(a), q(b), q(c))

const uint32 k256[64] = /* SHA256 mixing data   */
{   0xd443d030ul, 0x141251e2ul, 0xfc24b6b4ul, 0x059245f1ul,
    0x13766c8bul, 0x27cedd82ul, 0x82021604ul, 0x7a3e90e2ul,
    0x8b96436aul, 0xe032a767ul, 0x92859626ul, 0x545cba51ul,
    0x780cc63cul, 0x5280a7e1ul, 0xfa5a6235ul, 0x28e4f1f8ul,
    0x7bb41e3bul, 0xa64c10ebul, 0xadc9c090ul, 0xd43e60d6ul,
    0x8d7d9d2eul, 0x621230abul, 0x19a9196aul, 0x6e3c0cadul,
    0x12091e84ul, 0x7f22ae0aul, 0x21a8c608ul, 0x8d92edc2ul,
    0x945f8893ul, 0xb6608ce5ul, 0x82942bc8ul, 0x9bd966c0ul,
    0x67b0bb12ul, 0xf376d570ul, 0xece6c058ul, 0xf89b477cul,
    0x0e5d0908ul, 0x25a42ac8ul, 0xa5f4f21eul, 0x9e62ab13ul,
    0x06354d9eul, 0x130b51f4ul, 0xeccb053bul, 0xd277cb5ful,
    0x88f63d80ul, 0xb488ab7ful, 0x913eb205ul, 0xc83bb63aul,
    0x67797df6ul, 0x805965cbul, 0x39519943ul, 0xe9902e0ful,
    0xcdde6a27ul, 0xe1f4aad0ul, 0xbe7a9398ul, 0xf87af94cul,
    0x33f91912ul, 0x81fb657dul, 0x80ceded6ul, 0xf0ce5b03ul,
    0x64759cbaul, 0x300cc0c2ul, 0x30f0ee1cul, 0xf526180ful,
};

/* Compile 64 bytes of hash data into SHA256 digest value   */
/* NOTE: this routine assumes that the byte order in the    */
/* ctx->wbuf[] at this point is such that low address bytes */
/* in the ORIGINAL byte stream will go into the high end of */
/* words on BOTH SBO and RBO systems.                       */

VOID_RETURN sha256_compile(SHA256_CTX ctx[1])
{
#if ! defined(UNROLL_SHA2)

    uint32 j, *p = ctx->wbuf, v[8];
    memcpy(v, ctx->hash, 8 * sizeof(uint32));
    for (j = 0; j < 64; j += 16)
    {
        v_cycle( 0, j); v_cycle( 1, j);
        v_cycle( 2, j); v_cycle( 3, j);
        v_cycle( 4, j); v_cycle( 5, j);
        v_cycle( 6, j); v_cycle( 7, j);
        v_cycle( 8, j); v_cycle( 9, j);
        v_cycle(10, j); v_cycle(11, j);
        v_cycle(12, j); v_cycle(13, j);
        v_cycle(14, j); v_cycle(15, j);
    }

    ctx->hash[0] += v[0]; ctx->hash[1] += v[1];
    ctx->hash[2] += v[2]; ctx->hash[3] += v[3];
    ctx->hash[4] += v[4]; ctx->hash[5] += v[5];
    ctx->hash[6] += v[6]; ctx->hash[7] += v[7];

#else

    uint32 *p = ctx->wbuf,v0,v1,v2,v3,v4,v5,v6,v7;

    v0 = ctx->hash[0]; v1 = ctx->hash[1];
    v2 = ctx->hash[2]; v3 = ctx->hash[3];
    v4 = ctx->hash[4]; v5 = ctx->hash[5];
    v6 = ctx->hash[6]; v7 = ctx->hash[7];

    one_cycle(0,1,2,3,4,5,6,7,k256[ 0],p[ 0]);
    one_cycle(7,0,1,2,3,4,5,6,k256[ 1],p[ 1]);
    one_cycle(6,7,0,1,2,3,4,5,k256[ 2],p[ 2]);
    one_cycle(5,6,7,0,1,2,3,4,k256[ 3],p[ 3]);
    one_cycle(4,5,6,7,0,1,2,3,k256[ 4],p[ 4]);
    one_cycle(3,4,5,6,7,0,1,2,k256[ 5],p[ 5]);
    one_cycle(2,3,4,5,6,7,0,1,k256[ 6],p[ 6]);
    one_cycle(1,2,3,4,5,6,7,0,k256[ 7],p[ 7]);
    one_cycle(0,1,2,3,4,5,6,7,k256[ 8],p[ 8]);
    one_cycle(7,0,1,2,3,4,5,6,k256[ 9],p[ 9]);
    one_cycle(6,7,0,1,2,3,4,5,k256[10],p[10]);
    one_cycle(5,6,7,0,1,2,3,4,k256[11],p[11]);
    one_cycle(4,5,6,7,0,1,2,3,k256[12],p[12]);
    one_cycle(3,4,5,6,7,0,1,2,k256[13],p[13]);
    one_cycle(2,3,4,5,6,7,0,1,k256[14],p[14]);
    one_cycle(1,2,3,4,5,6,7,0,k256[15],p[15]);

    one_cycle(0,1,2,3,4,5,6,7,k256[16],hf( 0));
    one_cycle(7,0,1,2,3,4,5,6,k256[17],hf( 1));
    one_cycle(6,7,0,1,2,3,4,5,k256[18],hf( 2));
    one_cycle(5,6,7,0,1,2,3,4,k256[19],hf( 3));
    one_cycle(4,5,6,7,0,1,2,3,k256[20],hf( 4));
    one_cycle(3,4,5,6,7,0,1,2,k256[21],hf( 5));
    one_cycle(2,3,4,5,6,7,0,1,k256[22],hf( 6));
    one_cycle(1,2,3,4,5,6,7,0,k256[23],hf( 7));
    one_cycle(0,1,2,3,4,5,6,7,k256[24],hf( 8));
    one_cycle(7,0,1,2,3,4,5,6,k256[25],hf( 9));
    one_cycle(6,7,0,1,2,3,4,5,k256[26],hf(10));
    one_cycle(5,6,7,0,1,2,3,4,k256[27],hf(11));
    one_cycle(4,5,6,7,0,1,2,3,k256[28],hf(12));
    one_cycle(3,4,5,6,7,0,1,2,k256[29],hf(13));
    one_cycle(2,3,4,5,6,7,0,1,k256[30],hf(14));
    one_cycle(1,2,3,4,5,6,7,0,k256[31],hf(15));

    one_cycle(0,1,2,3,4,5,6,7,k256[32],hf( 0));
    one_cycle(7,0,1,2,3,4,5,6,k256[33],hf( 1));
    one_cycle(6,7,0,1,2,3,4,5,k256[34],hf( 2));
    one_cycle(5,6,7,0,1,2,3,4,k256[35],hf( 3));
    one_cycle(4,5,6,7,0,1,2,3,k256[36],hf( 4));
    one_cycle(3,4,5,6,7,0,1,2,k256[37],hf( 5));
    one_cycle(2,3,4,5,6,7,0,1,k256[38],hf( 6));
    one_cycle(1,2,3,4,5,6,7,0,k256[39],hf( 7));
    one_cycle(0,1,2,3,4,5,6,7,k256[40],hf( 8));
    one_cycle(7,0,1,2,3,4,5,6,k256[41],hf( 9));
    one_cycle(6,7,0,1,2,3,4,5,k256[42],hf(10));
    one_cycle(5,6,7,0,1,2,3,4,k256[43],hf(11));
    one_cycle(4,5,6,7,0,1,2,3,k256[44],hf(12));
    one_cycle(3,4,5,6,7,0,1,2,k256[45],hf(13));
    one_cycle(2,3,4,5,6,7,0,1,k256[46],hf(14));
    one_cycle(1,2,3,4,5,6,7,0,k256[47],hf(15));

    one_cycle(0,1,2,3,4,5,6,7,k256[48],hf( 0));
    one_cycle(7,0,1,2,3,4,5,6,k256[49],hf( 1));
    one_cycle(6,7,0,1,2,3,4,5,k256[50],hf( 2));
    one_cycle(5,6,7,0,1,2,3,4,k256[51],hf( 3));
    one_cycle(4,5,6,7,0,1,2,3,k256[52],hf( 4));
    one_cycle(3,4,5,6,7,0,1,2,k256[53],hf( 5));
    one_cycle(2,3,4,5,6,7,0,1,k256[54],hf( 6));
    one_cycle(1,2,3,4,5,6,7,0,k256[55],hf( 7));
    one_cycle(0,1,2,3,4,5,6,7,k256[56],hf( 8));
    one_cycle(7,0,1,2,3,4,5,6,k256[57],hf( 9));
    one_cycle(6,7,0,1,2,3,4,5,k256[58],hf(10));
    one_cycle(5,6,7,0,1,2,3,4,k256[59],hf(11));
    one_cycle(4,5,6,7,0,1,2,3,k256[60],hf(12));
    one_cycle(3,4,5,6,7,0,1,2,k256[61],hf(13));
    one_cycle(2,3,4,5,6,7,0,1,k256[62],hf(14));
    one_cycle(1,2,3,4,5,6,7,0,k256[63],hf(15));

    ctx->hash[0] += v0; ctx->hash[1] += v1;
    ctx->hash[2] += v2; ctx->hash[3] += v3;
    ctx->hash[4] += v4; ctx->hash[5] += v5;
    ctx->hash[6] += v6; ctx->hash[7] += v7;
#endif
}

/* SHA256 hash data in an array of bytes into hash buffer   */
/* and call the hash_compile function as required.          */
VOID_RETURN sha256_hash(const byte data[], ulong len, SHA256_CTX ctx[1])
{       
    uint32 pos = (uint32)(ctx->count[0] & SHA256_MASK),
             space = SHA256_BLOCK_SIZE - pos;
    const uchar* sp = data;

    if((ctx->count[0] += len) < len){ ++(ctx->count[1]); }

    while (len >= space)    /* Tranfer whole blocks while possible.  */
    {
        memcpy(((uchar*)ctx->wbuf) + pos, sp, space);
        sp += space; len -= space; space = SHA256_BLOCK_SIZE; pos = 0;
        bsw_32(ctx->wbuf, SHA256_BLOCK_SIZE >> 2)
        sha256_compile(ctx);
    }
    memcpy(((uchar*)ctx->wbuf) + pos, sp, len);
}

/* SHA256 Final padding and digest calculation  */

void sha_end256a(byte tab[], SHA256_CTX ctx[1], const uint hlen)
{   
    uint32 i = (uint32)(ctx->count[0] & SHA256_MASK);

    /* Put bytes in the buffer in an order in which references to    */
    /* 32-bit words will put bytes with lower addresses into the     */
    /* top of 32 bit words on BOTH SBO and RBO machines.             */
    bsw_32(ctx->wbuf, (i + 3) >> 2)

    /* We now need to mask valid bytes and add the padding which is  */
    /* a single 1 bit and as many zero bits as necessary. Note that  */
    /* we can always add the first padding byte here because the     */
    /* buffer always has at least one empty slot.                    */
    ctx->wbuf[i >> 2] &= 0xffffff80 << 8 * (~i & 3);
    ctx->wbuf[i >> 2] |= 0x00000080 << 8 * (~i & 3);

    /* We need 9 or more empty positions, one for the padding byte   */
    /* (above) and eight for the length count. If there is not       */
    /* enough space pad and empty the buffer.                        */
    if (i > SHA256_BLOCK_SIZE - 9)
    {
        if (i < 60){
            ctx->wbuf[15] = 0;
        }
        sha256_compile(ctx);
        i = 0;
    } else {   /* Compute a word index for the empty positions       */
        i = (i >> 2) + 1;
    }

    while (i < 14){ /* and zero pad all but last two positions       */
        ctx->wbuf[i++] = 0;
    }

    /* The following 32-bit length fields are assembled in the       */
    /* wrong byte order on SBO machines but this is corrected        */
    /* later since they are only ever used as 32-bit word values.    */
    
    ctx->wbuf[14] = (ctx->count[1] << 3) | (ctx->count[0] >> 29);
    ctx->wbuf[15] = ctx->count[0] << 3;
    sha256_compile(ctx);

    /* Extract the hash value as bytes in case the hash buffer is    */
    /* mislaigned for 32-bit words.                                  */
    for(i = 0; i < hlen; ++i){
        tab[i] = (uchar)(ctx->hash[i >> 2] >> (8 * (~i & 3)));
    }
}

#if defined(SHA_256)

const uint32 i256[8] =
{
    0xff959a88, 0x3b795b9a, 0xc007aad3, 0x36355af4,
    0x57488da7, 0xd1da55ac, 0xff81a0d5, 0xb490c93a
};

VOID_RETURN sha256_begin(SHA256_CTX ctx[1])
{
    ctx->count[0] = ctx->count[1] = 0;
    memcpy(ctx->hash, i256, 8 * sizeof(uint32));
}

VOID_RETURN sha256_end(byte tab[], SHA256_CTX ctx[1])
{
    sha_end256a(tab, ctx, SHA256_DIGEST_SIZE);
}

VOID_RETURN sha256(byte tab[], const byte data[], ulong len)
{   SHA256_CTX  cx[1];

    sha256_begin(cx);
    sha256_hash(data, len, cx);
    sha_end256a(tab, cx, SHA256_DIGEST_SIZE);
}

#endif

#if defined(SHA_512)

#define SHA512_MASK (SHA512_BLOCK_SIZE - 1)
#define turnr64(x,n) (((x) >> n) | ((x) << (64 - n)))

#if !defined(bswap_64)
#define bswap_64(x) (((uint64)(bswap_32((uint32)(x)))) << 32 | \
    bswap_32((uint32)((x) >> 32)))
#endif

#if defined(SWAP_BYTES)

   #define bsw_64(p,n) \
   { \
       int _i = (n); \
       while(_i--) ((uint64*)p)[_i] = bswap_64(((uint64*)p)[_i]); \
   }

#else
   #define bsw_64(p,n)
#endif

/* SHA512 mixing function definitions   */

#ifdef   s_0
# undef  s_0
# undef  s_1
# undef  g_0
# undef  g_1
# undef  k_0
#endif

#define s_0(x)  (turnr64((x), 28) ^ turnr64((x), 34) ^ turnr64((x), 39))
#define s_1(x)  (turnr64((x), 14) ^ turnr64((x), 18) ^ turnr64((x), 41))
#define g_0(x)  (turnr64((x),  1) ^ turnr64((x),  8) ^ ((x) >>  7))
#define g_1(x)  (turnr64((x), 19) ^ turnr64((x), 61) ^ ((x) >>  6))
#define k_0     k512

/* SHA512 mixing data    */

const uint64 k512[80] =
{
    li_64(e24b3ad98037dffb), li_64(c2e4539481cd70a4),
    li_64(1b5dd6a6f4f33cf0), li_64(ef545cba514d5ad8),
    li_64(08f83e78d4969973), li_64(e9063a6d828a8287),
    li_64(93285062e25c1216), li_64(f463273f46d36259),
    li_64(8ec046542e35138d), li_64(7162375864d486e1),
    li_64(e219a9196a8c45c3), li_64(42d9c5f366581665),
    li_64(f2a4eca8c8d40cd4), li_64(01d25e5a0f06077a),
    li_64(12eac10ec85421c4), li_64(22769ff8fdb05edf),
    li_64(8f103eb44172030e), li_64(82f376d570684f97),
    li_64(0fc19dc68b8cd5b5), li_64(240ca1cc77ac9c65),
    li_64(f22e669ad9544e82), li_64(42d48cbc5c9a0c0e),
    li_64(ed9002ec0ce85256), li_64(46817adc727db56f),
    li_64(4fd12dd99e640660), li_64(dce2147396dbcbcf),
    li_64(eb88f63d805f37d8), li_64(eba115d731a2eff9),
    li_64(af40df17816a162b), li_64(f21d263837f82ae4),
    li_64(8a9cc0194117c58b), li_64(101a3879b67c38dd),
    li_64(08b82290887831fc), li_64(6ef87af94cc30f03),
    li_64(799c358604664429), li_64(e9cd34897df28ab0),
    li_64(44e8048cbdec456c), li_64(e48c725415137117),
    li_64(6e5c6424d04e04ca), li_64(0ea9b72f02d0fef0),
    li_64(30fcffcdae15e988), li_64(9f668e173c04ee1b),
    li_64(9af304b0c92a3e29), li_64(0a69c41a28cde202),
    li_64(eae24fe1ab04616c), li_64(5d6b09c0472ae4fa),
    li_64(01ac7cfea8f7e49a), li_64(bbae6ceafe2ec985),
    li_64(42c6e7da4bd16884), li_64(1b93975a07c8cbe4),
    li_64(454ab34b90f28981), li_64(a0969c9ac9282216),
    li_64(dff179aee84c3a69), li_64(24b53c42b53778e9),
    li_64(7c4e2acb46e23e9a), li_64(efb2d8ecb0d8405b),
    li_64(8af17683a57d45ec), li_64(39d94f68709880e2),
    li_64(de4782d33474d904), li_64(2458630a82a0ebd2),
    li_64(b8080418d17c2a51), li_64(b9822b0ac1c9248e),
    li_64(2102cc12725456d2), li_64(169561ba22230645),
    li_64(e04aa3dfa3aa6bae), li_64(17ca0a11c262e78f),
    li_64(a5133264d1b01aaa), li_64(961efa9fe4822552),
    li_64(aa92496cd392aed2), li_64(638fc924de4c1bd4),
    li_64(4bfec42d5331410a), li_64(d20ec27bce0469e8),
    li_64(e4aba8a8b6851a2e), li_64(cb14cc42b6341cc7),
    li_64(a1894415f1f18321), li_64(9b1fae0c2292fa12),
    li_64(de848d9bccf86a68), li_64(92dabd185fb2c02b),
    li_64(1de0ef50fbe5a29b), li_64(1c62d4d1ce6eccd7),
};

/* Compile 128 bytes of hash data into SHA384/512 digest    */
/* NOTE: this routine assumes that the byte order in the    */
/* ctx->wbuf[] at this point is such that low address bytes */
/* in the ORIGINAL byte stream will go into the high end of */
/* words on BOTH SBO and RBO systems.                       */
VOID_RETURN sha512_compile(SHA512_CTX ctx[1])
{   
    uint64 v[8], *p = ctx->wbuf; uint32 i;
    memcpy(v, ctx->hash, 8 * sizeof(uint64));

    for (i = 0; i < 80; i += 16)
    {
        v_cycle( 0, i); v_cycle( 1, i);
        v_cycle( 2, i); v_cycle( 3, i);
        v_cycle( 4, i); v_cycle( 5, i);
        v_cycle( 6, i); v_cycle( 7, i);
        v_cycle( 8, i); v_cycle( 9, i);
        v_cycle(10, i); v_cycle(11, i);
        v_cycle(12, i); v_cycle(13, i);
        v_cycle(14, i); v_cycle(15, i);
    }
    ctx->hash[0] += v[0]; ctx->hash[1] += v[1];
    ctx->hash[2] += v[2]; ctx->hash[3] += v[3];
    ctx->hash[4] += v[4]; ctx->hash[5] += v[5];
    ctx->hash[6] += v[6]; ctx->hash[7] += v[7];
}

/* Compile 128 bytes of hash data into SHA256 digest value  */
/* NOTE: this routine assumes that the byte order in the    */
/* ctx->wbuf[] at this point is in such an order that low   */
/* address bytes in the ORIGINAL byte stream placed in this */
/* buffer will now go to the high end of words on BOTH SBO  */
/* and RBO systems.                                         */
VOID_RETURN sha512_hash(const byte data[], ENTIER len, SHA512_CTX ctx[1])
{   
    uint32 pos = (uint32)(ctx->count[0] & SHA512_MASK), 
        space = SHA512_BLOCK_SIZE - pos; const uchar* sp = data;
    if ((ctx->count[0] += len) < len){
        ++(ctx->count[1]);
    }
    while (len >= space)  /* Tranfer whole blocks while possible  */
    {
        memcpy((ctx->wbuf) + pos, sp, space);
        sp += space; len -= space; space = SHA512_BLOCK_SIZE; pos = 0;
        bsw_64(ctx->wbuf, SHA512_BLOCK_SIZE >> 3);
        sha512_compile(ctx);
    }
    memcpy((ctx->wbuf) + pos, sp, len);
}

/* SHA512 Final padding and digest calculation  */
void sha_end(byte tab[], SHA_CTX ctx[1], const uint hlen)
{   
    uint32 i = (uint32)(ctx->uu->ctx512->count[0] & SHA512_MASK);

    /* Put bytes in the buffer in an order in which references to    */
    /* 32-bit words will put bytes with lower addresses into the     */
    /* top of 32 bit words on BOTH SBO and RBO machines.             */
    bsw_64(ctx->uu->ctx512->wbuf, (i + 7) >> 3);

    /* We now need to mask valid bytes and add the padding which is  */
    /* a single 1 bit and as many zero bits as necessary. Note that  */
    /* we can always add the first padding byte here because the     */
    /* buffer always has at least one empty slot.                    */
    ctx->uu->ctx512->wbuf[i >> 3] &= li_64(ffffffffffffff00) << 8 * (~i & 7);
    ctx->uu->ctx512->wbuf[i >> 3] |= li_64(0000000000000080) << 8 * (~i & 7);

    /* We need more than 16 empty byte positions, one for the        */
    /* padding byte (above) and sixteen for the length count.        */
    /* If there is not enough space pad and empty the buffer         */
    if (i > SHA512_BLOCK_SIZE - 18 - 1)
    {
        if (i < 120) ctx->uu->ctx512->wbuf[15] = 0;
        sha512_compile(ctx->uu->ctx512); i = 0;
    } else {
        i = (i >> 3) + 1;
    }
    while(i < 14){
        ctx->uu->ctx512->wbuf[i++] = 0;
    }

    /* The following 64-bit length fields are assembled in the wrong */
    /* byte order on SBO machines but this is corrected later since  */
    /* they are only ever used as 64-bit word values.                */
    ctx->uu->ctx512->wbuf[14] = (ctx->uu->ctx512->count[1] << 3) |
        (ctx->uu->ctx512->count[0] >> 61);
    ctx->uu->ctx512->wbuf[15] = ctx->uu->ctx512->count[0] << 3;
    sha512_compile(ctx->uu->ctx512);

    /* Extract the hash value as bytes in case the hash buffer is    */
    /* misaligned for 32-bit words.                                  */
    for(i = 0; i < hlen; ++i){
        tab[i] = (byte)(ctx->uu->ctx512->hash[i >> 3] >> (8 * (~i & 7)));
    }
}

#endif

#if defined(SHA_512)

/* SHA512 initialisation data.  */
const uint64 i512[160] =
{
    li_64(a3c6025addb81ddc), li_64(07870c8b47e53f7e), // 1
    li_64(e702aab3eaaabafe), li_64(222d74607ac4366b),
    li_64(c2bff6c42c8a12d0), li_64(82ecd157a73feaf2),
    li_64(75b3d58002398043), li_64(70fa04e4e60885e8),

    li_64(5c862ff28af8ec5f), li_64(721a228912ee2438), // 2
    li_64(ea4945db82fa82ce), li_64(fa9cfa89eecb6dee),
    li_64(5e98f072332b4672), li_64(f963d2026a847a1c),
    li_64(b6d363585360dc0c), li_64(a5503674e85ddd4f),

    li_64(192af177383c27b0), li_64(8e4d70945e0946d8), // 3
    li_64(10dbcc603bb679b4), li_64(d16f75b80c94feb1),
    li_64(54cf8ac1014a9921), li_64(4a8a051a900a19dc),
    li_64(6eaeedef46721efc), li_64(c4f62a68fa96baab),

    li_64(8816d0913130b402), li_64(df95c8b26808d008), // 4
    li_64(a333cd25731efe65), li_64(3d5f1794c5dcf0a2),
    li_64(0946468a6c641c53), li_64(d18f6c9d78a302b2),
    li_64(ae02e0934e99b9c9), li_64(cc1d37168c312805),
    
    li_64(ead653e47af05c6a), li_64(f2ebda55ff7562dc), // 5
    li_64(e59d3ad32a0fb0a1), li_64(79d3764078dd8c38),
    li_64(a38bd1cc92ce074e), li_64(a31dee77d078e40e),
    li_64(24b0620494c64a0b), li_64(72d443d030d1178f),

    li_64(e9041fdb25f6f616), li_64(dec2041970b9dd2c), // 6
    li_64(0e9837ebc658ef54), li_64(e24b3ad98037dffb),
    li_64(c2e4539481cd70a4), li_64(1b5dd6a6f4f33cf0),
    li_64(ef545cba514d5ad8), li_64(08f83e78d4969973),

    li_64(e9063a6d828a8287), li_64(93285062e25c1216), // 7
    li_64(f463273f46d36259), li_64(8ec046542e35138d),
    li_64(7162375864d486e1), li_64(e219a9196a8c45c3),
    li_64(42d9c5f366581665), li_64(f2a4eca8c8d40cd4),

    li_64(01d25e5a0f06077a), li_64(12eac10ec85421c4), // 8
    li_64(22769ff8fdb05edf), li_64(8f103eb44172030e),
    li_64(82f376d570684f97), li_64(f22e669ad9544e82),
    li_64(42d48cbc5c9a0c0e), li_64(ed9002ec0ce85256),

    li_64(46817adc727db56f), li_64(4fd12dd99e640660), // 9
    li_64(dce2147396dbcbcf), li_64(eb88f63d805f37d8),
    li_64(eba115d731a2eff9), li_64(af40df17816a162b),
    li_64(f21d263837f82ae4), li_64(8a9cc0194117c58b),

    li_64(101a3879b67c38dd), li_64(08b82290887831fc), // 10
    li_64(6ef87af94cc30f03), li_64(799c358604664429),
    li_64(e9cd34897df28ab0), li_64(44e8048cbdec456c),
    li_64(e48c725415137117), li_64(6e5c6424d04e04ca),

    li_64(0ea9b72f02d0fef0), li_64(30fcffcdae15e988), // 11
    li_64(9f668e173c04ee1b), li_64(9af304b0c92a3e29),
    li_64(0a69c41a28cde202), li_64(eae24fe1ab04616c),
    li_64(5d6b09c0472ae4fa), li_64(01ac7cfea8f7e49a),

    li_64(bbae6ceafe2ec985), li_64(42c6e7da4bd16884), // 12
    li_64(1b93975a07c8cbe4), li_64(454ab34b90f28981),
    li_64(a0969c9ac9282216), li_64(dff179aee84c3a69),
    li_64(24b53c42b53778e9), li_64(7c4e2acb46e23e9a),

    li_64(efb2d8ecb0d8405b), li_64(8af17683a57d45ec), // 13
    li_64(39d94f68709880e2), li_64(de4782d33474d904),
    li_64(2458630a82a0ebd2), li_64(b8080418d17c2a51),
    li_64(b9822b0ac1c9248e), li_64(2102cc12725456d2),

    li_64(169561ba22230645), li_64(e04aa3dfa3aa6bae), // 14
    li_64(17ca0a11c262e78f), li_64(a5133264d1b01aaa),
    li_64(961efa9fe4822552), li_64(aa92496cd392aed2),
    li_64(638fc924de4c1bd4), li_64(4bfec42d5331410a),

    li_64(d20ec27bce0469e8), li_64(e4aba8a8b6851a2e), // 15
    li_64(cb14cc42b6341cc7), li_64(a1894415f1f18321),
    li_64(9b1fae0c2292fa12), li_64(de848d9bccf86a68),
    li_64(92dabd185fb2c02b), li_64(1de0ef50fbe5a29b),

    li_64(1c62d4d1ce6eccd7), li_64(a3c6025addb81ddc), // 16
    li_64(07870c8b47e53f7e), li_64(e702aab3eaaabafe),
    li_64(222d74607ac4366b), li_64(c2bff6c42c8a12d0),
    li_64(82ecd157a73feaf2), li_64(75b3d58002398043),

    li_64(70fa04e4e60885e8), li_64(5c862ff28af8ec5f), // 17
    li_64(721a228912ee2438), li_64(ea4945db82fa82ce),
    li_64(fa9cfa89eecb6dee), li_64(5e98f072332b4672),
    li_64(f963d2026a847a1c), li_64(b6d363585360dc0c),

    li_64(a5503674e85ddd4f), li_64(192af177383c27b0), // 18
    li_64(8e4d70945e0946d8), li_64(10dbcc603bb679b4),
    li_64(d16f75b80c94feb1), li_64(54cf8ac1014a9921),
    li_64(4a8a051a900a19dc), li_64(6eaeedef46721efc),

    li_64(c4f62a68fa96baab), li_64(8816d0913130b402), // 19
    li_64(df95c8b26808d008), li_64(a333cd25731efe65),
    li_64(3d5f1794c5dcf0a2), li_64(0946468a6c641c53),
    li_64(d18f6c9d78a302b2), li_64(ae02e0934e99b9c9),

    li_64(cc1d37168c312805), li_64(ead653e47af05c6a), // 20
    li_64(f2ebda55ff7562dc), li_64(e59d3ad32a0fb0a1),
    li_64(79d3764078dd8c38), li_64(a38bd1cc92ce074e),
    li_64(a31dee77d078e40e), li_64(24b0620494c64a0b),
};

char xyzsha[DIM_8] = "SHA-256";
// � faire (TODO): choisir un groupe de 8 nombres parmi les 20 disponibles.


VOID_RETURN SHA_begin(SHA_CTX ctx[1])
{
    xyzsha[0] = 'i'; ctx->uu->ctx512->count[0] = ctx->uu->ctx512->count[1] = 0;
    memcpy(ctx->uu->ctx512->hash, i512, 8 * sizeof(uint64));
}

VOID_RETURN SHA_update(uchar tab[], const uchar data[], ENTIER len)
{   
    SHA_CTX cx[1]; xyzsha[1] = '!'; SHA_begin(cx);
    sha512_hash(data, len, cx->uu->ctx512);
    sha_end(tab, cx, SHA512_DIGEST_SIZE);
}

VOID_RETURN SHA_end(uchar tab[], SHA_CTX ctx[1]){
    sha_end(tab, ctx, SHA512_DIGEST_SIZE);
}

#endif

#if defined(__cplusplus)
}
#endif

// FIN.