#ifndef AES_DEFS_H
#define AES_DEFS_H

#include "CompatibX.h"

#define AES_256             DIM_256  /* If AES with 256 bit keys.    */

/* The following must also be set in assembler files if being used.  */
#define AES_ENCRYPT /* If support for encryption is needed           */
#define AES_DECRYPT /* If support for decryption is needed           */
#define AES_ERR_V�RIF /* For parameter checks & error return codes   */
#define AES_REV_DKS /* Define to reverse decryption key schedule     */
#define REM_BLOCK_SIZE      DIM_16 /* In bytes                       */
#define DIM_BLOC_EA         (int)REM_BLOCK_SIZE // =16
#define DIM_CL�_EA          (int)DIM_32 
#define BYTES_PER_XYZTS     DIM_BLOC_EA

/* The key schedule length is 11, 13 or 15 16-byte blocks for 128,   */
/* 192 or 256-bit keys respectively. That is 176, 208 or 240 bytes   */
/* or 44, 52 or 60 32-bit words.                                     */

#if defined(AES_256)
#define AES_KS_LENGTH       60
#endif

#if defined( AES_ERR_V�RIF )
  #define AES_RETURN         int
#else
  #define AES_RETURN         VOID_RETURN
#endif

#define N_ROWS               4
#define N_COLS               N_ROWS
#define N_BLOCKS             N_ROWS * N_COLS
#define N_MAX_ROUNDS         16

typedef struct
{   uint8 ksch[N_MAX_ROUNDS * N_BLOCKS], rnd;
} AES_CONTEXT; 


#define AES_INF_B0           (N_MAX_ROUNDS-2) * N_BLOCKS

/* The character array 'inf' in the following structures is used     */
/* to hold AES context information. This AES code uses cx->inf.b[0]  */
/* to hold the number of rounds multiplied by 16. The other elements */
/* (1 & 2) can be used by code that implements additional modes.     */
typedef union
{   
    uint32 l; uint8 b[4];
} AES_INF;

typedef struct
{   
    uint32 key[AES_KS_LENGTH]; AES_INF inf; 

} AES_CRYPTO_CTX;

#define DIM_REM_AES sizeof(AES_CRYPTO_CTX)

#endif // AES_DEFS_H